# Filled fictional application

ReturnLoop Demo B.V. is wholly fictional. This pack supplies every official project-plan narrative section, labelled company/project statements and a proposed EUR 60,000 budget. It contains no actual registration identifier, signature, bank evidence, customer research, certification, successful pilot or grant award.

`source.json` is the editable authoring source. Run `uv run scripts/build_filled_example.py` to regenerate `company_and_application.docx` and `project_budget.txt`. The app reads only the DOCX/TXT bytes through its ordinary parsers, not this JSON source. Ordinary uploads of these files still require confirmation. The explicit **Open filled example** action simulates confirmation of fictional statements in a separate workspace, then uses the normal rule, calculation and drafting services.

The example uses the labelled 15 June 2026 historical context. The filled narrative and proposed budget are reviewable; legal, policy, documentary and actual submission requirements remain unresolved. This pack is independent of `operator_only` and is not an accepted application or model output.
