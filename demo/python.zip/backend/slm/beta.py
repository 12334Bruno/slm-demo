"""A server-owned beta waiting list, independent of demo workspaces."""
import re
from fastapi import FastAPI
from pydantic import BaseModel, Field
from .config import now


class BetaSignup(BaseModel):
    email: str = Field(min_length=3, max_length=254)


def normalize_email(value: str) -> str:
    value = value.strip()
    if value.count("@") != 1:
        raise ValueError("Enter a valid email address.")
    local, domain = value.rsplit("@", 1)
    try:
        domain = domain.encode("idna").decode("ascii").lower()
    except UnicodeError:
        raise ValueError("Enter a valid email address.") from None
    if (not re.fullmatch(r"[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]{1,64}", local)
            or local.startswith(".") or local.endswith(".") or ".." in local
            or "." not in domain or len(domain) > 253
            or any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
                   for label in domain.split("."))):
        raise ValueError("Enter a valid email address.")
    normalized = f"{local.lower()}@{domain}"
    if len(normalized) > 254:
        raise ValueError("Enter a valid email address.")
    return normalized


def register(app: FastAPI, store):
    with store.connect() as connection:
        connection.execute("""CREATE TABLE IF NOT EXISTS beta_signups (
            email TEXT PRIMARY KEY, created_at TEXT NOT NULL)""")

    @app.post("/api/beta-signups", status_code=201)
    def signup(body: BetaSignup):
        email = normalize_email(body.email)
        with store.connect() as connection:
            connection.execute("INSERT INTO beta_signups (email, created_at) VALUES (?, ?) "
                               "ON CONFLICT(email) DO NOTHING", (email, now()))
        # The same reply for first and repeat requests avoids disclosing membership.
        return {"registered": True}
