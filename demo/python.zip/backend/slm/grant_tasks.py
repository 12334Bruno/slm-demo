"""A task view of immutable source specifications; original passages stay available.

General annexes are reviewed in source groups, never promoted into hundreds of
independent eligibility declarations. Structured rules and source conflicts always
retain their individual outcomes. Each application item has exactly one way to be
completed: write it here, upload a file, do it on the funder's website, or answer
whether a condition applies.
"""
import hashlib
import json
import re
from copy import deepcopy

ACTIONABLE = {"eligibility", "financial", "attachment", "reference"}


def normalise(text):
    return re.sub(r"\W+", " ", text.casefold()).strip()


def requirement_tasks(spec):
    conflicts = {rid for c in spec.get("conflicts", []) for rid in c["requirement_ids"]}
    tasks, groups, seen = [], {}, {}
    sources = {s["url"]: s for s in spec.get("sources", [])}
    for original in spec.get("requirements", []):
        req = deepcopy(original)
        if req.get("category") not in ACTIONABLE:
            continue  # Context (assessment, info) is shown with the grant, never as a check.
        proof = req.get("evidence") or {}
        key = (req.get("category"), normalise(req.get("text", req.get("label", ""))),
               json.dumps(req.get("rule"), sort_keys=True))
        if key in seen and req["id"] not in conflicts:
            seen[key].setdefault("supporting_evidence", []).append(proof)
            continue
        seen[key] = req
        scope = req.get("scope", "call")
        if scope in {"annex", "guidance", "template"} and not req.get("rule") and req["id"] not in conflicts:
            url = proof.get("url", "")
            source = sources.get(url, {})
            group_key = (scope, url)
            if group_key not in groups:
                ident = "source-review-" + hashlib.sha256((scope + url).encode()).hexdigest()[:16]
                fallback = {"annex": "Programme rules", "guidance": "Application guidance", "template": "Official form instructions"}[scope]
                title = source.get("title") or fallback
                if title.startswith("http") or len(title) < 4:
                    title = fallback
                groups[group_key] = {"id": ident, "category": "reference", "label": "General rules: " + title,
                    "text": "General programme provisions. Most apply to every call in the programme; read them before submitting.",
                    "rule": None, "scope": scope, "conditional": True, "review_required": True,
                    "evidence": proof, "members": []}
            groups[group_key]["members"].append(req)
        else:
            tasks.append(req)
    for group in groups.values():
        group["passage_count"] = len(group["members"])
        group["content_hash"] = hashlib.sha256(json.dumps(group["members"], sort_keys=True).encode()).hexdigest()
        tasks.append(group)
    return tasks


def source_scope(spec, item):
    req = next((r for r in spec.get("requirements", []) if r["id"] == item["id"]), None)
    if req:
        return req.get("scope", "call")
    url = (item.get("evidence") or {}).get("url")
    return next((s.get("role", "call") for s in spec.get("sources", []) if s["url"] == url), "call")


DOCUMENT_NAMES = [
    (r"financial (?:statement|report)", "Financial statement"),
    (r"financing (?:statement|report)|financieringsverklaring", "Financing statement"),
    (r"financieringsplan|financing plan|financial plan", "Financing plan"),
    (r"annual (?:accounts|report)|jaarrekening|openingsbalans", "Annual accounts"),
    (r"consortium agreement|samenwerkingsovereenkomst", "Consortium agreement"),
    (r"participation sheet|participant sheet|participation form|deelnemersformulier", "Participation sheet"),
    (r"letters? of (?:support|intent|commitment)|support(?:ing)? letters?|intentieverklaring|steunbrief", "Letter of support"),
    (r"liquiditeitsbegroting|cash ?flow", "Cash-flow forecast"),
    (r"detailed budget table|budget (?:spreadsheet|breakdown|table)|projectbegroting|\bbegroting\b", "Budget table"),
    (r"kvk-?uittreksel|registration (?:extract|document)|uittreksel", "Company registration extract (KVK)"),
    (r"ubo", "UBO declaration"),
    (r"de minimis", "De minimis declaration"),
    (r"business ?plan|ondernemingsplan", "Business plan"),
    (r"project ?plan|projectplan", "Project plan"),
    (r"part b|technical description", "Part B — technical description (PDF)"),
    (r"curriculum vitae|\bCVs?\b", "Team CVs"),
    (r"offertes?|quotations?", "Supplier quotations"),
    (r"machtiging", "Authorisation form (machtiging)"),
    (r"ethics self-assessment|ethics (?:statement|approval)", "Ethics self-assessment"),
    (r"data management plan", "Data management plan"),
    (r"statuten|articles of association", "Articles of association"),
]
NARRATIVE_DOCUMENTS = re.compile(r"(?i)project ?plan|projectplan|business ?plan|ondernemingsplan|part b|technical description|"
                                 r"projectbeschrijving|project description|motivat")


def document_title(item):
    text = (item.get("evidence") or {}).get("quote") or item.get("title", "")
    title = item.get("title", text)
    for pattern, label in DOCUMENT_NAMES:
        if re.search(pattern, title if len(title) <= 80 else text, re.I):
            return label
    if len(title) <= 90:
        return title.rstrip(".:")
    from .grant_structure import short_label
    return short_label(title, 90)


def later_stage(text):
    from .grant_structure import LATER_STAGE
    return bool(LATER_STAGE.search(text))


# Usual steps on each funder's website. These describe the funder's standard procedure,
# never this applicant's eligibility, and are labelled as such in the interface.
PROVIDER_STEPS = {
    "eu": [
        ("step-eu-pic", "Register your organisation and get a PIC",
         "Your organisation needs a Participant Identification Code (PIC) in the EU Funding & Tenders Portal before a proposal can be submitted. "
         "Check whether your company already has one."),
        ("step-eu-part-a", "Create the proposal and fill in Part A online",
         "Part A (administrative forms: participants, budget table, ethics and security questions) is completed online in the Submission System."),
        ("step-eu-upload", "Upload Part B and any annexes as PDF",
         "Part B is the narrative you prepare from your answers here. Download the official Part B template from the Submission System, "
         "copy your answers into it and upload it as a PDF together with any required annexes."),
        ("step-eu-submit", "Submit before the deadline",
         "Submit in the Funding & Tenders Portal before the deadline shown on the topic page. You can resubmit until the deadline."),
    ],
    "rvo": [
        ("step-rvo-eherkenning", "Arrange eHerkenning for your company",
         "You log in to Mijn RVO with eHerkenning. Check the required level on the scheme page and arrange it early; it can take several days."),
        ("step-rvo-form", "Fill in the application form in Mijn RVO",
         "Complete RVO's online application form and attach the documents prepared in this application."),
        ("step-rvo-submit", "Submit before the deadline",
         "Submit through Mijn RVO before the closing date. Some schemes are first come, first served, so earlier is better."),
    ],
    "zh": [
        ("step-zh-eherkenning", "Arrange eHerkenning for your company",
         "The Province of South Holland's subsidy portal uses eHerkenning. Arrange it early; it can take several working days."),
        ("step-zh-form", "Fill in the online form in the provincial subsidy portal",
         "Use the copy sheet below: it lists the portal's fields in order with the values prepared in this application."),
        ("step-zh-attach", "Attach the project plan in the official format",
         "Upload the project plan written in the province's mandatory format. Applications cannot be supplemented after submission."),
        ("step-zh-submit", "Submit before the deadline", "Submit in the portal during the application period. When the budget is oversubscribed the province may decide by lottery."),
    ],
    "snn": [
        ("step-snn-eherkenning", "Arrange eHerkenning for your company",
         "SNN's online application portal uses eHerkenning. Arrange it early; it can take several days."),
        ("step-snn-form", "Fill in SNN's online application form",
         "Complete the application form in SNN's portal and attach the documents prepared in this application."),
        ("step-snn-submit", "Submit before the deadline", "Submit through SNN's portal before the closing date."),
    ],
}
GENERIC_STEPS = [
    ("step-generic-form", "Fill in the funder's application form",
     "Copy your answers into the funder's form and attach the documents prepared here."),
    ("step-generic-submit", "Submit before the deadline", "Submit through the funder's website before the closing date."),
]


def provider_steps(spec):
    provider = spec.get("provider") or str(spec.get("opportunity_id", "")).split("-")[0]
    steps = PROVIDER_STEPS.get(provider, GENERIC_STEPS)
    return [{"id": ident, "title": title, "instruction": text, "origin": "usual_procedure"} for ident, title, text in steps]
