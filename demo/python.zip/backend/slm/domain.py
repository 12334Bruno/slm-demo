"""Typed boundaries shared by extraction, intake and user corrections."""
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator
from .config import CORE_PATHS, FORM

BOOL_PATHS = {
    "company.sme_self_declared", "company.vat_recoverable", "company.dutch_wage_or_income_tax",
    "project.prepares_later_development", "project.one_off", "project.routine_operations",
    "project.same_activities_other_public_funding", "project.future_own_technical_rd",
}
INT_PATHS = {"company.annual_turnover_cents", "company.balance_sheet_total_cents", "project.independent_sme_participant_count"}
DATE_PATHS = {"project.start_date", "project.end_date", "project.award_date"}
ACTIVITIES = {"feasibility_study", "industrial_research", "experimental_development", "combined_research_development", "other"}
ALL_PATHS = set(CORE_PATHS) | {"company.activities", "project.award_date", "project.framework_category", "finance.external_funding_status"} | {f"narrative.{s['id']}" for s in FORM["sections"]}


def validate_value(path, value):
    if path not in ALL_PATHS:
        raise ValueError(f"Unsupported field: {path}")
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    if path in BOOL_PATHS:
        if not isinstance(value, bool):
            raise ValueError(f"{path} must be true, false or null")
    elif path in INT_PATHS:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{path} must be a nonnegative integer")
    elif path == "company.fte":
        if isinstance(value, bool):
            raise ValueError("FTE must be a nonnegative number")
        value = float(value)
        if not Decimal(str(value)).is_finite() or value < 0:
            raise ValueError("FTE must be a finite nonnegative number")
    elif path in DATE_PATHS:
        value = date.fromisoformat(str(value)).isoformat()
    elif path == "project.primary_activity":
        if value not in ACTIVITIES:
            raise ValueError("Choose a supported project activity")
    else:
        if not isinstance(value, str) or len(value) > 12000:
            raise ValueError(f"{path} must be text of at most 12,000 characters")
        value = value.strip()
    return value


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class BudgetLine(Strict):
    id: str = Field(min_length=1, max_length=80)
    activity: str = Field(min_length=1, max_length=1000)
    activity_group: Literal["feasibility_study", "related_research", "other"]
    cost_type: Literal["internal_personnel", "external_service", "materials", "equipment", "buildings", "other"]
    quantity: str
    unit: Literal["hours", "item"]
    rate_cents: int = Field(ge=0, le=100_000_000_000, strict=True)
    eligibility_review: Literal["proposed", "reviewed", "excluded", "unknown"] = "proposed"
    evidence: list[dict] = Field(default_factory=list)
    confirmed: bool = False
    state: str = "proposed"

    @field_validator("quantity")
    @classmethod
    def quantity_valid(cls, value):
        try:
            q = Decimal(value)
            if not q.is_finite() or q < 0 or q > 1_000_000_000:
                raise ValueError("Quantity must be a finite nonnegative number")
        except InvalidOperation:
            raise ValueError("Invalid quantity")
        return str(q)


class FundingSource(Strict):
    id: str = Field(min_length=1, max_length=80)
    kind: Literal["own_cash", "private_loan", "other_private", "other_public", "other", "unknown"]
    amount_cents: int = Field(ge=0, le=100_000_000_000, strict=True)
    status: Literal["proposed", "committed", "unknown"]
    evidence: list[dict] = Field(default_factory=list)
    founder_confirmed: bool = False
    note: str = Field(default="", max_length=3000)
    state: str = "proposed"


class FactChange(Strict):
    path: str
    value: str | bool | int | float | None
    note: str = Field(default="Founder correction / confirmation", max_length=3000)


class ProfilePatch(Strict):
    changes: list[FactChange] = Field(default_factory=list)
    confirm_paths: list[str] = Field(default_factory=list)
    confirm_budget: bool = False
    confirm_funding: bool = False
    expected_revision: int


class BudgetPatch(Strict):
    lines: list[BudgetLine]
    project_revenues_cents: int | None = Field(default=None, ge=0, strict=True)
    other_project_costs_cents: int | None = Field(default=None, ge=0, strict=True)
    requested_grant_cents: int | None = Field(default=None, ge=0, strict=True)
    expected_revision: int


class FundingPatch(Strict):
    sources: list[FundingSource]
    expected_revision: int


class ContextChange(Strict):
    mode: Literal["current", "historical_rules_demo"]


class ExtractionRequest(Strict):
    mode: Literal["basic", "model"] = "basic"


class DraftRequest(Strict):
    grant_id: str = "ZH_MIT_FEASIBILITY_2026"
    mode: Literal["basic", "model"] = "basic"
    regenerate_sections: list[str] = Field(default_factory=list)
    expected_revision: int


class DraftEdit(Strict):
    sections: dict[str, str]
    expected_draft_revision: int


class LinkLetter(Strict):
    letter_id: str
    funding_source_id: str
    expected_revision: int
