from .config import QUESTIONS, FORM
from .profiles import fact_value
from .budget import euro

QUESTION_MAP = {q["id"]: q for q in QUESTIONS}


def missing_questions(ws, evaluation, grant_id):
    grant = next((g for g in evaluation["grants"] if g["id"] == grant_id), None)
    if grant is None:
        raise ValueError("Unknown grant")
    result, seen = [], set()

    def add(question, group, priority):
        path = question["field"]
        if path in seen or (path in ws["facts"] and ws["facts"][path]["state"] == "confirmed"):
            return
        seen.add(path)
        result.append({**question, "group": group, "priority": priority,
                       "state": ws["facts"].get(path, {}).get("state", "missing"),
                       "current_value": fact_value(ws, path)})

    for check in grant["checks"]:
        for path in check["field_paths"]:
            if path == "budget":
                continue
            q = QUESTION_MAP.get(check.get("question_id"))
            add(q or {"id": f"FIELD_{path}", "field": path, "question": f"Confirm {path.replace('.', ' ').replace('_', ' ')}.",
                      "input_type": "date" if path.endswith("_date") else "text", "reason": check["label"]}, "Eligibility facts", 1)
    if grant["support_level"] == "worked_application":
        for qid in ["Q_OWNERSHIP", "Q_FINANCIAL_STATUS", "Q_FRAMEWORK", "Q_VAT", "Q_PRIOR_MIT"]:
            add(QUESTION_MAP[qid], "Declarations and review", 2)
        add({"id": "Q_FRAMEWORK_CATEGORY", "field": "project.framework_category", "input_type": "text",
             "question": "What is the proposed KIA number and official title?",
             "reason": "Fills the variable KIA heading in the official template. Your selection still requires formal policy review."}, "Declarations and review", 2)
        budget = evaluation["budget"]
        if budget["unconfirmed_financing_cents"] is None or budget["unconfirmed_financing_cents"] > 0:
            q = {**QUESTION_MAP["Q_FINANCING"], "question": f"How will you cover the {euro(budget['unconfirmed_financing_cents'])} still unconfirmed in this funding plan?",
                 "reason": "Save financing sources and link any commitment document in the Budget step. A text explanation alone does not mark money committed."}
            add(q, "Financing and evidence", 3)
        for section in FORM["sections"]:
            # Structured sections are populated from confirmed facts/budget; narrative gaps are specific to this application.
            if section["id"] in {"company", "partners", "policy_framework", "policy_framework_category", "provincial_relevance", "budget_explanation", "financing_explanation", "previous_mit"}:
                continue
            path = f"narrative.{section['id']}"
            if section["id"] == "innovation_description" and fact_value(ws, "project.description", True):
                continue
            add({"id": f"SECTION_{section['id']}", "field": path, "question": section["expected_heading"], "input_type": "text",
                 "reason": "Official project-plan section. Give only facts, plans and evidence you can support; planned results must stay planned."}, "Application answers", 4)
    return sorted(result, key=lambda q: (q["priority"], q["id"]))
