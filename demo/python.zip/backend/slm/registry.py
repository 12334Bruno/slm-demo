"""Optional KVK (Dutch Chamber of Commerce) registry enrichment.

With KVK_API_KEY set on the server, requests go to `api.kvk.nl` (full profile
and name search). Without a key, a lookup by KVK number uses the free open
dataset at `opendata.kvk.nl` instead (see `fetch_open_record`). Requests go
through the SSRF-safe fetcher to these two allowlisted hosts. Results are
PROPOSALS with registry evidence: nothing here confirms a fact.

The adapter targets the KVK Handelsregister APIs documented at
https://developers.kvk.nl (Basisprofiel by KVK number, Zoeken by name). It has
been exercised only against mocked responses, not the live service. The free
open dataset carries neither names nor addresses, so it can only describe a
KVK number the founder already gave (BV/NV only, one request per minute per
IP address). It has been written from the published OpenAPI spec and was not
reachable from the development machine, so it is untested against the live service.
"""
import json
import os
import re
import threading
from datetime import date
from urllib.parse import quote, urlencode
from .safe_http import FetchError, SafeFetcher

HOST = "api.kvk.nl"
OPEN_HOST = "opendata.kvk.nl"
SOURCE = "KVK Handelsregister"
OPEN_SOURCE = "KVK open dataset"
NOT_CONFIGURED = "The KVK registry is not configured on this server."
OPEN_NEEDS_KVK = "The free KVK register can only check a KVK number. Enter the 8-digit number."
LEGAL_FORMS = {"BV": "B.V.", "NV": "N.V."}
INSOLVENCY = {"FAIL": "bankruptcy", "SSAN": "debt restructuring", "SURS": "suspension of payments"}
JSON_TYPES = ("application/json", "application/hal+json", "application/problem+json")
_usage = {"day": None, "count": 0}
_lock = threading.Lock()


class RegistryError(Exception):
    """A registry problem whose message may be shown to the founder."""


def configured():
    return bool(os.getenv("KVK_API_KEY", "").strip())


def base_url():
    return "https://" + HOST + ("/test" if os.getenv("KVK_API_ENV") == "test" else "")


def daily_limit():
    try:
        return max(1, int(os.getenv("SLM_REGISTRY_DAILY_LOOKUPS", "100")))
    except ValueError:
        return 100


def reserve():
    """Count one lookup against the server-wide daily allowance (the key belongs to the operator)."""
    with _lock:
        today = date.today().isoformat()
        if _usage["day"] != today:
            _usage.update(day=today, count=0)
        if _usage["count"] >= daily_limit():
            raise RegistryError("The registry lookup allowance for today has been used. Please try again tomorrow.")
        _usage["count"] += 1


def fetcher(transport=None, resolver=None):
    return SafeFetcher(transport=transport, resolver=resolver, https_only=True, allowed_hosts={HOST, OPEN_HOST}, max_response_bytes=300_000,
                       max_total_bytes=1_000_000, deadline_seconds=20.0, request_timeout=8.0, max_redirects=1, max_requests=3)


def key_headers():
    if not configured():
        raise RegistryError(NOT_CONFIGURED)
    return {"apikey": os.environ["KVK_API_KEY"].strip(), "Accept": "application/json"}


def get_json(client, url, headers):
    try:
        fetched = client.get(url, accept=JSON_TYPES, headers=headers)
        data = json.loads(fetched.body)
    except FetchError as exc:
        if exc.status in (401, 403):
            raise RegistryError("The registry rejected this server's access. The operator needs to check the registry key.") from None
        if exc.status == 404:
            raise RegistryError("No registry entry was found.") from None
        if exc.status == 429:
            raise RegistryError("The registry is limiting requests right now. Please try again shortly.") from None
        raise RegistryError("The registry could not be reached: " + str(exc)) from None
    except ValueError:
        raise RegistryError("The registry returned an unreadable answer.") from None
    if not isinstance(data, dict):
        raise RegistryError("The registry returned an unexpected answer.")
    return data, fetched.url


def kvk_digits(value):
    digits = re.sub(r"\D", "", str(value or ""))
    if len(digits) != 8:
        raise RegistryError("A KVK number has exactly 8 digits.")
    return digits


def text(value):
    return " ".join(str(value).split())[:300] if isinstance(value, (str, int)) and str(value).strip() else ""


def address_text(address):
    street = " ".join(p for p in (text(address.get("straatnaam")), text(address.get("huisnummer")), text(address.get("huisletter"))) if p)
    place = " ".join(p for p in (text(address.get("postcode")), text(address.get("plaats"))) if p)
    return ", ".join(p for p in (street, place) if p)


def search_by_name(name, client):
    """Candidate registrations for a name: [{kvk_number, name, city, type, active}]. Proposes nothing."""
    name = " ".join(str(name or "").split())
    if len(name) < 2:
        raise RegistryError("Enter at least two characters of the company name.")
    query = urlencode([("naam", name[:100]), ("type", "hoofdvestiging"), ("type", "rechtspersoon"), ("resultatenPerPagina", 5)])
    data, _ = get_json(client, f"{base_url()}/api/v2/zoeken?{query}", key_headers())
    found = []
    for item in (data.get("resultaten") or [])[:5]:
        if not isinstance(item, dict) or not re.fullmatch(r"\d{8}", str(item.get("kvkNummer", ""))):
            continue
        address = (item.get("adres") or {}).get("binnenlandsAdres") or {}
        active = item.get("actief")
        found.append({"kvk_number": str(item["kvkNummer"]), "name": text(item.get("naam")), "city": text(address.get("plaats")),
                      "type": text(item.get("type")), "active": None if active is None else str(active).lower() in {"ja", "j", "true", "yes"}})
    return found


def fetch_profile(kvk_number, client):
    """The official basic profile for one KVK number, normalised. Raises RegistryError."""
    kvk = kvk_digits(kvk_number)
    data, url = get_json(client, f"{base_url()}/api/v1/basisprofielen/{quote(kvk)}", key_headers())
    returned = text(data.get("kvkNummer"))
    if returned and returned != kvk:
        raise RegistryError("The registry answered for a different KVK number and the result was discarded.")
    embedded = data.get("_embedded") or {}
    owner = embedded.get("eigenaar") or {}
    main = embedded.get("hoofdvestiging") or {}
    addresses = [a for a in (main.get("adressen") or []) if isinstance(a, dict)]
    address = next((a for a in addresses if a.get("type") == "bezoekadres"), addresses[0] if addresses else {})
    name = text(data.get("statutaireNaam")) or text(data.get("naam"))
    if not name:
        raise RegistryError("The registry record has no company name.")
    registration = data.get("materieleRegistratie") or {}
    ended = text(registration.get("datumEinde"))
    return {"kvk_number": kvk, "name": name, "trade_names": [text(h.get("naam")) for h in (data.get("handelsnamen") or []) if isinstance(h, dict) and text(h.get("naam"))][:5],
            "legal_form": text(owner.get("uitgebreideRechtsvorm")) or text(owner.get("rechtsvorm")),
            "address": address_text(address) if address else "", "city": text(address.get("plaats")) if address else "",
            "country": "Netherlands" if address and text(address.get("land") or "Nederland").lower() in {"nederland", "netherlands"} else "",
            "registered_since": text(registration.get("datumAanvang") or data.get("formeleRegistratiedatum")),
            "status": "Deregistered since " + ended if ended else "Registered (no end date reported)",
            "source_url": url}


def proposal_rows(record, rows, filename):
    """[{label, value, path|None, evidence}] for the (label, key, path) rows that have a value. Never confirmed."""
    def ref(field, value):
        return {"document_id": None, "block_id": None, "filename": filename, "source_type": "registry",
                "locator": f"KVK registry {record['kvk_number']}, {field}", "quote": str(value), "source_url": record["source_url"],
                "note": "Official registry record; a proposal until you confirm it"}
    return [{"label": label, "value": record[key], "path": path, "evidence": ref(key, record[key])}
            for label, key, path in rows if record.get(key)]


def proposals(record):
    """Full registry profile as proposals."""
    return proposal_rows(record, [("Official name", "name", "company.name"), ("KVK number", "kvk_number", "company.registration_number"),
                                  ("Legal form", "legal_form", "company.legal_form"), ("Registered city", "city", "company.city"),
                                  ("Country", "country", "company.country"), ("Visiting address", "address", None),
                                  ("Registration status", "status", None), ("Registered since", "registered_since", None)],
                         SOURCE + " (Basisprofiel)")


def start_date(value):
    """ISO date from the open dataset's YYYYMMDD; a date containing zeros means unknown, so it gives ''."""
    value = text(value)
    year, month, day = value[:4], value[4:6], value[6:8]
    if not re.fullmatch(r"\d{8}", value) or int(year) == 0 or int(month) == 0 or int(day) == 0:
        return ""
    return f"{year}-{month}-{day}"


def fetch_open_record(kvk_number, client):
    """Free open-dataset facts for one KVK number (BV/NV only), normalised. Raises RegistryError."""
    kvk = kvk_digits(kvk_number)
    data, url = get_json(client, f"https://{OPEN_HOST}/api/v1/hvds/basisbedrijfsgegevens/kvknummer/{quote(kvk)}", {"Accept": "application/json"})
    active, form = text(data.get("actief")), text(data.get("rechtsvormCode"))
    if active not in ("J", "N") or not form:
        raise RegistryError("The free KVK register returned an answer without the active flag or legal form.")
    insolvency = INSOLVENCY.get(text(data.get("insolventieCode")), "")
    activities = [a for a in (data.get("activiteiten") or []) if isinstance(a, dict) and text(a.get("sbiCode"))]
    region = text(data.get("postcodeRegio"))
    return {"kvk_number": kvk, "legal_form": LEGAL_FORMS.get(form, form),
            "country": "Netherlands" if text(data.get("lidstaat")) == "NL" else "",
            "status": ("Active" if active == "J" else "Not active") + (f"; insolvency: {insolvency}" if insolvency else ""),
            "registered_since": start_date(data.get("datumAanvang")),
            "postcode_region": f"Postcode starts with {region.zfill(2)}" if region else "",
            "activities": "; ".join(f"SBI {text(a['sbiCode'])} ({'main' if text(a.get('soortActiviteit')) == 'Hoofdactiviteit' else 'other'})" for a in activities[:10]),
            "source_url": url}


def open_proposals(record):
    """Open-dataset facts as proposals. It has no name or address, so only a few fields can fill the profile."""
    return proposal_rows(record, [("Legal form", "legal_form", "company.legal_form"), ("Country", "country", "company.country"),
                                  ("Registration status", "status", None), ("Active since", "registered_since", None),
                                  ("Postcode area", "postcode_region", None), ("Activity codes", "activities", None)],
                         OPEN_SOURCE)
