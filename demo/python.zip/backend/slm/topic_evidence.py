"""Why a grant fits a project: a sentence of the grant's own text next to a sentence of the project.

A keyword list does not convince anyone. This module looks for the sentence in the grant text that
covers the most of the project's distinctive concepts, and the sentence in the project that says the same.
Dutch and English words for the same thing (waterstof / hydrogen) count as one concept. The level says
how much evidence there is, so a grant that merely was not excluded is never presented as a match.
"""
import math
import re
from typing import Literal, TypedDict

from .retrieval import GENERIC, SYNONYM_INDEX, TRANSLATION_INDEX, Prepared, stem, words

Level = Literal["strong", "partial", "weak", "none"]
QUOTE_LIMIT = 300
# Words that describe the team, the plan or everyday actions, not the subject of the project.
IGNORED = {stem(w) for w in ("save saving improve reduce increase support enable provide help test use make monitor monitoring "
                             "people person team employees founder founders member members startup startups scaleup company "
                             "sme smes small medium").split()}
LOOK_ALIKES = re.compile(r"(?i)\bgreenhouse\s+(?:gas|gases|emissions?|effect)\b")  # "greenhouse gas" is not horticulture
RELATED = 0.6  # A related word (recycled for circular) counts less than the word itself or its translation.
# Points: a concept is worth 0 (in every call) to 1 (in almost none), a common concept half, a related word 60%.
STRONG_POINTS, PARTIAL_POINTS, CONFIRMED_POINTS = 1.35, 0.83, 0.68


class Quote(TypedDict):
    text: str
    words: list[str]
    locator: str | None
    block_id: str | None


class Pair(TypedDict):
    project: str
    grant: str


class TopicEvidence(TypedDict):
    level: Level
    points: float
    pairs: list[Pair]
    grant: Quote | None
    project: Quote | None
    title_words: list[str]


def concept_key(term):
    """One key for a word and its translations."""
    return min(TRANSLATION_INDEX.get(term, {term}) | {term})


def project_concepts(prepared: Prepared):
    """Concept key -> {weight, specific, word}; plus a lookup from any word stem to (concept key, how close it is)."""
    from .matching_depth import GENERIC_WORDS  # Broad sectors (software, manufacturing) name a field, not a project's subject.
    generic = {stem(w) for w in GENERIC | GENERIC_WORDS} | IGNORED
    concepts, lookup, related = {}, {}, {}
    for term, count in prepared.query.items():
        if term in generic or term not in prepared.subjects or not prepared.concept_df[term]:
            continue  # Everyday words, and concepts no call mentions in either language, carry no evidence.
        key = concept_key(term)
        weight = math.log(1 + prepared.size / (1 + prepared.concept_df[term])) / math.log(1 + prepared.size)
        specific = prepared.concept_df[term] / prepared.size < (0.1 if prepared.size >= 50 else 1.01)
        known = concepts.get(key)
        if known is None:
            concepts[key] = {"weight": weight, "specific": specific, "word": prepared.readable.get(term, term), "count": count}
        else:  # The rarest word of the concept sets its weight; the most repeated one is the word shown.
            known.update(weight=max(known["weight"], weight), specific=known["specific"] or specific)
            if count > known["count"]:
                known.update(word=prepared.readable.get(term, term), count=count)
        for member in TRANSLATION_INDEX.get(term, set()) | {term}:
            lookup[member] = (key, 1.0)
        for member in SYNONYM_INDEX.get(term, set()):
            related.setdefault(member, (key, RELATED))
    for member, entry in related.items():
        lookup.setdefault(member, entry)
    return concepts, lookup


def hits(text, lookup):
    """Concept key -> {"words": the words of this text that express it, "factor": 1 for the word itself, less if only related}."""
    found = {}
    for word in words(LOOK_ALIKES.sub(" ", text)):
        entry = lookup.get(stem(word))
        if entry is None:
            continue
        key, factor = entry
        known = found.setdefault(key, {"words": [], "factor": factor})
        known["factor"] = max(known["factor"], factor)
        if word not in known["words"]:
            known["words"].append(word)
    return found


def sentences_of(text):
    parts = []
    for part in re.split(r"(?<=[.!?;])\s+|\n+", text or ""):
        part = " ".join(part.split())
        if len(part) >= 20:
            parts.append(part)
    return parts


def fitted(text, highlighted):
    """A quote of at most QUOTE_LIMIT characters, cut at word boundaries around the highlighted words."""
    if len(text) <= QUOTE_LIMIT:
        return text
    anchor = min((text.casefold().find(w.casefold()) for w in highlighted if w.casefold() in text.casefold()), default=0)
    start = max(0, anchor - QUOTE_LIMIT // 3)
    if start:
        start = text.find(" ", start) + 1 or start
    end = min(len(text), start + QUOTE_LIMIT)
    if end < len(text):
        end = text.rfind(" ", start, end) if " " in text[start:end] else end
    return ("… " if start else "") + text[start:end].strip() + (" …" if end < len(text) else "")


def points_of(found, concepts):
    return sum(concepts[k]["weight"] * (1.0 if concepts[k]["specific"] else 0.5) * v["factor"] for k, v in found.items())


def topic_evidence(prepared: Prepared, title, sources, project_text) -> TopicEvidence:
    """The best grant sentence and the project sentence that says the same, with an honest level."""
    concepts, lookup = project_concepts(prepared)
    best, best_key = None, (0, 0.0)
    for source in sources:
        found = hits(source["text"], lookup)
        if found and any(concepts[k]["specific"] or v["factor"] == 1.0 for k, v in found.items()):
            key = (len(found), points_of(found, concepts))
            if key > best_key:
                best, best_key = (source, found), key
    title_hits = hits(title, lookup)
    anywhere = set(title_hits)
    for source in sources:
        anywhere |= set(hits(source["text"], lookup))
    sentence_hits = best[1] if best else {}
    union = {k: max((h[k] for h in (sentence_hits, title_hits) if k in h), key=lambda v: v["factor"]) for k in set(sentence_hits) | set(title_hits)}
    points = points_of(union, concepts)
    in_both = set(title_hits) & set(sentence_hits)
    confirmed = any(concepts[k]["specific"] and title_hits[k]["factor"] == 1.0 for k in in_both)

    def exact(found):
        return {k for k, v in found.items() if v["factor"] == 1.0}  # The project's own word or its translation.

    exact_union, exact_title, exact_sentence = exact(union), exact(title_hits), exact(sentence_hits)
    if ((points >= STRONG_POINTS and len(exact_union) >= 2) or (len(exact_title) >= 2 and len(exact_sentence) >= 2)
            or (len(title_hits) >= 2 and len(sentence_hits) >= 2 and exact_title and exact_sentence)
            or (confirmed and points >= CONFIRMED_POINTS)):
        level = "strong"
    elif (len(title_hits) >= 2 and exact_title) or (points >= PARTIAL_POINTS and len(exact_union) >= 2):
        level = "partial"
    elif anywhere:
        level = "weak"
    else:
        level = "none"
    matched = set(union)
    # The project's own sentence that covers the same concepts.
    project, project_key = None, (0, 0.0, 0)
    for sentence in sentences_of(project_text)[:600]:
        found = hits(sentence, lookup)
        overlap = [k for k in found if k in matched] or ([] if matched else list(found))
        key = (len(overlap), sum(concepts[k]["weight"] for k in overlap), -len(sentence))
        if overlap and key > project_key:
            project, project_key = (sentence, found, overlap), key
    pairs = []
    for key in sorted(matched, key=lambda k: -concepts[k]["weight"])[:4]:
        grant_words = (sentence_hits.get(key) or title_hits.get(key) or {}).get("words")
        if grant_words:
            pairs.append({"project": concepts[key]["word"], "grant": grant_words[0]})
    grant_quote, project_quote = None, None
    if best:
        highlighted = [w for v in best[1].values() for w in v["words"]]
        grant_quote = {"text": fitted(best[0]["text"], highlighted), "words": highlighted, "locator": best[0].get("locator"),
                       "block_id": best[0].get("block_id")}
    if project:
        highlighted = [w for k in project[2] for w in project[1][k]["words"]]
        project_quote = {"text": fitted(project[0], highlighted), "words": highlighted, "locator": None, "block_id": None}
    return {"level": level, "points": round(points, 2), "pairs": pairs, "grant": grant_quote, "project": project_quote,
            "title_words": [w for v in title_hits.values() for w in v["words"]]}
