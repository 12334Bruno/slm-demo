"""Resumable live discovery and automatic company-driven investigation."""
import json
import hashlib
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from uuid import uuid4
from .config import now
from .discovery_store import DiscoveryStore
from .grant_providers import PublicClient, index_page, detail, fingerprint
from .funding_conditions import basic_requirements, schedule
from .live_matching import retrieve, profile_text, match_records, public_record, interpret_with_model
from .live_matching import concepts, CONCEPTS
from .matching_depth import evaluation_key, profile_match_key, result_ids
from .model_adapter import configured, model_profile
from .grant_documents import DocumentStore, collect_bundle, parse_public_document
from .grant_specification import SpecificationStore, build_specification, SPEC_VERSION
from .official_sources import authority, canonical_url, FUNDING_PROVIDERS, funding_page
from urllib.parse import urlparse, unquote

# AI fit checks run for the top of the recommended list only, so the list is final within a few minutes on a free AI plan.
FIT_CHECKS_PER_LIST = 8
# A check the AI answered unusably (unverifiable quotes, broken output) is not retried by itself: retrying the same text
# rarely helps and kept the list "still being checked" for many minutes. "Refresh matches" tries it again.
RETRY_ON_REFRESH = {"invalid_output", "unsupported_evidence", "incomplete_output", "refused", "request_rejected"}


class DiscoveryService:
    def __init__(self, store, transport=None, enabled=True, clock=None):
        self.db = DiscoveryStore(store)
        self.documents = DocumentStore(store)
        self.specifications = SpecificationStore(store)
        self.transport, self.enabled = transport, enabled
        self.clock = clock
        self.owner = uuid4().hex
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.active = set()
        self.pending = set()
        self.pool = None
        self.scheduler = None
        self.evaluations = 0
        self.cache_hits = 0
        self.scenario_runs = 0
        self.fit_pending = set()
        self.fit_retry_after = {}
        # When the AI plan's daily allowance is used up, no fit check can succeed until it frees up (one key, so all companies).
        self.fit_paused_until = 0.0
        self.fit_locks = {}
        self.semantic_pending = set()

    def start(self):
        try:
            from .focus_grants import install_focus
            install_focus(self)
        except Exception:
            pass  # The curated set is an addition; discovery still works without it.
        if not self.enabled:
            return
        with self.lock:
            if self.pool is not None:
                return
            self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="slm-discovery")
        self.scheduler = threading.Thread(target=self._schedule, daemon=True, name="slm-source-scheduler")
        self.scheduler.start()
        # No feed delivers the province's scheme pages (MIT, Kansen voor West): read the missing focus pages once.
        self.pool.submit(self._import_focus_pages)

    def _import_focus_pages(self):
        from .focus_grants import install_focus
        install_focus(self, import_pages=True)

    def close(self):
        self.stop_event.set()
        if self.scheduler:
            self.scheduler.join(timeout=2)
        if self.pool:
            self.pool.shutdown(wait=False, cancel_futures=True)

    def _schedule(self):
        while not self.stop_event.is_set():
            self.ensure_sync()
            # Saved calls are monitored even when the founder is away.
            with self.db.store.connect() as conn:
                watched = [r[0] for r in conn.execute("SELECT DISTINCT opportunity_id FROM discovery_saved")]
            self.investigate([rid for rid in watched if self.db.get(rid, missing_ok=True)][:100])
            self.stop_event.wait(30)

    def ensure_sync(self, force=False):
        if not self.enabled or self.pool is None:
            return
        states = {r["provider"]: r for r in self.db.runs()}
        for provider in ("rvo", "eu", "snn"):
            state = states.get(provider, {})
            checked = state.get("finished_at") or state.get("attempted_at")
            age = time.time() - datetime.fromisoformat(checked).timestamp() if checked else float("inf")
            interval = float(os.getenv("SLM_DISCOVERY_REFRESH_SECONDS", "86400")) if state.get("status") == "complete" else 300
            due = age > interval or state.get("status") == "running" or str(state.get("error", "")).startswith("Import interrupted")
            with self.lock:
                if provider in self.active or not (force or due):
                    continue
                self.active.add(provider)
            self.pool.submit(self._sync, provider, force)

    def _sync(self, provider, force=False):
        if not self.db.claim(provider, self.owner):
            with self.lock:
                self.active.discard(provider)
            return
        previous = next((s for s in self.db.runs() if s["provider"] == provider), {})
        resume = previous.get("status") != "complete" and not force
        cursor = previous.get("cursor", 0) if resume else 0
        pages = previous.get("pages", 0) if resume else 0
        count = previous.get("records", 0) if resume else 0
        hashes = previous.get("page_hashes", []) if resume else []
        run_id = previous.get("run_id") if resume else None
        run_id = run_id or uuid4().hex
        self.db.run(provider, status="running", attempted_at=now(), error=None, cursor=cursor, pages=pages, records=count,
                    run_id=run_id, page_hashes=hashes, finished_at=None,
                    scope={"rvo": "All RVO subsidy-feed pages", "eu": "EU English grant/topic records in source open/forthcoming status codes; schedules checked separately",
                           "snn": "All pages of the SNN regional business-subsidy catalogue"}[provider])
        client = PublicClient(self.transport)
        try:
            while not self.stop_event.is_set():
                rows, next_cursor, total = index_page(client, provider, cursor)
                page_hash = fingerprint(sorted(r["external_id"] for r in rows))
                if rows and page_hash in hashes:
                    raise ValueError("Source repeated a page; import paused to prevent a pagination loop")
                hashes.append(page_hash)
                for row in rows:
                    row.update(last_seen_run=run_id, listing_state="listed")
                    self.db.upsert(row)
                pages, count = pages + 1, count + len(rows)
                self.db.run(provider, cursor=next_cursor if next_cursor is not None else 0, pages=pages, records=count,
                            source_total=total, page_hashes=hashes, status="running", lease_until=time.time() + 120)
                if next_cursor is None:
                    for record in self.db.records():
                        if record["provider"] == provider and record.get("last_seen_run") != run_id:
                            self.db.update(record["id"], listing_state="not_seen", source_missing_at=now())
                    self.db.run(provider, status="complete", finished_at=now(), last_success_at=now(), error=None)
                    return
                cursor = next_cursor
                if self.stop_event.wait(float(os.getenv("SLM_DISCOVERY_REQUEST_DELAY", "0.2"))):
                    break
            self.db.run(provider, status="partial", finished_at=now(), error="Import interrupted; progress retained")
        except Exception as exc:
            self.db.run(provider, status="partial" if count else "failed", finished_at=now(), error=type(exc).__name__ + ": " + str(exc)[:250])
        finally:
            client.close()
            self.db.run(provider, lease_until=0)
            with self.lock:
                self.active.discard(provider)

    def hydrate(self, rid, model=False, force=False):
        record = self.db.get(rid)
        if record.get("curated"):
            # Curated focus records are built from checked text; there is no page to fetch.
            primary = {"id": "primary", "url": record["url"], "title": record["title"], "sha256": record["detail_hash"],
                       "format": "html", "role": "primary", "blocks": record["blocks"], "warnings": [], "tables": []}
            saved = self.specifications.save(build_specification(record, [primary]))
            return self.db.update(rid, spec_version=saved["version"], spec_extractor=SPEC_VERSION, spec_status=saved["coverage"], spec_error=None)
        client = PublicClient(self.transport)
        phase = "detail"
        try:
            refreshed = force or self.detail_due(record) or record.get("spec_extractor") != SPEC_VERSION
            if refreshed:
                changes, url, body = detail(client, record)
                self.db.snapshot(rid, url, body)
                grouped = {}
                for block in changes["blocks"]:
                    if block.get("source_url"):
                        grouped.setdefault(block["source_url"], []).append(block)
                for source_url, source_blocks in grouped.items():
                    self.db.snapshot(rid, source_url, json.dumps({"blocks": source_blocks}, ensure_ascii=False))
                if changes["detail_hash"] != record.get("detail_hash"):
                    changes.update(model_call=None, analysis_error=None)
                record = self.db.update(rid, **changes)
                record = self.db.update(rid, requirements=basic_requirements(record))
            phase = "model"
            from .official_forms import official_documents
            bundle, issues = collect_bundle(record, client, self.documents, force=force or refreshed,
                                            scheme_pages=self.scheme_pages(record), extra_documents=official_documents(record))
            blocks = [b for document in bundle for b in document["blocks"]]
            model_source_hash = fingerprint({"sources": [(doc["url"], doc["sha256"]) for doc in bundle], "model": model_profile()})
            model_rules, call = None, None
            if model and configured():
                if record.get("model_call") and record.get("model_source_hash") == model_source_hash and not force:
                    model_rules, call = record.get("model_requirements", record.get("requirements", [])), record["model_call"]
                else:
                    model_rules, call = interpret_with_model({**record, "blocks": blocks})
            spec = build_specification(record, bundle, issues, model_rules, call)
            saved = self.specifications.save(spec)
            changed = saved["changes"]
            record = self.db.update(rid, spec_version=saved["version"], spec_extractor=SPEC_VERSION,
                spec_status=saved["coverage"], spec_review_required=bool(record.get("spec_review_required") or
                    changed["previous_version"] and (changed["added"] or changed["removed"] or changed["changed"] or changed["application_changed"])), spec_error=None,
                **({"model_call": call, "model_requirements": model_rules, "model_source_hash": model_source_hash} if call else {}))
            if refreshed and not record.get("discovery_depth"):
                known = {r["url"] for r in self.db.records()}
                queued = 0
                for candidate in record.get("related_opportunities", []):
                    self.documents.candidate(candidate["url"], record["url"], "verified_related_opportunity")
                    if candidate["url"] not in known and self.enabled and self.pool and queued < 2:
                        self.pool.submit(self.import_official, candidate["url"], False, 1)
                        queued += 1
            return record
        except Exception as exc:
            self.db.update(rid, **({"analysis_error": str(exc)[:250], "spec_error": str(exc)[:250]} if phase == "model" else {"detail_error": str(exc)[:250]}),
                           attempted_detail_at=now())
            return self.db.get(rid)
        finally:
            client.close()

    def scheme_pages(self, record):
        """Catalogue pages below this scheme's URL: its conditions, attachments and procedure."""
        from .grant_documents import scheme_page
        if record.get("provider") == "eu":
            return []
        return [{"title": r["title"], "url": r["url"]} for r in self.db.records()
                if r["id"] != record["id"] and scheme_page(record["url"], r["url"])][:12]

    @staticmethod
    def detail_due(record):
        stamp = record.get("detail_fetched_at")
        timing = schedule(record)
        deadline = timing.get("deadline")
        near_deadline = False
        if deadline:
            try:
                near_deadline = 0 <= (datetime.fromisoformat(deadline).date() - datetime.now().date()).days <= 7
            except ValueError:
                pass
        interval = 3600 if near_deadline else 86400
        return not stamp or bool(record.get("detail_error")) or time.time() - datetime.fromisoformat(stamp).timestamp() > interval

    def investigate(self, ids, model=False, force=False):
        if not self.enabled or self.pool is None:
            return
        for rid in ids:
            key = (rid, model, force)
            record = self.db.get(rid)
            if not force and not self.detail_due(record) and record.get("spec_extractor") == SPEC_VERSION and (not model or record.get("model_call") or record.get("analysis_error")):
                continue
            attempted = record.get("attempted_detail_at")
            if not force and attempted and time.time() - datetime.fromisoformat(attempted).timestamp() < 300:
                continue
            with self.lock:
                if any(p[0] == rid for p in self.pending):
                    continue
                self.pending.add(key)
            self.pool.submit(self._investigate_one, key)

    def _investigate_one(self, key):
        try:
            self.hydrate(key[0], key[1], key[2])
        finally:
            with self.lock:
                self.pending.discard(key)

    def import_official(self, url, model=False, depth=0):
        from .grant_providers import safe_url, clean
        from bs4 import BeautifulSoup
        from .discovery_store import identity
        url = canonical_url(url)
        origin = authority(url)
        if origin["provider"] not in FUNDING_PROVIDERS or urlparse(url).hostname == "api.tech.ec.europa.eu":
            raise ValueError("Import a funding opportunity page from a registered funding authority")
        if not funding_page(url):
            raise ValueError("Use the official page for an individual funding opportunity")
        for existing in self.db.records():
            try:
                same = canonical_url(existing["url"]) == url
            except ValueError:
                same = False  # Curated records may point at non-registered origins.
            if same:
                self.investigate([existing["id"]], model)
                return existing
        client = PublicClient(self.transport)
        try:
            if origin["provider"] == "eu" and "/topic-details/" in url:
                from .grant_providers import normalize_eu, EU_API, value
                identifier = unquote(url.split("/topic-details/", 1)[1].split("?")[0])
                query = {"bool": {"must": [{"term": {"identifier": identifier}}, {"term": {"language": "en"}},
                                           {"terms": {"type": ["1", "2", "8"]}}]}}
                data, _ = client.json("POST", EU_API, params={"apiKey": "SEDIA", "text": identifier, "pageSize": 10},
                    files={"query": (None, json.dumps(query), "application/json")})
                row = next((r for r in data.get("results", []) if value(r.get("metadata", {}), "identifier") == identifier and str(value(r.get("metadata", {}), "type")) in {"1", "2", "8"}), None)
                if not row:
                    raise ValueError("Official topic was not found in the public EU service")
                record = self.db.upsert(normalize_eu(row))
            else:
                data, final = client.request("GET", url)
                parsed = parse_public_document(data, final)
                record = self.db.upsert({"provider": origin["provider"], "external_id": canonical_url(final),
                    "title": parsed["title"], "url": canonical_url(final), "description": " ".join(b["text"] for b in parsed["blocks"][:8]),
                    "tags": [], "programme": "", "instrument": "grant", "kind": "opportunity", "language": "nl" if origin["provider"] != "eu" else "en",
                    "opens_at": None, "deadlines": [], "source_status": None, "index_hash": parsed["sha256"],
                    "detail_hash": parsed["sha256"], "detail_fetched_at": now(), "blocks": parsed["blocks"], "documents": parsed["links"],
                    "listing_state": "imported", "discovered_from": url, "discovery_depth": depth})
                self.documents.save(parsed, data)
            self.documents.candidate(record["url"], url, "registered_official_origin")
        except Exception as exc:
            self.documents.candidate(url, url, "import_failed:" + type(exc).__name__)
            raise
        finally:
            client.close()
        self.investigate([record["id"]], model)
        if self.pool is None:
            return self.hydrate(record["id"], model)
        return record

    def specification(self, rid, model=False, force=False):
        record = self.db.get(rid)
        previous = self.specifications.latest(rid)
        due = force or previous is None or record.get("spec_extractor") != SPEC_VERSION or (
            model and configured() and not record.get("model_call") and not record.get("analysis_error"))
        if due:
            if self.pool is None:
                self.hydrate(rid, model and configured(), force)
            else:
                self.investigate([rid], model and configured(), force)
        latest = self.specifications.latest(rid)
        record = self.db.get(rid)
        error = record.get("spec_error") or record.get("detail_error")
        return {"status": "partial" if latest and (error or latest["coverage"] == "partial") else "ready" if latest else "failed" if error else "reading",
                "specification": latest, "versions": self.specifications.versions(rid),
                "refreshing": any(key[0] == rid for key in self.pending),
                "error": error,
                "review_required": record.get("spec_review_required", False)}

    def evaluation_inputs(self, ws, model=False, investigate=True):
        """Records, clock and retained specifications that matching is evaluated against.

        The catalogue signature and specification heads are read *before* the records, so a concurrent
        update can only cause a harmless cache miss and never a stale hit.
        """
        signature, heads = self.db.catalogue_signature(), self.db.spec_heads()
        records = self.db.records()
        clock = self.clock() if self.clock else None
        active = self.open_candidates(records, ws, clock)
        if investigate:
            self.investigate([r["id"] for r in active[:16]], model and configured())
        return {"records": records, "clock": clock, "specifications": self.retained_specifications(active),
                "signature": signature, "heads": heads}

    @staticmethod
    def open_candidates(records, ws, clock):
        candidates = retrieve(records, profile_text(ws), limit=80, ws=ws)
        return [r for _, r, _, _ in candidates if schedule(r, clock)["status"] != "CLOSED"]

    def retained_specifications(self, active):
        """Latest retained specification of each open candidate; reads local storage only."""
        return {r["id"]: self.specifications.latest(r["id"]) for r in active if r.get("spec_version")}

    def matches(self, ws, model=False):
        """The saved matches for this profile, without matching again.

        Matching runs again only when the profile changes, when the saved result was made while grant pages,
        AI fit checks or the AI search were still running, when a fit check the founder asked for on a grant's
        page changed an assessment, on a new day (deadlines move), or when the founder asks (refresh_matches).
        Opening the grants page starts no new AI checks: grants left unchecked (for example because the AI's daily
        allowance was used up) are checked again on a refresh or a profile change, so the list stays as it was.
        """
        self.ensure_sync()
        clock = self.clock() if self.clock else None
        key = profile_match_key(ws, model, clock)
        saved = self.db.cached_matches(ws["id"], key)
        if saved and not saved["provisional"] and saved["fit_inputs"] == self.fit_inputs(ws, result_ids(saved)):
            self.cache_hits += 1
            return {**self.with_current_state(ws, saved, clock), "assessing_fit": False}
        return self.match_now(ws, model, key)

    def fit_inputs(self, ws, ids):
        """Fingerprint of the current AI fit assessments of these grants."""
        from .relevance import current_assessments
        records = [r for r in (self.db.get(rid, missing_ok=True) for rid in ids) if r]
        assessments = current_assessments(self, ws, records)
        return hashlib.sha256(json.dumps(assessments, sort_keys=True).encode()).hexdigest()

    def refresh_matches(self, ws, model):
        """Match again now against the current catalogue, replacing the saved result; failed fit checks are tried again."""
        self.ensure_sync()
        with self.lock:
            self.fit_retry_after = {key: until for key, until in self.fit_retry_after.items() if key[0] != ws["id"]}
            self.fit_paused_until = 0.0
        return self.match_now(ws, model, profile_match_key(ws, model, self.clock() if self.clock else None))

    def match_now(self, ws, model, key):
        from .relevance import current_assessments
        inputs = self.evaluation_inputs(ws, model)
        records, clock, specifications = inputs["records"], inputs["clock"], inputs["specifications"]
        from .semantic_search import queue as queue_semantic
        semantic = queue_semantic(self, ws, records)
        semantic_ids = set(semantic.get("ids", []))
        records = [{**r, "semantic_candidate": True} if r["id"] in semantic_ids else r for r in records]
        if semantic_ids:
            self.investigate(list(semantic_ids)[:16])
            specifications.update(self.retained_specifications([r for r in records if r["id"] in semantic_ids]))
        assessments = current_assessments(self, ws, records)
        self.evaluations += 1
        result = match_records(records, ws, clock, specifications=specifications, relevance=assessments)
        if result["empty_reason"] and self.pending:
            result["empty_reason"] = {**result["empty_reason"], "message": result["empty_reason"]["message"] +
                                      " Some calls are still being read, so this may change."}
        self.queue_fit_checks(ws, result["matches"] + [{"id": rid} for rid in sorted(semantic_ids) if rid not in {i["id"] for i in result["matches"]}])
        with self.lock:
            assessing_fit = any(wid == ws["id"] for wid, _ in self.fit_pending)
            daily_limit = self.fit_paused_until > time.time()
        result.update(assessing_fit=assessing_fit, ai_daily_limit=daily_limit, investigating=bool(self.pending),
                      semantic_search={"status": semantic["status"], "message": semantic.get("message", "")},
                      ai_available=configured(), historical_context=ws["context"]["mode"] == "historical_rules_demo",
                      matched_at=clock.isoformat(timespec="seconds") if clock else now())
        # Results made while calls were still being read or checked are shown, but matched again on the next visit.
        result["provisional"] = bool(result["investigating"] or assessing_fit or semantic["status"] == "checking"
                                     or (self.active and not result["matches"]))
        result["fit_inputs"] = self.fit_inputs(ws, result_ids(result))
        self.db.save_matches(ws["id"], key, result)
        return self.with_current_state(ws, result, clock)

    def with_current_state(self, ws, result, clock):
        """A saved result with the workspace's current saved grants and the catalogue's status."""
        assessed = {item["id"]: item for section in ("matches", "excluded", "fit_review", "not_recommended", "closed") for item in result[section]}
        saved_ids = self.db.saved(ws["id"])
        saved = []
        for rid in saved_ids:
            record = assessed.get(rid) or self.db.get(rid, missing_ok=True)
            if record is not None:
                saved.append(record if rid in assessed else {**public_record(record), "schedule": schedule(record, clock), "relevance": None})
        # Current source data is never evaluated as if it were a historical snapshot.
        return {**result, "workspace_id": ws["id"], "profile_revision": ws["revision"], "saved_ids": saved_ids,
                "saved_opportunities": saved, "discovery": self.status()}

    def queue_fit_checks(self, ws, items):
        """Check shortlisted calls in the background, with at most two in flight."""
        from .relevance import configured as fit_configured, retained_blocks, input_hash, project_excerpt
        if self.pool is None or not fit_configured() or self.stop_event.is_set():
            return
        text = project_excerpt(ws)
        if not text.strip() or self.fit_paused_until > time.time():
            return
        for item in items[:FIT_CHECKS_PER_LIST]:
            if item.get("relevance"):
                continue
            record = self.db.get(item["id"])
            blocks = retained_blocks(record, text)
            if not blocks:
                continue
            digest = input_hash(record, blocks, text, ws["id"])
            key = (ws["id"], digest)
            with self.lock:
                if len(self.fit_pending) >= 2:
                    break
                if key in self.fit_pending or self.fit_retry_after.get(key, 0) > time.time():
                    continue
                self.fit_pending.add(key)
            self.pool.submit(self._check_project_fit, ws["id"], item["id"], key)

    def opportunity_match(self, ws, rid):
        from .relevance import current_assessments
        from .live_matching import evaluate_all
        record = {**self.db.get(rid), "semantic_candidate": True}
        spec = self.specifications.latest(rid)
        _, items = evaluate_all([record], ws, self.clock() if self.clock else None,
                               {rid: spec} if spec else {}, current_assessments(self, ws, [record]))
        item = items[0]
        self.queue_fit_checks(ws, [item])
        item["ai_available"] = configured()
        from .relevance import project_excerpt, retained_blocks, input_hash
        digest = input_hash(record, retained_blocks(record, project_excerpt(ws)), project_excerpt(ws), ws["id"])
        item["assessment_state"] = "assessed" if item.get("relevance") else "checking" if (ws["id"], digest) in self.fit_pending else "unavailable" if not configured() else "preliminary"
        item["funding_summary"] = next((ob["text"] for ob in (spec or {}).get("financial_observations", [])
                                       if ob.get("scope") == "project" and (ob.get("amount_cents") is not None or ob.get("rate_percent"))), None)
        return item

    def _check_project_fit(self, wid, rid, key):
        from .relevance import assess_relevance
        delay = 300
        try:
            result = assess_relevance(self, self.db.store.load(wid), rid)
            delay = 0 if result["assessment"] is not None else float("inf") if result.get("failure_code") in RETRY_ON_REFRESH \
                else result.get("retry_after", 300)
            if result.get("failure_code") == "daily_limit":
                with self.lock:
                    self.fit_paused_until = time.time() + delay
        finally:
            with self.lock:
                self.fit_pending.discard(key)
                if delay:
                    self.fit_retry_after[key] = time.time() + delay

    def status(self):
        records = self.db.records()
        return {"providers": self.db.runs(), "opportunities": sum(r.get("kind") == "opportunity" for r in records),
                "running": bool(self.active), "investigating": len(self.pending), "enabled": self.enabled}

    def catalogue(self, query="", provider="", status="", page=1, page_size=20, saved_ids=None):
        self.ensure_sync()
        expanded = query + " " + " ".join(CONCEPTS[c] for c in concepts(query))
        records = [r for r in (self.db.search(expanded) if query.strip() else self.db.records()) if r.get("kind") == "opportunity"]
        if query.strip():
            records = [r for _, r, _, _ in retrieve(records, query, limit=len(records))]
        if provider:
            records = [r for r in records if r["provider"] == provider]
        if saved_ids is not None:
            records = [r for r in records if r["id"] in saved_ids]
        items = [{**public_record(r), "schedule": schedule(r)} for r in records]
        items.sort(key=lambda item: (item["schedule"]["status"] == "CLOSED", item["schedule"]["status"] == "UNKNOWN", item["schedule"].get("deadline") or "9999", item["title"]))
        if status == "current":
            items = [r for r in items if r["schedule"]["status"] != "CLOSED"]
        elif status == "open":
            items = [r for r in items if r["schedule"]["status"] in {"WITHIN_WINDOW", "ROLLING", "DEADLINE_PUBLISHED", "REPORTED_OPEN"}]
        elif status:
            items = [r for r in items if r["schedule"]["status"] == status]
        start = (page - 1) * page_size
        return {"items": items[start:start + page_size], "total": len(items), "page": page, "page_size": page_size, "discovery": self.status()}
