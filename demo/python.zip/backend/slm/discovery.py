"""Resumable live discovery and automatic company-driven investigation."""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from uuid import uuid4
from .config import now
from .discovery_store import DiscoveryStore
from .grant_providers import PublicClient, index_page, detail, fingerprint
from .funding_conditions import basic_requirements, schedule
from .live_matching import retrieve, profile_text, match_records, public_record, interpret_with_model
from .live_matching import concepts, CONCEPTS
from .model_adapter import configured
from .grant_documents import DocumentStore, collect_bundle, parse_public_document
from .grant_specification import SpecificationStore, build_specification, SPEC_VERSION
from .official_sources import authority, canonical_url, FUNDING_PROVIDERS, funding_page
from urllib.parse import urlparse, unquote


class DiscoveryService:
    def __init__(self, store, transport=None, enabled=True, clock=None):
        self.db = DiscoveryStore(store)
        self.documents = DocumentStore(store)
        self.specifications = SpecificationStore(store)
        self.transport, self.enabled = transport, enabled
        self.clock = clock
        self.owner = uuid4().hex
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.active = set()
        self.pending = set()
        self.pool = None
        self.scheduler = None

    def start(self):
        if not self.enabled:
            return
        with self.lock:
            if self.pool is not None:
                return
            self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="slm-discovery")
        self.scheduler = threading.Thread(target=self._schedule, daemon=True, name="slm-source-scheduler")
        self.scheduler.start()

    def close(self):
        self.stop_event.set()
        if self.scheduler:
            self.scheduler.join(timeout=2)
        if self.pool:
            self.pool.shutdown(wait=False, cancel_futures=True)

    def _schedule(self):
        while not self.stop_event.is_set():
            self.ensure_sync()
            self.stop_event.wait(30)

    def ensure_sync(self, force=False):
        if not self.enabled or self.pool is None:
            return
        states = {r["provider"]: r for r in self.db.runs()}
        for provider in ("rvo", "eu", "snn"):
            state = states.get(provider, {})
            checked = state.get("finished_at") or state.get("attempted_at")
            age = time.time() - datetime.fromisoformat(checked).timestamp() if checked else float("inf")
            interval = float(os.getenv("SLM_DISCOVERY_REFRESH_SECONDS", "86400")) if state.get("status") == "complete" else 300
            due = age > interval or state.get("status") == "running" or str(state.get("error", "")).startswith("Import interrupted")
            with self.lock:
                if provider in self.active or not (force or due):
                    continue
                self.active.add(provider)
            self.pool.submit(self._sync, provider, force)

    def _sync(self, provider, force=False):
        if not self.db.claim(provider, self.owner):
            with self.lock:
                self.active.discard(provider)
            return
        previous = next((s for s in self.db.runs() if s["provider"] == provider), {})
        resume = previous.get("status") != "complete" and not force
        cursor = previous.get("cursor", 0) if resume else 0
        pages = previous.get("pages", 0) if resume else 0
        count = previous.get("records", 0) if resume else 0
        hashes = previous.get("page_hashes", []) if resume else []
        run_id = previous.get("run_id") if resume else None
        run_id = run_id or uuid4().hex
        self.db.run(provider, status="running", attempted_at=now(), error=None, cursor=cursor, pages=pages, records=count,
                    run_id=run_id, page_hashes=hashes, finished_at=None,
                    scope={"rvo": "All RVO subsidy-feed pages", "eu": "EU English grant/topic records in source open/forthcoming status codes; schedules checked separately",
                           "snn": "All pages of the SNN regional business-subsidy catalogue"}[provider])
        client = PublicClient(self.transport)
        try:
            while not self.stop_event.is_set():
                rows, next_cursor, total = index_page(client, provider, cursor)
                page_hash = fingerprint(sorted(r["external_id"] for r in rows))
                if rows and page_hash in hashes:
                    raise ValueError("Source repeated a page; import paused to prevent a pagination loop")
                hashes.append(page_hash)
                for row in rows:
                    row.update(last_seen_run=run_id, listing_state="listed")
                    self.db.upsert(row)
                pages, count = pages + 1, count + len(rows)
                self.db.run(provider, cursor=next_cursor if next_cursor is not None else 0, pages=pages, records=count,
                            source_total=total, page_hashes=hashes, status="running", lease_until=time.time() + 120)
                if next_cursor is None:
                    for record in self.db.records():
                        if record["provider"] == provider and record.get("last_seen_run") != run_id:
                            self.db.update(record["id"], listing_state="not_seen", source_missing_at=now())
                    self.db.run(provider, status="complete", finished_at=now(), last_success_at=now(), error=None)
                    return
                cursor = next_cursor
                if self.stop_event.wait(float(os.getenv("SLM_DISCOVERY_REQUEST_DELAY", "0.2"))):
                    break
            self.db.run(provider, status="partial", finished_at=now(), error="Import interrupted; progress retained")
        except Exception as exc:
            self.db.run(provider, status="partial" if count else "failed", finished_at=now(), error=type(exc).__name__ + ": " + str(exc)[:250])
        finally:
            client.close()
            self.db.run(provider, lease_until=0)
            with self.lock:
                self.active.discard(provider)

    def hydrate(self, rid, model=False, force=False):
        record = self.db.get(rid)
        client = PublicClient(self.transport)
        phase = "detail"
        try:
            refreshed = force or self.detail_due(record) or record.get("spec_extractor") != SPEC_VERSION
            if refreshed:
                changes, url, body = detail(client, record)
                self.db.snapshot(rid, url, body)
                grouped = {}
                for block in changes["blocks"]:
                    if block.get("source_url"):
                        grouped.setdefault(block["source_url"], []).append(block)
                for source_url, source_blocks in grouped.items():
                    self.db.snapshot(rid, source_url, json.dumps({"blocks": source_blocks}, ensure_ascii=False))
                if changes["detail_hash"] != record.get("detail_hash"):
                    changes.update(model_call=None, analysis_error=None)
                record = self.db.update(rid, **changes)
                record = self.db.update(rid, requirements=basic_requirements(record))
            phase = "model"
            bundle, issues = collect_bundle(record, client, self.documents, force=force or refreshed)
            blocks = [b for document in bundle for b in document["blocks"]]
            model_source_hash = fingerprint([(doc["url"], doc["sha256"]) for doc in bundle])
            model_rules, call = None, None
            if model and configured():
                if record.get("model_call") and record.get("model_source_hash") == model_source_hash and not force:
                    model_rules, call = record.get("model_requirements", record.get("requirements", [])), record["model_call"]
                else:
                    model_rules, call = interpret_with_model({**record, "blocks": blocks})
            spec = build_specification(record, bundle, issues, model_rules, call)
            saved = self.specifications.save(spec)
            changed = saved["changes"]
            record = self.db.update(rid, spec_version=saved["version"], spec_extractor=SPEC_VERSION,
                spec_status=saved["coverage"], spec_review_required=bool(record.get("spec_review_required") or
                    changed["previous_version"] and (changed["added"] or changed["removed"] or changed["changed"] or changed["application_changed"])), spec_error=None,
                **({"model_call": call, "model_requirements": model_rules, "model_source_hash": model_source_hash} if call else {}))
            if refreshed and not record.get("discovery_depth"):
                known = {r["url"] for r in self.db.records()}
                queued = 0
                for candidate in record.get("related_opportunities", []):
                    self.documents.candidate(candidate["url"], record["url"], "verified_related_opportunity")
                    if candidate["url"] not in known and self.enabled and self.pool and queued < 2:
                        self.pool.submit(self.import_official, candidate["url"], False, 1)
                        queued += 1
            return record
        except Exception as exc:
            self.db.update(rid, **({"analysis_error": str(exc)[:250], "spec_error": str(exc)[:250]} if phase == "model" else {"detail_error": str(exc)[:250]}),
                           attempted_detail_at=now())
            return self.db.get(rid)
        finally:
            client.close()

    @staticmethod
    def detail_due(record):
        stamp = record.get("detail_fetched_at")
        return not stamp or bool(record.get("detail_error")) or time.time() - datetime.fromisoformat(stamp).timestamp() > 86400

    def investigate(self, ids, model=False, force=False):
        if not self.enabled or self.pool is None:
            return
        for rid in ids:
            key = (rid, model, force)
            record = self.db.get(rid)
            if not force and not self.detail_due(record) and record.get("spec_extractor") == SPEC_VERSION and (not model or record.get("model_call") or record.get("analysis_error")):
                continue
            attempted = record.get("attempted_detail_at")
            if not force and attempted and time.time() - datetime.fromisoformat(attempted).timestamp() < 300:
                continue
            with self.lock:
                if any(p[0] == rid for p in self.pending):
                    continue
                self.pending.add(key)
            self.pool.submit(self._investigate_one, key)

    def _investigate_one(self, key):
        try:
            self.hydrate(key[0], key[1], key[2])
        finally:
            with self.lock:
                self.pending.discard(key)

    def import_official(self, url, model=False, depth=0):
        from .grant_providers import safe_url, clean
        from bs4 import BeautifulSoup
        from .discovery_store import identity
        url = canonical_url(url)
        origin = authority(url)
        if origin["provider"] not in FUNDING_PROVIDERS or urlparse(url).hostname == "api.tech.ec.europa.eu":
            raise ValueError("Import a funding opportunity page from a registered funding authority")
        if not funding_page(url):
            raise ValueError("Use the official page for an individual funding opportunity")
        for existing in self.db.records():
            if canonical_url(existing["url"]) == url:
                self.investigate([existing["id"]], model)
                return existing
        client = PublicClient(self.transport)
        try:
            if origin["provider"] == "eu" and "/topic-details/" in url:
                from .grant_providers import normalize_eu, EU_API, value
                identifier = unquote(url.split("/topic-details/", 1)[1].split("?")[0])
                query = {"bool": {"must": [{"term": {"identifier": identifier}}, {"term": {"language": "en"}},
                                           {"terms": {"type": ["1", "2", "8"]}}]}}
                data, _ = client.json("POST", EU_API, params={"apiKey": "SEDIA", "text": identifier, "pageSize": 10},
                    files={"query": (None, json.dumps(query), "application/json")})
                row = next((r for r in data.get("results", []) if value(r.get("metadata", {}), "identifier") == identifier and str(value(r.get("metadata", {}), "type")) in {"1", "2", "8"}), None)
                if not row:
                    raise ValueError("Official topic was not found in the public EU service")
                record = self.db.upsert(normalize_eu(row))
            else:
                data, final = client.request("GET", url)
                parsed = parse_public_document(data, final)
                record = self.db.upsert({"provider": origin["provider"], "external_id": canonical_url(final),
                    "title": parsed["title"], "url": canonical_url(final), "description": " ".join(b["text"] for b in parsed["blocks"][:8]),
                    "tags": [], "programme": "", "instrument": "grant", "kind": "opportunity", "language": "nl" if origin["provider"] != "eu" else "en",
                    "opens_at": None, "deadlines": [], "source_status": None, "index_hash": parsed["sha256"],
                    "detail_hash": parsed["sha256"], "detail_fetched_at": now(), "blocks": parsed["blocks"], "documents": parsed["links"],
                    "listing_state": "imported", "discovered_from": url, "discovery_depth": depth})
                self.documents.save(parsed, data)
            self.documents.candidate(record["url"], url, "registered_official_origin")
        except Exception as exc:
            self.documents.candidate(url, url, "import_failed:" + type(exc).__name__)
            raise
        finally:
            client.close()
        self.investigate([record["id"]], model)
        if self.pool is None:
            return self.hydrate(record["id"], model)
        return record

    def specification(self, rid, model=False, force=False):
        record = self.db.get(rid)
        previous = self.specifications.latest(rid)
        due = force or previous is None or record.get("spec_extractor") != SPEC_VERSION or (
            model and configured() and not record.get("model_call") and not record.get("analysis_error"))
        if due:
            if self.pool is None:
                self.hydrate(rid, model and configured(), force)
            else:
                self.investigate([rid], model and configured(), force)
        latest = self.specifications.latest(rid)
        record = self.db.get(rid)
        error = record.get("spec_error") or record.get("detail_error")
        return {"status": "partial" if latest and (error or latest["coverage"] == "partial") else "ready" if latest else "failed" if error else "reading",
                "specification": latest, "versions": self.specifications.versions(rid),
                "refreshing": any(key[0] == rid for key in self.pending),
                "error": error,
                "review_required": record.get("spec_review_required", False)}

    def matches(self, ws, model=False):
        self.ensure_sync()
        records = self.db.records()
        candidates = retrieve(records, profile_text(ws), limit=80)
        clock = self.clock() if self.clock else None
        active = [r for _, r, _, _ in candidates if schedule(r, clock)["status"] != "CLOSED"]
        self.investigate([r["id"] for r in active[:16]], model and configured())
        specifications = {r["id"]: self.specifications.latest(r["id"]) for r in active[:24] if r.get("spec_version")}
        result = match_records(records, ws, clock, specifications=specifications)
        saved_ids = self.db.saved(ws["id"])
        saved_records = [r for r in records if r["id"] in saved_ids]
        result["workspace_id"] = ws["id"]
        result["saved_opportunities"] = [{**public_record(r), "schedule": schedule(r, clock)} for r in saved_records]
        result.update(saved_ids=self.db.saved(ws["id"]), discovery=self.status(), investigating=bool(self.pending),
                      historical_context=ws["context"]["mode"] == "historical_rules_demo")
        # Current source data is never evaluated as if it were a historical snapshot.
        return result

    def status(self):
        records = self.db.records()
        return {"providers": self.db.runs(), "opportunities": sum(r.get("kind") == "opportunity" for r in records),
                "running": bool(self.active), "investigating": len(self.pending), "enabled": self.enabled}

    def catalogue(self, query="", provider="", status="", page=1, page_size=20, saved_ids=None):
        self.ensure_sync()
        expanded = query + " " + " ".join(CONCEPTS[c] for c in concepts(query))
        records = [r for r in (self.db.search(expanded) if query.strip() else self.db.records()) if r.get("kind") == "opportunity"]
        if query.strip():
            records = [r for _, r, _, _ in retrieve(records, query, limit=len(records))]
        if provider:
            records = [r for r in records if r["provider"] == provider]
        if saved_ids is not None:
            records = [r for r in records if r["id"] in saved_ids]
        items = [{**public_record(r), "schedule": schedule(r)} for r in records]
        if status:
            items = [r for r in items if r["schedule"]["status"] == status]
        start = (page - 1) * page_size
        return {"items": items[start:start + page_size], "total": len(items), "page": page, "page_size": page_size, "discovery": self.status()}
