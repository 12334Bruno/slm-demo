"""Readable paragraphs and headings from official PDF text.

pypdf returns each page as wrapped lines. Collapsing a whole page into one block
loses the numbered headings, bullets and paragraph breaks that tell us which part
of a form asks for what. This module keeps that structure without inventing text:
every emitted paragraph is a whitespace-normalised join of consecutive source lines.
"""
import re
from collections import Counter

BULLET = re.compile(r"^\s*(?:[•●▪◦‣∙·]|[-−‒–—](?=\s)|o(?=\s)|\(?[a-z]\)(?=\s)|\(?[ivx]{1,4}\)(?=\s)|\d{1,2}\)(?=\s))\s*")
NUMBERED_HEADING = re.compile(r"^\s*((?:\d{1,2}\.){0,3}\d{1,2})\.?\s+(?:[–—-]\s*)?([A-ZÀ-Ý‘'“\"(][^\n]{1,190})$")
NAMED_HEADING = re.compile(r"(?i)^\s*(?:part\s+[A-E]\b|section\s+\d+|annex\s+[A-Z0-9]+\b|table\s+\d+(?:\.\d+)*[a-z]?\b|bijlage\s+\d+|hoofdstuk\s+\d+|deel\s+[A-E1-9]\b)[^\n]{0,140}$")
TOC_LINE = re.compile(r"(?:\.{4,}|…{2,}|(?:\.\s){4,})\s*\d{1,4}\s*$")
PAGE_MARKER = re.compile(r"(?i)^\s*part\s+[a-e]\s*[-–]\s*page\s+\S+\s+of\s+.{1,20}$|^\s*(?:page|pagina|blz\.?)\s*\d+\s*(?:of|van|/)\s*\d+\s*$|^\s*\d{1,4}\s*(?:/\s*\d{1,4})?\s*$|^\s*-\s*\d{1,4}\s*-\s*$")
LABEL_LINE = re.compile(r"^[A-ZÀ-Ý][\w/()&'’.\- ]{1,45}:\s+\S.{0,200}$")
TERMINAL = re.compile(r"[.!?;:]['’”\")\]]*$")


def _normal(line):
    return re.sub(r"\d+", "#", " ".join(line.split()).casefold())


def _layout_lines(page):
    """Layout extraction keeps reading order and word spacing; multi-column pages fall back.

    Narrow sidebars can still interleave with the main column; fixing that needs word
    coordinates (e.g. pdfplumber), which is a known limitation of this text-only reader.
    """
    text = page.extract_text(extraction_mode="layout", layout_mode_space_vertically=False) or ""
    lines = [line.rstrip() for line in text.replace("\r", "\n").split("\n")]
    content = [line for line in lines if line.strip()]
    gaps = sum(bool(re.search(r"\S {8,}\S", line.strip()[25:])) for line in content)
    if content and gaps / len(content) > 0.3:
        return None
    return [re.sub(r" {2,}", " ", line).strip() for line in lines]


def _fragments(page):
    """Text fragments with page coordinates, from pypdf's text visitor."""
    found = []

    def visit(text, cm, tm, font, size):
        if not text or not text.strip():
            return
        x = tm[4] * cm[0] + tm[5] * cm[2] + cm[4]
        y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5]
        scale = abs(cm[0]) if cm[0] else 1
        height = (size or 10) * scale * (abs(tm[0]) or 1)
        found.append({"text": text.replace("\n", " "), "x": x, "y": y, "w": len(text.strip()) * height * 0.5, "h": height})
    page.extract_text(visitor_text=visit)
    return found


def _rows(fragments):
    """Group fragments into rows by baseline, top to bottom."""
    rows = []
    for frag in sorted(fragments, key=lambda f: (-round(f["y"], 0), f["x"])):
        if rows and abs(rows[-1][0]["y"] - frag["y"]) <= max(2.0, frag["h"] * 0.4):
            rows[-1].append(frag)
        else:
            rows.append([frag])
    return [sorted(row, key=lambda f: f["x"]) for row in rows]


def column_lines(page):
    """Two-column pages (e.g. a tips sidebar beside the main text) read left column first, then right.

    A gutter is an x position that almost no text crosses while both sides hold real
    sentences. Label/value tables have short cells on one side and are left alone.
    """
    fragments = _fragments(page)
    if len(fragments) < 20:
        return None
    rows = _rows(fragments)
    left_edge = min(f["x"] for f in fragments)
    right_edge = max(f["x"] + f["w"] for f in fragments)
    best = None
    for step in range(20, 81, 2):
        gutter = left_edge + (right_edge - left_edge) * step / 100
        crossing = sum(any(f["x"] < gutter - 2 < f["x"] + f["w"] - 4 for f in row) for row in rows)
        left = [" ".join(f["text"] for f in row if f["x"] < gutter).strip() for row in rows]
        right = [" ".join(f["text"] for f in row if f["x"] >= gutter).strip() for row in rows]
        left_rows, right_rows = [t for t in left if t], [t for t in right if t]
        if min(len(left_rows), len(right_rows)) < 3 or max(len(left_rows), len(right_rows)) < len(rows) * 0.4:
            continue  # A sidebar can be short; the main column must carry most of the page.
        long_left = sum(len(t) >= 25 for t in left_rows) / len(left_rows)
        long_right = sum(len(t) >= 25 for t in right_rows) / len(right_rows)
        average = min(sum(map(len, left_rows)) / len(left_rows), sum(map(len, right_rows)) / len(right_rows))
        # One side is running text and the other holds sentences too (a sidebar), not short table cells.
        if crossing / len(rows) <= 0.06 and max(long_left, long_right) >= 0.5 and average >= 18:
            # The leftmost clean gutter: a sidebar's edge, or the middle of a two-column article.
            # Gutters further right are usually between the cells of a table inside the main column.
            best = (left, right)
            break
    if best is None:
        return None
    left, right = best
    # Rows that are empty in one column are not paragraph breaks in that column.
    return [" ".join(t.split()) for t in left if t.strip()] + [""] + [" ".join(t.split()) for t in right if t.strip()]


def page_lines(reader, max_pages):
    pages = []
    for page in reader.pages[:max_pages]:
        lines = None
        try:
            lines = column_lines(page) or _layout_lines(page)
        except Exception:
            lines = None
        if lines is None:
            try:
                text = page.extract_text() or ""
            except Exception:  # A damaged page is reported by the caller as unreadable text.
                text = ""
            lines = [line.rstrip() for line in text.replace("\r", "\n").split("\n")]
        pages.append(lines)
    return pages


def running_lines(pages):
    """Header/footer lines repeated across pages (page numbers normalised)."""
    if len(pages) < 3:
        return set()
    counts = Counter()
    for lines in pages:
        edge = [l for l in lines if l.strip()]
        candidates = edge[:4] + edge[-4:]
        counts.update({_normal(l) for l in candidates if len(l.strip()) < 220})
    threshold = max(3, int(len(pages) * 0.3))
    return {line for line, count in counts.items() if count >= threshold and line}


def heading_level(line):
    text = " ".join(line.split())
    if len(text) > 200 or text.endswith((",", ";")):
        return None
    numbered = NUMBERED_HEADING.match(text)
    if numbered:
        title = numbered[2]
        # Sentences that happen to start with a number (amounts, dates, list counts) are not headings.
        if re.match(r"(?i)^(?:EUR|€|%|\(|percent|procent|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*|"
                    r"januari|februari|maart|mei|juni|juli|augustus|oktober)\b", title) or title.startswith("("):
            return None
        if title.endswith((".", ",")) and len(title) > 60 or title.endswith(":"):
            return None
        bare = re.sub(r"\[[^\]]*\]?|\([^)]*\)?", "", title)
        if len(bare.split()) > 14 or re.search(r"(?i),\s*(?:please|see|refer)\b", title):
            return None  # Long numbered lines are footnotes or list sentences, not section headings.
        return min(4, numbered[1].count(".") + 1)
    if NAMED_HEADING.match(text) and not text.endswith("."):
        return 2
    return None


def structured_paragraphs(reader, max_pages):
    """Return paragraphs as (text, page_number, attributes)."""
    pages = page_lines(reader, max_pages)
    repeated = running_lines(pages)
    widths = [len(l.strip()) for lines in pages for l in lines if l.strip()]
    typical = sorted(widths)[int(len(widths) * 0.8)] if widths else 90
    paragraphs = []
    current, current_page, current_attrs = [], None, {}
    last_page = None

    def flush():
        nonlocal current, current_attrs
        if current:
            text = " ".join(" ".join(current).split())
            if text:
                attrs = dict(current_attrs)
                if last_page and last_page != current_page:
                    attrs["end_page"] = last_page
                paragraphs.append((text, current_page, attrs))
        current, current_attrs = [], {}

    for number, lines in enumerate(pages, 1):
        # An unfinished sentence continues on the next page; a finished one does not.
        previous = " ".join(current[-1].split()) if current else ""
        if current and TERMINAL.search(previous):
            flush()
            previous = ""
        page_content = False
        last_content = max((i for i, raw in enumerate(lines) if raw.strip()), default=-1)
        for index, raw in enumerate(lines):
            line = " ".join(raw.split())
            if not line and index > last_content:
                continue  # Trailing blank lines at the bottom of a page never end an unfinished sentence.
            if not line:
                # Blank lines before a page's first content line are layout, not a paragraph break.
                if page_content or (current and TERMINAL.search(previous)):
                    flush()
                    previous = ""
                continue
            if _normal(line) in repeated or PAGE_MARKER.match(line) or TOC_LINE.search(line):
                continue
            page_content = True
            level = heading_level(line)
            bullet = BULLET.match(line)
            if paragraphs and paragraphs[-1][2].get("heading_level") and not current and (
                    paragraphs[-1][0].count("[") > paragraphs[-1][0].count("]") or
                    paragraphs[-1][0].count("(") > paragraphs[-1][0].count(")")):
                text, page_number, attrs = paragraphs.pop()
                paragraphs.append((text + " " + line, page_number, attrs))
                continue
            if level:
                flush()
                paragraphs.append((line, number, {"heading_level": level}))
                previous = ""
                continue
            if LABEL_LINE.match(line) and len(line) < typical * 0.72:
                flush()  # "Company name: Example B.V." is a field, kept on its own like in a form.
                paragraphs.append((line, number, {"label_line": True}))
                previous = ""
                continue
            starts_new = bool(bullet) or not current or (
                TERMINAL.search(previous) and len(previous) < typical * 0.72 and line[:1].isupper())
            if starts_new:
                flush()
                current_page = number
                last_page = number
                if bullet:
                    current_attrs = {"list_item": True}
                    marker = bullet.group(0).strip()
                    line = line[bullet.end():].strip()
                    if re.fullmatch(r"\(?[a-z0-9ivx]{1,4}\)", marker):
                        line = marker + " " + line
                current.append(line)
            elif current and current[-1].endswith("-") and not current[-1].endswith(" -") and line[:1].islower():
                current[-1] = current[-1][:-1] + line  # Rejoin a word hyphenated at a line break.
            else:
                current.append(line)
            last_page = number
            previous = line
    flush()
    return paragraphs
