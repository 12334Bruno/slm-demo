import json
import sqlite3
from contextlib import contextmanager
from uuid import uuid4
from .config import data_dir, now
from .domain import ALL_PATHS


class RevisionConflict(Exception):
    pass


def empty_workspace(wid=None):
    return {
        "id": wid or uuid4().hex, "revision": 0, "created_at": now(), "updated_at": now(),
        "context": {"mode": "current"},
        "facts": {p: {"id": uuid4().hex, "path": p, "value": None, "state": "missing", "evidence": [],
                       "candidates": [], "revision": 0, "confirmed_at": None, "history": []} for p in sorted(ALL_PATHS)},
        "documents": [], "budget_lines": [], "funding_sources": [], "funding_letters": [],
        "budget_metadata": {"project_revenues_cents": None, "other_project_costs_cents": None,
                            "requested_grant_cents": None, "confirmed": False, "evidence": []},
        "draft": None, "last_evaluation": None, "extraction_runs": [], "audit": [],
    }


def hydrate(ws):
    """Add newly supported missing fields without replacing saved user values."""
    changed = False
    for path in sorted(ALL_PATHS - set(ws["facts"])):
        ws["facts"][path] = {"id": uuid4().hex, "path": path, "value": None, "state": "missing", "evidence": [],
                             "candidates": [], "revision": ws["revision"], "confirmed_at": None, "history": []}
        changed = True
    return changed


def touch(ws, paths, reason):
    ws["revision"] += 1
    ws["updated_at"] = now()
    ws["audit"].append({"at": now(), "revision": ws["revision"], "paths": paths, "reason": reason})
    if ws["last_evaluation"]:
        ws["last_evaluation"]["stale"] = True
    if ws["draft"]:
        for section in ws["draft"]["sections"]:
            if any(p in {"*", "context"} or p in section["dependencies"] for p in paths):
                section["state"] = "stale"
        ws["draft"]["stale"] = any(s["state"] == "stale" for s in ws["draft"]["sections"])
        ws["draft"]["revision"] += 1


class Store:
    def __init__(self, root=None):
        self.root = root or data_dir()
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "uploads").mkdir(exist_ok=True)
        self.db = self.root / "slm.sqlite3"
        with self.connect() as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS workspaces (id TEXT PRIMARY KEY, state TEXT NOT NULL)")
            conn.execute("CREATE TABLE IF NOT EXISTS retrievals (source_id TEXT PRIMARY KEY, state TEXT NOT NULL)")

    def connect(self):
        conn = sqlite3.connect(self.db, timeout=15)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def create(self, label=None, example_id=None):
        ws = empty_workspace()
        if label:
            ws["label"] = label
        if example_id:
            ws["example_id"] = example_id
        with self.connect() as conn:
            conn.execute("INSERT INTO workspaces VALUES (?, ?)", (ws["id"], json.dumps(ws)))
        return ws

    def find_example(self, example_id):
        with self.connect() as conn:
            rows = conn.execute("SELECT id, state FROM workspaces").fetchall()
        return next((wid for wid, state in rows if json.loads(state).get("example_id") == example_id), None)

    def load(self, wid):
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT state FROM workspaces WHERE id=?", (wid,)).fetchone()
            if not row:
                raise KeyError("Workspace not found")
            ws = json.loads(row[0])
            if hydrate(ws):
                conn.execute("UPDATE workspaces SET state=? WHERE id=?", (json.dumps(ws), wid))
        return ws

    def list(self):
        with self.connect() as conn:
            rows = conn.execute("SELECT state FROM workspaces").fetchall()
        workspaces = [json.loads(r[0]) for r in rows]
        return [{"id": w["id"], "updated_at": w["updated_at"], "revision": w["revision"],
                 "name": w["facts"]["company.name"]["value"], "label": w.get("label")} for w in sorted(workspaces, key=lambda w: w["updated_at"], reverse=True)]

    @contextmanager
    def edit(self, wid, expected=None):
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT state FROM workspaces WHERE id=?", (wid,)).fetchone()
            if not row:
                raise KeyError("Workspace not found")
            ws = json.loads(row[0])
            hydrate(ws)
            if expected is not None and expected != ws["revision"]:
                raise RevisionConflict("Workspace changed. Reload before saving your changes.")
            yield ws
            conn.execute("UPDATE workspaces SET state=? WHERE id=?", (json.dumps(ws), wid))

    def reset(self, wid):
        with self.edit(wid) as ws:
            for doc in ws["documents"]:
                (self.root / "uploads" / doc["storage_name"]).unlink(missing_ok=True)
            revision = ws["revision"] + 1
            ws.clear()
            ws.update(empty_workspace(wid))
            ws["revision"] = revision
        return self.load(wid)

    def retrieval(self, sid):
        with self.connect() as conn:
            row = conn.execute("SELECT state FROM retrievals WHERE source_id=?", (sid,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_retrieval(self, sid, state):
        with self.connect() as conn:
            conn.execute("INSERT OR REPLACE INTO retrievals VALUES (?, ?)", (sid, json.dumps(state)))
