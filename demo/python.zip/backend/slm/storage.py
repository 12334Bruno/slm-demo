import json
import shutil
import sqlite3
from contextlib import contextmanager
from copy import deepcopy
from uuid import uuid4
from .config import data_dir, now
from .domain import ALL_PATHS, KEY_PATHS
from .hosted_access import current_owner, require_owner


class RevisionConflict(Exception):
    pass


def empty_workspace(wid=None):
    return {
        "id": wid or uuid4().hex, "revision": 0, "created_at": now(), "updated_at": now(),
        "context": {"mode": "current"},
        "facts": {p: {"id": uuid4().hex, "path": p, "value": None, "state": "missing", "evidence": [],
                       "candidates": [], "revision": 0, "confirmed_at": None, "history": []} for p in sorted(ALL_PATHS)},
        "documents": [], "budget_lines": [], "funding_sources": [], "funding_letters": [],
        "budget_metadata": {"project_revenues_cents": None, "other_project_costs_cents": None,
                            "requested_grant_cents": None, "confirmed": False, "evidence": []},
        "draft": None, "last_evaluation": None, "extraction_runs": [], "audit": [],
    }


def hydrate(ws):
    """Add newly supported missing fields without replacing saved user values."""
    changed = False
    for path in sorted(ALL_PATHS - set(ws["facts"])):
        ws["facts"][path] = {"id": uuid4().hex, "path": path, "value": None, "state": "missing", "evidence": [],
                             "candidates": [], "revision": ws["revision"], "confirmed_at": None, "history": []}
        changed = True
    return changed


def touch(ws, paths, reason):
    ws["revision"] += 1
    ws["updated_at"] = now()
    ws["audit"].append({"at": now(), "revision": ws["revision"], "paths": paths, "reason": reason})
    if ws["last_evaluation"]:
        ws["last_evaluation"]["stale"] = True
    if ws["draft"]:
        for section in ws["draft"]["sections"]:
            if any(p in {"*", "context"} or p in section["dependencies"] for p in paths):
                section["state"] = "stale"
        ws["draft"]["stale"] = any(s["state"] == "stale" for s in ws["draft"]["sections"])
        ws["draft"]["revision"] += 1


class Store:
    def __init__(self, root=None):
        self.root = root or data_dir()
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "uploads").mkdir(exist_ok=True)
        self.db = self.root / "slm.sqlite3"
        with self.connect() as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS workspaces (id TEXT PRIMARY KEY, state TEXT NOT NULL)")
            conn.execute("CREATE TABLE IF NOT EXISTS retrievals (source_id TEXT PRIMARY KEY, state TEXT NOT NULL)")
            conn.execute("CREATE TABLE IF NOT EXISTS workspace_owners (workspace_id TEXT PRIMARY KEY, owner TEXT NOT NULL)")

    def connect(self):
        conn = sqlite3.connect(self.db, timeout=15)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def create(self, label=None, example_id=None):
        ws = empty_workspace()
        if label:
            ws["label"] = label
        if example_id:
            ws["example_id"] = example_id
        self.insert(ws)
        return ws

    def insert(self, ws):
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            if current_owner.get() and conn.execute("SELECT COUNT(*) FROM workspace_owners WHERE owner=?", (current_owner.get(),)).fetchone()[0] >= 20:
                raise ValueError("You can keep up to 20 projects. Delete an old project before creating another.")
            conn.execute("INSERT INTO workspaces VALUES (?, ?)", (ws["id"], json.dumps(ws)))
            if current_owner.get() is not None:
                conn.execute("INSERT INTO workspace_owners VALUES (?, ?)", (ws["id"], current_owner.get()))

    def rename(self, wid, label):
        with self.edit(wid) as ws:
            ws["label"] = label
            ws["updated_at"] = now()

    def duplicate(self, wid, label):
        """A separate copy with its own upload files, so deleting either company never touches the other."""
        source = self.load(wid)
        copy = deepcopy(source)
        copy.pop("example_id", None)  # The copy is the founder's own variant, not the reusable example.
        copy.update(id=uuid4().hex, label=label, created_at=now(), updated_at=now())
        copied = []
        try:
            for doc in copy["documents"]:
                original = self.root / "uploads" / doc["storage_name"]
                doc["storage_name"] = uuid4().hex + original.suffix
                if original.is_file():  # Unreadable uploads were never stored, so they have no file to copy.
                    shutil.copyfile(original, self.root / "uploads" / doc["storage_name"])
                    copied.append(self.root / "uploads" / doc["storage_name"])
            self.insert(copy)
        except BaseException:
            for path in copied:
                path.unlink(missing_ok=True)
            raise
        return copy

    def find_example(self, example_id):
        with self.connect() as conn:
            rows = conn.execute("SELECT id, state FROM workspaces").fetchall()
            owned = {r[0] for r in conn.execute("SELECT workspace_id FROM workspace_owners WHERE owner=?", (current_owner.get(),))} if current_owner.get() else None
        return next((wid for wid, state in rows if (owned is None or wid in owned) and json.loads(state).get("example_id") == example_id), None)

    def load(self, wid):
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            require_owner(conn, wid)
            row = conn.execute("SELECT state FROM workspaces WHERE id=?", (wid,)).fetchone()
            if not row:
                raise KeyError("Workspace not found")
            ws = json.loads(row[0])
            if hydrate(ws):
                conn.execute("UPDATE workspaces SET state=? WHERE id=?", (json.dumps(ws), wid))
        return ws

    def list(self):
        with self.connect() as conn:
            rows = conn.execute("SELECT w.state FROM workspaces w JOIN workspace_owners o ON w.id=o.workspace_id WHERE o.owner=?", (current_owner.get(),)).fetchall() if current_owner.get() else conn.execute("SELECT state FROM workspaces").fetchall()
        workspaces = [json.loads(r[0]) for r in rows]
        return [{"id": w["id"], "created_at": w["created_at"], "updated_at": w["updated_at"], "revision": w["revision"],
                 "name": w["facts"]["company.name"]["value"], "label": w.get("label"), "documents": len(w["documents"]),
                 "key_facts_confirmed": sum(w["facts"].get(p, {}).get("state") == "confirmed" for p in KEY_PATHS),
                 "key_facts_total": len(KEY_PATHS)} for w in sorted(workspaces, key=lambda w: w["updated_at"], reverse=True)]

    @contextmanager
    def edit(self, wid, expected=None):
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            require_owner(conn, wid)
            row = conn.execute("SELECT state FROM workspaces WHERE id=?", (wid,)).fetchone()
            if not row:
                raise KeyError("Workspace not found")
            ws = json.loads(row[0])
            hydrate(ws)
            if expected is not None and expected != ws["revision"]:
                raise RevisionConflict("Workspace changed. Reload before saving your changes.")
            yield ws
            conn.execute("UPDATE workspaces SET state=? WHERE id=?", (json.dumps(ws), wid))

    def reset(self, wid):
        with self.edit(wid) as ws:
            for doc in ws["documents"]:
                (self.root / "uploads" / doc["storage_name"]).unlink(missing_ok=True)
            revision = ws["revision"] + 1
            ws.clear()
            ws.update(empty_workspace(wid))
            ws["revision"] = revision
        return self.load(wid)

    def retrieval(self, sid):
        with self.connect() as conn:
            row = conn.execute("SELECT state FROM retrievals WHERE source_id=?", (sid,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_retrieval(self, sid, state):
        with self.connect() as conn:
            conn.execute("INSERT OR REPLACE INTO retrievals VALUES (?, ?)", (sid, json.dumps(state)))
