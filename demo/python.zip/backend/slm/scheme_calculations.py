"""Benefit calculations for schemes that do not fund a percentage of project costs.

WBSO lowers the payroll tax for R&D work. Its benefit follows from the R&D hours, the hourly wage and the
costs and expenses for R&D, with fixed rates per year. The figures below are RVO's own (Handleiding WBSO 2027);
RVO notes they are final once the Senate has approved the Belastingplan.
"""
from typing import TypedDict

WBSO_SOURCE = "https://www.rvo.nl/sites/default/files/2026-11/Handleiding_WBSO_2027_v1.pdf"
WBSO_2027 = {
    "year": 2027,
    "first_bracket_cents": 39_102_000,   # Upper limit of the first bracket of the R&D base (€391,020).
    "rate_first": 0.36,                  # Benefit on the first bracket.
    "rate_first_starter": 0.50,          # Benefit on the first bracket for starters.
    "rate_second": 0.16,                 # Benefit on the R&D base above the first bracket.
    "flat_hourly_wage_cents": 3_300,     # Flat R&D hourly wage when there is no wage history (€33).
    "flat_costs_cents": (1_000, 400),    # Flat costs and expenses per R&D hour: €10 up to 1,800 hours, €4 above.
    "flat_costs_hours": 1_800,
}


class WbsoEstimate(TypedDict):
    year: int
    hours: int
    hourly_wage_cents: int
    wage_cents: int
    costs_cents: int
    costs_basis: str
    base_cents: int
    first_bracket_cents: int
    second_bracket_cents: int
    rate_first: float
    rate_second: float
    benefit_cents: int
    source: str


def wbso_estimate(hours: int, hourly_wage_cents: int, starter: bool, actual_costs_cents: int | None) -> WbsoEstimate:
    """Estimated WBSO benefit for a company with employees: rate x (R&D wage costs + costs and expenses)."""
    if hours < 0 or hourly_wage_cents < 0 or (actual_costs_cents is not None and actual_costs_cents < 0):
        raise ValueError("Hours, hourly wage and costs cannot be negative.")
    p = WBSO_2027
    wage = hours * hourly_wage_cents
    if actual_costs_cents is None:
        low, high = p["flat_costs_cents"]
        costs = min(hours, p["flat_costs_hours"]) * low + max(0, hours - p["flat_costs_hours"]) * high
    else:
        costs = actual_costs_cents
    base = wage + costs
    first = min(base, p["first_bracket_cents"])
    second = base - first
    rate_first = p["rate_first_starter"] if starter else p["rate_first"]
    benefit = round(first * rate_first + second * p["rate_second"])
    return {"year": p["year"], "hours": hours, "hourly_wage_cents": hourly_wage_cents, "wage_cents": wage, "costs_cents": costs,
            "costs_basis": "flat" if actual_costs_cents is None else "actual", "base_cents": base, "first_bracket_cents": first,
            "second_bracket_cents": second, "rate_first": rate_first, "rate_second": p["rate_second"], "benefit_cents": benefit,
            "source": WBSO_SOURCE}
