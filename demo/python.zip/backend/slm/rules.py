from datetime import datetime, date, time
from zoneinfo import ZoneInfo
from decimal import Decimal
from .config import CATALOGUE, SOURCES, MAIN_GRANT, now
from .profiles import fact_value
from .budget import calculate, rounded

AMSTERDAM = ZoneInfo("Europe/Amsterdam")


def effective_time(mode, clock=None):
    if mode == "historical_rules_demo":
        return datetime(2026, 6, 15, 12, tzinfo=AMSTERDAM)
    return (clock or datetime.now(AMSTERDAM)).astimezone(AMSTERDAM)


def schedule_status(grant, effective, mode):
    schedule = grant["schedule"]
    if "opens_at" not in schedule:
        if mode == "historical_rules_demo":
            return "UNKNOWN"
        # A reviewed status is never extrapolated to arbitrary future dates.
        return "REPORTED_STATUS_ONLY" if effective.date().isoformat() == schedule["as_of"] else "UNKNOWN"
    opens = datetime.fromisoformat(schedule["opens_at"])
    closes = datetime.fromisoformat(schedule["closes_at"])
    if effective < opens:
        return "NOT_YET_OPEN"
    return "CLOSED" if effective > closes else "WITHIN_SCHEDULED_WINDOW"


def duration_check(start, end):
    if start is None or end is None:
        return None
    start, end = date.fromisoformat(start), date.fromisoformat(end)
    try:
        anniversary = start.replace(year=start.year+1)
    except ValueError:
        anniversary = start.replace(year=start.year+1, day=28)
    return start <= end <= anniversary


def evaluate(ws, clock=None):
    mode = ws["context"]["mode"]
    effective = effective_time(mode, clock)
    budget = calculate(ws)
    rd_rate = next(g["formula"]["rate_basis_points"] for g in CATALOGUE["grants"] if g["id"] == "ZH_MIT_RD_SMALL_2026")
    derived = {"derived.duration_within_one_year": duration_check(fact_value(ws, "project.start_date"), fact_value(ws, "project.end_date")),
               "derived.eligible_study_share_basis_points": budget["study_share_basis_points"],
               "derived.eligible_research_share_basis_points": budget["research_share_basis_points"],
               "derived.rd_uncapped_grant_cents": None if budget["proposed_eligible_cents"] is None else rounded(Decimal(budget["proposed_eligible_cents"]) * rd_rate / 10000)}
    grants = []
    for grant in CATALOGUE["grants"]:
        checks = []
        for rule in grant["rules"]:
            path = rule["field"]
            actual = derived.get(path) if path.startswith("derived.") else fact_value(ws, path)
            f = ws["facts"].get(path)
            paths = [path] if f else (["project.start_date", "project.end_date"] if rule["id"] == "F_DURATION" else ["budget"])
            evidence = f["evidence"] if f else ([ref for p in paths if p in ws["facts"] for ref in ws["facts"][p]["evidence"]] if "budget" not in paths else [ref for r in budget["rows"] for ref in r["evidence"]])
            if actual is None:
                outcome = "UNKNOWN"
                why = "Conflicting evidence requires resolution." if f and f["state"] == "conflict" else "Required information or calculation is unresolved."
            else:
                expected = rule["expected"]
                if rule["id"] == "F_STUDY_SHARE":
                    passed = budget["study_share_passes"]
                elif rule["id"] == "F_RESEARCH_SHARE":
                    passed = budget["research_share_passes"]
                elif rule["operator"] == "eq":
                    passed = actual.casefold() == expected.casefold() if isinstance(actual, str) and isinstance(expected, str) else actual == expected
                elif rule["operator"] == "in":
                    passed = actual in expected
                elif rule["operator"] == "gte":
                    passed = actual >= expected
                else:
                    passed = actual <= expected
                outcome = "PASS" if passed else "FAIL"
                why = f"Observed {actual!s}; requires {rule['operator']} {expected!s}."
                if f and f["state"] == "proposed":
                    why += " Uses an unconfirmed proposal."
                if rule["id"] in {"F_STUDY_SHARE", "F_RESEARCH_SHARE"}:
                    why += " Proposed classifications: " + "; ".join(f"{r['id']}={r['activity_group']}" for r in budget["rows"]) + ". Exact ratio compared before display rounding."
            checks.append({"rule_id": rule["id"], "label": rule["label"], "outcome": outcome, "actual": actual,
                           "required": {"operator": rule["operator"], "value": rule["expected"]}, "explanation": why,
                           "fact_ids": [ws["facts"][p]["id"] for p in paths if p in ws["facts"]], "field_paths": paths,
                           "evidence": evidence, "source_id": rule["source_id"], "source_locator": rule["source_locator"],
                           "source_url": SOURCES[rule["source_id"]]["url"], "question_id": rule.get("question_id"), "kind": rule["kind"]})
        manual = [{**c, "rule_id": c["id"], "outcome": "MANUAL_REVIEW", "source_url": SOURCES[c["source_id"]]["url"],
                   "explanation": "Requires human assessment even when a founder supplies an explanation."} for c in grant["manual_checks"]]
        deferred = []
        for check in grant.get("deferred_checks", []):
            award = fact_value(ws, "project.award_date")
            start = fact_value(ws, "project.start_date")
            if award is None:
                outcome, explanation = "NOT_APPLICABLE", "Deferred until an award date exists. Do not invent an award date."
            elif start is None:
                outcome, explanation = "UNKNOWN", "Project start date is unresolved."
            else:
                import calendar
                a, s = date.fromisoformat(award), date.fromisoformat(start)
                month = a.month-1+4
                y, m = a.year+month//12, month%12+1
                limit = date(y, m, min(a.day, calendar.monthrange(y, m)[1]))
                outcome = "PASS" if a <= s <= limit else "FAIL"
                explanation = f"Start {start}; award {award}; latest start {limit}."
            deferred.append({**check, "rule_id": check["id"], "outcome": outcome, "explanation": explanation,
                             "source_url": SOURCES[check["source_id"]]["url"]})
        relevant = [c for c in checks if c["kind"] == "hard"] + [c for c in deferred if c["outcome"] != "NOT_APPLICABLE"]
        failed = any(c["outcome"] == "FAIL" for c in relevant)
        unresolved = any(c["outcome"] == "UNKNOWN" for c in relevant) or bool(manual)
        suitability = "NOT_SUITABLE_AS_DESCRIBED" if failed else "POSSIBLE_NEEDS_REVIEW" if unresolved else "PASSES_IMPLEMENTED_CHECKS"
        if grant["instrument_type"] == "tax_relief":
            suitability = "RELEVANCE_ONLY"
        status = schedule_status(grant, effective, mode)
        grants.append({**grant, "call_status": status, "next_opening_date": None,
                       "call_note": "Within scheduled window does not establish remaining funds." if status == "WITHIN_SCHEDULED_WINDOW" else "Reviewed calendar/status only; no future opening date inferred.",
                       "schedule_source_url": SOURCES[grant["schedule"]["source_id"]]["url"],
                       "suitability": suitability, "checks": checks, "manual_checks": manual, "deferred_checks": deferred,
                       "budget": budget if grant["id"] == MAIN_GRANT else None,
                       "unknown_count": sum(c["outcome"] == "UNKNOWN" for c in checks),
                       "actionable_schedule": status == "WITHIN_SCHEDULED_WINDOW",
                       "profile_revision": ws["revision"], "mode": mode, "evaluated_at": now(),
                       "effective_datetime": effective.isoformat()})
    grants.sort(key=lambda g: (g["instrument_type"] != "cash_grant", g["suitability"] == "NOT_SUITABLE_AS_DESCRIBED",
                               not g["actionable_schedule"], g["unknown_count"], g["name"]))
    return {"profile_revision": ws["revision"], "mode": mode, "effective_datetime": effective.isoformat(), "evaluated_at": now(),
            "stale": False, "grants": grants, "budget": budget,
            "label": "Historical rules demo — 15 June 2026 (reviewed 2026 rules; not archived webpages)" if mode == "historical_rules_demo" else f"Current server date — {effective.date()} (Europe/Amsterdam)",
            "uses_unconfirmed_facts": any(f["state"] == "proposed" for f in ws["facts"].values())}
