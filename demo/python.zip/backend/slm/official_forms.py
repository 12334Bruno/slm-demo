"""Hand-checked official application forms for the most-used startup schemes.

The automatic reader turns any official form into questions. For the schemes most South-Holland
startups use, we go further and check the form by hand: every question keeps the funder's own heading
and instruction text, and is tied to the fillable field it belongs to. Character limits come from the form's own counter fields ("1500 tekens over."). Field names in these PDFs do not
always follow the order of the questions (in the WBSO research form, field "Vraag3" holds question 2),
so each field was matched to its question by its position on the page.

A checked form replaces the automatically read questions for that scheme, and the founder can download
the official PDF filled with their answers. The funder's online form asks the same questions; RVO says to
prepare the PDF first and copy the answers into the online form.
"""
import re
from io import BytesIO
from typing import NotRequired, TypedDict

from pypdf import PdfReader, PdfWriter

from .profiles import fact_value


class FormQuestion(TypedDict, total=False):
    key: str
    heading: str
    group: str
    page: int
    fields: list[str]
    instructions: list[str]
    prompt: str
    max_characters: int
    required: bool
    control: dict
    kind: str  # "text" (one field), "date" (dd-mm-jjjj), "choice" (export value), "rows" (activity + date per line)
    counter: str  # The form's own "characters left" field; its default text states the limit.


class OfficialForm(TypedDict):
    title: str
    url: str
    fillable: bool  # True when the questions are fields of a fillable PDF; False for a writing structure such as a guide.
    checked_on: str
    profile_fields: dict
    switches: list
    questions: list[FormQuestion]
    alternatives: list[dict]
    variant: NotRequired[dict]  # For a scheme with several forms: the short choice label and a plain explanation for the founder.


WBSO_DEVELOPMENT = "https://www.rvo.nl/sites/default/files/2026-01/Projectformulier_WBSO_ontwikkelingsproject_fysiek_product_of_productieproces_v1.81.pdf"
WBSO_SOFTWARE = "https://www.rvo.nl/sites/default/files/2025-11/Projectformulier_WBSO_ontwikkelingsproject_programmatuur_v1.8.pdf"
COSTS_GROUP = "Alleen als u kiest voor toekenning op basis van werkelijke kosten en uitgaven"
SOFTWARE_GROUP = "Alleen als u in dit project ook technisch nieuwe programmatuur ontwikkelt"

FORMS: dict[str, OfficialForm] = {
    "wbso-development": {
        "title": "Projectformulier WBSO ontwikkelingsproject fysiek product of productieproces (v1.81)",
        "url": WBSO_DEVELOPMENT,
        "fillable": True,
        "checked_on": "2026-11-12",
        "variant": {"label": "Physical product or production process",
                    "explanation": "Choose this when you develop a technically new device, material or production process. Software that is part of it is described in the same form."},
        "profile_fields": {"Bedrijfsnaam": "company.name", "KvK-nummer": "company.registration_number"},
        # A yes/no field the form derives from other answers: "Do you also develop software in this project?"
        "switches": [{"field": "WbsoMedeProgrammatuurOntwikkeld", "on": "/J", "off": "/N", "when_any": [
            "software-problems", "software-solutions", "software-tools", "software-novelty"]}],
        "alternatives": [
            {"title": "Projectformulier WBSO ontwikkelingsproject programmatuur (v1.8) — for projects that are mainly software",
             "url": WBSO_SOFTWARE, "form": "wbso-software"},
            {"title": "Projectformulier WBSO technisch-wetenschappelijk onderzoek (v1.8) — for research that seeks an explanation",
             "url": "https://www.rvo.nl/sites/default/files/2025-11/Projectformulier_WBSO_technisch-wetenschappelijk_onderzoek_v1.8.pdf"},
        ],
        "questions": [
            {"key": "project-number", "heading": "Projectnummer", "group": "Projectgegevens", "page": 1, "fields": ["Projectnummer"],
             "max_characters": 25, "instructions": ["Elk project dient gekenmerkt te worden door een projectnummer en een naam."],
             "control": {"type": "text"}},
            {"key": "project-title", "heading": "Projecttitel", "group": "Projectgegevens", "page": 1, "fields": ["Projectnaam"],
             "max_characters": 200, "instructions": ["Elk project dient gekenmerkt te worden door een projectnummer en een naam."],
             "control": {"type": "text"}},
            {"key": "focus", "heading": "Kies het zwaartepunt waar de ontwikkeling zich voornamelijk op richt", "group": "Projectgegevens",
             "page": 1, "fields": ["WbsoProjectzwaartepunt"], "kind": "choice",
             "control": {"type": "select", "options": ["Technisch nieuw product", "Technisch nieuw productieproces"],
                         "values": {"Technisch nieuw product": "PDT", "Technisch nieuw productieproces": "PPS"}}},
            {"key": "description", "max_characters": 1500, "counter": "tellerProjectomschrijving", "heading": "Projectomschrijving", "group": "Projectgegevens", "page": 2, "fields": ["WbsoProjectomschrijving"],
             "instructions": ["Geef een algemene omschrijving van het project.",
                              "Beschrijf in uw eigen woorden wat u wilt gaan ontwikkelen en wat het doel is van het project."]},
            {"key": "start", "heading": "Startdatum project", "group": "Projectgegevens", "page": 2, "fields": ["DatumStart"], "kind": "date",
             "instructions": ["Het project is/wordt gestart op: Let op: gebruik formaat dd-mm-jjjj",
                              "De periode van de WBSO-aanvraag kan, maar hoeft niet overeen te komen met de startdatum van het project."],
             "control": {"type": "date"}},
            {"key": "phases", "heading": "Fasering werkzaamheden", "group": "Projectgegevens", "page": 3, "kind": "rows",
             "fields": [f"Ontwikkeling{i}" for i in range(1, 11)] + [f"DatumGereed{i}" for i in range(1, 11)],
             "instructions": ["Omschrijf per fase uw eigen projectwerkzaamheden (S&O-werkzaamheden van het bedrijf waarvoor u deze WBSO-aanvraag indient). "
                              "Uit de fasering moet ook de vermoedelijke einddatum van het S&O-project blijken. U kunt maximaal 10 regels invoeren.",
                              "Geef uw belangrijkste S&O-werkzaamheden in het project aan. Voorbeelden van werkzaamheden: ontwerpfase, bouw van een prototype, testen van een prototype."],
             "prompt": "One phase per line, ending with the date it is ready (dd-mm-jjjj). For example: Bouw eerste prototype 30-06-2027"},
            {"key": "problems", "max_characters": 1500, "counter": "tellerKnelpuntenFysiek", "heading": "1. Technische knelpunten", "group": "Specifieke vragen ontwikkeling", "page": 4, "fields": ["WbsoTWOVraag1"],
             "instructions": ["Geef aan welke concrete technische knelpunten u zelf tijdens het ontwikkelingsproces moet oplossen om het gewenste projectresultaat te bereiken. "
                              "Vermeld geen aanleidingen, algemene randvoorwaarden of functionele eisen van het project.",
                              "Knelpunten zijn verwachte problemen, risico’s, onzekerheden en uitdagingen tijdens uw ontwikkeling.",
                              "Beschrijf deze technische problemen zo concreet mogelijk. Vermeld geen technische knelpunten die door eventuele samenwerkende partijen worden opgelost."]},
            {"key": "solutions", "max_characters": 1500, "counter": "tellerOplossingenFysiek", "heading": "2. Technische oplossingsrichtingen", "group": "Specifieke vragen ontwikkeling", "page": 4, "fields": ["WbsoTWOVraag2"],
             "instructions": ["Geef voor ieder genoemd technisch knelpunt aan wat u specifiek zelf gaat ontwikkelen om het knelpunt op te lossen. "
                              "U moet een idee hebben hoe u de genoemde technische knelpunten wilt gaan oplossen.",
                              "Beschrijf de technische oplossingsrichtingen die u gaat onderzoeken, uitwerken en ontwikkelen. "
                              "Vermeld geen functionele eisen van het project, maar benadruk de techniek."]},
            {"key": "novelty", "max_characters": 1500, "counter": "tellerNieuwheidFysiek", "heading": "3. Technische nieuwheid", "group": "Specifieke vragen ontwikkeling", "page": 5, "fields": ["WbsoTWOVraag3"],
             "instructions": ["Geef aan waarom de hiervoor genoemde oplossingsrichtingen technisch nieuw voor u zijn. Oftewel beschrijf waarom het project technisch "
                              "vernieuwend en uitdagend is en geef aan welke technische risico’s en onzekerheden u hierbij verwacht.",
                              "Nieuwheid voor een ondernemer is niet hetzelfde als technische nieuwheid, zoals de WBSO vereist.",
                              "Kopiëren, imiteren of reverse-engineering van bestaande technologie valt niet onder de WBSO."]},
            {"key": "hours", "heading": "Aantal S&O-uren in de aanvraagperiode", "group": "Specifieke vragen ontwikkeling", "page": 5,
             "fields": ["WbsoSOUrenBegroot"], "control": {"type": "number", "min": 0, "step": "1"},
             "instructions": ["Geef aan hoeveel uur u in de aanvraagperiode van plan bent aan het project te besteden. "
                              "Let op: u kunt hier alleen uren invoeren voor medewerkers. Uren voor een zelfstandige kunt u alleen online in het online aanvraagformulier aangeven."]},
            {"key": "costs", "max_characters": 500, "counter": "tellerKostenOmschrijving", "heading": "Kosten", "group": COSTS_GROUP, "page": 6, "fields": ["WbsoKostenOmschrijving"], "required": False,
             "instructions": ["Kiest u voor een forfaitaire toekenning op basis van uw S&O-uren? Laat dan onderstaande velden leeg.",
                              "Kosten dienen uitsluitend dienstbaar en direct toerekenbaar te zijn aan de eigen S&O-werkzaamheden. "
                              "Benoem de verschillende kosten, licht de relatie van de kosten met het S&O-project toe en specificeer de afzonderlijke kosten in euro’s."]},
            {"key": "expenses", "max_characters": 500, "counter": "tellerUitgavenOmschrijving", "heading": "Uitgaven", "group": COSTS_GROUP, "page": 6, "fields": ["WbsoUitgavenOmschrijving"], "required": False,
             "instructions": ["Uitgaven dienen dienstbaar en direct toerekenbaar te zijn aan de eigen S&O-werkzaamheden. "
                              "Benoem het bedrijfsmiddel, licht de relatie met het S&O-project toe, geef aan voor hoeveel procent de uitgave is toe te rekenen "
                              "aan het S&O-project en specificeer de afzonderlijke uitgaven in euro’s."]},
            {"key": "software-problems", "max_characters": 1500, "counter": "tellerBeschrijvingTechnischProbleem", "heading": "Technische knelpunten programmatuur", "group": SOFTWARE_GROUP, "page": 7,
             "fields": ["WbsoBeschrijvingTechnischProbleem"], "required": False,
             "instructions": ["Geef aan welke concrete technische knelpunten u zelf tijdens het ontwikkelen van de programmatuur moet oplossen om het gewenste "
                              "projectresultaat te bereiken. Vermeld geen aanleidingen, algemene randvoorwaarden of functionele eisen van de programmatuur.",
                              "Beantwoord de programmatuurvragen niet als u programmatuur realiseert zonder dat er sprake is van technische nieuwe programmatuur, "
                              "zoals bijvoorbeeld PLC-besturing ter ondersteuning van uw ontwikkeling."]},
            {"key": "software-solutions", "max_characters": 1500, "counter": "tellerGekozenOplossingsrichting", "heading": "Oplossingsrichtingen programmatuur", "group": SOFTWARE_GROUP, "page": 7,
             "fields": ["WbsoGekozenOplossingsrichting"], "required": False,
             "instructions": ["Geef voor ieder genoemd technisch knelpunt aan wat u specifiek zelf gaat ontwikkelen om het knelpunt op te lossen. "
                              "Beschrijf de technische oplossingsrichtingen die u gaat onderzoeken, uitwerken en programmeren. "
                              "Vermeld geen functionele eisen van het project, maar benadruk de techniek."]},
            {"key": "software-tools", "max_characters": 1500, "counter": "tellerBestaandeMethodenEnTechnieken", "heading": "Programmeertalen, ontwikkelomgevingen en tools", "group": SOFTWARE_GROUP, "page": 8,
             "fields": ["WbsoBestaandeMethodenTechnieken"], "required": False,
             "instructions": ["Geef aan welke programmeertalen, ontwikkelomgevingen en tools u gebruikt bij de ontwikkeling van technisch nieuwe programmatuur.",
                              "Het invoeren en implementeren van bestaande applicaties komt niet in aanmerking."]},
            {"key": "software-novelty", "max_characters": 1500, "counter": "tellerBestaandeMethoden", "heading": "Technische nieuwheid programmatuur", "group": SOFTWARE_GROUP, "page": 8,
             "fields": ["WbsoZelfOntwikkelenMethoden"], "required": False,
             "instructions": ["Geef aan waarom de hiervoor genoemde oplossingsrichtingen technisch nieuw voor u zijn. Oftewel beschrijf waarom het project technisch "
                              "vernieuwend en uitdagend is en geef aan welke technische risico’s en onzekerheden u hierbij verwacht."]},
        ],
    },
    "wbso-software": {
        # Checked against the PDF on 2026-11-14. Fields were matched to questions by their position on the page: on page 5
        # "WbsoBestaandeMethodenTechnieken" holds question 3 (languages and tools) and "WbsoZelfOntwikkelenMethoden" question 4 (novelty).
        # The project type ("B") and focus ("PRG", software) fields are preset by RVO and left as they are.
        "title": "Projectformulier WBSO ontwikkelingsproject programmatuur (v1.8)",
        "url": WBSO_SOFTWARE,
        "fillable": True,
        "checked_on": "2026-11-14",
        "variant": {"label": "Software",
                    "explanation": "Choose this when the technically new part is software you program yourself, such as new algorithms or a new software architecture. Configuring or implementing existing applications does not count."},
        "profile_fields": {"Bedrijfsnaam": "company.name", "KvK-nummer": "company.registration_number"},
        "switches": [],
        "alternatives": [],
        "questions": [
            {"key": "project-number", "heading": "Projectnummer", "group": "Projectgegevens", "page": 1, "fields": ["Projectnummer"],
             "max_characters": 25, "instructions": ["Elk project dient gekenmerkt te worden door een projectnummer en een naam."],
             "control": {"type": "text"}},
            {"key": "project-title", "heading": "Projecttitel", "group": "Projectgegevens", "page": 1, "fields": ["Projectnaam"],
             "max_characters": 200, "instructions": ["Elk project dient gekenmerkt te worden door een projectnummer en een naam."],
             "control": {"type": "text"}},
            {"key": "description", "max_characters": 1500, "counter": "tellerProjectomschrijving", "heading": "Projectomschrijving", "group": "Projectgegevens",
             "page": 2, "fields": ["WbsoProjectomschrijving"],
             "instructions": ["Geef een algemene omschrijving van het project.",
                              "Beschrijf in uw eigen woorden wat u wilt gaan ontwikkelen en wat het doel is van het project."]},
            {"key": "collaboration", "heading": "Samenwerking", "group": "Projectgegevens", "page": 2, "fields": ["Samenwerking"], "kind": "choice",
             "instructions": ["Levert een of meer partijen een bijdrage aan het project?"],
             "control": {"type": "select", "options": ["Nee", "Ja"], "values": {"Nee": "/SamenwerkingNee", "Ja": "/SamenwerkingJa"}}},
            {"key": "partners", "heading": "Samenwerkingspartners", "group": "Projectgegevens", "page": 2, "kind": "partners", "required": False,
             "fields": [f"Projectrelatienaam{i}" for i in range(1, 6)] + [f"Projectrelatieplaats{i}" for i in range(1, 6)] + [f"Projectrol{i}" for i in range(1, 6)],
             "instructions": ["Als één of meerdere andere partijen betrokken zijn bij het project (zoals een holding B.V. of een onderzoeksinstelling), "
                              "geef dan aan welke partijen dat zijn en welke werkzaamheden zij verrichten.",
                              "De lijst is gemaximaliseerd op vijf. Indien er meer partijen zijn, beperkt u zich tot de meest relevante."],
             "prompt": "One partner per line: name; place; contribution (at most 80 characters). For example: TU Delft; Delft; test data en validatie"},
            {"key": "start", "heading": "Start project", "group": "Projectgegevens", "page": 2, "fields": ["DatumStart"], "kind": "date",
             "instructions": ["Het project is/wordt gestart op: Let op: gebruik formaat dd-mm-jjjj",
                              "De periode van de WBSO-aanvraag kan, maar hoeft niet overeen te komen met de startdatum van het project."],
             "control": {"type": "date"}},
            {"key": "phases", "heading": "Fasering werkzaamheden", "group": "Projectgegevens", "page": 3, "kind": "rows",
             "fields": [f"Ontwikkeling{i}" for i in range(1, 11)] + [f"DatumGereed{i}" for i in range(1, 11)],
             "instructions": ["Omschrijf per fase uw eigen projectwerkzaamheden (S&O-werkzaamheden van het bedrijf waarvoor u deze WBSO-aanvraag indient). "
                              "Uit de fasering moet ook de vermoedelijke einddatum van het S&O-project blijken. U kunt maximaal 10 regels invoeren.",
                              "Geef uw belangrijkste S&O-werkzaamheden in het project aan. Voorbeelden van werkzaamheden: technisch ontwerp, ontwikkelen component X, technisch testen."],
             "prompt": "One phase per line, ending with the date it is ready (dd-mm-jjjj). For example: Ontwikkelen matching-algoritme 30-06-2027"},
            {"key": "update", "max_characters": 1500, "counter": "tellerWijzigingPlanning", "heading": "Update project", "group": "Projectgegevens", "page": 3,
             "fields": ["WbsoToelichtingWijzigingPlanning"], "required": False,
             "instructions": ["Vermeld de voortgang van uw S&O-werkzaamheden.",
                              "Als u voor dit project voor het eerst WBSO aanvraagt dan kunt u dit veld leeg laten."]},
            {"key": "problems", "max_characters": 1500, "counter": "tellerBeschrijvingTechnischProbleem", "heading": "1. Technische knelpunten programmatuur",
             "group": "Specifieke vragen programmatuur", "page": 4, "fields": ["WbsoBeschrijvingTechnischProbleem"],
             "instructions": ["Geef aan welke concrete technische knelpunten of problemen op het gebied van informatietechnologie u zelf tijdens het ontwikkelen van de "
                              "programmatuur moet oplossen om het gewenste projectresultaat te bereiken. Vermeld geen aanleidingen, algemene randvoorwaarden of functionele eisen van de programmatuur.",
                              "Knelpunten zijn verwachte problemen, risico’s, onzekerheden en uitdagingen tijdens uw ontwikkeling.",
                              "Beschrijf deze technische problemen zo concreet mogelijk. Vermeld geen technische knelpunten die door eventuele samenwerkende partijen worden opgelost."]},
            {"key": "solutions", "max_characters": 1500, "counter": "tellerGekozenOplossingsrichting", "heading": "2. Technische oplossingsrichtingen programmatuur",
             "group": "Specifieke vragen programmatuur", "page": 4, "fields": ["WbsoGekozenOplossingsrichting"],
             "instructions": ["Geef voor ieder genoemd technisch knelpunt aan wat u specifiek zelf gaat ontwikkelen om het knelpunt op te lossen.",
                              "Beschrijf de technische oplossingsrichtingen die u gaat onderzoeken, uitwerken en programmeren. Vermeld geen functionele eisen van het project, maar benadruk de techniek."]},
            {"key": "tools", "max_characters": 1500, "counter": "tellerBestaandeMethodenEnTechnieken", "heading": "3. Programmeertalen, ontwikkelomgevingen en tools",
             "group": "Specifieke vragen programmatuur", "page": 5, "fields": ["WbsoBestaandeMethodenTechnieken"],
             "instructions": ["Geef aan welke programmeertalen, ontwikkelomgevingen en tools u gebruikt bij de ontwikkeling van technisch nieuwe programmatuur.",
                              "Het invoeren en implementeren van bestaande applicaties komt niet in aanmerking."]},
            {"key": "novelty", "max_characters": 1500, "counter": "tellerBestaandeMethoden", "heading": "4. Technische nieuwheid programmatuur",
             "group": "Specifieke vragen programmatuur", "page": 5, "fields": ["WbsoZelfOntwikkelenMethoden"],
             "instructions": ["Geef aan waarom de hiervoor genoemde oplossingsrichtingen technisch nieuw voor u zijn. Oftewel beschrijf waarom het project technisch "
                              "vernieuwend en uitdagend is en geef aan welke technische risico’s en onzekerheden u hierbij verwacht.",
                              "Nieuwheid voor een ondernemer is niet hetzelfde als technische nieuwheid, zoals de WBSO vereist. Als het beoogde eindresultaat kan worden "
                              "gerealiseerd op basis van gangbare technieken of algemeen bekende werkingsprincipes, dan is er geen sprake van ontwikkeling in de zin van de WBSO."]},
            {"key": "hours", "heading": "Uren", "group": "Specifieke vragen programmatuur", "page": 5,
             "fields": ["WbsoSOUrenBegroot"], "control": {"type": "number", "min": 0, "step": "1"},
             "instructions": ["Geef aan hoeveel uur u in de aanvraagperiode van plan bent aan het project te besteden. "
                              "Let op: u kunt hier alleen uren invoeren voor medewerkers. Uren voor een zelfstandige kunt u alleen online in het online aanvraagformulier aangeven."]},
            {"key": "costs", "max_characters": 500, "counter": "tellerKostenOmschrijving", "heading": "Kosten", "group": COSTS_GROUP, "page": 6, "fields": ["WbsoKostenOmschrijving"], "required": False,
             "instructions": ["Kiest u voor een forfaitaire toekenning op basis van uw S&O-uren? Laat dan onderstaande velden leeg.",
                              "Kosten dienen uitsluitend dienstbaar en direct toerekenbaar te zijn aan de eigen S&O-werkzaamheden. "
                              "Benoem de verschillende kosten, licht de relatie van de kosten met het S&O-project toe en specificeer de afzonderlijke kosten in euro’s."]},
            {"key": "expenses", "max_characters": 500, "counter": "tellerUitgavenOmschrijving", "heading": "Uitgaven", "group": COSTS_GROUP, "page": 6, "fields": ["WbsoUitgavenOmschrijving"], "required": False,
             "instructions": ["Uitgaven dienen dienstbaar en direct toerekenbaar te zijn aan de eigen S&O-werkzaamheden. Het bedrijfsmiddel mag niet eerder zijn gebruikt. "
                              "Benoem het bedrijfsmiddel, licht de relatie met het S&O-project toe, geef aan voor hoeveel procent de uitgave is toe te rekenen "
                              "aan het S&O-project en specificeer de afzonderlijke uitgaven in euro’s."]},
        ],
    },
    "innovatiekrediet-plan": {
        "title": "Innovatiekrediet: business-, project- en financieringsplan (Handleiding voor het schrijven van een aanvraag)",
        "url": "https://www.rvo.nl/sites/default/files/2026-02/Handleiding%20voor%20aanvraag%20Innovatiekrediet.pdf",
        "fillable": False,
        "checked_on": "2026-11-12",
        "profile_fields": {},
        "switches": [],
        "alternatives": [],
        "questions": [
            {"key": "summary", "heading": "Samenvatting", "group": "Samenvatting", "page": 3, "fields": [], "instructions": ["Geef hier een kernachtig overzicht (maximaal 1 pagina) van:", "Het probleem/gat in de markt en hoe uw innovatie dit adresseert.", "De doelgroep en verwachte marktimpact.", "Het stadium van de ontwikkeling en de technische risico’s.", "De reden voor de aanvraag van het Innovatiekrediet.", "Korte beschrijving van uw bedrijf en het team.", "Overzicht van de benodigde en beschikbare financiering."]},
            {"key": "company", "heading": "1. Bedrijfsoverzicht", "group": "Businessplan", "page": 5, "fields": [], "instructions": ["Oprichtingsdatum en korte geschiedenis.", "Missie en visie van het bedrijf.", "Huidige activiteiten en producten (indien van toepassing).", "Organisatiestructuur: overzicht van teams, functies.", "Beschrijving van het huidige managementteam en hun relevante ervaring.", "HR-strategie: aanwerving van sleutelpersoneel en benodigde expertise."]},
            {"key": "problem", "heading": "2. Probleemstelling en marktbehoefte", "group": "Businessplan", "page": 6, "fields": [], "instructions": ["Wie is de eindgebruiker of klant?", "Wat is het probleem dat zij ervaren?", "Hoe heeft u dit probleem vastgesteld?", "Heeft u deze probleemstelling ook geverifieerd met de beoogde eindgebruiker of klant?", "Welke bestaande oplossingen in de markt adresseren dit probleem?", "Welk economisch voordeel valt er te behalen voor de klant?"]},
            {"key": "solution", "heading": "3. Oplossing en USP’s", "group": "Businessplan", "page": 7, "fields": [], "instructions": ["Welke oplossing biedt uw innovatie voor de geschetste problematiek?", "Wat maakt uw innovatie uniek in vergelijking tot bestaande oplossingen en nieuwe oplossingsrichtingen?", "Waarom is dit onderscheidend genoeg voor markttoetreding en (langdurige) groei?", "Waarom is een staatsinstrument als het Innovatiekrediet noodzakelijk om uw innovatie te realiseren?", "Hoe draagt uw product/oplossing bij aan de economische- en maatschappelijke belangen van Nederland?"]},
            {"key": "market", "heading": "4. Markt- en concurrentieanalyse", "group": "Businessplan", "page": 8, "fields": [], "instructions": ["Beschrijving van de marktgrootte en trends (in € of aantal gebruikers).", "Marktvalidatie: gesprekken met potentiële klanten, pilotprojecten, Letters of Intent (LOI's).", "Concurrenten en alternatieven.", "Objectieve vergelijking: hoe scoort de innovatie onder andere op prijs, prestaties, gebruiksgemak en duurzaamheid?", "Omzetprognoses voor 3– 5 jaar."]},
            {"key": "sales", "heading": "5. Marketing- en salesstrategie", "group": "Businessplan", "page": 9, "fields": [], "instructions": ["Verdienmodel (bv. verkoop, licentie, abonnement).", "Go-to-market , markttoetredingsstrategie (directe verkoop, partners, online, etc. ).", "Prijsstellingstrategie.", "Analyse van de kosten van uw product/dienst.", "Margeanalyse bij verschillende volumes."]},
            {"key": "csr", "heading": "6. Duurzaamheid en Maatschappelijk Verantwoord Ondernemen (MVO)", "group": "Businessplan", "page": 10, "fields": [], "instructions": ["Welke kansen/positieve effecten ziet u , benoem er minimaal 2.", "Welke risico’s ziet u en wat doet u om deze te mitigeren, benoem er minimaal 2.", "Hoe wordt MVO geborgd in beleid of bedrijfsvoering?"]},
            {"key": "start", "heading": "7. Startpositie project", "group": "Projectplan", "page": 11, "fields": [], "instructions": ["Wat heeft u tot nu toe technisch/klinisch bereikt (en wat is de onderbouwing van de “Proof-of-concept/principle” voor uw product/dienst/procedé)?", "Wat maakt uw oplossing technisch, procesmatig of klinisch gezien nieuw?", "Wat maakt uw oplossing innovatief binnen de context van bestaande alternatieven?"]},
            {"key": "challenges", "heading": "8. Technische en klinische uitdagingen", "group": "Projectplan", "page": 12, "fields": [], "instructions": ["Wat zijn de technische (en/of klinische) eindspecificaties waar u naartoe werkt? Hoe ver ligt dit nog van wat u nu heeft bereikt?", "Wat zijn de belangrijkste technische of klinische uitdagingen die u nog moet tackelen? En waar zitten de grootste risico’s?", "Heeft u alternatieve plannen als een belangrijk onderdeel tegenvalt?", "Bent u in uw ontwikkeling afhankelijk van partners en/of externe partijen (zoals leveranciers, klinische partners, certificeringsinstanties)?"]},
            {"key": "phasing", "heading": "9. Projectfasering", "group": "Projectplan", "page": 13, "fields": [], "instructions": ["Welke concrete deliverables wilt u in de looptijd van het project behalen en wanneer?", "Geef aan wie welke werkzaamheden uitvoert of bewaakt.", "Zorg ervoor dat de uitkomsten van uw werk (deliverables) duidelijk zijn omschreven, formuleer zo SMART mogelijk.", "Gebruik een planning in beeld (bijv. een GANTT-chart, PERT-diagram of ander schema)."]},
            {"key": "risks", "heading": "10. Risicoanalyse", "group": "Projectplan", "page": 14, "fields": [], "instructions": ["Welke methode u gebruikt voor risicomanagement op projectniveau.", "Wat de belangrijkste risico’s zijn (standaard risico’s mag u kort benoemen, tenzij ze cruciaal zijn voor de planning of projectfasering).", "Wanneer in het project de risico’s zich kunnen voordoen.", "Gebruik bijvoorbeeld een FMEA om risico’s, ernst en impact inzichtelijk te maken."]},
            {"key": "team", "heading": "11. Projectteam", "group": "Projectplan", "page": 15, "fields": [], "instructions": ["Wie zijn de sleutelfiguren in uw team? Wat is hun expertise en waarom zijn zij geschikt?", "Wat is de beschikbaarheid (FTE-inzet) van de kernteamleden tijdens het project?", "Moet er nog externe expertise worden ingehuurd? Zo ja, waarom en wanneer en hoe?"]},
            {"key": "ip", "heading": "12. Intellectual Property (IP) en bedrijfsmiddelen", "group": "Projectplan", "page": 16, "fields": [], "instructions": ["Wat uw IP-strategie is (beschermen, aanvragen, etc.).", "Welke octrooien al zijn aangevraagd of verleend (noem titel, nummers, publicatiedatum en landen/procedures).", "Waarom is uw IP essentieel voor uw concurrentiepositie of verdienmodel?"]},
            {"key": "budget", "heading": "13. Projectbegroting", "group": "Projectplan", "page": 17, "fields": [], "instructions": ["Voor de projectbegroting gebruik u het verplichte Excel-format op de website van het Innovatiekrediet.", "Licht de belangrijkste kostenposten toe, zowel intern als extern.", "Onvoorziene kosten zijn niet subsidiabel – die moet u zelf opvangen."], "budget": True},
            {"key": "financing", "heading": "14. Financiering en gegevens", "group": "Financieringsplan", "page": 18, "fields": [], "instructions": ["Juridische structuur (bijv. BV, VOF).", "Aandeelhouders en cap table (incl. oprichters en investeerders).", "Overzicht van reeds opgehaalde financiering (eigen middelen, subsidies, investeerders).", "Maak de voorziene financiering zo concreet mogelijk door financieringsovereenkomsten en/of 'term sheets' aan te leveren.", "De financiering moet voldoende ruimte bieden voor projectuitloop en/of overschrijding"], "budget": True},
            {"key": "model", "heading": "15. Financiële model", "group": "Financieringsplan", "page": 20, "fields": [], "instructions": ["Geef gedurende de looptijd van het project inzage in de financiële ontwikkeling per kwartaal.", "Neem in de balans een uitsplitsing van de overige verstrekkers van het vreemd vermogen op."], "budget": True},
        ],
    },
}


def form_for(record):
    """The checked form of a focus scheme's catalogue record, if it has one."""
    from .focus_grants import FOCUS
    entry = next((f for f in FOCUS if f["key"] == record.get("focus_key")), None)
    return FORMS[entry["official_form"]] if entry and entry.get("official_form") else None


def official_documents(record):
    """Documents to read with the grant: the checked form to fill, alternatives that are checked forms too (read so the
    founder can switch, see variants_for), and the other alternatives as links."""
    form = form_for(record)
    if form is None:
        return []
    return [{"title": form["title"], "url": form["url"], "role": "template"}] + [
        {"title": alternative["title"], "url": alternative["url"], "role": "template" if alternative.get("form") else "guidance"}
        for alternative in form["alternatives"]]


def section_id(form, question):
    return "form-" + re.sub(r"[^a-z0-9]+", "-", form["url"].rsplit("/", 1)[-1].casefold())[:40] + "-" + question["key"]


def checked_sections(form, document):
    """Application sections of a checked form whose PDF (or guide) was retrieved as ``document``."""
    sections = []
    for question in form["questions"]:
        where = f"PDF page {question['page']}" + (f" · field {question['fields'][0]}" if form["fillable"] else "")
        proof = {"url": form["url"], "block_id": None, "locator": where,
                 "quote": question["heading"], "snapshot_hash": document["sha256"]}
        sections.append({"id": section_id(form, question), "heading": question["heading"], "group": question["group"],
                         "required": question.get("required", True), "evidence": proof, "template_url": form["url"] if form["fillable"] else None,
                         "instructions": [{"text": text, "evidence": {**proof, "quote": text}} for text in question.get("instructions", [])],
                         "max_words": None, "max_characters": question.get("max_characters"), "page_hint": f"page {question['page']}",
                         "assessment_aspects": [], "budget": question.get("budget", False), "checked_form": True,
                         **({"control": question["control"]} if question.get("control") else {}),
                         **({"prompt": question["prompt"]} if question.get("prompt") else {})})
    return sections


def retrieved(bundle, url):
    return next((d for d in bundle if d.get("url") == url and d.get("blocks")), None)


def sections_for(record, bundle):
    """Application sections from the checked form, when its PDF was retrieved with the grant's documents."""
    form = form_for(record)
    if form is None:
        return None
    document = retrieved(bundle, form["url"])
    if document is None:
        return None  # Without the official PDF there is nothing to fill; the automatic reading stays.
    return checked_sections(form, document)


def variants_for(record, bundle):
    """For a scheme with several checked forms (WBSO: physical product or software), every form the founder can choose.

    The first is the scheme's main form. Each application stores its choice; see applications.with_variant.
    Empty when the scheme has one form or when no alternative PDF was retrieved.
    """
    form = form_for(record)
    if form is None:
        return {}
    keys = [next(k for k, f in FORMS.items() if f is form)] + [a["form"] for a in form["alternatives"] if a.get("form")]
    variants = {}
    for key in keys:
        document = retrieved(bundle, FORMS[key]["url"])
        if document is not None:
            variants[key] = {**FORMS[key]["variant"], "title": FORMS[key]["title"], "url": FORMS[key]["url"],
                             "sha256": document["sha256"], "sections": checked_sections(FORMS[key], document)}
    return variants if len(variants) > 1 else {}


def field_values(form, answers, ws):
    """PDF field -> value for every answered question, in the formats the form asks for."""
    values = {}
    for pdf_field, path in form["profile_fields"].items():
        value = fact_value(ws, path)
        if value:
            values[pdf_field] = str(value)
    for question in form["questions"]:
        text = (answers.get(question["key"]) or "").strip()
        if not text:
            continue
        kind = question.get("kind", "text")
        if kind == "date":
            iso = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", text)
            values[question["fields"][0]] = f"{iso[3]}-{iso[2]}-{iso[1]}" if iso else text
        elif kind == "choice":
            mapping = question["control"]["values"]
            if text not in mapping:
                raise ValueError(f"“{question['heading']}” must be one of: {', '.join(mapping)}")
            values[question["fields"][0]] = mapping[text]
        elif kind == "partners":
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            count = len(question["fields"]) // 3
            if len(lines) > count:
                raise ValueError(f"“{question['heading']}” allows at most {count} partners; you wrote {len(lines)}.")
            for index, line in enumerate(lines):
                parts = [part.strip() for part in line.split(";")]
                if len(parts) != 3 or not all(parts):
                    raise ValueError(f"“{question['heading']}”, line {index + 1}: write each partner as name; place; contribution.")
                for offset, (part, limit) in enumerate(zip(parts, (60, 60, 80))):
                    if len(part) > limit:
                        raise ValueError(f"“{question['heading']}”, line {index + 1}: “{part[:30]}…” is longer than {limit} characters.")
                    values[question["fields"][offset * count + index]] = part
        elif kind == "rows":
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            half = len(question["fields"]) // 2
            if len(lines) > half:
                raise ValueError(f"“{question['heading']}” allows at most {half} lines; you wrote {len(lines)}.")
            for index, line in enumerate(lines):
                dated = re.match(r"(.*?)[\s,;:–-]*(\d{1,2}-\d{1,2}-\d{4})\s*$", line)
                values[question["fields"][index]] = (dated[1] if dated else line).strip()
                if dated:
                    values[question["fields"][half + index]] = dated[2]
        else:
            values[question["fields"][0]] = text
            if question.get("counter"):
                values[question["counter"]] = f"{question['max_characters'] - len(text)} tekens over."
    for switch in form["switches"]:
        values[switch["field"]] = switch["on"] if any((answers.get(k) or "").strip() for k in switch["when_any"]) else switch["off"]
    return values


def fill(form, template_bytes, answers, ws):
    """The official PDF with the answers in its own fields; every written value is read back to confirm it."""
    missing = [q["heading"] for q in form["questions"] if q.get("required", True) and not (answers.get(q["key"]) or "").strip()]
    if missing:
        raise ValueError("Complete these questions before downloading the filled form: " + "; ".join(missing))
    values = field_values(form, answers, ws)
    writer = PdfWriter(clone_from=PdfReader(BytesIO(template_bytes)))
    for page in writer.pages:
        writer.update_page_form_field_values(page, values, auto_regenerate=False)
    writer.set_need_appearances_writer(True)
    out = BytesIO()
    writer.write(out)
    written = PdfReader(BytesIO(out.getvalue())).get_fields() or {}
    wrong = [name for name, value in values.items() if str((written.get(name) or {}).get("/V", "")) != value]
    if wrong:
        raise ValueError("The official form could not be filled reliably (fields: " + ", ".join(wrong) + "). Use the preparation package.")
    return out.getvalue()
