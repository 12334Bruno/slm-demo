"""Source-based controls for application answers, documents and instructions."""
from datetime import date
from decimal import Decimal, InvalidOperation
import re


def answer_control(question):
    title = re.sub(r"^\s*\d+(?:\.\d+)*[.)]?\s+", "", question["heading"]).strip()
    if len(title) > 220:
        return {"type": "textarea"}
    if re.search(r"(?i)\b(start date|end date|completion date|commencement date|date of birth|startdatum|einddatum)\b", title):
        return {"type": "date"}
    if re.search(r"(?i)\b(how many|number of|aantal)\b", title):
        return {"type": "number", "min": 0, "step": "1"}
    if re.search(r"(?i)\b(requested (?:grant|funding|amount)|total (?:project )?(?:budget|costs)|grant amount|aangevraagd bedrag|totale kosten)\b", title):
        return {"type": "number", "min": 0, "step": "0.01", "unit": "EUR"} if re.search(r"(?i)\bEUR\b|€", title) else {"type": "number", "min": 0, "step": "0.01"}
    if (re.match(r"(?i)^(?:do you|does your|is your|are you|have you|has your|will you|confirm that|bent u|heeft u)\b", title)
            and not re.search(r"(?i)\b(describe|explain|outline|provide|beschrijf|licht toe)\b", title)) or re.search(r"(?i)\byes\s*/\s*no\b|\bja\s*/\s*nee\b", title):
        return {"type": "select", "options": ["Yes", "No"]}
    return {"type": "textarea"}


def validate_answer(question, text):
    text = text.strip()
    if not text:
        return text
    control = answer_control(question)
    if control["type"] == "date":
        try:
            return date.fromisoformat(text).isoformat()
        except ValueError:
            raise ValueError("Enter a valid date for this question") from None
    if control["type"] == "select" and text not in control["options"]:
        raise ValueError("Choose one of the options for this question")
    if control["type"] == "number":
        try:
            value = Decimal(text)
        except InvalidOperation:
            raise ValueError("Enter a valid number for this question") from None
        if not value.is_finite() or value < 0 or value > 1_000_000_000_000:
            raise ValueError("Enter a finite nonnegative number within the supported limit")
        if control["step"] == "1" and value != value.to_integral_value():
            raise ValueError("Enter a whole number for this question")
    return text


DOCUMENT = re.compile(
    r"(?i)\b(financ(?:ial|ing) (?:statement|plan|report)|annual (?:accounts|report)|audited accounts|"
    r"bank statement|business plan|project plan|work plan|consortium agreement|support(?:ing)? letter|letter of (?:support|intent)|"
    r"(?:signed|completed) (?:application )?(?:form|declaration)|certificate|registration (?:extract|document)|"
    r"proof of|curriculum vitae|CVs?|budget (?:spreadsheet|breakdown)|insurance|ethics (?:statement|approval)|"
    r"data management plan|supporting documents?|technical report|feasibility report|impact report|"
    r"participation sheets?|participant sheets?|participation forms?|deelnemersformulier|deelnameformulier|"
    r"jaarrekening|projectplan|financieringsverklaring|begroting|uittreksel|ondertekend)\b")
FORMATS = {"pdf": ("pdf",), "docx": ("docx", "word"), "xlsx": ("xlsx", "excel"),
           "png": ("png",), "jpg": ("jpg", "jpeg")}


def evidence_control(item):
    text = item.get("text") or (item.get("evidence") or {}).get("quote") or item["title"]
    # A generic instruction to upload the application/PDF on the funder's site
    # does not request a separate supporting document in this workspace.
    conditional = bool(re.search(r"(?i)\b(some calls|may require|where applicable|if requested|if required|depending on|indien|eventueel)\b", text))
    action = bool(re.search(r"(?i)\b(upload(?:ed|ing)?|download(?:ed|ing)?|submit(?:ted|ting)?|submission|attach|attaching|"
                            r"provide|enclose|meesturen|bijvoegen|indienen)\b|\b(?:be|must be|shall be) attached\b|"
                            r"\b(?:filled|completed) in (?:directly )?online\b", text))
    if not action and not DOCUMENT.search(text):
        return {"kind": None, "accepted_types": []}
    kind = "document" if DOCUMENT.search(text) and not conditional else "instruction"
    accepted = [extension for extension, names in FORMATS.items()
                if any(re.search(r"(?i)\b" + re.escape(name) + r"\b", text) for name in names)] if kind == "document" else []
    return {"kind": kind, "accepted_types": accepted}


def evidence_prompt(text):
    """Form fields requesting files/instructions belong with evidence, not prose answers."""
    title = re.sub(r"^\s*\d+(?:\.\d+)*[.)]?\s+", "", text).strip().rstrip(".:")
    if DOCUMENT.fullmatch(title) and not re.fullmatch(r"(?i)(?:business|project|work|data management) plan", title):
        return True
    if re.match(r"(?i)^(?:please\s+)?(?:attach|upload|download|voeg bij|bijvoegen)\b", text.strip()):
        return True
    if re.match(r"(?i)^(?:required |supporting )?(?:documents|attachments|bijlagen)\b|^application form\s*$", text.strip()):
        return True
    return bool(re.match(r"(?i)^(?:submit|complete|use)\b", text.strip()) and re.search(r"(?i)\b(?:PDF|portal|website|online form)\b", text))


# Only unambiguous form labels can write back to the reusable profile.
PROFILE_QUESTIONS = {
    "company name": "company.name", "organisation name": "company.name",
    "organization name": "company.name", "legal company name": "company.name",
    "company country": "company.country", "country of registration": "company.country",
    "company province": "company.province", "company city": "company.city",
    "registration number": "company.registration_number", "company registration number": "company.registration_number",
    "project name": "project.name", "project title": "project.name",
    "project summary": "project.description", "project description": "project.description",
    "planned start date": "project.start_date", "project start date": "project.start_date",
    "planned end date": "project.end_date", "project end date": "project.end_date",
}


def profile_field(question):
    title = re.sub(r"^\s*\d+(?:\.\d+)*[.)]?\s+", "", question["heading"])
    return PROFILE_QUESTIONS.get(title.strip().rstrip(":?").casefold())


def answer_guidance(question):
    """Preparation help, not an invented funder requirement."""
    text = question["heading"].casefold()
    control = answer_control(question)
    if control["type"] == "date":
        return "Enter the planned date for this project."
    if control["type"] == "number":
        return "Enter the amount in EUR." if control.get("unit") == "EUR" else "Enter the number requested for this project."
    if control["type"] == "select":
        return "Choose the answer that reflects your current situation."
    if profile_field(question) == "project.description":
        return "Explain the problem, what you plan to do and the result you want. A few clear sentences are a good start."
    if any(word in text for word in ("feasibility", "haalbaarheid")):
        return "Explain what you still need to test, how you will test it and how you will decide whether the project can go ahead."
    if any(word in text for word in ("impact", "benefit", "result", "outcome")):
        return "Describe who will benefit and what will change. Include measurable results where you have them."
    if any(word in text for word in ("activit", "work plan", "planning")):
        return "Describe the main tasks, who will carry them out and the planned timing."
    if any(word in text for word in ("innovat", "technical", "technolog")):
        return "Explain what is new, how it differs from existing solutions and what still needs development."
    if profile_field(question):
        return "Use your current business or project details. You can reuse a saved detail below."
    return "Answer this part for the project you want funded. Use the official wording below to check what to include."
