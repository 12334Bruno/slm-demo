"""Parse bytes, retaining genuine page/paragraph/cell/line locations."""
import hashlib
import re
import zipfile
from io import BytesIO
from pathlib import Path
from uuid import uuid4
from docx import Document
from docx.oxml.ns import qn
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pypdf import PdfReader
from . import ocr
from .config import now
from .spreadsheets import workbook_blocks

MAX_FILE = 25 * 1024 * 1024
MAX_TEXT = 150_000
MAX_PAGES = 30
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg"}
TEXT_SUFFIXES = {".txt", ".md"}
SUPPORTED = TEXT_SUFFIXES | {".pdf", ".docx", ".pptx", ".xlsx"} | IMAGE_SUFFIXES


def parse_document(filename, content):
    filename = Path(filename.replace("\\", "/")).name[:180] or "document.txt"
    suffix = Path(filename).suffix.lower()
    doc = {"id": uuid4().hex, "filename": filename, "type": suffix.lstrip("."), "size": len(content),
           "sha256": hashlib.sha256(content).hexdigest(), "uploaded_at": now(), "blocks": [],
           "status": "parsed", "warnings": [], "storage_name": uuid4().hex + suffix}
    if suffix not in SUPPORTED:
        doc.update(status="error", warnings=["Unsupported file. Upload UTF-8 TXT or MD, PDF, DOCX, PPTX, XLSX or a PNG/JPEG image."])
        return doc
    if not content or len(content) > MAX_FILE:
        doc.update(status="error", warnings=["File is empty or exceeds the 25 MB limit."])
        return doc

    def block(text, locator, **kwargs):
        if text.strip():
            doc["blocks"].append({"id": f"b{len(doc['blocks'])+1}", "text": text,
                                  "locator": locator, **kwargs})
    try:
        if suffix == ".pdf":
            if not content.startswith(b"%PDF-"):
                raise ValueError("Not a valid PDF")
            pdf = PdfReader(BytesIO(content))
            if pdf.is_encrypted:
                raise ValueError("Encrypted PDF; upload a readable copy")
            if len(pdf.pages) > MAX_PAGES:
                raise ValueError("PDF exceeds 30 pages; split it into smaller files")
            scanned, ocr_state = [], {"budget": None, "done": 0, "stopped": None}
            from .pdf_structure import structured_paragraphs
            # Paragraphs (with headings, lists and two-column pages read in order) instead of whole pages.
            numbered = {}
            for text, page_number, attributes in structured_paragraphs(pdf, MAX_PAGES):
                numbered[page_number] = numbered.get(page_number, 0) + 1
                end = attributes.pop("end_page", None)
                block(text, f"PDF page {page_number}" + (f"–{end}" if end else "") + f", paragraph {numbered[page_number]}",
                      kind="paragraph", page=page_number, **attributes)
            for i, page in enumerate(pdf.pages):
                if i + 1 not in numbered and not (page.extract_text() or "").strip():
                    scanned.append(i + 1)
                    ocr_pdf_page(doc, page, i + 1, block, ocr_state)
            summarise_scanned_pages(doc, scanned, ocr_state)
        elif suffix in IMAGE_SUFFIXES:
            ocr_image_file(doc, content, block)
        elif suffix == ".xlsx":
            blocks, notes = workbook_blocks(content)
            doc["blocks"].extend(blocks)
            doc["warnings"].extend(notes)
        elif suffix == ".docx":
            with zipfile.ZipFile(BytesIO(content)) as z:
                if sum(i.file_size for i in z.infolist()) > 40 * 1024 * 1024:
                    raise ValueError("DOCX expanded contents exceed 40 MB")
            document = Document(BytesIO(content))
            pi = ti = 0
            for element in document.element.body:
                if element.tag == qn("w:p"):
                    p = document.paragraphs[pi]
                    block(p.text, f"DOCX paragraph {pi+1}", kind="paragraph", style=p.style.name)
                    pi += 1
                elif element.tag == qn("w:tbl"):
                    table = document.tables[ti]
                    for ri, row in enumerate(table.rows):
                        label = row.cells[0].text if row.cells else ""
                        for ci, cell in enumerate(row.cells):
                            block(cell.text, f"DOCX table {ti+1}, row {ri+1}, cell {ci+1}",
                                  kind="cell", label=label if ci > 0 else "")
                    ti += 1
        elif suffix == ".pptx":
            slide_blocks(content, block)
        else:
            text = content.decode("utf-8-sig")
            if "\x00" in text:
                raise ValueError("TXT contains binary data")
            for i, line in enumerate(text.splitlines()):
                block(line, f"{suffix[1:].upper()} line {i+1}", kind="line")
        length = sum(len(b["text"]) for b in doc["blocks"])
        if length > MAX_TEXT:
            raise ValueError("Extracted text exceeds 150,000 characters; split the document")
        if not doc["blocks"]:
            doc["status"] = "no_readable_text"
            if not doc["warnings"]:
                doc["warnings"].append("No readable text; paste the text or provide a text PDF, DOCX, PPTX, XLSX or TXT copy.")
    except Exception as exc:
        doc.update(status="error", blocks=[], warnings=[f"Could not parse this file: {str(exc)[:200]}"])
    return doc


def slide_blocks(content, block):
    """One block per paragraph of slide text, table cell and speaker note, located by slide and shape number.

    Slide titles get kind "slide_title" so the first slide's title can be offered as the company name."""
    with zipfile.ZipFile(BytesIO(content)) as z:
        if sum(i.file_size for i in z.infolist()) > 200 * 1024 * 1024:
            raise ValueError("PPTX expanded contents exceed 200 MB")
    presentation = Presentation(BytesIO(content))

    def shapes(collection):
        for shape in collection:
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                yield from shapes(shape.shapes)
            else:
                yield shape

    for number, slide in enumerate(presentation.slides, 1):
        title = slide.shapes.title
        for index, shape in enumerate(shapes(slide.shapes), 1):
            where = f"PPTX slide {number}, shape {index}"
            if shape.has_text_frame:
                kind = "slide_title" if title is not None and shape.shape_id == title.shape_id else "paragraph"
                for paragraph in shape.text_frame.paragraphs:
                    block(paragraph.text, where, kind=kind, slide=number)
            elif shape.has_table:
                for ri, row in enumerate(shape.table.rows):
                    label = row.cells[0].text if len(row.cells) else ""
                    for ci, cell in enumerate(row.cells):
                        block(cell.text, f"{where}, table row {ri+1}, cell {ci+1}", kind="cell", slide=number,
                              label=label if ci > 0 else "")
        notes = slide.notes_slide.notes_text_frame if slide.has_notes_slide else None
        if notes is not None:  # A notes page without a notes placeholder holds no speaker text.
            for paragraph in notes.paragraphs:
                block(paragraph.text, f"PPTX slide {number}, speaker notes", kind="notes", slide=number)


def ocr_pdf_page(doc, page, number, block, state):
    """OCR one PDF page that has no text layer; never invents text."""
    if state["stopped"]:
        return
    status = ocr.status()
    if not status["available"]:
        state["stopped"] = "unavailable"
        return
    if state["done"] >= ocr.max_pages():
        state["stopped"] = "page limit"
        return
    state["budget"] = state["budget"] or ocr.Budget()
    if state["budget"].remaining() <= 1:
        state["stopped"] = "time limit"
        return
    state["done"] += 1
    try:
        paragraphs = []
        for data in ocr.pdf_page_images(page):
            paragraphs += ocr.recognise(data, timeout=min(ocr.timeout_seconds(), state["budget"].remaining()))
    except (ocr.OcrError, ocr.OcrUnavailable) as exc:
        doc["warnings"].append(f"PDF page {number}: OCR could not read this page ({str(exc)[:160]}).")
        return
    for n, paragraph in enumerate(paragraphs, 1):
        block(paragraph["text"], f"PDF page {number} (OCR), paragraph {n}", kind="ocr", page=number,
              confidence=paragraph["confidence"])


def summarise_scanned_pages(doc, scanned, state):
    ocr_blocks = [b for b in doc["blocks"] if b.get("kind") == "ocr"]
    pages = ", ".join(map(str, scanned[:12])) + ("…" if len(scanned) > 12 else "")
    if not scanned:
        return
    if state["stopped"] == "unavailable":
        doc["warnings"].append(f"PDF page(s) {pages}: no text layer, and {ocr.OCR_UNAVAILABLE}. Provide a text copy of those pages.")
    elif state["stopped"] in {"page limit", "time limit"}:
        doc["warnings"].append(f"OCR stopped early ({state['stopped']}); some scanned pages were not read. Provide a text copy of the remaining pages.")
    if ocr_blocks:
        finish_ocr(doc, ocr_blocks)
    elif state["stopped"] is None:
        doc["warnings"].append(f"PDF page(s) {pages}: no readable text or recognisable scanned text was found.")


def finish_ocr(doc, ocr_blocks):
    scores = [b["confidence"] for b in ocr_blocks]
    mean = round(sum(scores) / len(scores), 1)
    doc["ocr"] = {"used": True, "engine": "tesseract", "mean_confidence": mean, "paragraphs": len(ocr_blocks)}
    doc["warnings"].append(ocr.OCR_NOTICE)
    if mean < 60:
        doc["warnings"].append(f"Recognition confidence is low (about {mean:.0f}%). Treat this text with particular caution.")


def ocr_image_file(doc, content, block):
    status = ocr.status()
    if not status["available"]:
        doc["warnings"].append(f"{ocr.OCR_UNAVAILABLE}. Upload a text, PDF, DOCX or XLSX version of this image's content.")
        return
    paragraphs = ocr.recognise(content)
    for n, paragraph in enumerate(paragraphs, 1):
        block(paragraph["text"], f"Image {doc['filename']} (OCR), paragraph {n}", kind="ocr", confidence=paragraph["confidence"])
    if paragraphs:
        finish_ocr(doc, [b for b in doc["blocks"] if b.get("kind") == "ocr"])
    else:
        doc["warnings"].append("No text was recognised in this image. Check that it is sharp, upright and contains English text.")


def evidence(doc, block, quote):
    if not quote or quote not in block["text"]:
        raise ValueError("Evidence quote does not occur in the referenced text block")
    ref = {"document_id": doc["id"], "block_id": block["id"], "filename": doc["filename"],
           "locator": block["locator"], "quote": quote, "source_type": doc.get("source_type", "document")}
    # Optional, source-specific context. Plain uploaded documents are unchanged.
    if block.get("kind") == "ocr":
        ref.update(kind="ocr", note="Read with OCR; may contain recognition errors")
    elif block.get("kind") == "website":
        ref.update(kind="website", note="Public website text; an unverified company claim")
        if block.get("url"):
            ref["source_url"] = block["url"]
    if block.get("sheet") and block.get("label"):
        ref["context"] = block["label"]
    return ref


def founder_evidence(value, note):
    stamp = now()
    return {"document_id": None, "block_id": None, "locator": f"Founder answer {stamp}",
            "quote": str(value), "source_type": "founder_answer", "note": note}
