"""Parse bytes, retaining genuine page/paragraph/cell/line locations."""
import hashlib
import re
import zipfile
from io import BytesIO
from pathlib import Path
from uuid import uuid4
from docx import Document
from docx.oxml.ns import qn
from pypdf import PdfReader
from .config import now

MAX_FILE = 10 * 1024 * 1024
MAX_TEXT = 150_000
MAX_PAGES = 30


def parse_document(filename, content):
    filename = Path(filename.replace("\\", "/")).name[:180] or "document.txt"
    suffix = Path(filename).suffix.lower()
    doc = {"id": uuid4().hex, "filename": filename, "type": suffix.lstrip("."), "size": len(content),
           "sha256": hashlib.sha256(content).hexdigest(), "uploaded_at": now(), "blocks": [],
           "status": "parsed", "warnings": [], "storage_name": uuid4().hex + suffix}
    if suffix not in {".txt", ".pdf", ".docx"}:
        doc.update(status="error", warnings=["Unsupported file. Upload UTF-8 TXT, text PDF or DOCX."])
        return doc
    if not content or len(content) > MAX_FILE:
        doc.update(status="error", warnings=["File is empty or exceeds the 10 MB limit."])
        return doc

    def block(text, locator, **kwargs):
        if text.strip():
            doc["blocks"].append({"id": f"b{len(doc['blocks'])+1}", "text": text,
                                  "locator": locator, **kwargs})
    try:
        if suffix == ".pdf":
            if not content.startswith(b"%PDF-"):
                raise ValueError("Not a valid PDF")
            pdf = PdfReader(BytesIO(content))
            if pdf.is_encrypted:
                raise ValueError("Encrypted PDF; upload a readable copy")
            if len(pdf.pages) > MAX_PAGES:
                raise ValueError("PDF exceeds 30 pages; split it into smaller files")
            for i, page in enumerate(pdf.pages):
                page_text = page.extract_text() or ""
                block(page_text, f"PDF page {i+1}", kind="page")
                if not page_text.strip():
                    doc["warnings"].append(f"PDF page {i+1}: no readable text; this page may require a text copy. OCR is not supported.")
        elif suffix == ".docx":
            with zipfile.ZipFile(BytesIO(content)) as z:
                if sum(i.file_size for i in z.infolist()) > 40 * 1024 * 1024:
                    raise ValueError("DOCX expanded contents exceed 40 MB")
            document = Document(BytesIO(content))
            pi = ti = 0
            for element in document.element.body:
                if element.tag == qn("w:p"):
                    p = document.paragraphs[pi]
                    block(p.text, f"DOCX paragraph {pi+1}", kind="paragraph", style=p.style.name)
                    pi += 1
                elif element.tag == qn("w:tbl"):
                    table = document.tables[ti]
                    for ri, row in enumerate(table.rows):
                        label = row.cells[0].text if row.cells else ""
                        for ci, cell in enumerate(row.cells):
                            block(cell.text, f"DOCX table {ti+1}, row {ri+1}, cell {ci+1}",
                                  kind="cell", label=label if ci > 0 else "")
                    ti += 1
        else:
            text = content.decode("utf-8-sig")
            if "\x00" in text:
                raise ValueError("TXT contains binary data")
            for i, line in enumerate(text.splitlines()):
                block(line, f"TXT line {i+1}", kind="line")
        length = sum(len(b["text"]) for b in doc["blocks"])
        if length > MAX_TEXT:
            raise ValueError("Extracted text exceeds 150,000 characters; split the document")
        if not doc["blocks"]:
            doc.update(status="no_readable_text", warnings=["No readable text; paste text or provide a text PDF. OCR is not supported."])
    except Exception as exc:
        doc.update(status="error", blocks=[], warnings=[f"Could not parse this file: {str(exc)[:200]}"])
    return doc


def evidence(doc, block, quote):
    if not quote or quote not in block["text"]:
        raise ValueError("Evidence quote does not occur in the referenced text block")
    return {"document_id": doc["id"], "block_id": block["id"], "filename": doc["filename"],
            "locator": block["locator"], "quote": quote, "source_type": "document"}


def founder_evidence(value, note):
    stamp = now()
    return {"document_id": None, "block_id": None, "locator": f"Founder answer {stamp}",
            "quote": str(value), "source_type": "founder_answer", "note": note}
