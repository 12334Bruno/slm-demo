"""Content-based basic extraction. No fixture filenames or company answers."""
import re
from decimal import Decimal, ROUND_HALF_UP
from datetime import date
from uuid import uuid4
from .config import now, FORM
from .domain import BOOL_PATHS, DATE_PATHS, BudgetLine, FundingSource, validate_value
from .ingestion import evidence
from .profiles import merge_fact, merge_row
from .storage import touch

LABELS = {
    "company.activities": ["business activities", "company activities"],
    "company.name": ["company name", "business name", "organisation name", "brand name", "trade name"],
    "company.country": ["country"], "company.province": ["province", "registered province"],
    "company.city": ["registered city", "city", "registered establishment", "registered location", "registered office"],
    "company.legal_form": ["legal form", "legal structure", "legal entity"], "company.registration_number": ["registration number", "kvk number"],
    "company.fte": ["fte", "team", "full-time equivalents", "employees"],
    "company.annual_turnover_cents": ["annual turnover", "turnover"],
    "company.balance_sheet_total_cents": ["balance-sheet total", "balance sheet total"],
    "company.sme_self_declared": ["sme status confirmed", "sme declaration"],
    "company.ownership_notes": ["ownership", "ownership notes"],
    "company.financial_difficulty_review": ["financial difficulty assessment"],
    "company.vat_recoverable": ["vat recoverable", "vat recovery confirmed"],
    "company.previous_mit_five_years": ["previous mit awards", "previous mit support"],
    "company.dutch_wage_or_income_tax": ["dutch wage or income tax"],
    "project.name": ["project name", "project title"],
    "project.description": ["project description", "concept description"],
    "project.start_date": ["planned start date", "start date"],
    "project.end_date": ["planned end date", "end date"],
    "project.award_date": ["award date"],
    "project.primary_activity": ["primary activity", "project type"],
    "project.one_off": ["one-off project", "one off project"],
    "project.routine_operations": ["routine business operations", "routine operations"],
    "project.prepares_later_development": ["prepares later development", "study precedes development decision"],
    "project.independent_sme_participant_count": ["project participants", "independent sme participants", "participant count"],
    "project.same_activities_other_public_funding": ["same activities other public funding", "other public subsidy for same activities"],
    "project.framework_alignment_notes": ["policy framework alignment", "kia alignment"],
    "project.framework_category": ["proposed kia category", "policy framework category"],
    "project.future_own_technical_rd": ["future own technical r&d"],
    "company.founded_date": ["founded", "founding date", "date of incorporation", "opgericht"],
    "company.website": ["website"],
    "company.sector": ["sector", "industry"],
    "project.trl": ["trl", "technology readiness level"],
}

NARRATIVE_LABELS = {
    "the concept and customer problem": ["project.description", "narrative.innovation_description"],
    "what the company is investigating": ["project.description"],
    "current state and development decision": ["narrative.need_for_feasibility", "narrative.bottlenecks"],
    "questions to answer": ["narrative.feasibility_questions"],
    "activities and budget responsibilities": ["narrative.activities"],
    "team and outside support": ["narrative.team", "narrative.third_party_roles"],
    "planning and intended outputs": ["narrative.planning", "narrative.results_and_decision"],
    "innovation description": ["project.description", "narrative.innovation_description"],
    "feasibility questions": ["narrative.feasibility_questions"],
    "planned activities": ["narrative.activities"],
    "route to market": ["narrative.route_to_market"],
    "novelty": ["narrative.novelty"],
    "market evidence": ["narrative.market_perspective"],
    "known gaps": [],
}

# Accept every mapped application section as a normal document heading. This
# works for arbitrary uploaded companies and does not map example filenames.
for section in FORM["sections"]:
    for heading in (section["id"].replace("_", " "), section["expected_heading"].lower()):
        NARRATIVE_LABELS.setdefault(heading, [f"narrative.{section['id']}"])


def cents(value):
    value = re.sub(r"[^0-9.,+-]", "", value)
    if "," in value and "." in value:
        value = value.replace(",", "") if value.rfind(".") > value.rfind(",") else value.replace(".", "").replace(",", ".")
    elif "," in value:
        value = value.replace(",", ".") if len(value.rsplit(",", 1)[-1]) == 2 else value.replace(",", "")
    return int((Decimal(value) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def parsed_date(text):
    text = text.strip().rstrip(".")
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return date.fromisoformat(text).isoformat()
    months = {name: i + 1 for i, name in enumerate("january february march april may june july august september october november december".split())}
    m = re.search(r"(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})", text)
    if not m or m[2].lower() not in months:
        raise ValueError("Unsupported date; confirm an ISO date in profile")
    return date(int(m[3]), months[m[2].lower()], int(m[1])).isoformat()


def convert(path, raw):
    text = raw.strip()
    if re.match(r"(?i)(not provided|unknown|not confirmed|not yet|not supplied|n/?a|to be determined)", text):
        return None
    if path in BOOL_PATHS:
        m = re.match(r"(?i)(yes|no|true|false)\b", text)
        return None if not m else m[1].lower() in {"yes", "true"}
    if path.endswith("_cents"):
        m = re.search(r"[-+]?\d[\d.,]*", text)
        return cents(m[0]) if m else None
    if path in DATE_PATHS:
        return parsed_date(text)
    if path == "company.website":
        # "Website: €95 template: https://…" is a cost line, not the company's site. Accept a bare address only.
        m = re.fullmatch(r"(?i)((?:https?://)?(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:/\S*)?)\.?", text)
        return m[1] if m else None
    if path == "project.trl":
        m = re.match(r"(?i)(?:trl\s*)?(\d)\b", text)
        return int(m[1]) if m else None
    if path in {"company.fte", "project.independent_sme_participant_count"}:
        m = re.search(r"\d+(?:\.\d+)?", text)
        if m:
            return float(m[0]) if path == "company.fte" else int(m[0])
        word = re.match(r"(?i)(one|two|three|four|five|six|zero)\b", text)
        return {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6}.get(word[1].lower()) if word else None
    if path == "project.primary_activity":
        text = text.lower().replace("_", " ")
        for key in ["feasibility study", "combined research development", "industrial research", "experimental development", "other"]:
            if text.startswith(key):
                return key.replace(" ", "_")
        return None
    return text


def basic_extract(docs):
    facts, lines, funding, letters, metadata, warnings = [], [], [], [], {}, []
    label_list = [(path, label) for path, labels in LABELS.items() for label in labels]

    def propose(doc, b, path, raw, quote=None, context=None):
        try:
            value = validate_value(path, convert(path, raw))
            if value is not None:
                ref = evidence(doc, b, quote or raw)
                if context:
                    ref["context"] = context
                facts.append({"path": path, "value": value, "evidence": [ref]})
        except (ValueError, ArithmeticError) as exc:
            warnings.append(f"{doc['filename']} · {b['locator']}: {path}: {str(exc)[:120]}")

    for doc in docs:
        # Public website text is evidence for analysis only; it never becomes a fact by label matching.
        if doc["status"] != "parsed" or doc.get("source_type") == "website":
            continue
        blocks = doc["blocks"]
        if doc.get("type") == "xlsx":
            from .sheet_extraction import fact_cells, budget_rows
            for path, b, context in fact_cells(doc, label_list):
                propose(doc, b, path, b["text"], context=context)
            sheet_lines, sheet_warnings = budget_rows(doc, cents)
            lines.extend(sheet_lines)
            warnings.extend(sheet_warnings)
        for b in blocks:
            text = b["text"]
            if b.get("label") and doc.get("type") != "xlsx":
                label = re.sub(r",?\s*\d{4}$", "", b["label"].strip()).lower()
                for path, alias in label_list:
                    if label == alias:
                        propose(doc, b, path, text)
            for path, label in label_list:
                pattern = r"(?im)(?:^|[\n.])\s*" + re.escape(label) + r"(?:,?\s*\d{4})?\s*:\s*([^\n]+)"
                for match in re.finditer(pattern, text):
                    raw = match[1].strip()
                    # A following label on the same line is a separate assertion.
                    raw = re.split(r"\.\s+(?=[A-Z][A-Za-z -]+:)", raw)[0]
                    propose(doc, b, path, raw)
            # Generic company title in a DOCX; the value comes from its bytes.
            if b.get("kind") == "paragraph" and b["locator"] == "DOCX paragraph 1" and re.search(r"(?i)(b\.?v\.?|ltd\.?|llc|inc\.?|gmbh)\s*$", text):
                propose(doc, b, "company.name", text)
            for row_text in text.splitlines():
                parts = [p.strip() for p in row_text.split("|")]
                if len(parts) == 7 and parts[2] in {"feasibility_study", "related_research", "other"}:
                    try:
                        row = BudgetLine(id=parts[0], activity=parts[1], activity_group=parts[2], cost_type=parts[3],
                                         quantity=parts[4], unit=parts[5], rate_cents=cents(parts[6]),
                                         evidence=[evidence(doc, b, row_text)]).model_dump()
                        lines.append(row)
                    except ValueError as exc:
                        warnings.append(f"Could not extract budget row at {b['locator']}: {str(exc)[:140]}")
                elif len(parts) == 5 and parts[1] in {"own_cash", "private_loan", "other_private", "other_public", "other"}:
                    try:
                        funding.append(FundingSource(id=parts[0], kind=parts[1], amount_cents=cents(parts[2]), status=parts[3],
                                                     note=parts[4], evidence=[evidence(doc, b, row_text)]).model_dump())
                    except ValueError as exc:
                        warnings.append(f"Invalid financing row at {b['locator']}: {str(exc)[:140]}")
                for label, key in [("Project revenues during this study", "project_revenues_cents"), ("Project revenues", "project_revenues_cents"),
                                   ("Other project costs outside these rows", "other_project_costs_cents")]:
                    m = re.search(re.escape(label) + r":\s*([\d.,]+)", row_text, re.I)
                    if m:
                        val = cents(m[1])
                        if key in metadata and metadata[key]["value"] != val:
                            metadata[key] = {"value": None, "evidence": metadata[key]["evidence"] + [evidence(doc, b, m[0])], "conflict": True}
                        else:
                            metadata[key] = {"value": val, "evidence": [evidence(doc, b, m[0])]}
            # Named narrative sections are copied, never rewritten as achieved results.
            matches = list(re.finditer(r"(?im)^\s*(" + "|".join(re.escape(x) for x in NARRATIVE_LABELS) + r")\s*\n", text))
            for mi, match in enumerate(matches):
                stop = matches[mi+1].start() if mi+1 < len(matches) else len(text)
                quote = text[match.end():stop].strip()
                if quote and len(quote) <= 12000:
                    for path in NARRATIVE_LABELS[match[1].strip().lower()]:
                        facts.append({"path": path, "value": quote, "evidence": [evidence(doc, b, quote)]})
        # DOCX heading followed by ordinary paragraphs (table contents are not prose).
        for bi, b in enumerate(blocks):
            label = b["text"].strip().lower()
            if b.get("kind") != "paragraph" or label not in NARRATIVE_LABELS:
                continue
            following = []
            for nxt in blocks[bi+1:]:
                if nxt.get("kind") != "paragraph" or "heading" in nxt.get("style", "").lower():
                    break
                following.append(nxt)
            if following:
                # One evidence-backed value, using the first paragraph only; other text remains inspectable.
                for path in NARRATIVE_LABELS[label]:
                    facts.append({"path": path, "value": following[0]["text"], "evidence": [evidence(doc, following[0], following[0]["text"])]})
        rule_facts(doc, facts, propose)
        # Commitment proposals never change the financing plan until the founder links them.
        fulltext = "\n".join(b["text"] for b in blocks)
        if re.search(r"(?i)\bcommits?\s+(?:a\s+)?(?:private\s+)?loan\b", fulltext):
            for b in blocks:
                m = re.search(r"(?:EUR|€)\s*(\d[\d,.]*)", b["text"])
                if m:
                    letters.append({"id": uuid4().hex, "document_id": doc["id"], "amount_cents": cents(m[1]),
                                    "kind": "private_loan", "state": "proposed", "linked_source_id": None,
                                    "evidence": [evidence(doc, x, x["text"]) for x in blocks],
                                    "note": "Document contains commitment language. Confirm amount, recipient, project and source link; no legal authentication."})
                    break
    return {"facts": facts, "budget_lines": lines, "funding_sources": funding, "letters": letters,
            "metadata": metadata, "warnings": warnings}


def rule_facts(doc, facts, propose):
    """Offline rules for prose without labels (decks, pasted text): KvK number, "Name B.V.", city/province, deck title.

    Paths already proposed from labelled fields in this document are left to those labels."""
    from .entity_resolution import kvk_numbers
    from .research_api import site_facts
    labelled = {f["path"] for f in facts if f["evidence"][0]["document_id"] == doc["id"]}
    numbers = {}
    for b in doc["blocks"]:
        for number, start, end in kvk_numbers(b["text"]):
            numbers.setdefault(number, (b, b["text"][start:end]))
    if len(numbers) == 1 and "company.registration_number" not in labelled:
        number, (b, snippet) = next(iter(numbers.items()))
        propose(doc, b, "company.registration_number", number, quote=snippet)
    stated = site_facts(doc)
    title = next((b for b in doc["blocks"] if b.get("kind") == "slide_title" and b.get("slide") == 1), None)
    if title and "company.name" not in stated and len(title["text"].split()) <= 4:
        stated["company.name"] = (title["text"].strip(), title, title["text"])
    for path, (value, b, snippet) in stated.items():
        if path not in labelled:
            propose(doc, b, path, value, quote=snippet)


def apply_extraction(ws, result, mode, warnings=None, call=None):
    for fact in result["facts"]:
        merge_fact(ws, fact["path"], fact["value"], fact["evidence"])
    for line in result["budget_lines"]:
        merge_row(ws["budget_lines"], line, ["activity", "activity_group", "cost_type", "quantity", "unit", "rate_cents"])
    for source in result["funding_sources"]:
        merge_row(ws["funding_sources"], source, ["kind", "amount_cents", "status"])
    for letter in result["letters"]:
        if not any(l["document_id"] == letter["document_id"] and l["amount_cents"] == letter["amount_cents"] for l in ws["funding_letters"]):
            ws["funding_letters"].append(letter)
    for key, item in result["metadata"].items():
        if item["evidence"] and all(ref in ws["budget_metadata"]["evidence"] for ref in item["evidence"]):
            continue
        current = ws["budget_metadata"][key]
        if current is not None and current != item["value"]:
            ws["budget_metadata"][key] = None
            ws["budget_metadata"].setdefault("conflicts", []).append(key)
        else:
            ws["budget_metadata"][key] = item["value"]
        ws["budget_metadata"]["confirmed"] = False
        ws["budget_metadata"]["evidence"].extend(item["evidence"])
    ws["extraction_runs"].append({"at": now(), "mode": mode, "model_call": call,
                                  "warnings": result["warnings"] + (warnings or []), "fact_count": len(result["facts"])})
    touch(ws, ["*"], "Extracted proposed facts; founder confirmation required")
