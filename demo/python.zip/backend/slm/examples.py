"""Explicit, isolated fictional examples using the normal processing services."""
from threading import Lock
from datetime import date, timedelta
from .config import ROOT, FORM
from .ingestion import parse_document
from .extraction import basic_extract, apply_extraction
from .domain import FactChange, ProfilePatch
from .profiles import apply_profile_patch
from .rules import evaluate
from .drafting import generate_basic_sections, save_generated_draft

EXAMPLE_ID = "returnloop-filled-v1"
EXAMPLE_LOCK = Lock()


def startup_details():
    """Simulated founder answers complementing the fictional ReturnLoop documents."""
    return {
        "company.activities": "Designing removable low-power sensors and software to monitor wash cycles and handling of reusable transport containers, helping container-pool operators investigate premature retirement and reduce packaging waste.",
        "company.founded_date": "2025-02-03",
        "company.sector": "Circular economy and reusable packaging",
        "company.technology_domain": "Embedded electronics, low-power sensing, reusable transport packaging and data analytics",
        "company.team_members": "Mila de Vries, CEO and industrial designer; Sam Vermeer, embedded-systems engineer; Noor Bakker, circular-packaging researcher. Three full-time founders in this fictional company.",
        "company.revenue_status": "none",
        "company.has_paying_customers": False,
        "company.customer_validation": "Illustrative target users are reusable-container pool operators and food-logistics businesses. Customer interviews, willingness-to-pay research and pilot commitments are planned; no validated customer results or contracts are claimed.",
        "company.employs_staff_with_wage_tax": False,
        "company.founders_are_self_employed_only": True,
        "company.tu_delft_affiliation": "alumnus",
        "company.tu_delft_ip_license": False,
        "company.university_spin_out": False,
        "company.founder_employed_researcher": False,
        "company.women_led": True,
        "company.ip_status": "trade_secret",
        "company.ownership_notes": "Fictional founders Mila, Sam and Noor hold 40%, 30% and 30% respectively. Mila is CEO. No linked or partner enterprises are declared in this illustrative scenario.",
        "company.email": "hello@returnloop.example",
        "contact.name": "Mila de Vries (fictional)",
        "contact.role": "Co-founder and CEO",
        "contact.email": "mila@returnloop.example",
        "project.description": "A six-month, EUR 60,000 feasibility study of a removable sensor module for reusable transport containers. Investigate signal quality during wash cycles, a non-damaging attachment, battery life, user workflows and commercial feasibility. Deliver a sensing architecture, laboratory test plan, customer-research report, cost model and a go/no-go decision for later prototype development. No successful pilot or environmental impact is asserted.",
        "project.start_date": (date.today() + timedelta(days=60)).isoformat(),
        "project.end_date": (date.today() + timedelta(days=240)).isoformat(),
        "project.trl": 2,
        "project.rd_hours_estimate": 600,
        "project.is_software_only": False,
        "project.involves_hardware": True,
        "project.technical_uncertainty_description": "Determine whether useful wash-cycle and handling signals can be obtained with a removable, low-power module; assess sealing, attachment durability, signal interpretation and battery life. These are questions to investigate, not demonstrated capabilities.",
        "project.funding_need_cents": 2000000,
        "project.funding_purpose": "EUR 20,000 towards a EUR 60,000 feasibility study, covering engineering time, independent technical and market research, materials and initial bench tests. The fictional financing plan supplies EUR 40,000 from other sources.",
        "finance.cofinancing_available": True,
        "finance.cofinancing_details": "EUR 40,000 in simulated committed private contributions, itemised in the example financing plan. No real bank evidence, signature or legally binding commitment is supplied.",
        "finance.grants_received": "No grants or other public funding received in this fictional scenario.",
    }


def open_filled_example(store, *, startup=False):
    with EXAMPLE_LOCK:
        example_id = "returnloop-startup-v1" if startup else EXAMPLE_ID
        existing = store.find_example(example_id)
        if existing:
            return store.load(existing)
        directory = ROOT / "sample_documents" / "filled_example"
        paths = sorted(p for p in directory.iterdir() if p.suffix in {".docx", ".txt"})
        if not paths:
            raise ValueError("Filled example files are missing. Run uv run scripts/build_filled_example.py.")
        items = [(p.name, p.read_bytes()) for p in paths]
        documents = [parse_document(name, content) for name, content in items]
        if any(d["status"] != "parsed" for d in documents):
            raise ValueError("Could not parse the fictional example documents")
        result = basic_extract(documents)
        supplied = {f["path"] for f in result["facts"]}
        if any(f"narrative.{s['id']}" not in supplied for s in FORM["sections"]):
            raise ValueError("The fictional example is missing a mapped application answer")
        label = "ReturnLoop — demo startup (fictional)" if startup else "ReturnLoop — filled example (fictional)"
        created = store.create(label=label, example_id=example_id)
        with store.edit(created["id"]) as ws:
            ws["context"]["mode"] = "current" if startup else "historical_rules_demo"
            for doc, (_, content) in zip(documents, items):
                (store.root / "uploads" / doc["storage_name"]).write_bytes(content)
                doc["extracted_modes"] = ["basic"]
                ws["documents"].append(doc)
            apply_extraction(ws, result, "Basic extraction — fictional example")
            note = "Explicitly loaded fictional example: simulated acceptance of illustrative statements; no real founder, legal or financial verification."
            apply_profile_patch(ws, ProfilePatch(
                expected_revision=ws["revision"],
                changes=[FactChange(path=path, value=value, note=note + " Demo startup details supersede the example documents where different.")
                         for path, value in startup_details().items()] if startup else [],
                confirm_paths=[p for p, fact in ws["facts"].items() if fact["state"] == "proposed"],
                confirm_budget=True, confirm_funding=True,
            ), confirmation_note=note)
            evaluation = evaluate(ws)
            if not startup:
                sections = generate_basic_sections(ws, evaluation)
                save_generated_draft(ws, evaluation, sections, mode="Template-assisted draft — fictional example")
            ws["last_evaluation"] = evaluation
        return store.load(created["id"])
