"""Explicit, isolated fictional examples using the normal processing services."""
from threading import Lock
from .config import ROOT, FORM
from .ingestion import parse_document
from .extraction import basic_extract, apply_extraction
from .domain import ProfilePatch
from .profiles import apply_profile_patch
from .rules import evaluate
from .drafting import generate_basic_sections, save_generated_draft

EXAMPLE_ID = "returnloop-filled-v1"
EXAMPLE_LOCK = Lock()


def open_filled_example(store):
    with EXAMPLE_LOCK:
        existing = store.find_example(EXAMPLE_ID)
        if existing:
            return store.load(existing)
        directory = ROOT / "sample_documents" / "filled_example"
        paths = sorted(p for p in directory.iterdir() if p.suffix in {".docx", ".txt"})
        if not paths:
            raise ValueError("Filled example files are missing. Run uv run scripts/build_filled_example.py.")
        items = [(p.name, p.read_bytes()) for p in paths]
        documents = [parse_document(name, content) for name, content in items]
        if any(d["status"] != "parsed" for d in documents):
            raise ValueError("Could not parse the fictional example documents")
        result = basic_extract(documents)
        supplied = {f["path"] for f in result["facts"]}
        if any(f"narrative.{s['id']}" not in supplied for s in FORM["sections"]):
            raise ValueError("The fictional example is missing a mapped application answer")
        created = store.create(label="ReturnLoop — filled example (fictional)", example_id=EXAMPLE_ID)
        with store.edit(created["id"]) as ws:
            ws["context"]["mode"] = "historical_rules_demo"
            for doc, (_, content) in zip(documents, items):
                (store.root / "uploads" / doc["storage_name"]).write_bytes(content)
                doc["extracted_modes"] = ["basic"]
                ws["documents"].append(doc)
            apply_extraction(ws, result, "Basic extraction — fictional example")
            apply_profile_patch(ws, ProfilePatch(
                expected_revision=ws["revision"],
                confirm_paths=[p for p, fact in ws["facts"].items() if fact["state"] == "proposed"],
                confirm_budget=True, confirm_funding=True,
            ), confirmation_note="Explicitly loaded fictional example: simulated acceptance of illustrative statements; no real founder, legal or financial verification.")
            evaluation = evaluate(ws)
            sections = generate_basic_sections(ws, evaluation)
            save_generated_draft(ws, evaluation, sections, mode="Template-assisted draft — fictional example")
            ws["last_evaluation"] = evaluation
        return store.load(created["id"])
