"""Automatic company-analysis status/review; optional legacy developer endpoints."""
import os
from pydantic import Field
from .domain import Strict, FactChange
from .company_analysis import CompanyResult


class StartSession(Strict):
    name: str = Field(min_length=1, max_length=100)


class Session(Strict):
    token: str


class Completion(Session):
    result: CompanyResult
    execution: str = Field(min_length=1, max_length=500)


class Failure(Session):
    message: str = Field(min_length=1, max_length=500)


class Confirmation(Strict):
    expected_revision: int
    changes: list[FactChange] = Field(min_length=1, max_length=30)


class RequestAnalysis(Strict):
    expected_revision: int


def register(app, service, view):
    @app.get("/api/workspaces/{wid}/analysis")
    def status(wid: str):
        return service.listing(wid)

    @app.post("/api/workspaces/{wid}/analysis")
    def request_analysis(wid: str, body: RequestAnalysis):
        from .storage import RevisionConflict
        ws = service.store.load(wid)
        if ws["revision"] != body.expected_revision:
            raise RevisionConflict("Reload the current project before requesting analysis")
        if service.automatic or os.getenv("SLM_CODEX_BRIDGE_ENABLED") == "1":
            service.sync(ws, force=True, expected_revision=body.expected_revision)
        return service.listing(wid)

    @app.post("/api/workspaces/{wid}/analysis/stop")
    def stop_analysis(wid: str):
        service.disable(wid)
        return service.listing(wid)

    @app.post("/api/workspaces/{wid}/analysis/{tid}/confirm")
    def confirm(wid: str, tid: str, body: Confirmation):
        return view(service.confirm(wid, tid, body.expected_revision, body.changes))

    # The rejected chat bridge is retained only as an explicit local developer
    # compatibility option. It is absent from normal and hosted applications.
    if os.getenv("SLM_CODEX_BRIDGE_ENABLED") != "1" or os.getenv("SLM_HOSTED") == "1":
        return

    @app.get("/api/analysis/tasks")
    def tasks():
        return service.listing()

    @app.post("/api/analysis/session")
    def start(body: StartSession):
        return service.connect(body.name)

    @app.post("/api/analysis/session/heartbeat")
    def heartbeat(body: Session):
        return service.heartbeat(body.token)

    @app.post("/api/analysis/session/stop")
    def disconnect(body: Session):
        return service.heartbeat(body.token, stop=True)

    @app.post("/api/analysis/tasks/{tid}/claim")
    def claim(tid: str, body: Session):
        return service.claim(tid, body.token)

    @app.post("/api/analysis/tasks/{tid}/result")
    def complete(tid: str, body: Completion):
        return service.complete(tid, body.token, body.result, body.execution)

    @app.post("/api/analysis/tasks/{tid}/failure")
    def failure(tid: str, body: Failure):
        return service.fail(tid, body.token, body.message)
