"""The plain facts behind a match, for the grant card.

Three kinds of evidence, never mixed up:
  * topic: a sentence of the grant next to a sentence of the project (or the AI assessment's own quotes);
  * instrument: for broad startup schemes that are not about one topic, whether the company's region and
    project stage in the profile match what the scheme is for;
  * who: the grant's conditions that are met, still to check, or not met.
A grant that was merely not excluded gets level "weak" or "none", and the card says so.
"""
import re
from typing import Literal, TypedDict

from .grant_specification import EU27
from .profiles import fact_value
from .retrieval import DUTCH_PROVINCES

# The founder's own answer about the project, mapped to the stages a scheme says it funds.
ACTIVITY_STAGES = {"feasibility_study": "feasibility", "industrial_research": "research", "experimental_development": "development"}
Status = Literal["met", "unknown", "different", "failed", "not_found"]


class InstrumentCheck(TypedDict):
    kind: Literal["region", "stage", "requirement"]
    status: Status
    value: str | None
    needed: str


def region_check(entry, ws) -> InstrumentCheck:
    region, cities = entry["region"], entry.get("cities") or []
    province = str(fact_value(ws, "company.province") or "")
    country = str(fact_value(ws, "company.country") or "")
    city = str(fact_value(ws, "company.city") or "")
    if cities:
        status = "unknown" if not city else "met" if city.casefold() in {c.casefold() for c in cities} else "failed"
        return {"kind": "region", "status": status, "value": city or None, "needed": cities[0]}
    if region in DUTCH_PROVINCES:
        status = "unknown" if not province else "met" if province == region else "failed"
        return {"kind": "region", "status": status, "value": province or None, "needed": region}
    if region == "Europe":
        status = "unknown" if not country else "met" if country in EU27 else "failed"
        return {"kind": "region", "status": status, "value": country or None, "needed": region}
    in_netherlands = country == "Netherlands" or province in DUTCH_PROVINCES
    status = "met" if in_netherlands else "failed" if country else "unknown"
    return {"kind": "region", "status": status, "value": country or province or None, "needed": region}


def stage_check(entry, ws) -> InstrumentCheck:
    """Whether the project stage in the profile is one the scheme funds; never guessed from loose words in the text."""
    funds = entry.get("stages") or []
    stage = ACTIVITY_STAGES.get(str(fact_value(ws, "project.primary_activity")))
    status = "unknown" if stage is None else "met" if stage in funds else "different"
    return {"kind": "stage", "status": status, "value": stage, "needed": ", ".join(funds)}


# Words that describe technical development work. Passing mentions ("accounting software") happen in any business
# plan, so a few are needed before a profile counts as describing technical work.
TECHNICAL = re.compile(r"(?i)\b(technolog\w*|technical|technisch\w*|technologie\w*|r\s?&\s?d|s\s?&\s?o|research and development|"
                       r"speur- en ontwikkel\w*|prototyp\w*|proof[- ]of[- ](?:principle|concept)|software|algorithm\w*|algoritme\w*|"
                       r"machine learning|sensor\w*|hardware|patent\w*|octrooi\w*|engineer\w*|trl\s?\d|laborator\w*|biotech\w*|deep[- ]tech)\b")
RESEARCH = re.compile(r"(?i)\b(universit\w*|hogeschool|tu delft|erasmus mc|lumc|knaw|nwo|phd|promovend\w*|postdoc\w*|researcher\w*|"
                      r"onderzoeker\w*|spin[- ]?off|spin[- ]?out|licen[cs]ed? (?:from|van)|valorisation|valorisatie)\b")
TECHNICAL_ACTIVITIES = {"feasibility_study", "industrial_research", "experimental_development", "combined_research_development"}
ENOUGH_WORDS = 150  # Below this, a profile says too little to conclude that something is absent.


def company_text(ws):
    """Everything the company has told us: profile facts and its documents (public website pages excluded)."""
    parts = [str(f["value"]) for f in ws["facts"].values() if isinstance(f.get("value"), str) and f["state"] not in {"missing", "conflict"}]
    parts += [b["text"] for doc in ws.get("documents", []) if doc.get("status") == "parsed" and doc.get("source_type") != "website"
              for b in doc.get("blocks", [])]
    return "\n".join(parts)[:400_000]


def requirement_check(entry, ws, text=None):
    """Whether the profile shows the kind of work the scheme is for. Never "failed": a missing description is not proof,
    so the outcome is met, unknown (too little information) or not_found (plenty of information, none of it this)."""
    from .focus_grants import REQUIREMENTS
    need = entry.get("requires")
    if not need:
        return None
    text = company_text(ws) if text is None else text
    pattern = TECHNICAL if need == "technical_innovation" else RESEARCH
    found = [m for m in pattern.finditer(text)]
    activity = str(fact_value(ws, "project.primary_activity") or "")
    stated = need == "technical_innovation" and (activity in TECHNICAL_ACTIVITIES or fact_value(ws, "project.trl") is not None)
    if stated or len(found) >= 3:
        status = "met"
    elif len(re.findall(r"\w+", text)) < ENOUGH_WORDS:
        status = "unknown"
    else:
        status = "not_found"
    return {"kind": "requirement", "status": status, "value": found[0][0] if found and status == "met" else None,
            "needed": REQUIREMENTS[need], "requirement": need}


def topic_label(entry):
    return entry.get("topic_label") or " ".join(entry["topic"].split()[:3])


def topic_words_found(entry, ws):
    """Whether the company writes about the sector a scheme is for, using the scheme's own hand-picked words.

    A word in the company's own description of what it does counts. Business plans and web-shop pages mention many
    subjects in passing ("shipping policy", "energy"), so in documents two different sector words must recur."""
    words = [w for w in entry["topic"].split() if len(w) > 2]
    pattern = re.compile(r"(?i)\b(" + "|".join(re.escape(w) for w in words) + r")\b")
    described = " ".join(str(f["value"]) for path, f in ws["facts"].items()
                         if (path.startswith("narrative.") or path in DESCRIPTION_PATHS)
                         and isinstance(f.get("value"), str) and f["state"] not in {"missing", "conflict"})
    if pattern.search(described):
        return True
    hits = [m.lower() for m in pattern.findall(company_text(ws))]
    return len(set(hits)) >= 2 and len(hits) >= 5


DESCRIPTION_PATHS = {"project.description", "project.name", "company.activities", "company.sector"}


def fit_verdict(why, checks, match_status, assessment, wrong_stage):
    """An honest overall answer for the card: likely, possible or unlikely, with the main reason in plain words.

    Only an AI check or a sentence of the grant matching the project can make a fit likely. A region match alone
    makes a general scheme possible at best, and a scheme for other work or another sector is unlikely."""
    topic, instrument = why["topic"], why["instrument"] or {}
    requirement = next((c for c in instrument.get("checks", []) if c["kind"] == "requirement"), None)
    region = next((c for c in instrument.get("checks", []) if c["kind"] == "region"), None)
    failed = [c for c in checks if c["outcome"] == "FAIL"]
    fit = (assessment or {}).get("fit")
    if match_status == "DOES_NOT_FIT" or failed:
        label = failed[0]["label"] if failed else "a condition of this scheme"
        return {"level": "unlikely", "reason": f"Your details do not meet: {label[:160]}."}
    if fit == "weak":
        return {"level": "unlikely", "reason": assessment.get("rationale") or "The AI check found a poor fit with your project."}
    if topic["source"] == "instrument_topic":
        return {"level": "unlikely", "reason": f"This scheme is for {topic['needed']}; nothing in your profile is about that."}
    if requirement and requirement["status"] == "not_found":
        return {"level": "unlikely", "reason": f"This scheme is for {requirement['needed']}. Your profile does not describe that kind of work."}
    if region and region["status"] == "failed":
        return {"level": "unlikely", "reason": f"This scheme is only for companies in {region['needed']}."}
    if fit == "strong":
        return {"level": "likely", "reason": assessment.get("rationale") or "The AI check found a strong fit."}
    if fit == "unclear":
        return {"level": "possible", "reason": assessment.get("rationale") or "The AI check could not tell whether this fits."}
    if wrong_stage:
        return {"level": "possible", "reason": "This scheme funds a different project stage than the one in your profile; check whether your plans fit."}
    if topic["source"] in {"call_text", "semantic"}:
        # Shared words suggest a topic link but cannot confirm one; only the AI check or a hand-checked audience can.
        if topic["level"] in {"strong", "partial"}:
            return {"level": "possible", "reason": "The grant’s text uses the same words as your project; that does not confirm it fits."}
        return {"level": "unlikely" if topic["level"] == "none" and not fit else "possible",
                "reason": "Little in the grant’s text matches what your company does."}
    if requirement and requirement["status"] == "unknown":
        return {"level": "possible", "reason": f"Only if your company does {requirement['needed']}. Add more about your work to check."}
    if requirement and requirement["status"] == "met" and (not region or region["status"] == "met"):
        # A hand-checked scheme whose audience we can verify: the kind of work and the region both match.
        return {"level": "likely", "reason": f"Your profile describes {requirement['needed'].split(' (')[0]}, which this scheme is for, "
                                             "and your region matches. Check its other conditions."}
    if topic["source"] == "instrument":
        return {"level": "possible", "reason": "A general scheme open to many kinds of companies; check its conditions."}
    return {"level": "possible", "reason": "Part of the grant matches your project; check the conditions."}


def quoted(check):
    evidence = check.get("evidence")
    evidence = evidence[0] if isinstance(evidence, list) and evidence else evidence
    return (evidence or {}).get("quote") if isinstance(evidence, dict) else None


def who_can_apply(checks):
    """Conditions of the grant by outcome, each with the sentence it comes from."""
    def entry(check):
        return {"label": check["label"][:200], "actual": check.get("actual"), "quote": quoted(check)}
    groups = {"met": [], "to_check": [], "failed": []}
    for check in checks:
        if check["outcome"] == "PASS":
            groups["met"].append(entry(check))
        elif check["outcome"] == "FAIL":
            groups["failed"].append(entry(check))
        elif check["outcome"] in {"UNKNOWN", "CONFLICT", "MANUAL_REVIEW"}:
            groups["to_check"].append(entry(check))
    return {key: {"count": len(items), "items": items[:3]} for key, items in groups.items()}


def explain(record, ws, checks, evidence, assessment, focus_entry):
    """Everything the card shows under "Why this could fit"."""
    instrument = None
    # A focus scheme without a sector topic is open to any project: its text describes the instrument, so shared words
    # ("seed" in a seed round and in Seed Capital) say nothing about the project's subject.
    general_scheme = bool(focus_entry) and "topic" not in focus_entry
    if focus_entry:
        requirement = requirement_check(focus_entry, ws)
        instrument = {"audience": focus_entry["audience"], "summary": focus_entry["summary"], "verify": bool(focus_entry.get("verify")),
                      "checks": [region_check(focus_entry, ws), stage_check(focus_entry, ws)] + ([requirement] if requirement else [])}
    if assessment:
        grant = (assessment.get("grant_quotes") or [None])[0]
        project = (assessment.get("project_quotes") or [None])[0]
        topic = {"source": "ai", "level": assessment["fit"], "pairs": [], "rationale": assessment["rationale"],
                 "grant": {"text": grant["quote"], "words": [], "locator": grant.get("locator"), "url": grant.get("url")} if grant else None,
                 "project": {"text": project["quote"], "words": []} if project else None}
    elif evidence and not general_scheme and (evidence["level"] in {"strong", "partial"} or not focus_entry):
        grant = evidence["grant"]
        topic = {"source": "call_text", "level": evidence["level"], "pairs": evidence["pairs"], "rationale": None,
                 "grant": {**grant, "url": record["url"]} if grant else None, "project": evidence["project"]}
    elif focus_entry and not general_scheme and not topic_words_found(focus_entry, ws):
        # A scheme for one sector (maritime, healthcare, energy) whose text does not match the project is not a general
        # scheme: say what it is for instead of presenting it as open to anyone.
        topic = {"source": "instrument_topic", "level": "none", "pairs": [], "rationale": None, "grant": None, "project": None,
                 "needed": topic_label(focus_entry)}
    elif focus_entry:
        topic = {"source": "instrument", "level": "broad", "pairs": [], "rationale": None, "grant": None, "project": None}
    elif record.get("semantic_candidate"):
        topic = {"source": "semantic", "level": "none", "pairs": [], "rationale": None, "grant": None, "project": None}
    else:
        topic = {"source": "call_text", "level": "none", "pairs": [], "rationale": None, "grant": None, "project": None}
    return {"topic": topic, "instrument": instrument, "who": who_can_apply(checks)}
