"""The plain facts behind a match, for the grant card.

Three kinds of evidence, never mixed up:
  * topic: a sentence of the grant next to a sentence of the project (or the AI assessment's own quotes);
  * instrument: for broad startup schemes that are not about one topic, whether the company's region and
    project stage in the profile match what the scheme is for;
  * who: the grant's conditions that are met, still to check, or not met.
A grant that was merely not excluded gets level "weak" or "none", and the card says so.
"""
from typing import Literal, TypedDict

from .grant_specification import EU27
from .profiles import fact_value
from .retrieval import DUTCH_PROVINCES

# The founder's own answer about the project, mapped to the stages a scheme says it funds.
ACTIVITY_STAGES = {"feasibility_study": "feasibility", "industrial_research": "research", "experimental_development": "development"}
Status = Literal["met", "unknown", "different", "failed"]


class InstrumentCheck(TypedDict):
    kind: Literal["region", "stage"]
    status: Status
    value: str | None
    needed: str


def region_check(entry, ws) -> InstrumentCheck:
    region, cities = entry["region"], entry.get("cities") or []
    province = str(fact_value(ws, "company.province") or "")
    country = str(fact_value(ws, "company.country") or "")
    city = str(fact_value(ws, "company.city") or "")
    if cities:
        status = "unknown" if not city else "met" if city.casefold() in {c.casefold() for c in cities} else "failed"
        return {"kind": "region", "status": status, "value": city or None, "needed": cities[0]}
    if region in DUTCH_PROVINCES:
        status = "unknown" if not province else "met" if province == region else "failed"
        return {"kind": "region", "status": status, "value": province or None, "needed": region}
    if region == "Europe":
        status = "unknown" if not country else "met" if country in EU27 else "failed"
        return {"kind": "region", "status": status, "value": country or None, "needed": region}
    in_netherlands = country == "Netherlands" or province in DUTCH_PROVINCES
    status = "met" if in_netherlands else "failed" if country else "unknown"
    return {"kind": "region", "status": status, "value": country or province or None, "needed": region}


def stage_check(entry, ws) -> InstrumentCheck:
    """Whether the project stage in the profile is one the scheme funds; never guessed from loose words in the text."""
    funds = entry.get("stages") or []
    stage = ACTIVITY_STAGES.get(str(fact_value(ws, "project.primary_activity")))
    status = "unknown" if stage is None else "met" if stage in funds else "different"
    return {"kind": "stage", "status": status, "value": stage, "needed": ", ".join(funds)}


def quoted(check):
    evidence = check.get("evidence")
    evidence = evidence[0] if isinstance(evidence, list) and evidence else evidence
    return (evidence or {}).get("quote") if isinstance(evidence, dict) else None


def who_can_apply(checks):
    """Conditions of the grant by outcome, each with the sentence it comes from."""
    def entry(check):
        return {"label": check["label"][:200], "actual": check.get("actual"), "quote": quoted(check)}
    groups = {"met": [], "to_check": [], "failed": []}
    for check in checks:
        if check["outcome"] == "PASS":
            groups["met"].append(entry(check))
        elif check["outcome"] == "FAIL":
            groups["failed"].append(entry(check))
        elif check["outcome"] in {"UNKNOWN", "CONFLICT", "MANUAL_REVIEW"}:
            groups["to_check"].append(entry(check))
    return {key: {"count": len(items), "items": items[:3]} for key, items in groups.items()}


def explain(record, ws, checks, evidence, assessment, focus_entry):
    """Everything the card shows under "Why this could fit"."""
    instrument = None
    # A focus scheme without a sector topic is open to any project: its text describes the instrument, so shared words
    # ("seed" in a seed round and in Seed Capital) say nothing about the project's subject.
    general_scheme = bool(focus_entry) and "topic" not in focus_entry
    if focus_entry:
        instrument = {"audience": focus_entry["audience"], "summary": focus_entry["summary"], "verify": bool(focus_entry.get("verify")),
                      "checks": [region_check(focus_entry, ws), stage_check(focus_entry, ws)]}
    if assessment:
        grant = (assessment.get("grant_quotes") or [None])[0]
        project = (assessment.get("project_quotes") or [None])[0]
        topic = {"source": "ai", "level": assessment["fit"], "pairs": [], "rationale": assessment["rationale"],
                 "grant": {"text": grant["quote"], "words": [], "locator": grant.get("locator"), "url": grant.get("url")} if grant else None,
                 "project": {"text": project["quote"], "words": []} if project else None}
    elif evidence and not general_scheme and (evidence["level"] in {"strong", "partial"} or not focus_entry):
        grant = evidence["grant"]
        topic = {"source": "call_text", "level": evidence["level"], "pairs": evidence["pairs"], "rationale": None,
                 "grant": {**grant, "url": record["url"]} if grant else None, "project": evidence["project"]}
    elif focus_entry:
        topic = {"source": "instrument", "level": "broad", "pairs": [], "rationale": None, "grant": None, "project": None}
    elif record.get("semantic_candidate"):
        topic = {"source": "semantic", "level": "none", "pairs": [], "rationale": None, "grant": None, "project": None}
    else:
        topic = {"source": "call_text", "level": "none", "pairs": [], "rationale": None, "grant": None, "project": None}
    return {"topic": topic, "instrument": instrument, "who": who_can_apply(checks)}
