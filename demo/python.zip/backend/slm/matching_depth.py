"""Module 4: transparent prioritisation, grouping, actionable changes and questions.

Ranking is deterministic given the current profile, call text and verified fit assessments. Nothing in this module estimates the
chance of an award; the single number it produces is labelled "ranking information" and
only orders the list.

Ranking order (the same order is documented in docs/MODULE_04_STATUS.md):

1. ``group``: pursue_now, could_fit_after_change, fit_review, other_instruments and outside_window (one place),
   not_recommended, known_incompatible. Known incompatibilities and application windows come first.
2. ``project_fit``: verified strong/partial assessments take priority over unassessed keyword candidates.
   Weak and unclear fits leave the recommended list; eligibility failures remain authoritative.
3. ``timing``: confirmed open window, then published deadline / reported open, then
   not yet open, then undated, then closed.
4. ``fit tier``: 0 when the call matches the project on specific topics and its stated
   stage does not differ from the project's; +1 for a stage mismatch; +1 when only generic
   sector words matched. A word-heavy generic match therefore cannot outrank a project that
   meets the call's actual activity/maturity requirements.
5. ``ranking information`` (0-100): weighted objective fit (40), stage compatibility (20),
   evidence coverage (20), budget fit (10) and preparation effort (10).
6. The opportunity identifier, so equal inputs always give the same order.
"""
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
from .funding_conditions import evaluate_requirements, date_value
from .live_matching import tokens, concepts, CONCEPTS, profile_text
from .profiles import fact_value
from .domain import BOOL_PATHS, CHOICE_PATHS

RANKING_VERSION = "ranking-1.6"
GROUP_ORDER = ("pursue_now", "could_fit_after_change", "fit_review", "other_instruments", "outside_window", "not_recommended", "known_incompatible")
ADJUSTABLE = {"project.organisation_count", "project.independent_sme_participant_count",
              "project_budget_cents", "project.primary_activity"}
WEIGHTS = {"objective_fit": 50, "stage_compatibility": 20, "evidence_coverage": 20, "budget_fit": 10}
TIMING = {
    "WITHIN_WINDOW": (0, "Open for applications"),
    "ROLLING": (0, "Applications are ongoing"),
    "DEADLINE_PUBLISHED": (1, "Closing date published"),
    "REPORTED_OPEN": (1, "Reported open by the source"),
    "UPCOMING": (2, "Not open yet"),
    "UNKNOWN": (3, "No confirmed application dates"),
    "CONFLICT": (3, "Sources disagree on the dates"),
    "CLOSED": (4, "Closed"),
}
ACTIONABLE_TIMING = {"WITHIN_WINDOW", "ROLLING", "DEADLINE_PUBLISHED", "REPORTED_OPEN"}
INFORMATION_NOTE = ("Ranking information only: it orders this list and is not a probability or likelihood of an award. "
                    "Eligibility and awards are decided by the funder.")
CAVEAT = ("Meeting this one condition does not establish eligibility; the other conditions and the full call text "
          "still need review, and the change must reflect a genuine change to the project.")
GROUP_DEFINITIONS = {
    "fit_review": "The project’s fit needs clarification before this call can be recommended.",
    "not_recommended": "The described project does not align well with the call’s objectives or supported activities.",
    "pursue_now": "Open for applications with no known incompatibility.",
    "could_fit_after_change": "Fails a condition only because of a project detail that can be changed.",
    "other_instruments": "Loans, tax relief, guarantees or investment; these are not grants.",
    "outside_window": "Closed, not yet open, or without confirmed application dates.",
    "known_incompatible": "Fails a condition that your company or project cannot simply change.",
}
RANKING_POLICY = {
    "version": RANKING_VERSION,
    "order": ["Group (worth pursuing now, could fit after a change, fit needs clarification, other instruments, outside window, not recommended, known incompatibility)",
              "Verified project fit (strong, partial, not assessed; unclear and weak fits are separated)", "Application timing", "Fit tier (stage matches and specific topic overlap)",
              "Ranking information (objective fit 50, stage 20, evidence coverage 20, budget 10); preparation effort is informational"],
    "note": INFORMATION_NOTE,
}
ACTIVITY_LABELS = {"feasibility_study": "feasibility study", "industrial_research": "industrial research",
                   "experimental_development": "experimental development",
                   "combined_research_development": "combined research and development", "other": "other activity"}
ACTIVITY_PHRASES = {"feasibility_study": "a feasibility study", "industrial_research": "industrial research",
                    "experimental_development": "experimental development",
                    "combined_research_development": "combined research and development", "other": "another type of project"}
ACTIVITY_STAGES = {"feasibility_study": {"feasibility_study"}, "industrial_research": {"industrial_research"},
                   "experimental_development": {"experimental_development"},
                   "combined_research_development": {"industrial_research", "experimental_development"}, "other": set()}
STAGE_PATTERNS = {
    "feasibility_study": re.compile(r"(?i)feasibility stud|haalbaarheidsstud|haalbaarheidsproject|haalbaarheidsonderzoek"),
    "industrial_research": re.compile(r"(?i)industrial research|industrieel onderzoek|industri[eë]le onderzoek"),
    "experimental_development": re.compile(r"(?i)experimental development|experimentele ontwikkeling|demonstrat|\bpilots?\b|prototyp|proefproject|\bTRL ?[6-8]\b"),
}
NEGATION = re.compile(r"(?i)\b(?:not|niet|geen|no|except|tenzij|excluding|excluded|uitgesloten|uitgezonderd)\b")
OBJECTIVE_MARKERS = re.compile(
    r"(?i)objective|doelstelling|\bdoel\b|purpose|\baims?\b|eligible activit|subsidiabele activiteit|scope|\bfocus|\bsupports?\b|"
    r"ondersteun|\bfunds?\b|\bfunded\b|expected (?:outcome|impact|result)|call for|gericht op|bedoeld voor|projecten die|"
    r"projects (?:that|which)|\bactivit")
# Broad industry vocabulary can never substitute for a project's actual subject.
GENERIC_CONCEPTS = {"manufacturing", "research", "software", "transport"}
GENERIC_WORDS = {w for name in GENERIC_CONCEPTS for w in CONCEPTS[name].split()} | tokens(" ".join(CONCEPTS[n] for n in GENERIC_CONCEPTS))
INSTRUMENTS = {"tax_relief": "Tax support", "loan": "Loan (repayable)", "equity": "Investment", "guarantee": "Guarantee"}
QUESTION_LABELS = {
    "company.country": "Where is your company registered?",
    "company.province": "In which province is your company established?",
    "company.sme_self_declared": "Have you checked that your company qualifies as an SME?",
    "project.independent_sme_participant_count": "How many independent SME partners will take part?",
    "project.organisation_count": "How many organisations will take part, including yours?",
    "project.primary_activity": "What stage is this project at?",
    "project_budget_cents": "What is the proposed project budget?",
    "company.legal_form": "What is your company's legal form (for example B.V.)?",
    "company.founded_date": "When was your company founded?",
    "project.trl": "Which technology readiness level (TRL 1–9) has your technology reached?",
    "company.tu_delft_affiliation": "What is your link with TU Delft?",
    "company.women_led": "Does a woman founder hold the top position (CEO or CTO) and at least 25% of the shares?",
    "company.university_spin_out": "Is your company built on research taken over or licensed from a Dutch university or knowledge institute?",
    "company.founder_employed_researcher": "Is one of the founders employed as a researcher at a Dutch university or research institute (not as a PhD candidate)?",
    "company.fte": "How many people work in your company (in full-time equivalents)?",
    "finance.cofinancing_available": "Can you pay the part of the project costs that a scheme does not cover (yourself or with investors)?",
}
# Yes/no questions: the founder answers with one of these, sent as true or false.
YES_NO = {"true": "Yes", "false": "No"}
# A condition on a worked-out value is answered through the profile detail it comes from.
ASKED_FIELDS = {"company.age_months": "company.founded_date"}
QUESTION_PRIORITY = ["project.primary_activity", "project.organisation_count",
                     "company.country", "company.province", "project_budget_cents", "company.sme_self_declared",
                     "project.independent_sme_participant_count", "company.tu_delft_affiliation", "company.legal_form",
                     "company.founded_date", "project.trl", "company.university_spin_out", "company.women_led",
                     "company.founder_employed_researcher", "finance.cofinancing_available", "company.fte"]
STATE_FACTS = ("company.country", "company.province", "company.sme_self_declared", "project.primary_activity",
               "company.legal_form", "company.founded_date", "project.trl", "company.tu_delft_affiliation",
               "company.women_led", "company.university_spin_out", "company.founder_employed_researcher", "company.fte",
               "finance.cofinancing_available",
               "project.independent_sme_participant_count", "project.start_date", "project.description",
               "narrative.innovation_description", "narrative.activities", "narrative.market_perspective", "company.activities")


def money(cents):
    value = cents / 100
    return "€" + (f"{value:,.0f}" if value == int(value) else f"{value:,.2f}")


def activity_label(value):
    return ACTIVITY_LABELS.get(value, str(value).replace("_", " "))


def plural(count, noun):
    return f"{count} {noun}{'' if count == 1 else 's'}"


# --- condition structure ---------------------------------------------------------------------

def rule_leaves(rule, ws, evidence=None, conjunctive=True):
    """Atomic conditions below a typed rule. ``conjunctive`` is true only through ``all`` nodes."""
    if not rule or rule.get("kind") in {None, "manual"}:
        return []
    if rule["kind"] == "atomic":
        checked = evaluate_requirements({"requirements": [{"id": "leaf", "label": rule["field"], "field": rule["field"],
            "operator": rule["operator"], "expected": rule["expected"], "evidence": evidence or {}}]}, ws)[0]
        return [{"field": rule["field"], "operator": rule["operator"], "expected": rule["expected"],
                 "actual": checked["actual"], "outcome": checked["outcome"], "conjunctive": conjunctive}]
    leaves = []
    for child in rule.get("children", []):
        leaves += rule_leaves(child, ws, evidence, conjunctive and rule["kind"] == "all")
    return leaves


def check_leaves(check):
    if "leaves" in check:
        return check["leaves"]
    if check.get("field") and check.get("operator"):
        return [{"field": check["field"], "operator": check["operator"], "expected": check.get("expected"),
                 "actual": check.get("actual"), "outcome": check["outcome"], "conjunctive": True}]
    return []


def condition_text(leaf):
    field, operator, n = leaf["field"], leaf["operator"], leaf["expected"]
    if field == "project.organisation_count":
        return {"gte": f"minimum {plural(n, 'organisation')}", "lte": f"maximum {plural(n, 'organisation')}",
                "eq": f"exactly {plural(n, 'organisation')}"}.get(operator)
    if field == "project.independent_sme_participant_count":
        return {"gte": f"minimum {plural(n, 'independent SME partner')}", "lte": f"maximum {plural(n, 'independent SME partner')}",
                "eq": f"exactly {plural(n, 'independent SME partner')}"}.get(operator)
    if field == "project_budget_cents":
        return {"gte": f"minimum project budget {money(n)}", "lte": f"maximum project budget {money(n)}",
                "eq": f"project budget of {money(n)}"}.get(operator)
    if field == "project.primary_activity":
        return "project type: " + " or ".join(activity_label(v) for v in (n if isinstance(n, list) else [n]))
    if field == "company.country":
        return "established in " + " or ".join(n if isinstance(n, list) else [n])
    if field == "company.province":
        return f"established in {n}"
    if field == "company.sme_self_declared":
        return "SME applicant" if n else "not an SME"
    if field == "company.legal_form":
        return "legal form: " + (n[0] if isinstance(n, list) else n)
    if field == "project.trl":
        return {"gte": f"technology at TRL {n} or higher", "lte": f"technology at TRL {n} or lower", "eq": f"technology at TRL {n}"}.get(operator)
    if field == "company.age_months":
        age = f"{n // 12} years" if n % 12 == 0 else f"{n} months"
        return {"lte": f"company founded at most {age} ago", "gte": f"company founded at least {age} ago"}.get(operator)
    if field == "company.tu_delft_affiliation":
        return "TU Delft link: " + " or ".join(CHOICE_PATHS[field][v] for v in (n if isinstance(n, list) else [n]))
    if field == "company.fte":
        return {"lte": f"at most {n} FTE", "gte": f"at least {n} FTE"}.get(operator)
    if field in YES_FACTS and operator == "eq":
        return YES_FACTS[field] if n else "not: " + YES_FACTS[field]
    return None


# What a yes on these details means, in a condition line.
YES_FACTS = {"company.women_led": "woman founder in the top position", "company.university_spin_out": "built on Dutch university research",
             "company.founder_employed_researcher": "founder employed as a university researcher",
             "finance.cofinancing_available": "own share of the costs available"}


def describe_check(check):
    leaves = check_leaves(check)
    if len(leaves) == 1 and condition_text(leaves[0]):
        return condition_text(leaves[0])
    return check.get("label") or "condition"


def counts_of(checks):
    c = Counter(check["outcome"] for check in checks)
    return {"pass": c["PASS"], "fail": c["FAIL"], "unknown": c["UNKNOWN"], "conflict": c["CONFLICT"],
            "manual_review": c["MANUAL_REVIEW"], "not_applicable": c["NOT_APPLICABLE"], "total": len(checks)}


# --- stage ---------------------------------------------------------------------------------------

def sentences(text):
    found = []
    for part in re.split(r"(?<=[.!?;])\s+|\n+", text or ""):
        part = part.strip()
        if len(part) >= 20:
            found.append(part[:400])
    return found


def call_stage_signals(record, specification):
    """Stages a call positively states that it funds. The title is deliberately not used."""
    sources = [("Call description", None, s) for s in sentences(record.get("description"))]
    for block in record.get("blocks", []):
        sources += [(block.get("locator", "Call text"), block.get("id"), s) for s in sentences(block["text"])]
    for req in (specification or {}).get("requirements", []):
        sources += [(req.get("evidence", {}).get("locator", "Requirement"), req.get("evidence", {}).get("block_id"), s)
                    for s in sentences(req.get("text"))]
    signals = {}
    for locator, block_id, sentence in sources:
        if NEGATION.search(sentence):
            continue
        for stage, pattern in STAGE_PATTERNS.items():
            if stage not in signals and pattern.search(sentence):
                signals[stage] = {"locator": locator, "block_id": block_id, "quote": sentence}
    return signals


def stage_assessment(ws, checks, record, specification):
    activity = fact_value(ws, "project.primary_activity")
    leaves = [l for c in checks for l in check_leaves(c) if l["field"] == "project.primary_activity" and l["conjunctive"]]
    if leaves:
        stages = sorted({v for l in leaves for v in (l["expected"] if isinstance(l["expected"], list) else [l["expected"]])})
        state = "mismatch" if any(l["outcome"] == "FAIL" for l in leaves) else "unknown" if any(
            l["outcome"] in {"UNKNOWN", "CONFLICT"} for l in leaves) else "meets"
        return {"state": state, "source": "rule", "project": activity, "call": stages, "quote": None}
    signals = call_stage_signals(record, specification)
    if not signals:
        return {"state": "unspecified", "source": None, "project": activity, "call": [], "quote": None}
    first = next(iter(signals.values()))
    if activity is None:
        return {"state": "unknown", "source": "text", "project": None, "call": sorted(signals), "quote": first}
    shared = ACTIVITY_STAGES.get(activity, set()) & set(signals)
    return {"state": "meets" if shared else "mismatch", "source": "text", "project": activity, "call": sorted(signals),
            "quote": signals[sorted(shared)[0]] if shared else first}


def stage_factor(stage):
    names = " / ".join(activity_label(s) for s in stage["call"])
    mine = activity_label(stage["project"]) if stage["project"] else "unknown"
    basis = "a stated condition" if stage["source"] == "rule" else "the call text"
    if stage["state"] == "meets":
        return ("raises", 1.0, f"Your project ({mine}) matches what the call funds ({names}), according to {basis}.")
    if stage["state"] == "mismatch":
        return ("lowers", 0.0, f"Your project ({mine}) differs from what the call funds ({names}), according to {basis}.")
    if stage["state"] == "unknown":
        return ("unknown", 0.5, f"The call funds {names} ({basis}); your project's stage is not known yet.")
    return ("neutral", 0.5, "The call does not state a project stage that we could read.")


# --- objective fit -------------------------------------------------------------------------------

def objective_sources(record, specification):
    sources = []

    def add(locator, text, block_id=None):
        for sentence in sentences(text):
            sources.append({"locator": locator, "text": sentence, "block_id": block_id})

    add("Call description", record.get("description"))
    for block in record.get("blocks", []):
        if len(block["text"]) <= 3000 and OBJECTIVE_MARKERS.search(block.get("locator", "") + " " + block["text"]):
            add(block.get("locator", "Call text"), block["text"], block.get("id"))
    for criterion in (specification or {}).get("assessment_criteria", []):
        add("Assessment criteria", criterion["criterion"], (criterion.get("evidence") or {}).get("block_id"))
    return sources


def objective_fit(text, record, specification, shared, common_topics):
    project_tokens = tokens(text) - GENERIC_WORDS
    project_topics = concepts(text) - GENERIC_CONCEPTS
    topic_hits = sorted(set(common_topics) - GENERIC_CONCEPTS)
    word_hits = sorted(w for w in shared if w not in GENERIC_WORDS)
    generic_hits = sorted(w for w in shared if w in GENERIC_WORDS)
    sources = objective_sources(record, specification)
    scored, objective_concepts = [], set()
    for source in sources:
        objective_concepts |= concepts(source["text"])
        hits = sorted(tokens(source["text"]) & project_tokens)
        if hits:
            scored.append((len(hits), source, hits))
    scored.sort(key=lambda row: (row[1]["block_id"] is None, -row[0]))
    objective_terms = sorted({h for _, _, hits in scored for h in hits})
    concept_hits = sorted(objective_concepts & project_topics)
    ratio = lambda part: len(part) / len(project_topics) if project_topics else 0.0
    topic_component = 0.6 * ratio(topic_hits) + 0.4 * min(1.0, len(word_hits) / 6)
    objective_component = 0.6 * min(1.0, len(objective_terms) / 6) + 0.4 * ratio(concept_hits)
    component = round(0.5 * topic_component + 0.5 * objective_component, 3)
    # A concrete multi-word activity can establish fit within a broad sector.
    activity_phrase = any(re.search(r"(?i)\b(pilot|assembly|automation|robotic)\b", s["text"]) and
                          len(set(tokens(s["text"])) & tokens(text)) >= 2 for s in sources)
    specific = bool(topic_hits or concept_hits or len(objective_terms) >= 3 or activity_phrase)
    evidence = [{"locator": s["locator"], "block_id": s["block_id"], "quote": s["text"], "terms": hits[:6]}
                for _, s, hits in scored[:2]]
    if specific:
        parts = []
        if topic_hits:
            parts.append("topics " + ", ".join(topic_hits))
        if objective_terms:
            parts.append("the call's stated objectives and activities mention " + ", ".join(objective_terms[:6]))
        value = "Matches on " + "; ".join(parts) + "."
    elif generic_hits or word_hits:
        value = "Only generic sector words overlap (" + ", ".join((generic_hits + word_hits)[:5]) + "); no specific topic or objective term matched."
    else:
        value = "No overlap between your project text and the call's stated objectives was found."
    effect = "lowers" if not specific or component < 0.2 else "raises" if component >= 0.5 else "neutral"
    return {"component": component, "class": "specific" if specific else "generic", "value": value, "effect": effect,
            "evidence": evidence, "topics": topic_hits, "terms": objective_terms[:8]}


# --- other factors -------------------------------------------------------------------------------

def timing_factor(timing, ws, clock):
    status = timing["status"]
    tier, label = TIMING.get(status, (3, "Dates to check"))
    value, deadline = label, timing.get("deadline")
    if deadline:
        value += (" · closing date " if status in ACTIONABLE_TIMING or status == "UPCOMING" else " · last date ") + deadline[:10]
        parsed = date_value(deadline)
        if parsed is not None and status in ACTIONABLE_TIMING:
            today = (clock or datetime.now(ZoneInfo("Europe/Amsterdam"))).date()
            days = ((parsed.date() if isinstance(parsed, datetime) else parsed) - today).days
            if days >= 0:
                value += f" ({plural(days, 'day')} left)"
            start = fact_value(ws, "project.start_date")
            if start and deadline[:10] < str(start):
                value += f"; your planned start ({start}) is after this closing date"
    return tier, {"key": "timing", "label": "Application timing", "value": value,
                  "effect": "raises" if tier == 0 else "neutral" if tier == 1 else "lowers"}


def incompatibility_factor(checks):
    failed = [c for c in checks if c["outcome"] == "FAIL"]
    conflicts = [c for c in checks if c["outcome"] == "CONFLICT"]
    if failed:
        value = "Does not meet: " + "; ".join(describe_check(c) for c in failed[:3])
    else:
        value = f"No failed condition among the {plural(len(checks), 'condition')} read so far"
    if conflicts:
        value += "; conflicting information on " + "; ".join(describe_check(c) for c in conflicts[:2])
    return {"key": "incompatibility", "label": "Known incompatibilities", "value": value,
            "effect": "lowers" if failed else "unknown" if conflicts else "neutral"}


def coverage_factor(checks):
    counts = counts_of(checks)
    judged = counts["total"] - counts["not_applicable"]
    if not judged:
        return 0.0, {"key": "evidence_coverage", "label": "Evidence coverage", "effect": "lowers",
                     "value": "No conditions could be checked automatically from the call text read so far."}
    share = counts["pass"] / judged
    parts = [f"{counts['pass']} of {judged} conditions met on your information"]
    if counts["fail"]:
        parts.append(f"{counts['fail']} not met")
    if counts["unknown"] + counts["conflict"]:
        parts.append(f"{counts['unknown'] + counts['conflict']} unknown or conflicting")
    if counts["manual_review"]:
        parts.append(f"{counts['manual_review']} need a person's judgement")
    return share, {"key": "evidence_coverage", "label": "Evidence coverage", "value": "; ".join(parts),
                   "effect": "raises" if share >= 0.75 else "lowers" if share < 0.34 else "neutral"}


def budget_factor(checks):
    entries = [(c, l) for c in checks for l in check_leaves(c) if l["field"] == "project_budget_cents"]
    base = {"key": "budget_fit", "label": "Budget fit"}
    if not entries:
        return 0.5, {**base, "effect": "neutral", "value": "No project-budget condition was read from this call. "
                     "A programme budget or grant amount is never used as your project budget."}
    outcomes = {l["outcome"] for _, l in entries}
    texts = "; ".join(condition_text(l) for _, l in entries)
    actual = next((l["actual"] for _, l in entries if l["actual"] is not None), None)
    if "FAIL" in outcomes:
        return 0.0, {**base, "effect": "lowers", "value": f"Your project budget ({money(actual)}) does not meet: {texts}."}
    if outcomes & {"UNKNOWN", "CONFLICT"}:
        return 0.4, {**base, "effect": "unknown", "value": f"The call states a project-budget condition ({texts}); your project budget is not known."}
    return 1.0, {**base, "effect": "raises", "value": f"Your project budget ({money(actual)}) is within: {texts}."}


def effort_factor(specification):
    base = {"key": "preparation_effort", "label": "Preparation effort"}
    if not specification:
        return 0.5, {**base, "effect": "unknown", "value": "The call's attachments and application sections have not been read yet."}
    attachments = [a for a in specification.get("attachments", []) if a.get("required") is not False]
    sections = [s for s in specification.get("application_sections", []) if s.get("required") is not False]
    total = len(attachments) + len(sections)
    if not total:
        return 0.5, {**base, "effect": "unknown", "value": "No attachments or application sections were identified in the retained documents."}
    level, share, effect = ("light", 1.0, "raises") if total <= 5 else ("moderate", 0.6, "neutral") if total <= 12 else ("heavy", 0.2, "lowers")
    return share, {**base, "effect": effect,
                   "value": f"{level.capitalize()} preparation: {plural(len(attachments), 'attachment')} and {plural(len(sections), 'application section')} identified."}


# --- grouping and actionable changes ----------------------------------------------------------------

def analyse_failures(checks):
    entries = []
    for check in checks:
        if check["outcome"] != "FAIL":
            continue
        leaves = check_leaves(check)
        failing = [l for l in leaves if l["outcome"] == "FAIL" and l["conjunctive"]]
        hidden = [l for l in leaves if l["outcome"] == "FAIL" and not l["conjunctive"]]
        if failing and not hidden:
            entries += [(check, l) for l in failing]
        else:
            entries.append((check, None))
    adjustable = bool(entries) and all(l is not None and l["field"] in ADJUSTABLE for _, l in entries)
    return entries, adjustable


def change_for(leaf, check):
    field, op, expected, actual, outcome = leaf["field"], leaf["operator"], leaf["expected"], leaf["actual"], leaf["outcome"]
    base = {"field": field, "label": condition_text(leaf) or check.get("label"), "current": actual, "required": expected,
            "operator": op, "outcome": outcome, "check_id": check.get("id"), "evidence": check.get("evidence"),
            "options": None, "caveat": CAVEAT}
    if field in {"project.organisation_count", "project.independent_sme_participant_count"}:
        noun = "organisation" if field == "project.organisation_count" else "independent SME partner"
        phrase = {"gte": "at least", "lte": "at most", "eq": "exactly"}[op]
        if outcome == "UNKNOWN":
            return {**base, "kind": "confirm", "suggested_value": expected,
                    "change": f"Confirm how many {noun}s will take part: this call requires {phrase} {plural(expected, noun)}."}
        if op == "gte":
            short = expected - actual
            lead = "Add a partner" if short == 1 else f"Add {short} partners"
            return {**base, "kind": "increase", "suggested_value": expected,
                    "change": f"{lead}: this call requires at least {plural(expected, noun)}."}
        if op == "lte":
            return {**base, "kind": "decrease", "suggested_value": expected,
                    "change": f"Reduce to at most {plural(expected, noun)}: this call allows no more."}
        return {**base, "kind": "set", "suggested_value": expected,
                "change": f"Change to exactly {plural(expected, noun)}: this call requires that number."}
    if field == "project_budget_cents":
        if outcome == "UNKNOWN":
            return {**base, "kind": "confirm", "suggested_value": expected,
                    "change": f"Confirm your project budget: this call has a {condition_text(leaf)}."}
        if op == "gte":
            return {**base, "kind": "increase", "suggested_value": expected,
                    "change": f"Increase the planned project budget to at least {money(expected)} (now {money(actual)}): this call has a {condition_text(leaf)}."}
        if op == "lte":
            return {**base, "kind": "decrease", "suggested_value": expected,
                    "change": f"Reduce the planned project budget to at most {money(expected)} (now {money(actual)}): this call has a {condition_text(leaf)}."}
        return {**base, "kind": "set", "suggested_value": expected,
                "change": f"Change the planned project budget to {money(expected)}: this call has a {condition_text(leaf)}."}
    options = expected if isinstance(expected, list) else [expected]
    names = " or ".join(ACTIVITY_PHRASES.get(v, activity_label(v)) for v in options)
    suggested = next((v for v in options if v in ACTIVITY_LABELS), None)
    if outcome == "UNKNOWN":
        return {**base, "kind": "confirm", "suggested_value": suggested, "options": options,
                "change": f"Confirm the project type: this call only funds {names}."}
    return {**base, "kind": "set", "suggested_value": suggested, "options": options,
            "change": f"Scope the project as {names} (now {activity_label(actual)}): this call only funds that type of project."}


def actionable_changes(checks, entries, adjustable):
    """Changes for adjustable failures, plus confirmations for adjustable unknowns."""
    changes, seen = [], set()
    if adjustable:
        for check, leaf in entries:
            changes.append(change_for(leaf, check))
    elif entries:
        return []
    for check in checks:
        if check["outcome"] != "UNKNOWN":
            continue
        for leaf in check_leaves(check):
            if leaf["conjunctive"] and leaf["outcome"] == "UNKNOWN" and leaf["field"] in ADJUSTABLE:
                changes.append(change_for(leaf, check))
    unique = []
    for change in changes:
        key = (change["field"], change["operator"], str(change["required"]), change["outcome"])
        if key not in seen:
            seen.add(key)
            unique.append(change)
    return unique


def assign_group(record, timing, failures, adjustable):
    if record.get("instrument", "grant") != "grant":
        return "other_instruments"
    if timing["status"] == "CLOSED":
        return "outside_window"
    if failures:
        return "could_fit_after_change" if adjustable else "known_incompatible"
    return "pursue_now" if timing["status"] in ACTIONABLE_TIMING else "outside_window"


def group_reason(item, group, changes, failures):
    timing = item["schedule"]
    label = TIMING.get(timing["status"], (3, "Dates to check"))[1]
    date = (" · " + timing["deadline"][:10]) if timing.get("deadline") else ""
    unknown = item["condition_counts"]["unknown"] + item["condition_counts"]["conflict"]
    if group == "pursue_now":
        tail = f"; {plural(unknown, 'condition')} still need your input" if unknown else ""
        return f"{label}{date}; no known incompatibility{tail}."
    if group == "could_fit_after_change":
        return "Would fit if: " + " ".join(c["change"] for c in changes[:2])
    if group == "outside_window":
        reason = f"{label}{date}."
        if failures:
            reason += " It also fails: " + "; ".join(describe_check(c) for c, _ in failures[:2]) + "."
        return reason
    if group == "known_incompatible":
        return "Does not meet: " + "; ".join(describe_check(c) for c, _ in failures[:3]) + "."
    kind = INSTRUMENTS.get(item.get("instrument"), str(item.get("instrument")).replace("_", " "))
    state = "does not meet: " + describe_check(failures[0][0]) if failures else label.lower()
    return f"{kind}, not a grant; {state}."


# --- ranking ---------------------------------------------------------------------------------------

def rank_item(item, ctx, ws, text, clock):
    record, specification, checks = ctx["record"], ctx["specification"], item["checks"]
    entries, adjustable = analyse_failures(checks)
    group = assign_group(record, item["schedule"], entries, adjustable)
    assessment = item.get("relevance") or {}
    fit = assessment.get("fit")
    item["condition_status"] = item["match_status"]
    if fit in {"weak", "unclear"} and item["match_status"] != "DOES_NOT_FIT":
        item["match_status"] = "LOW_RELEVANCE" if fit == "weak" else "FIT_UNCLEAR"
        if group not in {"known_incompatible", "outside_window"}:
            group = "not_recommended" if fit == "weak" else "fit_review"
    if fit:
        item["reasons"] = [assessment["rationale"]] + item["reasons"][:2]
    # A closed call cannot be applied to, so a project change would not make it actionable.
    changes = [] if item["schedule"]["status"] == "CLOSED" else actionable_changes(checks, entries, adjustable)
    tier, timing = timing_factor(item["schedule"], ws, clock)
    objective = objective_fit(text, record, specification, ctx["shared"], ctx["topics"])
    stage = stage_assessment(ws, checks, record, specification)
    from .focus_grants import FOCUS
    from .match_explanation import explain
    focus_entry = next((f for f in FOCUS if f["key"] == record.get("focus_key")), None)
    item["why"] = explain(record, ws, checks, ctx.get("evidence"), assessment, focus_entry)
    topic_level = item["why"]["topic"]["level"]
    unproven = not fit and topic_level in {"weak", "none"} and item["why"]["topic"]["source"] == "call_text" and item["match_status"] != "DOES_NOT_FIT"
    if unproven:
        # Nothing was excluded, but nothing in the call text supports the project either: not a recommendation.
        item["match_status"] = "FIT_UNCLEAR"
        if group not in {"known_incompatible", "outside_window"}:
            group = "fit_review"
    instrument = item["why"]["instrument"]
    wrong_stage = bool(instrument) and any(c["kind"] == "stage" and c["status"] == "different" for c in instrument["checks"])
    from .match_explanation import fit_verdict
    item["fit"] = fit_verdict(item["why"], checks, item["match_status"], assessment, wrong_stage)
    mismatch = item["why"]["topic"]["source"] == "instrument_topic" or any(
        c["kind"] == "requirement" and c["status"] == "not_found" for c in (instrument or {}).get("checks", []))
    if mismatch and not fit and item["match_status"] != "DOES_NOT_FIT":
        # A scheme for another sector, or for technical work the profile does not describe, is not a recommendation
        # just because the region matches. It stays visible, folded away, with the reason.
        item["match_status"] = "LOW_RELEVANCE"
        if group not in {"known_incompatible", "outside_window"}:
            group = "not_recommended"
    fit_order = ({"strong": 0, "partial": 1, "unclear": 3, "weak": 4}[fit] if fit
                 else {"strong": 1, "partial": 2, "broad": 3 if wrong_stage else 2, "weak": 3, "none": 3}[topic_level])
    stage_effect, stage_share, stage_value = stage_factor(stage)
    coverage_share, coverage = coverage_factor(checks)
    budget_share, budget = budget_factor(checks)
    effort_share, effort = effort_factor(specification)
    effort["effect"] = "neutral"
    points = {"objective_fit": objective["component"], "stage_compatibility": stage_share, "evidence_coverage": coverage_share,
              "budget_fit": budget_share, "preparation_effort": effort_share}
    factors = [timing, incompatibility_factor(checks),
               {"key": "objective_fit", "label": "Fit to the call's objectives", "value": objective["value"],
                "effect": objective["effect"], "evidence": objective["evidence"]},
               coverage,
               {"key": "stage_compatibility", "label": "Project stage", "value": stage_value, "effect": stage_effect,
                "evidence": [stage["quote"]] if stage["quote"] else []},
               budget, effort]
    if fit:
        factors.insert(0, {"key": "project_fit", "label": "Project fit", "value": assessment["rationale"],
                           "effect": "lowers" if fit in {"weak", "unclear"} else "raises",
                           "evidence": assessment.get("grant_quotes", [])})
    for factor in factors:
        weight = WEIGHTS.get(factor["key"])
        if weight:
            factor["points"], factor["max_points"] = round(weight * points[factor["key"]], 1), weight
    total = round(sum(WEIGHTS[k] * points[k] for k in WEIGHTS))
    fit_tier = int(stage["state"] == "mismatch") + int(objective["class"] != "specific")
    from .retrieval import collaborative_eu
    partners = fact_value(ws, "project.organisation_count") or 0
    if collaborative_eu(record) and (not isinstance(partners, int) or partners < 3):
        fit_tier += 1  # A single startup cannot usually apply alone to an EU collaborative research call.
        item["consortium_note"] = ("EU collaborative research call: these usually require a consortium of at least three "
                                   "independent organisations from different EU or associated countries.")
        factors.append({"key": "consortium", "label": "Consortium", "value": item["consortium_note"], "effect": "lowers"})
        if group == "pursue_now":
            group = "could_fit_after_change"  # Could fit once a consortium is formed.
    item["group"], item["actionable_changes"] = group, changes
    if item.get("consortium_note") and group == "could_fit_after_change" and not changes:
        item["actionable_changes"] = [{"change": "Form a consortium with at least two other organisations from other eligible countries.",
                                       "caveat": "Check the call's own consortium conditions."}]
    item["group_reason"] = (assessment["rationale"] if assessment and group in {"fit_review", "not_recommended"}
                            else item["fit"]["reason"] if mismatch and group == "not_recommended"
                            else "Only a weak link to your project was found in the call text." if unproven and group == "fit_review"
                            else group_reason(item, group, changes, entries))
    item["qualitative_review"] = [{"id": c.get("id"), "label": c.get("label")} for c in checks if c["outcome"] == "MANUAL_REVIEW"][:6]
    item["ranking"] = {"version": RANKING_VERSION, "position": None, "of": None, "group": group, "factors": factors,
                       "summary": None, "ordered_by": ["group", "project_fit", "timing", "fit_tier", "ranking_information"], "fit_tier": fit_tier,
                       "project_fit": fit or "not_assessed",
                       "stage": {k: stage[k] for k in ("state", "source", "project", "call")},
                       "objective": {"class": objective["class"], "topics": objective["topics"], "terms": objective["terms"]},
                       "information": {"label": "Ranking information", "value": total, "max": 100, "note": INFORMATION_NOTE}}
    relevance = round(float(ctx.get("relevance") or 0), 1)
    item["ranking"]["targeting"] = targeting(record, checks)
    # An open scheme whose hand-checked conditions (who it is for) are not confirmed yet is not "worth pursuing now"
    # until they are; it waits with the instruments that need checking first.
    item["ranking"]["unconfirmed"] = bool(unconfirmed(checks))
    position = sort_group("other_instruments" if group == "pursue_now" and item["ranking"]["unconfirmed"] else group)
    return (position, fit_order, -item["ranking"]["targeting"], tier, fit_tier, -relevance if record.get("focus_key") else 0,
            -total, -relevance, record["id"])


def targeting(record, checks):
    """How specifically a focus scheme is made for this company: hand-checked conditions it meets (age, TRL range,
    spin-out, a woman founder) plus its sector topic, minus those still unknown. A scheme written for exactly this
    situation comes before general instruments that any company can use."""
    met = sum(1 for check in checks if check.get("interpretation") == "curated" and check["outcome"] == "PASS")
    return met + int(bool(record.get("focus_topic"))) - len(unconfirmed(checks))


def unconfirmed(checks):
    """Hand-checked conditions of a focus scheme that the profile does not answer yet."""
    return [check for check in checks if check.get("interpretation") == "curated" and check["outcome"] in {"UNKNOWN", "CONFLICT"}]


def sort_group(group):
    """Position of a group in the list. Loans and other instruments share a place with grants without confirmed
    dates: both need checking first, so the better project fit decides which comes first."""
    return GROUP_ORDER.index("other_instruments" if group == "outside_window" else group)


def summary_for(item, total):
    ranking, parts = item["ranking"], []
    factor = {f["key"]: f for f in ranking["factors"]}
    stage, objective = ranking["stage"], ranking["objective"]
    timing = item["schedule"]
    label = TIMING.get(timing["status"], (3, "Dates to check"))[1].lower()
    parts.append(label + (f" (closing {timing['deadline'][:10]})" if timing.get("deadline") and timing["status"] in ACTIONABLE_TIMING else ""))
    if item.get("relevance"):
        parts.append(item["relevance"]["fit"] + " project fit")
    failed = [c for c in item["checks"] if c["outcome"] == "FAIL"]
    parts.append("does not meet " + "; ".join(describe_check(c) for c in failed[:2]) if failed else "no known incompatibility")
    shown = list(dict.fromkeys(objective["terms"] + objective["topics"]))[:3]
    parts.append("specific match on " + ", ".join(shown) if objective["class"] == "specific" and shown else
                 "specific match on the call's objectives" if objective["class"] == "specific" else "only a generic sector match")
    counts = item["condition_counts"]
    judged = counts["total"] - counts["not_applicable"]
    parts.append(f"{counts['pass']} of {judged} conditions met" if judged else "no conditions checked yet")
    if stage["state"] == "meets":
        parts.append("stage fits")
    elif stage["state"] == "mismatch":
        parts.append("stage differs from the call")
    elif stage["state"] == "unknown":
        parts.append("project stage unknown")
    if factor["budget_fit"]["effect"] in {"raises", "lowers", "unknown"}:
        parts.append({"raises": "budget fits", "lowers": "budget does not fit", "unknown": "budget unknown"}[factor["budget_fit"]["effect"]])
    if factor["preparation_effort"]["effect"] != "unknown":
        parts.append(factor["preparation_effort"]["value"].split(" preparation")[0].lower() + " preparation")
    return f"Ranked {ranking['position']} of {total}: " + "; ".join(parts) + "."


def rank_items(items, ws, text, clock=None):
    keyed = []
    for item in items:
        ctx = item.pop("_ctx")
        keyed.append((rank_item(item, ctx, ws, text, clock), item))
    keyed.sort(key=lambda pair: pair[0])
    ordered = [item for _, item in keyed]
    for position, item in enumerate(ordered, 1):
        item["ranking"]["position"], item["ranking"]["of"] = position, len(ordered)
        item["ranking"]["summary"] = summary_for(item, len(ordered))
    return ordered


# --- result arrangement ------------------------------------------------------------------------------

def build_groups(visible, everything):
    groups = {}
    for key in GROUP_ORDER:
        members = [i for i in visible if i["group"] == key]
        total = sum(1 for i in everything if i["group"] == key)
        groups[key] = {"ids": [i["id"] for i in members], "count": total,
                       "reason": GROUP_DEFINITIONS[key] if total else "No options in this group.",
                       "items": [{"id": i["id"], "reason": i["group_reason"]} for i in members]}
    return groups


def fit_summary(matches, everything):
    """One honest sentence above the list when no grant is a clear fit, so a founder is not left to infer it.

    None when at least one shown option is likely to fit."""
    shown = [i for i in matches if i.get("fit")]
    if any(i["fit"]["level"] == "likely" for i in shown):
        return None
    set_aside = [i for i in everything if (i.get("fit") or {}).get("level") == "unlikely" and i["schedule"]["status"] != "CLOSED"]
    technical = sum(1 for i in set_aside for c in ((i.get("why") or {}).get("instrument") or {}).get("checks", [])
                    if c["kind"] == "requirement" and c["status"] == "not_found")
    grants = [i for i in shown if i["fit"]["level"] == "possible" and i.get("instrument") in {None, "grant"}]
    if shown and grants:
        message = ("No grant is a clear fit yet. The options below could apply, but none is written for a company like yours; "
                   "check each one's conditions before spending time on an application.")
        level = "uncertain"
    elif shown:
        message = ("No grant fits this business well. What remains are general instruments such as loans, guarantees or tax schemes, "
                   "which you can only use if you meet their conditions.")
        level = "weak"
    else:
        message = "We found no grant that fits this business."
        level = "none"
    if set_aside:
        message += (f" {plural(len(set_aside), 'scheme')} {'was' if len(set_aside) == 1 else 'were'} set aside because "
                    "they are meant for other kinds of companies; they are listed below with the reason.")
    mostly_technical = bool(technical) and technical >= len(set_aside) / 2
    if mostly_technical:
        message += (" Most innovation grants fund technical development or research. For a business without that, "
                    "a bank loan (possibly with the BMKB guarantee) or a microcredit is usually a more realistic route.")
    return {"level": level, "message": message, "set_aside": len(set_aside), "technical": mostly_technical}


def empty_reason(text, everything):
    pursue = [i for i in everything if i["group"] == "pursue_now"]
    if pursue:
        return None
    if not text.strip():
        return {"code": "no_information", "message": "Describe the company and project first; there is nothing to match yet.", "counts": {}}
    if not everything:
        return {"code": "no_related_opportunities", "message": "No funding opportunity in the current catalogue relates to this project's subject.", "counts": {}}
    if any(i.get("relevance", {}).get("fit") in {"weak", "unclear"} for i in everything if i.get("relevance")) and not any(i["match_status"] not in {"LOW_RELEVANCE", "FIT_UNCLEAR", "DOES_NOT_FIT"} and i["schedule"]["status"] != "CLOSED" for i in everything):
        return {"code": "no_clear_project_fit", "message": "No clear project fit was found. Calls needing clarification and poor fits are listed separately below.", "counts": {}}
    counts = {key: sum(1 for i in everything if i["group"] == key) for key in GROUP_ORDER}
    parts = []
    changeable = [i for i in everything if i["group"] == "could_fit_after_change"]
    if changeable:
        first = changeable[0]["actionable_changes"][0]["change"] if changeable[0]["actionable_changes"] else None
        parts.append(f"{counts['could_fit_after_change']} could fit after a change" + (f" (for example: {first})" if first else ""))
    if counts["outside_window"]:
        parts.append(f"{counts['outside_window']} are closed, not yet open or have no confirmed dates")
    if counts["known_incompatible"]:
        parts.append(f"{counts['known_incompatible']} have a known incompatibility")
    if counts["other_instruments"]:
        parts.append(f"{counts['other_instruments']} are other funding instruments, not grants")
    code = ("needs_change" if counts["could_fit_after_change"] else "none_open" if counts["outside_window"] and not counts["known_incompatible"]
            else "all_incompatible" if counts["known_incompatible"] and not counts["outside_window"] else "none_actionable")
    return {"code": code, "counts": counts,
            "message": "No grant is both open and compatible with this project right now: " + "; ".join(parts) + "."}


def information_questions(matches, ws, limit=3):
    """Questions ordered by how many live options they affect and whether they could change a group."""
    affected, hard = defaultdict(list), defaultdict(bool)
    for item in matches:
        seen = set()
        for check in item["checks"]:
            if check.get("source_conflict"):
                continue
            for leaf in check_leaves(check):
                field = ASKED_FIELDS.get(leaf["field"], leaf["field"])
                if leaf["outcome"] in {"UNKNOWN", "CONFLICT"} and field in QUESTION_LABELS:
                    seen.add(field)
                    hard[field] = True
        stage = item["ranking"]["stage"]
        if stage["state"] == "unknown" and stage["source"] == "text":
            seen.add("project.primary_activity")
        for field in seen:
            affected[field].append(item)
    ranked = sorted(affected, key=lambda f: (-sum(i["group"] == "pursue_now" and not i["ranking"]["unconfirmed"] for i in affected[f]), -len(affected[f]),
                                            0 if hard[f] else 1, QUESTION_PRIORITY.index(f)))
    result = []
    for field in ranked[:limit]:
        items = affected[field]
        now_open = sum(i["group"] == "pursue_now" and not i["ranking"]["unconfirmed"] for i in items)
        change = "group" if hard[field] else "ranking"
        why = (f"{plural(len(items), 'option')} {'depends' if len(items) == 1 else 'depend'} on this"
               + (f" ({now_open} open now)" if now_open else "") + ". "
               + ("Your answer can move them between worth pursuing, could fit after a change, and not a fit."
                  if change == "group" else "Your answer can change how they are ordered."))
        boolean = field in BOOL_PATHS
        result.append({"field": field, "question": QUESTION_LABELS[field], "options": YES_NO if boolean else CHOICE_PATHS.get(field),
                       "boolean": boolean, "affected_matches": len(items),
                       "affected_ids": [i["id"] for i in items], "affected_open_now": now_open, "could_change": change,
                       "why": why, "conflict": ws["facts"].get(field, {}).get("state") == "conflict"})
    return result


# --- cache keys --------------------------------------------------------------------------------------

def relevant_state(ws):
    """Everything about a workspace that can influence matching, and nothing else."""
    facts = {}
    for path in STATE_FACTS:
        fact = ws["facts"].get(path)
        if fact:
            facts[path] = [fact["value"], fact["state"], fact["revision"]]
    intake = ws.get("discovery_intake", {})
    state = {"text": profile_text(ws), "facts": facts,
             "intake": {k: intake.get(k) for k in ("budget_cents", "budget_confirmed", "organisation_count", "description_authoritative")}}
    if ws["budget_lines"]:
        from .budget import calculate
        state["budget"] = {"total": calculate(ws)["project_total_cents"],
                           "conflict": any(row.get("state") == "conflict" for row in ws["budget_lines"])}
    return state


def clock_bucket(clock):
    return (clock or datetime.now(ZoneInfo("Europe/Amsterdam"))).strftime("%Y-%m-%dT%H")


def profile_match_key(ws, model, clock):
    """Saved matches stay valid for the same profile, processing mode and ranking rules, for one day."""
    payload = {"ranking": RANKING_VERSION, "mode": "model" if model else "basic", "workspace": ws["id"], "state": relevant_state(ws),
               "day": clock_bucket(clock)[:10]}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def result_ids(result):
    return [item["id"] for section in ("matches", "excluded", "fit_review", "not_recommended", "closed") for item in result[section]]


def evaluation_key(ws, signature, spec_heads, clock, changes=None, scope=""):
    payload = {"ranking": RANKING_VERSION, "scope": scope, "workspace": ws["id"], "state": relevant_state(ws),
               "changes": changes or {}, "specifications": spec_heads, "catalogue": signature, "clock": clock_bucket(clock)}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()
