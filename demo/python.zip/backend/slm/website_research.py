"""Bounded company-site research.

Reads the homepage and at most six relevant same-site pages with the SSRF-safe
fetcher, converts their visible text into an ordinary workspace document and
never executes scripts, submits forms or follows links off the site. The text
is untrusted public marketing material: it becomes evidence for the normal
analysis and confirmation flow and is never confirmed automatically.
"""
import hashlib
import json
import re
from urllib.parse import urljoin, urlsplit, urlunsplit
from uuid import uuid4

from bs4 import BeautifulSoup, NavigableString
from .config import now
from .safe_http import FetchError, SafeFetcher, clean_url, load_robots, site_key

MAX_RELEVANT_PAGES = 6
MAX_BLOCKS_PER_PAGE = 70
MAX_BLOCK_CHARS = 1500
MAX_DOCUMENT_CHARS = 60_000
MAX_JSON_LD_BYTES = 100_000
THIN_PAGE_CHARS = 200  # Less visible text than this usually means the page is built by JavaScript.
NOTICE = ("Public website text: these are the company's own claims, not verified facts. Planned work, pilots and "
          "achievements described on the site stay unconfirmed until you confirm them.")

TOPICS = [
    ("about", r"about|over[-_ ]?ons|ons[-_ ]?verhaal|who[-_ ]?we[-_ ]?are|our[-_ ]?story|company|bedrijf|wie[-_ ]?zijn[-_ ]?wij|mission|missie"),
    ("team", r"team|people|mensen|medewerkers|management|leadership|founders|oprichters"),
    ("products", r"products?|producten|solutions?|oplossingen|services?|diensten|technolog|innovati|platform|research"),
    ("sustainability", r"sustainab|duurzaam|impact|esg|csr|mvo|climate|klimaat"),
    ("contact", r"contact|kontakt|locati|vestiging"),
    ("legal", r"colofon|imprint|impressum|disclaimer|voorwaarden|terms|privacy|legal"),
]
SKIP_PATH = re.compile(r"(?i)\.(?:pdf|jpe?g|png|gif|svg|webp|zip|docx?|xlsx?|pptx?|mp[34]|mov|css|js|xml|ico|json|txt)$|"
                       r"/(?:wp-admin|wp-login|login|log-in|signin|sign-in|account|cart|checkout|search|feed|tag|category|author)(?:/|$)|/page/\d+")
BLOCK_TAGS = {"h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "blockquote", "td", "th", "address", "figcaption", "dt", "dd",
              "summary", "div", "section", "article", "main", "header", "footer", "pre", "tr", "ul", "ol", "table", "body", "br"}
REMOVE_TAGS = ["script", "style", "noscript", "template", "svg", "canvas", "iframe", "object", "embed", "nav", "form",
               "button", "select", "textarea", "dialog", "head", "link", "meta"]
HIDDEN_STYLE = re.compile(r"display:none|visibility:hidden|font-size:0(?:px|pt|em|rem|%)?(?:;|$)|opacity:0(?:\.0+)?(?:;|$)|(?:left|top|text-indent):-\d{3,}")


class ResearchError(Exception):
    """Research could not produce a document; the message is shown to the founder."""


def clean_text(text):
    return " ".join(str(text).split())


def is_hidden(tag):
    attrs = getattr(tag, "attrs", None) or {}
    if "hidden" in attrs or str(attrs.get("aria-hidden", "")).lower() == "true":
        return True
    return bool(HIDDEN_STYLE.search(re.sub(r"\s+", "", str(attrs.get("style", ""))).lower()))


def structured_organisations(soup):
    """Organisation facts from JSON-LD, as {legalName, name, ...} dictionaries. Data only."""
    found = []
    for script in soup.find_all("script", attrs={"type": re.compile(r"ld\+json", re.I)}):
        raw = script.string or script.get_text()
        if not raw or len(raw) > MAX_JSON_LD_BYTES:
            continue
        try:
            stack, visited = [json.loads(raw)], 0
        except ValueError:
            continue
        while stack and visited < 2000:
            node = stack.pop()
            visited += 1
            if isinstance(node, list):
                stack.extend(node)
            elif isinstance(node, dict):
                kinds = node.get("@type")
                kinds = [kinds] if isinstance(kinds, str) else [k for k in kinds or [] if isinstance(k, str)]
                if any(re.search(r"Organization|Corporation|LocalBusiness|Company", kind) for kind in kinds):
                    found.append(node)
                stack.extend(v for v in node.values() if isinstance(v, (dict, list)))
    organisations = []
    for node in found[:3]:
        fields = {}
        for key in ("legalName", "name", "alternateName", "url", "vatID", "taxID", "foundingDate"):
            value = node.get(key)
            if isinstance(value, str) and value.strip():
                fields[key] = clean_text(value)[:200]
        address = node.get("address")
        if isinstance(address, dict):
            parts = [clean_text(str(address.get(k, ""))) for k in ("streetAddress", "postalCode", "addressLocality", "addressRegion", "addressCountry")]
            text = ", ".join(p for p in parts if p and not p.startswith("{"))
            if text:
                fields["address"] = text[:240]
        elif isinstance(address, str) and address.strip():
            fields["address"] = clean_text(address)[:240]
        if fields:
            organisations.append(fields)
    return organisations


def meta_content(soup, **attrs):
    tag = soup.find("meta", attrs=attrs)
    return clean_text(tag.get("content", "")) if tag and tag.get("content") else ""


def page_blocks(soup):
    """Visible text segmented at block boundaries, as [(text, heading_level)]."""
    body = soup.body or soup
    for tag in list(body.find_all(True)):
        if getattr(tag, "decomposed", False):
            continue
        if tag.name in REMOVE_TAGS or is_hidden(tag):
            tag.decompose()
    blocks, buffer, owner = [], [], None

    def flush():
        nonlocal buffer, owner
        text = clean_text("".join(buffer))
        level = int(owner.name[1]) if owner is not None and re.fullmatch(r"h[1-6]", owner.name or "") else None
        if text and (level or len(text) >= 8):
            blocks.append((text[:MAX_BLOCK_CHARS], level))
        buffer, owner = [], None

    for node in body.descendants:
        if not isinstance(node, NavigableString) or type(node) is not NavigableString:
            continue
        parent = node.parent
        while parent is not None and parent.name not in BLOCK_TAGS:
            parent = parent.parent
        if parent is not owner:
            flush()
            owner = parent
        buffer.append(str(node) + " ")
    flush()
    return blocks


def parse_page(html, url):
    """Parse one HTML page into title/meta/structured data/text blocks/links. No scripts are run."""
    soup = BeautifulSoup(html, "html.parser")
    title = clean_text(soup.title.get_text()) if soup.title else ""
    description = meta_content(soup, name="description") or meta_content(soup, property="og:description")
    site_name = meta_content(soup, property="og:site_name")
    organisations = structured_organisations(soup)
    has_password = bool(soup.find("input", attrs={"type": re.compile("^password$", re.I)}))
    links = []
    for anchor in soup.find_all("a", href=True):
        if is_hidden(anchor):
            continue
        links.append((anchor["href"], clean_text(anchor.get_text())[:120]))
    return {"title": title[:300], "description": description[:600], "site_name": site_name[:200], "organisations": organisations,
            "blocks": page_blocks(soup), "links": links, "login_wall": has_password}


def relevant_links(links, base_url, anchor, own_urls):
    """Choose up to six same-site pages by topic: about, team, products, technology, contact, sustainability."""
    candidates, seen = [], set(own_urls)
    for href, text in links:
        if not href or href.startswith(("#", "mailto:", "tel:", "javascript:", "data:")):
            continue
        try:
            url = clean_url(urljoin(base_url, href))
        except FetchError:
            continue
        parts = urlsplit(url)
        key = (site_key(parts.hostname), parts.path.rstrip("/").lower())
        if site_key(parts.hostname) != anchor or SKIP_PATH.search(parts.path) or key in seen:
            continue
        if re.search(r"(?i)(?:^|[?&])(?:s|q|search|add-to-cart|replytocom)=", parts.query):
            continue
        blob = (parts.path.replace("/", " ") + " " + text).lower()
        topic = next((index for index, (_, pattern) in enumerate(TOPICS) if re.search(pattern, blob)), None)
        if topic is None:
            continue
        seen.add(key)
        candidates.append((topic, len(parts.path), len(candidates), urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))))
    chosen, used = [], set()
    for topic, _, _, url in sorted(candidates):
        if topic not in used:
            used.add(topic)
            chosen.append((topic, url))
    for topic, _, _, url in sorted(candidates):
        if len(chosen) < MAX_RELEVANT_PAGES and url not in {u for _, u in chosen}:
            chosen.append((topic, url))
    return [url for _, url in sorted(chosen, key=lambda item: item[0])[:MAX_RELEVANT_PAGES]], {url: TOPICS[t][0] for t, url in chosen}


def research_site(url, fetcher, progress=None):
    """Fetch and parse a bounded set of pages. Returns a result dictionary or raises ResearchError."""
    progress = progress or (lambda message: None)
    try:
        start = clean_url(url)
    except FetchError as exc:
        raise ResearchError(str(exc)) from None
    result = {"pages": [], "skipped": [], "robots": "", "bytes": 0}
    progress("Checking the site's robots.txt")
    try:
        first_parts = urlsplit(start)
        robots = load_robots(fetcher, start)
        result["robots"] = robots.note
        if not robots.allows(start):
            raise ResearchError("This site's robots.txt asks automated tools not to read its home page, so nothing was read.")
        progress("Reading the home page")
        home = fetcher.get(start)
    except FetchError as exc:
        raise ResearchError(str(exc)) from None
    home_parts = urlsplit(home.url)
    anchor = site_key(home_parts.hostname)
    if site_key(first_parts.hostname) != anchor:
        raise ResearchError("The site redirected to a different address. Enter that address instead.")
    parsed_home = parse_page(home.text(), home.url)
    pages = [(home.url, "home", home, parsed_home)]
    targets, topics = relevant_links(parsed_home["links"], home.url, anchor, {(anchor, home_parts.path.rstrip("/").lower())})
    for index, target in enumerate(targets, 1):
        progress(f"Reading page {index} of {len(targets)}")
        try:
            if not robots.allows(target):
                result["skipped"].append({"url": target, "reason": "robots.txt asks automated tools not to read this page"})
                continue
            fetched = fetcher.get(target)
            pages.append((fetched.url, topics.get(target, "page"), fetched, parse_page(fetched.text(), fetched.url)))
        except FetchError as exc:
            result["skipped"].append({"url": target, "reason": str(exc)})
            if exc.code == "limit":
                break
    for page_url, topic, fetched, parsed in pages:
        if parsed["login_wall"] and sum(len(b[0]) for b in parsed["blocks"]) < 120:
            result["skipped"].append({"url": page_url, "reason": "This page needs a login and was not read"})
            continue
        result["pages"].append({"url": page_url, "topic": topic, "status": fetched.status, "bytes": len(fetched.body),
                                "sha256": hashlib.sha256(fetched.body).hexdigest(), "retrieved_at": now(),
                                "title": parsed["title"], "parsed": parsed})
    result["bytes"] = fetcher.total
    result["final_url"] = home.url
    result["host"] = home_parts.hostname
    if not result["pages"]:
        raise ResearchError("No readable pages were found on this site.")
    return result


def build_document(result):
    """A normal workspace document (same shape as parse_document) from researched pages."""
    host = result["host"]
    doc = {"id": uuid4().hex, "filename": f"Website: {site_key(host)}", "type": "website", "size": result["bytes"],
           "uploaded_at": now(), "blocks": [], "status": "parsed", "warnings": [NOTICE],
           "storage_name": uuid4().hex + ".txt", "extracted_modes": ["basic", "model"], "source_type": "website",
           "url": result["final_url"], "retrieved_at": now(), "robots": result["robots"],
           "pages": [{k: v for k, v in page.items() if k != "parsed"} for page in result["pages"]],
           "skipped_pages": result["skipped"]}
    total = 0

    def add(text, locator, page_url, **extra):
        nonlocal total
        if not text.strip():
            return
        if total + len(text) > MAX_DOCUMENT_CHARS:
            if NOTICE_LIMIT not in doc["warnings"]:
                doc["warnings"].append(NOTICE_LIMIT)
            return
        total += len(text)
        doc["blocks"].append({"id": f"b{len(doc['blocks']) + 1}", "text": text, "locator": locator, "kind": "website",
                              "url": page_url, **extra})

    seen = set()
    for page in result["pages"]:
        parsed, url = page["parsed"], page["url"]
        if parsed["title"]:
            add(parsed["title"], f"Website {url}, page title", url, role="title")
        if parsed["description"]:
            add(parsed["description"], f"Website {url}, meta description", url, role="meta_description")
        if parsed["site_name"]:
            add("Site name: " + parsed["site_name"], f"Website {url}, site name", url, role="site_name")
        for organisation in parsed["organisations"]:
            lines = ["Organization structured data"] + [f"{key}: {value}" for key, value in organisation.items()]
            add("\n".join(lines), f"Website {url}, structured data", url, role="structured")
        number = 0
        for text, level in parsed["blocks"][:MAX_BLOCKS_PER_PAGE]:
            fingerprint = text.casefold()
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
            number += 1
            add(text, f"Website {url}, paragraph {number}", url, **({"heading_level": level} if level else {}))
    doc["sha256"] = hashlib.sha256("\n".join(b["text"] for b in doc["blocks"]).encode()).hexdigest()
    if not doc["blocks"]:
        doc.update(status="no_readable_text")
        doc["warnings"].append("The pages contained no readable text.")
    if result["skipped"]:
        doc["warnings"].append(f"{len(result['skipped'])} page(s) were skipped; see the research details.")
    thin = [page["url"] for page in result["pages"] if sum(len(text) for text, _ in page["parsed"]["blocks"]) < THIN_PAGE_CHARS]
    if thin:
        doc["warnings"].append(f"Almost no text on {len(thin)} page(s), for example {thin[0]}. The site may need JavaScript, "
                               "which SLM does not run. Paste the text from those pages instead.")
    return doc


NOTICE_LIMIT = "The website text limit was reached; remaining pages were not added."


def plain_text(doc):
    """Readable snapshot stored with the document, for provenance."""
    lines = [f"{doc['filename']} — retrieved {doc['retrieved_at']}"]
    for page in doc["pages"]:
        lines.append(f"{page['url']} (HTTP {page['status']}, sha256 {page['sha256']})")
    lines.append("")
    lines.extend(f"[{b['locator']}] {b['text']}" for b in doc["blocks"])
    return "\n".join(lines)
