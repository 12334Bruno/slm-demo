import hashlib
import re
from io import BytesIO
from copy import deepcopy
from docx import Document
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph
from docx.shared import Pt, RGBColor
from .config import FORM, KIT, MAIN_GRANT, SOURCES, now
from .profiles import fact_value
from .budget import euro
from .questions import missing_questions


def template_validation(path=None):
    path = path or KIT / FORM["template_path"]
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != FORM["template_sha256"]:
        raise ValueError("Official template hash differs or template is missing. Official-format export unavailable.")
    document = Document(path)
    for section in FORM["sections"]:
        if document.paragraphs[section["original_paragraph_index"]].text != section["expected_heading"]:
            raise ValueError("Official heading map differs; refusing to mislabel an answer sheet as an official-format draft.")
    for mapping in FORM["numeric_tables"]:
        table = document.tables[mapping["table_index"]]
        if len(table.rows) != mapping["expected_rows"]:
            raise ValueError("Official budget table structure differs")
        for ri, label in mapping["expected_row_labels"].items():
            if table.rows[int(ri)].cells[0].text != label:
                raise ValueError(f"Official budget row label differs: {label}")
    return document


def effective_color(run, paragraph):
    if run.font.color.rgb is not None:
        return str(run.font.color.rgb).upper()
    # Character styles precede paragraph styles. Inherited instruction colour
    # must be removed too; direct-format-only cleanup is insufficient.
    for initial in (run.style, paragraph.style):
        style = initial
        while style:
            if style.font.color.rgb is not None:
                return str(style.font.color.rgb).upper()
            style = style.base_style
    return None


def format_run(run):
    run.font.name = "Arial"
    run.font.size = Pt(11)
    run.font.color.rgb = RGBColor(0, 0, 0)


def insert_after(paragraph, text):
    element = OxmlElement("w:p")
    paragraph._p.addnext(element)
    new = Paragraph(element, paragraph._parent)
    new.style = "Normal"
    format_run(new.add_run(text))
    return new


def official_docx(ws, evaluation):
    if not ws["draft"]:
        raise ValueError("Generate and review a draft before exporting")
    document = template_validation()
    original = list(document.paragraphs)
    protected = {s["original_paragraph_index"] for s in FORM["sections"]}
    blue = set(FORM["instruction_colors_to_review"])
    for index, paragraph in enumerate(original):
        if index in protected:
            for run in paragraph.runs:
                run.font.color.rgb = RGBColor(0, 0, 0)
        else:
            removed_instruction = False
            for run in list(paragraph.runs):
                if effective_color(run, paragraph) in blue:
                    removed_instruction = True
                    # Retain any footnote/endnote reference inside a coloured run.
                    if run._r.xpath(".//w:footnoteReference | .//w:endnoteReference"):
                        for text in run._r.xpath(".//w:t"):
                            text.text = ""
                        run.font.color.rgb = RGBColor(0, 0, 0)
                    else:
                        run._r.getparent().remove(run._r)
            if removed_instruction and not paragraph.text.strip() and not paragraph._p.xpath(".//w:footnoteReference | .//w:endnoteReference | .//w:sectPr"):
                paragraph._p.getparent().remove(paragraph._p)
        # The rest of the template's required black content stays untouched.
    company_heading = original[next(s["original_paragraph_index"] for s in FORM["sections"] if s["id"] == "company")]
    company_heading.text = fact_value(ws, "company.name", True) or "[NEEDS INPUT: company name]"
    for run in company_heading.runs:
        format_run(run)
    kia_heading = original[next(s["original_paragraph_index"] for s in FORM["sections"] if s["id"] == "policy_framework_category")]
    kia_heading.text = f"KIA {fact_value(ws, 'project.framework_category', True) or '[NEEDS INPUT: confirm number and title of the selected KIA]'}:"
    for run in kia_heading.runs:
        format_run(run)
    category = fact_value(ws, "project.framework_category", True)
    selected = re.match(r"^(?:KIA\s*)?([1-8])\b", category or "", re.I)
    if selected:
        # A checked box records the founder's proposed category, not a passed
        # policy assessment. All manual policy checks remain unresolved.
        checkbox = re.compile(r"☐(\s*" + selected[1] + r"\s*:)")
        for paragraph in document.paragraphs:
            replacement = checkbox.sub(r"☒\1", paragraph.text)
            if replacement != paragraph.text:
                paragraph.text = replacement
                for run in paragraph.runs:
                    format_run(run)
    sections = {s["id"]: s for s in ws["draft"]["sections"]}
    for spec in FORM["sections"]:
        section = sections[spec["id"]]
        cursor = original[spec["original_paragraph_index"]]
        if section["state"] == "stale":
            cursor = insert_after(cursor, "[NEEDS INPUT: this saved answer is stale after an input change; review or regenerate it]")
        for paragraph in section["text"].split("\n\n"):
            cursor = insert_after(cursor, paragraph)
    budget = evaluation["budget"]
    for mapping in FORM["numeric_tables"]:
        table = document.tables[mapping["table_index"]]
        for row, key in mapping["row_mapping"].items():
            cell = table.rows[int(row)].cells[mapping["amount_column_index"]]
            amount = budget.get(key)
            cell.text = euro(amount) if amount is not None else "[NEEDS INPUT: amount unresolved]"
            for p in cell.paragraphs:
                for r in p.runs:
                    format_run(r)
        # These fixed tables fit on an A4 page. Keep their rows together so a
        # financing contribution is not stranded apart from the grant/total.
        for index, row in enumerate(table.rows):
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.keep_with_next = index < len(table.rows) - 1
                    paragraph.paragraph_format.keep_together = True
    grant = next(g for g in evaluation["grants"] if g["id"] == MAIN_GRANT)
    cursor = original[1]
    for line in ["DRAFT — UNRESOLVED ITEMS. Editable official-template project plan; no submission or award.",
                 f"{evaluation['label']}. Effective timestamp: {evaluation['effective_datetime']}.",
                 f"Call status: {grant['call_status']}. Rule set: {grant['rule_version']}. Profile revision: {ws['revision']}.",
                 f"{ws['draft']['mode']}. Saved narrative revision: {ws['draft']['profile_revision']}. English demonstration answers; submission language must be checked.",
                 "Tables use the current deterministic calculation. Amounts and classifications are provisional; see separate checklist and financing narrative for commitment status."]:
        cursor = insert_after(cursor, line)
    if ws["draft"]["stale"]:
        insert_after(cursor, "[NEEDS INPUT: saved narrative has stale sections. Current tables may differ from saved narrative; review before submission.]")
    document.styles["Normal"].font.name = "Arial"
    document.styles["Normal"].font.size = Pt(11)
    document.core_properties.title = "Draft — MIT feasibility project plan"
    document.core_properties.author = "SLM prototype workspace"
    output = BytesIO()
    document.save(output)
    output.seek(0)
    # This catches a broken package before returning the download.
    reopened = Document(output)
    if len(reopened.tables) != 2:
        raise ValueError("Exported document failed table integrity check")
    return output.getvalue()


def checklist(ws, evaluation):
    grant = next(g for g in evaluation["grants"] if g["id"] == MAIN_GRANT)
    budget = evaluation["budget"]
    lines = ["DRAFT — UNRESOLVED ITEMS", "SLM grant preparation checklist", f"Exported: {now()}",
             evaluation["label"], f"Effective timestamp: {evaluation['effective_datetime']}",
             f"Rule set: {grant['rule_version']}; profile revision: {ws['revision']}",
             f"Call status: {grant['call_status']}; next opening: not known", "No legal eligibility or grant award is promised.", "",
             "MISSING OR UNCONFIRMED INFORMATION"]
    for q in missing_questions(ws, evaluation, MAIN_GRANT):
        lines.append(f"- [{q['state']}] {q['question']} ({q['field']}) — {q['reason']}")
    lines += ["", "IMPLEMENTED CHECKS"]
    for check in grant["checks"] + grant["deferred_checks"]:
        lines.append(f"- {check['rule_id']}: {check['outcome']} — {check['explanation']} [{check['source_url']}]")
    lines += ["", "UNRESOLVED MANUAL CHECKS"]
    for check in grant["manual_checks"]:
        lines.append(f"- {check['description']} — {check['source_url']}")
    lines += ["", "BUDGET AND FINANCING (PROVISIONAL)"]
    for key in ["project_total_cents", "proposed_eligible_cents", "grant_ceiling_cents", "requested_grant_cents", "other_financing_required_cents", "committed_other_finance_cents", "unconfirmed_financing_cents"]:
        lines.append(f"- {key}: {euro(budget[key])}")
    lines.extend(f"- {message}" for message in budget["warnings"] + budget["assumptions"])
    lines += ["", "ATTACHMENTS / ELECTRONIC FORM"]
    lines += ["- Confirm required applicant/contact details, public summary, authorisation and remaining declarations in the electronic form.",
              "- Review conditional attachments: SME/ownership data, CVs, financing evidence, supplier proposals, financial information and previous MIT award references as applicable.",
              "- The project-plan DOCX alone does not complete the electronic application. Check actual submission language.",
              "- No signature, bank details or registration number has been invented. Supply real identifiers only when required."]
    if ws["draft"]:
        lines += ["", f"SAVED DRAFT: {ws['draft']['mode']}; profile revision {ws['draft']['profile_revision']}; stale={ws['draft']['stale']}"]
        for section in ws["draft"]["sections"]:
            if section["missing_inputs"] or section["state"] == "stale" or "[NEEDS INPUT:" in section["text"]:
                lines.append(f"- {section['heading']} [{section['state']}]: " + "; ".join(section["missing_inputs"]))
            if section["user_edited"]:
                lines.append(f"- Founder edited {section['heading']}; changes require human factual review.")
    lines += ["", "COMPANY / PROJECT EVIDENCE"]
    for path, fact in ws["facts"].items():
        if fact["evidence"]:
            lines.append(f"{path} [{fact['state']}]: {fact['value']}")
            for ref in fact["evidence"]:
                lines.append(f"  {ref.get('filename', 'Founder')} · {ref['locator']}: {ref['quote']}")
    lines += ["", "BUDGET / FINANCING EVIDENCE"]
    for row in ws["budget_lines"] + ws["funding_sources"]:
        for ref in row["evidence"]:
            lines.append(f"{row['id']} · {ref.get('filename', 'Founder')} · {ref['locator']}: {ref['quote']}")
    lines += ["", "REVIEWED OFFICIAL SOURCES (curated data; fetching does not update rules)"]
    for source in SOURCES.values():
        if source["kind"].startswith("official_") and source["kind"] != "official_technical_docs":
            lines.append(f"- {source['title']} — reviewed {source['reviewed_on']} — {source['url']}")
    return "\n".join(lines) + "\n"
