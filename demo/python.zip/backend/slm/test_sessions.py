"""Founder user-test sessions: what the operator records and what the app already knows, as metrics.

Only active with SLM_TEST_MODE=1. When it is off, no routes are registered, no tables are created and nothing
extra is stored. What is recorded and how each metric is computed is described in docs/TEST_SESSIONS.md.

Two kinds of data:
  * events the operator records during a session (notes, marks, per-grant feedback, known grants, draft section
    reviews, willingness to pay, surprises, preparation minutes) plus two automatic ones: when matches were first
    shown and when the final list was ready;
  * metrics derived from data the workspace already keeps (fact evidence, candidates, history and confirmation
    times, application answer history), computed when asked and never stored twice.
"""
import json
import os
import re
from datetime import datetime
from typing import Annotated, Literal
from uuid import uuid4

from pydantic import Field

from .config import now
from .domain import KEY_PATHS, Strict


def enabled():
    return os.getenv("SLM_TEST_MODE", "0") == "1"


SCHEMA = """
CREATE TABLE IF NOT EXISTS test_sessions (
    id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, started_at TEXT NOT NULL, stopped_at TEXT);
CREATE TABLE IF NOT EXISTS test_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, workspace_id TEXT NOT NULL,
    kind TEXT NOT NULL, at TEXT NOT NULL, data TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS test_sessions_workspace ON test_sessions(workspace_id);
CREATE INDEX IF NOT EXISTS test_events_session ON test_events(session_id);
"""


class Note(Strict):
    kind: Literal["note"]
    text: str = Field(min_length=1, max_length=4000)


class Mark(Strict):
    kind: Literal["mark"]
    label: str = Field(min_length=1, max_length=200)


class MatchFeedback(Strict):
    kind: Literal["match_feedback"]
    grant_id: str = Field(min_length=1, max_length=200)
    title: str = Field(min_length=1, max_length=500)
    would_apply: Literal["yes", "maybe", "no"]
    knew_about_it: Literal["yes", "no"]
    reason: str = Field(max_length=2000)


class KnownGrant(Strict):
    kind: Literal["known_grant"]
    name: str = Field(min_length=2, max_length=300)
    record_id: str | None = Field(max_length=200)


class SectionReview(Strict):
    kind: Literal["section_review"]
    grant_id: str = Field(min_length=1, max_length=200)
    section_id: str = Field(min_length=1, max_length=200)
    section: str = Field(min_length=1, max_length=500)
    verdict: Literal["kept", "edited", "discarded"]
    comment: str = Field(max_length=2000)


class WillingnessToPay(Strict):
    kind: Literal["willingness_to_pay"]
    answer: str = Field(min_length=1, max_length=2000)


class Surprise(Strict):
    kind: Literal["surprise"]
    text: str = Field(min_length=1, max_length=2000)


class PrepMinutes(Strict):
    kind: Literal["prep_minutes"]
    activity: str = Field(min_length=1, max_length=300)
    team_minutes: int = Field(ge=0, le=10000)
    founder_minutes: int = Field(ge=0, le=10000)


Event = Annotated[Note | Mark | MatchFeedback | KnownGrant | SectionReview | WillingnessToPay | Surprise | PrepMinutes,
                  Field(discriminator="kind")]


class EventRequest(Strict):
    event: Event


class NoActiveSession(Exception):
    """An event or stop request arrived while no session was running for this company."""


# --- storage --------------------------------------------------------------------------------------------

def ensure_tables(store):
    with store.connect() as conn:
        conn.executescript(SCHEMA)


def delete_for_workspace(conn, wid):
    """Remove a company's session data; also when test mode is off now but tables exist from an earlier session."""
    tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "test_events" in tables:
        conn.execute("DELETE FROM test_events WHERE workspace_id=?", (wid,))
    if "test_sessions" in tables:
        conn.execute("DELETE FROM test_sessions WHERE workspace_id=?", (wid,))


def sessions(conn, wid):
    rows = conn.execute("SELECT id, started_at, stopped_at FROM test_sessions WHERE workspace_id=? ORDER BY started_at", (wid,))
    return [{"id": r[0], "started_at": r[1], "stopped_at": r[2]} for r in rows]


def active_session(conn, wid):
    row = conn.execute("SELECT id, started_at, stopped_at FROM test_sessions WHERE workspace_id=? AND stopped_at IS NULL", (wid,)).fetchone()
    return {"id": row[0], "started_at": row[1], "stopped_at": row[2]} if row else None


def events(conn, session_id):
    rows = conn.execute("SELECT id, kind, at, data FROM test_events WHERE session_id=? ORDER BY id", (session_id,))
    return [{"id": r[0], "kind": r[1], "at": r[2], **json.loads(r[3])} for r in rows]


def start(conn, wid):
    if active_session(conn, wid):
        raise ValueError("A test session is already running for this company; stop it first")
    session = {"id": uuid4().hex, "started_at": now(), "stopped_at": None}
    conn.execute("INSERT INTO test_sessions VALUES (?, ?, ?, NULL)", (session["id"], wid, session["started_at"]))
    return session


def stop(conn, wid):
    session = active_session(conn, wid)
    if session is None:
        raise NoActiveSession("No test session is running for this company")
    conn.execute("UPDATE test_sessions SET stopped_at=? WHERE id=?", (now(), session["id"]))


def add_event(conn, wid, kind, data):
    session = active_session(conn, wid)
    if session is None:
        raise NoActiveSession("Start a test session before recording events")
    conn.execute("INSERT INTO test_events (session_id, workspace_id, kind, at, data) VALUES (?, ?, ?, ?, ?)",
                 (session["id"], wid, kind, now(), json.dumps(data, ensure_ascii=False)))


def record_matching(store, wid, result):
    """Automatic timing events: when matches were first shown and when the final list was ready, once per session."""
    if not enabled():
        return
    final = not (result.get("provisional") or result.get("assessing_fit") or result.get("investigating"))
    with store.connect() as conn:
        session = active_session(conn, wid)
        if session is None:
            return
        seen = {e["kind"] for e in events(conn, session["id"])}
        for kind, due in (("matches_shown", True), ("matches_final", final)):
            if due and kind not in seen:
                add_event(conn, wid, kind, {"matches": len(result["matches"])})


# --- derived metrics ---------------------------------------------------------------------------------------

def minutes_between(start_iso, end_iso):
    if start_iso is None or end_iso is None:
        return None
    return round((datetime.fromisoformat(end_iso) - datetime.fromisoformat(start_iso)).total_seconds() / 60, 1)


def fact_origin(fact):
    """How a profile detail got its current state.

    automatic: it has evidence from a document, pasted text, website or registry (rules and AI read the same sources);
    accepted: confirmed with a value that an automatic source proposed; edited: confirmed with a different value;
    rejected: proposed automatically, then cleared by the founder; typed: confirmed without any automatic proposal;
    unreviewed: an automatic proposal not confirmed yet; conflict: sources disagree and nobody chose yet.
    """
    automatic = [ref for ref in fact["evidence"] if ref.get("source_type") != "founder_answer"]
    proposed = [c["value"] for c in fact["candidates"] if any(ref.get("source_type") != "founder_answer" for ref in c["evidence"])]
    if fact["state"] == "confirmed":
        if not automatic:
            return "typed"
        from .profiles import same
        return "accepted" if any(same(value, fact["value"]) for value in proposed) else "edited"
    if fact["state"] == "conflict":
        return "conflict"
    if fact["state"] == "proposed":
        return "unreviewed"
    return "rejected" if automatic and fact["history"] else None


def profile_metrics(ws):
    origins, sources = {}, {}
    for path, fact in ws["facts"].items():
        origin = fact_origin(fact)
        if origin:
            origins[origin] = origins.get(origin, 0) + 1
        for source in {ref.get("source_type") for ref in fact["evidence"] if ref.get("source_type") != "founder_answer"}:
            sources[source] = sources.get(source, 0) + 1
    first_material = min((d["uploaded_at"] for d in ws["documents"] if d.get("uploaded_at")), default=None)
    key_confirmed = [ws["facts"][p]["confirmed_at"] for p in KEY_PATHS if ws["facts"][p]["state"] == "confirmed" and ws["facts"][p].get("confirmed_at")]
    return {"facts_by_origin": {k: origins.get(k, 0) for k in ("accepted", "edited", "rejected", "typed", "unreviewed", "conflict")},
            "automatic_facts_by_source": dict(sorted(sources.items())),
            "first_material_at": first_material, "key_facts_confirmed": len(key_confirmed), "key_facts_total": len(KEY_PATHS),
            "minutes_to_key_facts": minutes_between(first_material, max(key_confirmed)) if key_confirmed else None}


def application_metrics(ws):
    result = []
    for grant_id, app in sorted(ws.get("applications", {}).items()):
        edits = [h for h in app["history"] if h["kind"] in {"answer", "answer_before_editor_merge"}]
        result.append({"grant_id": grant_id, "title": app["title"], "answers": sum(1 for a in app["answers"].values() if (a.get("text") or "").strip()),
                       "answer_edits": len(edits), "answers_edited": len({h["id"] for h in edits})})
    return result


def words(text):
    return {w for w in re.findall(r"[a-z0-9à-ÿ]+", text.casefold()) if len(w) > 2}


def recall(known, catalogue_search, saved_result):
    """For each grant the founder already knew: is it in the catalogue, and did it appear in this profile's matches?"""
    sections = ("matches", "fit_review", "not_recommended", "excluded", "closed")
    shown = {}
    for section in sections:
        for position, item in enumerate((saved_result or {}).get(section, []), 1):
            shown.setdefault(item["id"], {"section": section, "position": position, "group": item.get("group"), "title": item["title"]})
    rows = []
    for grant in known:
        name_words = words(grant["name"])
        candidates = catalogue_search(grant["name"])[:5]
        found = next((r for r in candidates if r["id"] == grant["record_id"]), None) if grant["record_id"] else \
            next((r for r in candidates if name_words and name_words <= words(r["title"])), None)
        match = shown.get(found["id"]) if found else None
        rows.append({"name": grant["name"], "in_catalogue": found is not None, "record_id": found["id"] if found else None,
                     "catalogue_title": found["title"] if found else None,
                     "similar_titles": [] if found else [r["title"] for r in candidates[:3]],
                     "in_matches": match is not None, "section": match["section"] if match else None,
                     "position": match["position"] if match else None})
    return rows


def latest(items, key):
    """The most recent event per key (feedback can be corrected during the session)."""
    result = {}
    for item in items:
        result[key(item)] = item
    return list(result.values())


def session_metrics(ws, session, session_events, catalogue_search, saved_result):
    by_kind = {}
    for event in session_events:
        by_kind.setdefault(event["kind"], []).append(event)
    feedback = latest(by_kind.get("match_feedback", []), lambda e: e["grant_id"])
    reviews = latest(by_kind.get("section_review", []), lambda e: (e["grant_id"], e["section_id"]))
    prep = by_kind.get("prep_minutes", [])
    known = latest(by_kind.get("known_grant", []), lambda e: e["name"].casefold())
    recall_rows = recall(known, catalogue_search, saved_result)
    first = lambda kind: (by_kind.get(kind) or [{}])[0].get("at")
    return {
        "session_id": session["id"], "workspace_id": ws["id"], "company": ws.get("label") or ws["facts"]["company.name"]["value"],
        "started_at": session["started_at"], "stopped_at": session["stopped_at"],
        "session_minutes": minutes_between(session["started_at"], session["stopped_at"] or now()),
        "minutes_to_first_matches": minutes_between(session["started_at"], first("matches_shown")),
        "minutes_matches_shown_to_final": minutes_between(first("matches_shown"), first("matches_final")),
        "profile": profile_metrics(ws), "applications": application_metrics(ws),
        "match_feedback": {"rated": len(feedback),
                           "would_apply": {v: sum(1 for f in feedback if f["would_apply"] == v) for v in ("yes", "maybe", "no")},
                           "already_known": sum(1 for f in feedback if f["knew_about_it"] == "yes"),
                           "new_to_founder": sum(1 for f in feedback if f["knew_about_it"] == "no")},
        "recall": {"known_grants": len(recall_rows), "in_catalogue": sum(1 for r in recall_rows if r["in_catalogue"]),
                   "in_matches": sum(1 for r in recall_rows if r["in_matches"]), "rows": recall_rows},
        "draft_review": {v: sum(1 for r in reviews if r["verdict"] == v) for v in ("kept", "edited", "discarded")},
        "team_minutes": sum(p["team_minutes"] for p in prep), "founder_minutes": sum(p["founder_minutes"] for p in prep),
        "willingness_to_pay": [e["answer"] for e in by_kind.get("willingness_to_pay", [])],
        "surprises": [e["text"] for e in by_kind.get("surprise", [])],
        "notes": [{"at": e["at"], "text": e["text"]} for e in by_kind.get("note", [])],
        "marks": [{"at": e["at"], "label": e["label"]} for e in by_kind.get("mark", [])],
    }


def workspace_report(store, discovery, wid):
    """Every session of one company with its events and metrics; used by the API and the export script."""
    ws = store.load(wid)
    saved_result = discovery.db.latest_matches(wid)
    with store.connect() as conn:
        found = [(s, events(conn, s["id"])) for s in sessions(conn, wid)]
    return [{"session": s, "events": e, "metrics": session_metrics(ws, s, e, discovery.db.search, saved_result)} for s, e in found]


# --- routes -------------------------------------------------------------------------------------------------

def register(app, store, discovery):
    from fastapi import HTTPException
    ensure_tables(store)

    @app.exception_handler(NoActiveSession)
    async def no_session(request, exc):
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=409, content={"detail": str(exc)})

    @app.get("/api/workspaces/{wid}/test-session")
    def current(wid: str):
        store.load(wid)  # 404 for an unknown company.
        with store.connect() as conn:
            session = active_session(conn, wid)
        reports = workspace_report(store, discovery, wid)
        return {"active": session, "sessions": reports}

    @app.post("/api/workspaces/{wid}/test-session/start")
    def start_session(wid: str):
        store.load(wid)
        with store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                return start(conn, wid)
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from None

    @app.post("/api/workspaces/{wid}/test-session/stop")
    def stop_session(wid: str):
        with store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            stop(conn, wid)
        return current(wid)

    @app.post("/api/workspaces/{wid}/test-session/events")
    def record(wid: str, body: EventRequest):
        store.load(wid)
        data = body.event.model_dump()
        with store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            add_event(conn, wid, data.pop("kind"), data)
        return current(wid)
