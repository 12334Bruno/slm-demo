"""Turn labelled spreadsheet cells into proposed facts and budget rows.

Everything returned is a proposal with cell-level evidence. Layouts handled:
label in column A with the value to its right; a header row followed by one
data row; and a budget table identified by its header names.
"""
import re
from .domain import BudgetLine
from .ingestion import evidence

EXTRA_ALIASES = {
    "company.name": ["company", "legal name", "statutory name", "name of company", "bedrijfsnaam"],
    "company.province": ["registered province", "provincie"],
    "company.city": ["place of business", "vestigingsplaats", "city/town"],
    "company.registration_number": ["kvk", "kvk-nummer", "kvk no", "chamber of commerce number"],
    "company.fte": ["number of fte", "total fte", "fte count", "headcount", "number of employees", "average fte", "gemiddeld aantal fte"],
    "company.annual_turnover_cents": ["revenue", "net revenue", "net turnover", "total revenue", "omzet", "netto-omzet", "net sales"],
    "company.balance_sheet_total_cents": ["total assets", "balance sheet total", "balanstotaal"],
}
NUMERIC_PATHS = {"company.fte", "company.annual_turnover_cents", "company.balance_sheet_total_cents",
                 "project.independent_sme_participant_count"}
TOTAL_ROW = re.compile(r"(?i)^\s*(sub\s*-?total|total(?:s| costs?)?|totaal|sum|grand total|overall)\b")
YEAR = re.compile(r"^(?:fy\s?)?(?:19|20)\d{2}(?:\s*[/-]\s*(?:19|20)?\d{2})?$", re.I)

BUDGET_HEADERS = {
    "id": {"id", "line id", "row id", "ref", "reference", "code", "no", "nr", "#"},
    "activity": {"activity", "description", "item", "cost item", "omschrijving", "activiteit", "work package"},
    "group": {"activity group", "group", "phase", "work stream", "activity type"},
    "cost_type": {"cost type", "type of cost", "cost category", "category", "kostensoort", "type"},
    "quantity": {"quantity", "qty", "hours", "number", "aantal", "uren", "units"},
    "unit": {"unit", "uom", "eenheid"},
    "rate": {"rate", "unit rate", "hourly rate", "unit price", "price", "cost per unit", "tarief", "unit cost", "rate (eur)", "price per unit"},
    "amount": {"amount", "cost", "costs", "total cost", "bedrag", "amount (eur)", "cost (eur)", "budget"},
}
COST_TYPES = [
    (r"personnel|staff|labou?r|wage|salary|salaris|personeel|internal|own hours", "internal_personnel"),
    (r"external|subcontract|consult|third.party|service|advis|derden|inhuur", "external_service"),
    (r"material|consumable|supplies|materiaal", "materials"),
    (r"equipment|machine|instrument|apparatuur|apparatus", "equipment"),
    (r"building|premises|rent|housing|facilit|huisvesting|gebouw", "buildings"),
]
GROUPS = [(r"feasib|haalbaar", "feasibility_study"), (r"related|supporting|aanvullend|onderzoek", "related_research")]


def label_key(text):
    """Normalise a spreadsheet label: case, trailing colon, brackets and year suffix."""
    text = re.sub(r"\([^)]*\)", " ", str(text)).lower().strip().rstrip(":")
    text = re.sub(r"[,\s]*(?:fy\s?)?(?:19|20)\d{2}\s*$", "", text)
    return " ".join(text.split())


def rows_of(doc):
    """{(sheet, row): [blocks sorted by column]} for spreadsheet cell blocks, in sheet order."""
    rows = {}
    for block in doc["blocks"]:
        if block.get("sheet") is not None:
            rows.setdefault((block["sheet"], block["row"]), []).append(block)
    return {key: sorted(cells, key=lambda b: b["column"]) for key, cells in rows.items()}


def year_header(rows, sheet, row, column):
    """A year-like heading above this cell, used only as display context."""
    for (name, number), cells in rows.items():
        if name != sheet or number >= row:
            continue
        for cell in cells:
            if cell["column"] == column and YEAR.match(cell["text"].strip()):
                return cell["text"].strip()
    return None


def fact_cells(doc, aliases):
    """Yield (path, block) pairs. Aliases: [(path, alias)] with lower-case aliases."""
    table = {}
    for path, alias in aliases:
        table.setdefault(alias, set()).add(path)
    for path, extras in EXTRA_ALIASES.items():
        for alias in extras:
            table.setdefault(alias, set()).add(path)
    rows, seen = rows_of(doc), set()
    # Label in column A, values to the right.
    for (sheet, number), cells in rows.items():
        if len(cells) < 2 or cells[0]["column"] != 1:
            continue
        paths = table.get(label_key(cells[0]["text"]), set())
        values = cells[1:]
        for path in sorted(paths):
            if path in NUMERIC_PATHS or path.endswith("_date"):
                typed = [c for c in values if c["value_type"] in {"number", "date"}]
                chosen = typed or values[:1]
            else:
                chosen = values[:1]
            for block in chosen:
                if (path, block["id"]) not in seen:
                    seen.add((path, block["id"]))
                    yield path, block, label_context(rows, block, cells[0]["text"])
    # Header row naming several known fields, followed by one data row.
    ordered = list(rows.items())
    for index, ((sheet, number), cells) in enumerate(ordered[:-1]):
        matches = [(c, table.get(label_key(c["text"]), set())) for c in cells if c["value_type"] == "text"]
        matches = [(c, p) for c, p in matches if p]
        if len(matches) < 2:
            continue
        (next_sheet, _), data = ordered[index + 1]
        if next_sheet != sheet:
            continue
        by_column = {c["column"]: c for c in data}
        for cell, paths in matches:
            target = by_column.get(cell["column"])
            if target is None:
                continue
            for path in sorted(paths):
                if (path, target["id"]) not in seen:
                    seen.add((path, target["id"]))
                    yield path, target, cell["text"]


def label_context(rows, block, label):
    year = year_header(rows, block["sheet"], block["row"], block["column"])
    return f"{label} · {year}" if year and year not in label else label


def classify(text, patterns, default):
    for pattern, value in patterns:
        if re.search(pattern, text, re.I):
            return value
    return default


def header_map(cells):
    mapping = {}
    for cell in cells:
        key = label_key(cell["text"])
        for field, names in BUDGET_HEADERS.items():
            if key in names and field not in mapping:
                mapping[field] = cell["column"]
    return mapping


def budget_rows(doc, cents):
    """Return (rows, warnings) for cost tables identified by their header names."""
    rows, warnings = rows_of(doc), []
    lines, seen, noted = [], set(), set()
    header = header_text = sheet_name = None
    for (sheet, number), cells in rows.items():
        if all(c["value_type"] == "text" for c in cells):
            mapping = header_map(cells)
            if "activity" in mapping and ("rate" in mapping or "amount" in mapping):
                header, header_text, sheet_name = mapping, {c["column"]: c["text"] for c in cells}, sheet
                continue
        if header is None or sheet != sheet_name:
            continue
        by_column = {c["column"]: c for c in cells}
        activity = by_column.get(header["activity"])
        value_cell = by_column.get(header.get("rate") or header.get("amount"))
        if activity is None or value_cell is None or TOTAL_ROW.match(activity["text"]):
            continue  # Notes, blank labels and totals are not cost rows.
        where = f"{doc['filename']} · XLSX {sheet}, row {number}"
        used = [activity, value_cell]
        try:
            if "rate" in header:
                quantity_cell = by_column.get(header.get("quantity"))
                if quantity_cell is None:
                    raise ValueError("a rate without a quantity")
                quantity, used = quantity_cell["text"].replace(",", "."), used + [quantity_cell]
            elif "quantity" in header:
                raise ValueError("an amount with a quantity but no rate; no rate is derived")
            else:
                quantity = "1"
            unit_cell = by_column.get(header.get("unit"))
            hours = "rate" in header and bool(re.search(
                r"(?i)\b(h|hr|hrs|hour|hours|uur|uren)\b",
                (unit_cell["text"] if unit_cell else "") + " " + header_text.get(header.get("quantity"), "")))
            type_cell, group_cell = by_column.get(header.get("cost_type")), by_column.get(header.get("group"))
            used += [c for c in (unit_cell, type_cell, group_cell) if c]
            for field, label in (("cost_type", "cost-type"), ("group", "activity-group")):
                if field not in header and (field, sheet) not in noted:
                    noted.add((field, sheet))
                    warnings.append(f"Sheet '{sheet}': no {label} column; rows were proposed as 'other'. Review before use.")
            ident_cell = by_column.get(header.get("id"))
            ident = ((ident_cell["text"] if ident_cell else "") or "xlsx-" + re.sub(r"[^a-z0-9]+", "-", sheet.lower()).strip("-") + f"-{number}")[:80]
            if ident in seen:
                warnings.append(f"{where}: duplicate row ID '{ident}' ignored.")
                continue
            if ident_cell:
                used.append(ident_cell)
            line = BudgetLine(id=ident, activity=activity["text"][:1000],
                              activity_group=classify(group_cell["text"] if group_cell else "", GROUPS, "other"),
                              cost_type=classify(type_cell["text"] if type_cell else "", COST_TYPES, "other"),
                              quantity=quantity, unit="hours" if hours else "item", rate_cents=cents(value_cell["text"]),
                              evidence=[evidence(doc, c, c["text"]) for c in used]).model_dump()
            seen.add(ident)
            lines.append(line)
        except (ValueError, ArithmeticError) as exc:
            warnings.append(f"Could not read a budget row at {where}: {str(exc)[:120]}")
    return lines, warnings
