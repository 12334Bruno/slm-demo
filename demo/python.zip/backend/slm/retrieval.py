"""Candidate retrieval: structured filters first, then bilingual BM25, then curated instruments.

The pattern follows established funding finders: hard eligibility filters (open, right
audience, right region), relevance ranking over the call's own words, and a small set of
broad startup instruments that are always worth considering. AI fit checks run later on
the shortlist; nothing here decides eligibility.
"""
import math
import re
import threading
import unicodedata
from collections import Counter
from typing import NamedTuple
from functools import lru_cache

import snowballstemmer
from wordfreq import zipf_frequency

# Same meaning in English and Dutch: most Dutch calls exist only in Dutch, so a translation counts almost like the word itself.
TRANSLATIONS = [
    "hydrogen waterstof", "electrolyser electrolysis elektrolyse elektrolyser", "packaging package verpakking",
    "plastic kunststof", "circular circulair circulaire circularity circulariteit", "recycling recyclen recycle",
    "reuse hergebruik reusable herbruikbaar", "waste afval", "energy energie", "electricity elektriciteit",
    "renewable hernieuwbaar hernieuwbare", "solar zonne-energie", "battery batterij accu", "storage opslag",
    "health gezondheid", "healthcare zorg gezondheidszorg", "medical medisch medische", "clinical klinisch klinische",
    "device hulpmiddel apparaat", "agriculture landbouw", "horticulture tuinbouw glastuinbouw greenhouse kas",
    "food voedsel voeding", "wastewater afvalwater", "mobility mobiliteit", "transport vervoer", "logistics logistiek",
    "vehicle voertuig", "maritime maritiem", "shipping scheepvaart", "vessel schip schepen vaartuig", "port haven",
    "inland binnenvaart", "building gebouw", "construction bouw", "renovation renovatie", "manufacturing maakindustrie",
    "industry industrie", "factory fabriek", "chemistry chemie", "chemical chemisch chemische",
    "material materiaal materialen", "biotechnology biotechnologie biotech", "medicine geneesmiddel", "climate klimaat",
    "emission emissie", "production productie", "innovation innovatie", "education onderwijs", "security veiligheid", "design ontwerp", "international internationaal",
    "fermentation fermentatie", "protein eiwit", "dairy zuivel", "artificial kunstmatige", "children kinderen",
    "parents ouders", "baby zuigeling",
]
# Related words: a query word also matches these terms, weighted lower than exact words.
SYNONYMS = [
    "circular circulair circulaire recycling recyclen hergebruik reuse reusable herbruikbaar afval waste",
    "packaging verpakking verpakkingen",
    "plastic plastics kunststof kunststoffen",
    "energy energie electricity elektriciteit renewable hernieuwbaar duurzame",
    "solar zon zonne",
    "hydrogen waterstof electrolyser elektrolyse",
    "battery batteries batterij batterijen storage opslag",
    "health healthcare zorg gezondheid gezondheidszorg medical medisch medische clinical klinisch",
    "baby babies infant infants newborn newborns pasgeborenen zuigeling zuigelingen neonatal parents ouders parenting ouderschap kraamzorg",
    "child children kind kinderen youth jeugd",
    "wellbeing welzijn mental stress",
    "device devices hulpmiddel hulpmiddelen apparaat medtech",
    "software app apps application platform digital digitaal digitale saas",
    "artificial intelligence ai kunstmatige machine learning",
    "data dataset datasets",
    "sensor sensors sensoren sensing monitoring wearable wearables iot",
    "robot robots robotics robotica automation automatisering",
    "agriculture agricultural landbouw agrarisch farming farm farmer boer tuinbouw horticulture greenhouse kas",
    "food voedsel voeding",
    "water wastewater afvalwater drinkwater",
    "mobility mobiliteit transport vervoer logistics logistiek vehicle vehicles voertuig",
    "maritime maritiem shipping scheepvaart vessel vessels haven port",
    "building buildings gebouw gebouwen construction bouw renovation renovatie",
    "manufacturing productie maakindustrie industry industrie factory fabriek",
    "chemistry chemie chemical chemicals",
    "materials materialen material",
    "biotech biotechnologie biotechnology",
    "drug drugs medicine medicines geneesmiddel geneesmiddelen pharma farmacie",
    "climate klimaat emissions emissies co2 carbon",
    "education onderwijs training opleiding skills",
    "security veiligheid cybersecurity",
    "creative creatieve design ontwerp media games",
    "export internationaal international abroad buitenland",
    "startup startups starter starters start-up young jonge",
    "innovation innovatie innovative innovatief novel nieuw",
    "research onderzoek r&d development ontwikkeling",
    "feasibility haalbaarheid haalbaarheidsstudie haalbaarheidsproject",
    "prototype prototypes pilot proeftuin demonstration demonstratie",
]
PLACE_WORDS = ["netherlands nederland dutch holland zuid-holland south europe european eu",
               "rotterdam den haag hague delft leiden dordrecht zoetermeer gouda schiedam westland amsterdam utrecht eindhoven groningen"]
STOP = set(("the and for with from that this will our are have has their your you its about into more than which can also each other "
            "een het van voor met deze dit zijn onze worden als aan dat door bij uit om op is in de en te of er ook niet wel naar "
            "wij we our us they them hun hen kunt kan wordt werd being been all any such may must "
            "cost costs kosten eur euro euros month months maand maanden year years jaar run meet out about budget want willen "
            "work working werk get make use using used way well like just "
            "before after help helps need needs test tests testing tested user users first better good best").split())
GENERIC = set("innovation innovatie innovative innovatief research onderzoek development ontwikkeling project projects company bedrijf "
              "business onderneming new nieuw nieuwe grant subsidie funding financiering support steun "
              # Project-stage words describe how, not what: they never establish a topic match on their own.
              "feasibility haalbaarheid haalbaarheidsstudie study studies studie pilot pilots demonstration demonstratie prototype "
              "prototypes experimental experimentele scale-up opschaling market markt launch based "
              # Words for the form of a product, not its subject.
              "module modules system systems systeem platform platforms process processes proces product products service services "
              "solution solutions oplossing oplossingen tool tools technology technologies technologie inspired measure measures".split())


def fold(text):
    text = unicodedata.normalize("NFKD", str(text).casefold())
    return "".join(c for c in text if not unicodedata.combining(c))


# A Snowball stemmer keeps the current word in its own state, so requests running in parallel each need their own.
_STEMMERS = threading.local()


@lru_cache(maxsize=200_000)  # The catalogue repeats the same words; stemming each once keeps ranking fast.
def stem(word):
    """Drop Dutch plurals, apply the English Snowball stemmer, keep at most 8 letters.

    monitor/monitoring and sensors/sensoren meet; electrolyser, electric and electronic stay
    apart. Dutch/English spellings that differ earlier (circular/circulair) are linked
    through TRANSLATIONS instead.
    """
    if word.endswith("en") and len(word) >= 8:
        word = word[:-2]  # Dutch plurals: sensoren, verpakkingen, batterijen.
    if not hasattr(_STEMMERS, "english"):
        _STEMMERS.english = snowballstemmer.stemmer("english")
    return _STEMMERS.english.stemWord(word)[:8]


def words(text):
    return [w for w in re.findall(r"[a-z][a-z0-9&-]{1,}", fold(text)) if w not in STOP and len(w) > 2]


def word_groups(lines):
    index = {}
    for line in lines:
        group = {stem(w) for w in fold(line).split()}
        for member in group:
            index.setdefault(member, set()).update(group)
    return index


TRANSLATION_INDEX = word_groups(TRANSLATIONS)
SYNONYM_INDEX = word_groups(SYNONYMS + TRANSLATIONS)


def terms(text):
    return [stem(w) for w in words(text)]


TOPIC_WORDS = {stem(w) for line in TRANSLATIONS + SYNONYMS for w in words(line)}
# Zipf scale: 6 = "the", 5 = "health", "whether", 4.5 = "attached", 4 = "sensor", "drone", 3 = "turbine", "algae".
EVERYDAY_ZIPF = 4.5


@lru_cache(maxsize=50_000)
def everyday(word):
    """True for words people use in all kinds of texts ("whether", "field", "attached"), in English or Dutch."""
    return max(zipf_frequency(word, "en"), zipf_frequency(word, "nl")) >= EVERYDAY_ZIPF


def subject_terms(text):
    """Stems that can name what a project is about: a known topic word, or a word that is uncommon in everyday language.

    The catalogue is mostly Dutch, so ordinary English words look rare in it; rarity in the catalogue alone
    turned words like "whether" and "declared" into topic matches."""
    forms = {}
    for word in words(text):
        forms.setdefault(stem(word), set()).add(word)
    # One everyday form is enough: "owning" is rare, but "own" in the same text is not.
    return {s for s, found in forms.items() if s in TOPIC_WORDS or not any(everyday(w) for w in found)}


# Pages a company publishes that say nothing about its project.
LEGAL_PAGE = re.compile(r"(?i)privacy|cookie|terms|voorwaarden|disclaimer|imprint|impressum|gdpr|avg|contact|careers?|jobs|vacature|"
                        r"werken-bij|news|nieuws|blog|press|pers|faq|support|login|shop|cart")


def topic_terms(text):
    """Stems of a sector description plus their translations and related words."""
    found = set()
    for term in terms(text):
        found |= {term} | SYNONYM_INDEX.get(term, set())
    return found


def document_text(doc):
    if doc.get("source_type") == "website":
        return " ".join(b["text"] for b in doc["blocks"] if not LEGAL_PAGE.search(b.get("source_url", "") + " " + b.get("locator", "")))
    return " ".join(b["text"] for b in doc["blocks"])


SUPPORTING_TITLE = re.compile(
    r"(?i):\s*(?:na uw aanvraag|voorwaarden|aanvraagproces|aanvragen|bijlagen|definities|veelgestelde vragen|achtergrondinformatie|"
    r"officiële bekendmakingen|voortgang|realisatie|controle|correctie|rekenvoorbeeld|stappenplan)|"
    r"^(?:feiten en cijfers|infographic|\d+ jaar |wet- en regelgeving|publicaties|resultaten|projecten van)|"
    r"(?:\s-\s)?na uw aanvraag$|kalender$|actualiteiten$|veelgestelde vragen")
WIDENING = {"Bulgaria", "Croatia", "Cyprus", "Czechia", "Estonia", "Greece", "Hungary", "Latvia", "Lithuania", "Malta",
            "Poland", "Portugal", "Romania", "Slovakia", "Slovenia"}
COMPANY_TARGETS = {"MKB (ook zzp)", "Grootbedrijf"}
DUTCH_PROVINCES = {"Zuid-Holland", "Noord-Holland", "Noord-Brabant", "Utrecht", "Gelderland", "Overijssel", "Limburg", "Zeeland",
                   "Friesland", "Fryslân", "Groningen", "Drenthe", "Flevoland"}
# EU action types that fund networks, public buyers, national funders or researchers, never a company's own project.
NOT_FOR_COMPANY_PROJECTS = re.compile(r"(?i)coordination and support|procurement|cofund|\bMSCA\b|\bERC\b|operating grants|"
                                      r"doctoral|fellowships|staff exchanges|certificate")
NORTH = {"Groningen", "Friesland", "Fryslân", "Drenthe"}


def is_scheme_subpage(record, by_path):
    """A record whose URL sits below another catalogue record is part of that scheme, not a separate opportunity."""
    url = record.get("url", "")
    match = re.match(r"https://[^/]+(/.*)$", url)
    if not match:
        return False
    path = match[1].rstrip("/")
    parts = path.split("/")
    return any("/".join(parts[:i]) in by_path for i in range(3, len(parts)))


def audience_ok(record, ws):
    targets = set(record.get("targets") or [])
    if not targets:
        return True
    if targets & COMPANY_TARGETS:
        return True
    agriculture = ws and re.search(r"(?i)agrar|landbouw|farm|boer|tuinbouw|veehouder", str((ws["facts"].get("company.activities") or {}).get("value") or ""))
    return bool(agriculture and "Agrarisch ondernemer" in targets)


def region_ok(record, ws):
    province = str(((ws or {}).get("facts", {}).get("company.province") or {}).get("value") or "")
    provider = record.get("provider")
    if provider == "snn":
        return not province or province in NORTH
    if provider in {"zh", "iq", "zh-regional", "municipal"} and province and province != "Zuid-Holland":
        return False
    city = str(((ws or {}).get("facts", {}).get("company.city") or {}).get("value") or "")
    cities = record.get("cities") or []
    return not (cities and city and city.casefold() not in {c.casefold() for c in cities})


TU_DELFT = re.compile(r"(?i)\bTU ?Delft\b|Delft University of Technology|Technische Universiteit Delft")


def tu_delft_link_possible(record, ws, text):
    """Schemes only for people linked to TU Delft need that link in the profile or text; a company in the city of Delft is not enough."""
    if not record.get("tu_delft_only"):
        return True
    from .focus_grants import TU_DELFT_LINK
    link = ((ws or {}).get("facts", {}).get("company.tu_delft_affiliation") or {}).get("value")
    return link in TU_DELFT_LINK if link else bool(TU_DELFT.search(text))


def eligible(record, ws, by_path, text):
    if record.get("kind") != "opportunity" or re.search(r"(?i)\bcancel+ed\b|ingetrokken|vervallen", record.get("title", "")):
        return False
    if record.get("curated") or record.get("focus_key"):
        return region_ok(record, ws) and tu_delft_link_possible(record, ws, text)
    if SUPPORTING_TITLE.search(record.get("title", "")) or is_scheme_subpage(record, by_path):
        return False
    facts = (ws or {}).get("facts", {})
    country = str((facts.get("company.country") or {}).get("value") or "")
    if not country and str((facts.get("company.province") or {}).get("value") or "") in DUTCH_PROVINCES:
        country = "Netherlands"  # A Dutch province is in the Netherlands.
    if any(NOT_FOR_COMPANY_PROJECTS.search(kind) for kind in (record.get("raw") or {}).get("typesOfAction") or []):
        return False
    if re.search(r"(?i)\bwidening\b", record.get("title", "")) and country and country not in WIDENING:
        return False  # "Widening" calls are reserved for applicants from widening countries.
    if record.get("instrument") in {"equity"} and re.search(r"(?i)\bB\.?V\.?$|fonds|fund\b", record.get("title", "")):
        return False  # Individual investment funds are reached through the Seed Capital scheme.
    return audience_ok(record, ws) and region_ok(record, ws)


def record_text(record):
    title = record.get("title", "")
    body = " ".join([record.get("description", "")[:4000], " ".join(record.get("tags") or [])])
    return title, body


def collaborative_eu(record):
    """EU research topics are mostly consortium projects, rarely a first grant for a single startup."""
    if record.get("provider") != "eu" or record.get("curated") or record.get("focus_key"):
        return False
    return not re.search(r"(?i)\bEIC\b|accelerator|startup|start-up|SME instrument|women ?techeu", record.get("title", "") + " " + record.get("programme", ""))


class Prepared(NamedTuple):
    """Word statistics of the open catalogue for one project text; shared by ranking and evidence."""
    docs: list
    query: Counter
    expanded: Counter
    readable: dict
    concept_df: dict
    subjects: set
    df: Counter
    size: int
    avg: float
    needed: int


def prepare(records, query_text, ws):
    """Parse the eligible catalogue once and choose the project's distinctive words. None when nothing is left to match."""
    by_path = set()
    for record in records:
        match = re.match(r"https://[^/]+(/.*)$", record.get("url", ""))
        if match and record.get("kind") == "opportunity":
            by_path.add(match[1].rstrip("/"))
    pool = [r for r in records if eligible(r, ws, by_path, query_text)]
    places = {stem(w) for name in PLACE_WORDS for w in words(name)}
    query = Counter(t for t in terms(query_text) if t not in places)
    if not query:
        return None
    readable = {}
    for word in words(query_text):
        readable.setdefault(stem(word), word)
    # Long texts (websites, plans) carry many everyday words: keep the most distinctive terms only.
    parsed = [(record, *(terms(text) for text in record_text(record))) for record in pool]
    corpus_df = Counter()
    for _, title_terms, body_terms in parsed:
        corpus_df.update(set(title_terms) | set(body_terms))
    size = len(pool) or 1
    common = 0.2 if size >= 50 else 1.01  # A tiny catalogue has no meaningful "common word" statistics.
    weighted = {t: c * math.log(1 + size / (1 + corpus_df[t])) for t, c in query.items() if corpus_df[t] / size < common}
    keep = set(sorted(weighted, key=weighted.get, reverse=True)[:40])
    query = Counter({t: min(c, 3) for t, c in query.items() if t in keep})
    if not query:
        return None
    expanded = Counter()
    for term, count in query.items():
        for synonym in SYNONYM_INDEX.get(term, ()):
            if synonym != term and synonym not in query:
                weight = 0.8 if synonym in TRANSLATION_INDEX.get(term, ()) else 0.35
                expanded[synonym] = max(expanded[synonym], weight)
    # How common a concept is across both languages: "zorg" is as common as "health", whatever its own count.
    concept_df = {t: max(corpus_df[x] for x in TRANSLATION_INDEX.get(t, set()) | {t}) for t in list(query) + list(expanded)}
    needed = 2 if len(query) <= 15 else 3  # A long website text shares two specific words with many calls by chance.
    docs = [(record, Counter(title_terms), Counter(body_terms), len(title_terms) * 3 + len(body_terms)) for record, title_terms, body_terms in parsed]
    df = Counter()
    for _, title_counts, body_counts, _ in docs:
        df.update(set(title_counts) | set(body_counts))
    avg = sum(d[3] for d in docs) / len(docs) if docs else 1
    return Prepared(docs, query, expanded, readable, concept_df, subject_terms(query_text), df, size, avg, needed)


def score_candidates(prepared, limit):
    """Return [(score, record, shared_terms, topics)] best first."""
    docs, query, expanded, readable, concept_df, _, df, size, avg, needed = prepared
    n = len(docs) or 1
    generic = {stem(w) for w in GENERIC}
    k1, b = 1.4, 0.75
    ranked = []
    for record, title_counts, body_counts, length in docs:
        score, shared = 0.0, []
        for term, weight in list(query.items()) + list(expanded.items()):
            frequency = 3 * title_counts.get(term, 0) + body_counts.get(term, 0)
            if not frequency:
                continue
            idf = math.log(1 + (n - df[term] + 0.5) / (df[term] + 0.5))
            if term in generic:
                idf *= 0.25  # "innovation" and "research" appear everywhere.
            tf = frequency * (k1 + 1) / (frequency + k1 * (1 - b + b * length / avg))
            score += min(weight, 3) * idf * tf
            if term not in generic and (weight >= 1 or title_counts.get(term)):
                shared.append(term)  # Exact words anywhere, or a synonym in the call's title (recycling -> "circular").
        # A topic match needs words that are distinctive in the catalogue, not common call vocabulary.
        rare = [t for t in shared if concept_df[t] / size < (0.04 if size >= 50 else 1.01)]
        specific = [t for t in shared if concept_df[t] / size < (0.1 if size >= 50 else 1.01)]
        # Loose related words ("energy" -> "duurzame") never make a title match on their own.
        in_title = any(title_counts.get(t) for t in rare if t in query or expanded.get(t, 0) >= 0.8)
        if record.get("focus_topic") and not set(query) & topic_terms(record["focus_topic"]):
            continue  # A curated instrument for one sector (maritime, circular, healthcare) needs that sector in the text.
        if not record.get("focus_key") and not (len(specific) >= needed or in_title):
            continue  # One distinctive word in the body ("comfort", "modules") is not a topic match.
        shared = rare + [t for t in shared if t not in rare]
        if not shared and not record.get("focus_key"):
            continue  # Only synonyms or generic words in common: not a real topic match.
        if record.get("focus_key"):
            score = score * 1.2 + 6.0  # Curated startup instruments are always worth a look.
        elif collaborative_eu(record):
            score *= 0.55
        if score <= 0:
            continue
        ranked.append((score, record, sorted({readable.get(t, t) for t in shared})[:12], []))
    ranked.sort(key=lambda item: (-item[0], item[1]["id"]))
    top = ranked[:limit]
    # Curated startup instruments that fit the company's region always reach the shortlist.
    top += [item for item in ranked[limit:] if item[1].get("focus_key")]
    return top


def rank(records, query_text, ws=None, limit=80):
    """Return [(score, record, shared_terms, topics)] best first."""
    prepared = prepare(records, query_text, ws)
    return score_candidates(prepared, limit) if prepared else []
