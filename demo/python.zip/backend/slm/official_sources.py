"""Explicit official-origin registry and canonical URLs for public retrieval."""
from urllib.parse import urljoin, urlparse, urlunparse, parse_qsl, urlencode

AUTHORITIES = {
    "www.rvo.nl": ("rvo", "Rijksdienst voor Ondernemend Nederland"),
    "rvo.nl": ("rvo", "Rijksdienst voor Ondernemend Nederland"),
    "english.rvo.nl": ("rvo", "Netherlands Enterprise Agency"),
    "ec.europa.eu": ("eu", "European Commission"),
    "api.tech.ec.europa.eu": ("eu", "European Commission public search"),
    "webgate.ec.europa.eu": ("eu", "European Commission"),
    "www.snn.nl": ("snn", "Samenwerkingsverband Noord-Nederland"),
    "snn.nl": ("snn", "Samenwerkingsverband Noord-Nederland"),
    "www.zuid-holland.nl": ("zh", "Provincie Zuid-Holland"),
    "lokaleregelgeving.overheid.nl": ("legal", "Official local regulations"),
    "wetten.overheid.nl": ("legal", "Official Dutch legislation"),
    "zoek.officielebekendmakingen.nl": ("legal", "Official Dutch publications"),
}
FUNDING_PROVIDERS = {"rvo", "eu", "snn", "zh"}


def official_url(url, base=None):
    if base:
        url = urljoin(base, url)
    p = urlparse(url)
    if (len(url) > 4096 or p.scheme != "https" or p.hostname not in AUTHORITIES or
            p.port not in {None, 443} or p.username or p.password or "\\" in url):
        raise ValueError("Use an HTTPS URL from a registered official source")
    return url


def canonical_url(url):
    official_url(url)
    p = urlparse(url)
    query = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True)
             if not k.lower().startswith("utm_") and k.lower() not in {"gclid", "fbclid"}]
    return urlunparse(("https", p.netloc.lower(), p.path or "/", "", urlencode(sorted(query)), ""))


def authority(url):
    official_url(url)
    provider, name = AUTHORITIES[urlparse(url).hostname]
    return {"provider": provider, "name": name, "origin": "https://" + urlparse(url).netloc}


def funding_page(url):
    info = authority(url)
    path = urlparse(url).path
    return (info["provider"] == "rvo" and path.startswith("/subsidies-financiering/") or
            info["provider"] == "snn" and path.startswith("/zakelijke-subsidies/") and not path.endswith("/subsidies-voor-zakelijk") or
            info["provider"] == "eu" and "/topic-details/" in path or
            info["provider"] == "zh" and "/subsidies/subsidies/" in path)
