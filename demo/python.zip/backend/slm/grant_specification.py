"""Versioned, evidence-bound requirements and application structures."""
import hashlib
import json
import re
from .application_prompts import input_prompt, reference_fragment
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field
from .config import now
from .funding_conditions import basic_requirements, reference, evaluate_requirements, AMOUNT_PATTERN, money_cents
from .profiles import fact_value
from .grant_structure import short_label, ATTACHMENT_PAGE

SPEC_VERSION = "grant-spec-3.5"
NUMERIC_FIELDS = {"project_budget_cents", "project.organisation_count", "project.independent_sme_participant_count", "project.trl",
                  "company.age_months", "company.fte"}
FIELDS = {"company.country", "company.province", "company.sme_self_declared", "project.primary_activity", "company.legal_form",
          "company.tu_delft_affiliation", "company.women_led", "company.university_spin_out", "company.founder_employed_researcher",
          "finance.cofinancing_available"} | NUMERIC_FIELDS


class Rule(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["atomic", "all", "any", "if", "manual"]
    field: str | None = None
    operator: Literal["eq", "in", "gte", "lte"] | None = None
    expected: str | bool | int | list[str] | None = None
    children: list["Rule"] = Field(default_factory=list)


def validate_rule(rule, depth=0):
    rule = Rule.model_validate(rule)
    if depth > 8:
        raise ValueError("Requirement expression is too deep")
    if rule.kind == "atomic":
        if rule.field not in FIELDS or not rule.operator or rule.expected is None:
            raise ValueError("Unknown requirement field/operator")
        numeric = rule.field in NUMERIC_FIELDS
        if numeric and (type(rule.expected) is not int or rule.expected < 0 or rule.operator not in {"eq", "gte", "lte"}):
            raise ValueError("Invalid numeric condition")
        if rule.field == "company.sme_self_declared" and (type(rule.expected) is not bool or rule.operator != "eq"):
            raise ValueError("Invalid SME condition")
        if not numeric and rule.field != "company.sme_self_declared":
            if rule.operator == "eq" and not isinstance(rule.expected, str):
                raise ValueError("Invalid text condition")
            if rule.operator == "in" and (not isinstance(rule.expected, list) or not rule.expected or any(not isinstance(v, str) for v in rule.expected)):
                raise ValueError("Invalid alternatives")
            if rule.operator not in {"eq", "in"}:
                raise ValueError("Text ordering is unsupported")
    elif rule.kind in {"all", "any", "if"}:
        if not 1 <= len(rule.children) <= 20 or rule.kind == "if" and len(rule.children) != 2:
            raise ValueError("Invalid logical requirement")
        for child in rule.children:
            validate_rule(child, depth + 1)
    return rule.model_dump()


def evaluate_rule(rule, workspace, evidence=None):
    rule = validate_rule(rule)
    kind = rule["kind"]
    if kind == "manual":
        return "MANUAL_REVIEW"
    if kind == "atomic":
        outcome = evaluate_requirements({"requirements": [{"id": "atomic", "label": rule["field"],
            "field": rule["field"], "operator": rule["operator"], "expected": rule["expected"], "evidence": evidence or {}}]}, workspace)[0]
        return outcome["outcome"]
    outcomes = [evaluate_rule(child, workspace, evidence) for child in rule["children"]]
    if kind == "if":
        return "NOT_APPLICABLE" if outcomes[0] == "FAIL" else outcomes[1] if outcomes[0] == "PASS" else outcomes[0]
    if kind == "all" and "FAIL" in outcomes:
        return "FAIL"
    if kind == "any" and "PASS" in outcomes:
        return "PASS"
    if "CONFLICT" in outcomes:
        return "CONFLICT"
    if "UNKNOWN" in outcomes:
        return "UNKNOWN"
    if "MANUAL_REVIEW" in outcomes:
        return "MANUAL_REVIEW"
    if all(outcome == "NOT_APPLICABLE" for outcome in outcomes):
        return "NOT_APPLICABLE"
    return "PASS" if kind == "all" else "FAIL"


def stable_id(*parts):
    return hashlib.sha256("|".join(str(p) for p in parts).encode()).hexdigest()[:20]


def classify(text, heading=""):
    combined = (heading + " " + text).casefold()
    if re.search(r"attach|upload|meesturen|voeg.{0,25}bij|bijlagen|required documents|benodigde documenten", combined):
        return "attachment"
    if re.search(r"award criteria|assessment criteria|beoordelingscriteria|scoring|selection criteria|hoe.{0,25}beoordeeld|how.{0,25}assessed", combined):
        return "assessment"
    if re.search(r"maximum grant|grant rate|project budget|project costs|subsidiepercent|subsidie bedraagt|subsidie.{0,20}maximaal|eligible costs|subsidiabele kosten|financiering|fixed grant|lump.sum|unit.cost|overhead|depreciation", combined):
        return "financial"
    if re.search(r"deadline|closing date|aanvraagperiode|indienen voor|uiterlijk|submission deadline", combined):
        return "timing"
    if re.search(r"eligib|voorwaarden|requirements|must |shall |moet|vereist|u bent|u heeft|uitsluitend|alleen voor|voor wie|wie kan.{0,20}aanvragen|who can apply|consortium includes", combined):
        return "eligibility"
    return None


COUNTRIES = {"netherlands": "Netherlands", "nederland": "Netherlands", "belgium": "Belgium", "belgië": "Belgium",
             "germany": "Germany", "duitsland": "Germany", "france": "France", "frankrijk": "France"}


def country_alternatives(text):
    match = re.search(r"(?i)(?:applicants must be (?:registered|established|based) in|uw bedrijf is gevestigd in)\s+(.*?)[.!;]?$", text)
    if not match:
        return None
    tail = match[1].strip().rstrip(".;").casefold()
    names = re.split(r"\s+(?:or|of)\s+|,\s*", tail)
    names = [re.sub(r"^the\s+", "", name.strip()) for name in names]
    if len(names) > 1 and all(name in COUNTRIES for name in names):
        return {"kind": "atomic", "field": "company.country", "operator": "in", "expected": [COUNTRIES[name] for name in names], "children": []}


def evidence_for(record, block, quote):
    if not quote or quote not in block["text"]:
        raise ValueError("Requirement quote is not supported by its source block")
    return reference(record, block, quote)


EU27 = ["Austria", "Belgium", "Bulgaria", "Croatia", "Cyprus", "Czechia", "Denmark", "Estonia", "Finland", "France", "Germany",
        "Greece", "Hungary", "Ireland", "Italy", "Latvia", "Lithuania", "Luxembourg", "Malta", "Netherlands", "Poland",
        "Portugal", "Romania", "Slovakia", "Slovenia", "Spain", "Sweden"]
POINTER = re.compile(r"(?i)^(?:[^:]{0,120}:\s*){0,2}(?:are\s+|is\s+)?(?:described|set out|specified|laid down|defined|explained|listed)\s+in\b|"
                     r"^(?:please\s+)?(?:see|consult|refer to|check)\b.{0,80}\b(?:annex|programme guide|online manual|call document|work programme)\b")


STOPWORDS = set("""de het een en van voor met dat die dit deze in op aan te bij om uw u is zijn wordt worden of als door niet ook
    the a an and of for with that this these in on to at by your you is are be or as not also must moet kan kunt""".split())


def significant(text):
    """Stems of the meaningful words, so a summary ("planmatig aanpakken") and its full rule ("planmatige aanpak") compare as equal."""
    from .retrieval import stem
    return {stem(w) for w in re.findall(r"[a-zà-ÿ0-9]{3,}", text.casefold()) if w not in STOPWORDS}


def similar(a, b):
    if not a or not b:
        return False
    overlap = len(a & b)
    return overlap / min(len(a), len(b)) >= 0.7 and overlap >= 4


def doc_scope(doc):
    return {"primary": "call", "call": "call", "annex": "annex", "template": "template"}.get(doc.get("role"), doc.get("role") or "guidance")


def document_label(text):
    from .grant_tasks import document_title
    title = document_title({"title": text, "evidence": {"quote": text}})
    if title.startswith("Supporting document"):
        return short_label(text, 110)
    return title


def action_profile(record):
    raw = record.get("raw") or {}
    flat = lambda key: " ".join(str(v) for v in (raw.get(key) or [])) if isinstance(raw.get(key), list) else str(raw.get(key) or "")
    actions = (flat("typesOfAction") + " " + flat("actions")).casefold()
    codes = set()
    for pattern, code in [(r"coordination and support", "csa"), (r"research and innovation action|\bria\b", "ria"), (r"innovation action|\bia\b", "ia"),
                          (r"programme co-?fund|cofund", "cofund"), (r"research infrastructure", "ri"), (r"\bpcp\b|pre-commercial", "pcp"),
                          (r"simple grant|\bsimple\b", "simple"), (r"lump sum", "ls")]:
        if re.search(pattern, actions):
            codes.add(code)
    return codes, "two-stage" in flat("deadlineModel").casefold()


def choose_form(record, templates):
    """With several standard forms linked, keep the one for this call's action type and stage."""
    from .grant_structure import form_sections
    mapped = [t for t in templates if form_sections(t)]
    if len(mapped) < 2:
        return mapped[0] if mapped else None
    codes, two_stage = action_profile(record)

    def score(doc):
        title = (doc.get("title") or "").casefold()
        found = set(re.findall(r"\b(csa|ria|ia|cofund|ri|pcp|simple|ls)\b", title))
        value = 3 * len(found & codes) - 2 * len(found - codes)
        value += (2 if "stage 1" in title else -2) if two_stage else (-3 if "stage 1" in title else 0)
        value -= 2 if "blind" in title else 0
        return value
    return max(mapped, key=score)


def build_specification(record, bundle, failures=None, model_rules=None, model_call=None):
    """Applicable call items, writing sections from the official form, and retained sources."""
    from .grant_structure import (grouped_items, section_kind, item_kind, junk, with_heading, short_label as label_for,
                                  form_sections, heading_title, CONDITIONAL, document_heading)
    requirements, sections, attachments, assessment, financial, sources = [], [], [], [], [], []
    purpose, steps, timing_notes = [], [], []
    seen = set()
    chosen_form = choose_form(record, [d for d in bundle if d.get("role") == "template" and d.get("blocks")])
    for doc in bundle:
        sources.append({k: doc.get(k) for k in ("id", "url", "title", "sha256", "format", "role", "warnings", "fetched")})
        scope = doc_scope(doc)
        if not doc.get("blocks"):
            continue
        if scope == "template":
            if chosen_form and doc is not chosen_form and form_sections(doc):
                continue  # Another action type's standard form (e.g. CSA or stage 1) does not apply to this call.
            found = form_sections(doc)
            for section in found:
                block = section["block"]
                ref = evidence_for(record, block, block["text"])
                instructions = [{"text": i["text"], "evidence": evidence_for(record, i["block"], i["block"]["text"])}
                                for i in section["instructions"][:40]]
                limits = section["limits"]
                sections.append({"id": stable_id(doc["url"], block.get("locator", ""), section["heading"]),
                                 "heading": section["heading"], "group": section["group"], "required": None, "evidence": ref,
                                 "instructions": instructions, "group_context": section.get("group_context", [])[:6],
                                 "assessment_aspects": section.get("assessment_aspects", [])[:8],
                                 "page_hint": section["page_hint"], "max_pages": limits.get("pages") or limits.get("pagina's") or limits.get("paginas"),
                                 "max_words": limits.get("words") or limits.get("woorden"),
                                 "max_characters": limits.get("characters") or limits.get("tekens"),
                                 "template_url": doc["url"], "template_title": doc.get("title")})
            if not found:
                # A template we cannot map into questions is a file to complete and attach.
                rid = stable_id(doc["url"], "template-upload")
                first = next((b for b in doc["blocks"] if b.get("text")), None)
                if first:
                    attachments.append({"id": rid, "title": "Completed " + (doc.get("title") or "official template").strip(),
                                        "required": True, "conditional": False, "template_sha256": doc.get("sha256"),
                                        "template_url": doc["url"], "evidence": evidence_for(record, first, first["text"]),
                                        "instruction": "Download the official template, fill it in and attach the completed file.",
                                        "source": "template"})
            continue
        if scope not in {"call", "annex"}:
            continue
        for item in grouped_items(doc):
            section = section_kind(item["path"])
            text = with_heading(item["text"], item["path"])
            if junk(item["text"]) or reference_fragment(item["text"]) and not item["path"]:
                continue
            kind = "info" if item.get("lead") else item_kind(text, section, item.get("context", ""))
            named_document = document_heading(item["path"]) if scope == "call" else None
            if named_document and kind not in {None, "purpose"}:
                kind = "document"
            if kind is None or scope == "annex" and kind not in {"condition", "document"}:
                continue  # General programme rules only contribute conditions and documents for reference.
            block = item["blocks"][0]
            proof = evidence_for(record, block, block["text"])
            parts = [evidence_for(record, b, b["text"]) for b in item["blocks"][1:]]
            heading = heading_title(item["path"][-1]) if item["path"] else ""
            if kind == "purpose":
                if scope == "call" and len(purpose) < 40:
                    purpose.append({"text": text, "section": heading, "evidence": proof})
                continue
            if kind == "info" or POINTER.search(text) and not re.search(r"(?i)eligible countr", heading + " " + text):
                kind = "info"
            if kind == "step":
                if scope == "call":
                    steps.append({"id": stable_id(doc["url"], "step", text), "text": text, "label": label_for(text, 140),
                                  "section": heading, "evidence": proof})
                continue
            if kind == "timing":
                if scope == "call":
                    timing_notes.append({"text": text, "evidence": proof})
                continue
            category = {"condition": "eligibility", "document": "attachment", "funding": "financial",
                        "assessment": "assessment", "info": "info"}[kind]
            key = (category, re.sub(r"\W+", " ", text.casefold()).strip())
            if key in seen:
                continue
            seen.add(key)

            uncertain = bool(CONDITIONAL.search(text))
            rules = []
            if category in {"eligibility", "financial"}:
                single = {**record, "blocks": [{**block, "text": text}]}
                rules = [{"kind": "atomic", "field": b["field"], "operator": b["operator"], "expected": b["expected"], "children": []}
                         for b in basic_requirements(single)]
                alternative = country_alternatives(text)
                if alternative:
                    rules = [alternative]
            explanation = None
            if record.get("provider") == "eu" and re.search(r"(?i)eligible countr", heading + " " + text) and re.search(r"(?i)annex b", text):
                # Programme knowledge: EU Member States are always eligible countries; others need Annex B.
                rules = [{"kind": "any", "children": [
                    {"kind": "atomic", "field": "company.country", "operator": "in", "expected": EU27, "children": []},
                    {"kind": "manual", "children": []}]}]
                explanation = ("Organisations established in an EU Member State meet this condition. "
                               "Associated and other countries need a check against Annex B of the General Annexes.")
                category, kind, uncertain = "eligibility", "condition", False
            rule = rules[0] if len(rules) == 1 else {"kind": "all", "children": rules} if rules else None
            if uncertain or scope != "call" or category not in {"eligibility", "financial"}:
                rule = None if not explanation else rule
            if category == "eligibility":
                words = significant(text)
                twin = next((r for r in requirements if r["category"] == "eligibility" and r["rule"] == (validate_rule(rule) if rule else None)
                             and r["scope"] == scope and similar(words, r["_words"])), None)
                if twin:
                    # The scheme's summary page often repeats its conditions page; keep one, with both sources.
                    if len(text) > len(twin["text"]):
                        twin.update(text=text, label=label_for(text), evidence=proof, _words=words)
                    twin.setdefault("supporting_evidence", []).append(proof)
                    continue
            rid = stable_id(doc["url"], heading, category, text)
            req = {"id": rid, "category": category, "kind": kind, "label": label_for(text), "text": text,
                   "section": heading, "section_kind": section, "explanation": explanation,
                   "rule": validate_rule(rule) if rule else None, "evidence": proof, "parts": parts,
                   "scope": scope, "conditional": uncertain, "review_required": not bool(rule), "interpretation": "basic"}
            req["_words"] = significant(text) if category == "eligibility" else set()
            requirements.append(req)
            if category == "attachment" and scope == "call":
                context = item.get("context", "") + " " + " ".join(heading_title(h) for h in item["path"])
                required = None if uncertain else False if re.search(r"(?i)optional|optioneel|may attach|kunt u .{0,30}meesturen|indien van toepassing", text) else \
                    True if re.search(r"(?i)must|shall|required|moet|vereist|verplicht|stuurt u mee|voegt u .{0,30}toe", text) or named_document and ATTACHMENT_PAGE.search(context) else None
                title = named_document or document_label(text)
                existing = next((a for a in attachments if named_document and a["title"] == title), None)
                if existing:
                    existing["instruction"] += " " + text  # Several paragraphs under one document heading.
                    continue
                attachments.append({"id": rid, "title": title, "required": required, "conditional": uncertain,
                                    "evidence": proof, "instruction": text, "source": "call"})
            elif category == "assessment" and scope == "call":
                assessment.append({"id": rid, "criterion": text, "evidence": proof})
            if category == "financial":
                # Scalars are sourced observations, never a computed grant award.
                money = re.search(r"(?i)(?:EUR|€)\s*" + AMOUNT_PATTERN, text)
                rate = re.search(r"\b(\d{1,2}(?:[.,]\d{1,2})?|100)\s*%", text)
                fscope = "programme" if re.search(r"(?i)programme budget|call budget|subsidieplafond|totale budget|budget (?:for|of) (?:this|the) (?:call|topic)|indicative budget|plafond", text) else \
                    "project" if re.search(r"(?i)per project|per applicant|per aanvraag|per aanvrager|per onderneming|per proposal|maximaal|maximum|up to|tot", text) else "unspecified"
                financial.append({"id": rid, "text": text, "scope": fscope if scope == "call" else "programme",
                    "amount_cents": money_cents(money[1]) if money and not re.search(r"(?i)million|miljoen|\bUSD\b|\bbn\b|billion", text) else None,
                    "currency": "EUR" if money else None, "rate_percent": rate[1].replace(",", ".") if rate else None, "evidence": proof})
    # Assessment aspects printed in the form complete the call's own criteria.
    for section in sections:
        for aspect in section.get("assessment_aspects", []):
            if not any(a["criterion"] == aspect for a in assessment) and len(assessment) < 30:
                assessment.append({"id": stable_id(section["id"], aspect), "criterion": aspect, "evidence": section["evidence"]})
    if model_rules:
        for rule in model_rules:
            expr = validate_rule({"kind": "atomic", "field": rule["field"], "operator": rule["operator"], "expected": rule["expected"], "children": []})
            proof = rule["evidence"]
            source = next((d for d in bundle if any(b["id"] == proof["block_id"] for b in d["blocks"])), None)
            block = next((b for b in source["blocks"] if b["id"] == proof["block_id"]), None) if source else None
            if not block or proof["quote"] not in block["text"]:
                raise ValueError("Model condition is not supported by the collected sources")
            inherited = source.get("role") in {"annex", "guidance"}
            if inherited or re.search(r"(?i)unless|except|tenzij|\bif\b|\bindien\b|\bals\b|\bmits\b|depending on|afhankelijk", block["text"]) or (
                    re.search(r"(?i)\bor\b|\bof\b", block["text"]) and expr["operator"] != "in"):
                expr = None
            requirements.append({"id": stable_id(proof["url"], rule["field"], proof["locator"], proof["quote"]), "category": "eligibility",
                "kind": "condition", "label": rule["label"], "text": proof["quote"], "section": "", "section_kind": "eligibility",
                "explanation": None, "rule": expr, "evidence": proof, "parts": [], "scope": doc_scope(source),
                "conditional": expr is None, "review_required": True, "interpretation": "model_proposed"})
    for condition in record["requirements"] if record.get("curated") else []:
        if condition["interpretation"] != "curated":
            continue  # Conditions read from the curated text itself were already added above.
        # Hand-checked conditions of a focus instrument, quoting its curated "Who can apply" text.
        block = next(b for b in record["blocks"] if b["id"] == condition["evidence"]["block_id"])
        rule = validate_rule({"kind": "atomic", "field": condition["field"], "operator": condition["operator"],
                              "expected": condition["expected"], "children": []})
        requirements.append({"id": stable_id(record["url"], condition["id"], condition["label"]), "category": "eligibility", "kind": "condition",
            "label": condition["label"], "text": condition["evidence"]["quote"], "section": block["locator"], "section_kind": "eligibility",
            "explanation": None, "rule": rule, "evidence": evidence_for(record, block, condition["evidence"]["quote"]), "parts": [],
            "scope": "call", "conditional": False, "review_required": False, "interpretation": "curated"})
    warnings = list(failures or [])
    for source in sources:
        warnings.extend({"url": source["url"], "error": warning} for warning in source.get("warnings") or [])
    conflicts = []
    atoms = {}
    for req in requirements:
        rule = req["rule"]
        if rule and rule["kind"] == "atomic":
            key = (rule["field"], rule["operator"])
            for other in atoms.get(key, []):
                if other["rule"]["expected"] != rule["expected"]:
                    conflicts.append({"field": rule["field"], "requirement_ids": [other["id"], req["id"]],
                                      "message": "Official sources give different conditions; applicability requires review."})
            atoms.setdefault(key, []).append(req)
    for req in requirements:
        req.pop("_words", None)
    unique = {r["id"]: r for r in requirements}
    from .official_forms import sections_for, variants_for
    checked = sections_for(record, bundle)
    variants = variants_for(record, bundle)
    if checked:
        sections = checked  # A hand-checked official form replaces the automatic reading of that form.
    spec = {"opportunity_id": record["id"], "title": record["title"], "provider": record.get("provider"), "extractor_version": SPEC_VERSION,
        "processing_mode": "Model-assisted interpretation" if model_call else "Basic interpretation",
        "model_call": model_call, "requirements": list(unique.values()), "application_sections": list({s["id"]: s for s in sections}.values()),
        "attachments": list({a["id"]: a for a in attachments}.values()), "assessment_criteria": assessment, "financial_observations": financial,
        "purpose": purpose, "submission_steps": steps, "timing_notes": timing_notes[:12],
        "templates": [{"url": d["url"], "title": d["title"], "format": d["format"], "sha256": d["sha256"],
                       "tables": d.get("tables", []), "mapped": any(s.get("template_url") == d["url"] for s in sections)}
                      for d in bundle if d.get("role") == "template" and d.get("blocks")],
        "reference_documents": [{"url": d["url"], "title": d["title"], "role": d.get("role")} for d in bundle
                                if d.get("role") in {"guidance", "post_award", "annex"}],
        "sources": sources, "conflicts": conflicts, "warnings": warnings,
        "coverage": "partial" if warnings or not requirements else "sources_read",
        "eligibility_review_required": True, **({"form_variants": variants} if variants else {})}
    spec["version"] = stable_id(json.dumps({k: v for k, v in spec.items() if k != "model_call"}, sort_keys=True, ensure_ascii=False))
    spec["created_at"] = now()
    return spec


def evaluate_specification(spec, workspace):
    from .grant_tasks import requirement_tasks
    conflicting = {rid for c in spec["conflicts"] for rid in c["requirement_ids"]}
    result = []
    for req in requirement_tasks(spec):
        outcome = "SOURCE_CONFLICT" if req["id"] in conflicting else evaluate_rule(req["rule"], workspace, req["evidence"]) if req["rule"] else "MANUAL_REVIEW"
        from .matching_depth import rule_leaves
        values = [{"field": leaf["field"], "value": leaf.get("actual"), "state": workspace["facts"].get(leaf["field"], {}).get("state", "missing")}
                  for leaf in rule_leaves(req.get("rule"), workspace, req["evidence"])] if req.get("rule") else []
        result.append({**req, "outcome": outcome, "profile_details": values})
    return result


class SpecificationStore:
    def __init__(self, store):
        self.store = store
        with store.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS grant_specifications (
                    opportunity_id TEXT NOT NULL, version TEXT NOT NULL, created_at TEXT NOT NULL,
                    state TEXT NOT NULL, PRIMARY KEY(opportunity_id, version));
                CREATE TABLE IF NOT EXISTS grant_specification_heads (
                    opportunity_id TEXT PRIMARY KEY, version TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS grant_specification_seen (
                    workspace_id TEXT NOT NULL, opportunity_id TEXT NOT NULL, version TEXT NOT NULL,
                    PRIMARY KEY(workspace_id, opportunity_id));
            """)

    def latest(self, rid):
        with self.store.connect() as conn:
            row = conn.execute("SELECT s.state FROM grant_specifications s JOIN grant_specification_heads h ON h.opportunity_id=s.opportunity_id AND h.version=s.version WHERE h.opportunity_id=?", (rid,)).fetchone()
        return json.loads(row[0]) if row else None

    def versions(self, rid):
        with self.store.connect() as conn:
            return [{"version": r[0], "created_at": r[1]} for r in conn.execute("SELECT version, created_at FROM grant_specifications WHERE opportunity_id=? ORDER BY created_at DESC", (rid,))]

    def get(self, rid, version):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM grant_specifications WHERE opportunity_id=? AND version=?", (rid, version)).fetchone()
        if not row:
            raise KeyError("Specification version not found")
        return json.loads(row[0])

    def seen(self, wid, rid):
        with self.store.connect() as conn:
            row = conn.execute("SELECT version FROM grant_specification_seen WHERE workspace_id=? AND opportunity_id=?", (wid, rid)).fetchone()
        return row[0] if row else None

    def mark_seen(self, wid, rid, version):
        self.store.load(wid)
        latest = self.latest(rid)
        if not latest or latest["version"] != version:
            raise ValueError("Grant conditions changed again. Reload before marking changes read.")
        with self.store.connect() as conn:
            conn.execute("INSERT INTO grant_specification_seen VALUES (?, ?, ?) ON CONFLICT(workspace_id, opportunity_id) DO UPDATE SET version=excluded.version", (wid, rid, version))

    def save(self, spec):
        previous = self.latest(spec["opportunity_id"])
        previous_requirements = {r["id"]: r for r in previous["requirements"]} if previous else {}
        current = {r["id"]: r for r in spec["requirements"]}
        def meaning(req):
            return {k: v for k, v in req.items() if k != "evidence"} | {
                "evidence": {k: v for k, v in req.get("evidence", {}).items() if k not in {"snapshot_hash", "block_id"}}}
        changes = {"previous_version": previous["version"] if previous else None,
            "added": sorted(set(current) - set(previous_requirements)), "removed": sorted(set(previous_requirements) - set(current)),
            "changed": [rid for rid in set(current) & set(previous_requirements) if meaning(current[rid]) != meaning(previous_requirements[rid])],
            "application_changed": bool(previous and (
                [(s["heading"], s.get("max_words"), s.get("max_characters")) for s in previous["application_sections"]] !=
                [(s["heading"], s.get("max_words"), s.get("max_characters")) for s in spec["application_sections"]]))}
        spec = {**spec, "changes": changes}
        with self.store.connect() as conn:
            conn.execute("INSERT OR IGNORE INTO grant_specifications VALUES (?, ?, ?, ?)", (spec["opportunity_id"], spec["version"], spec["created_at"], json.dumps(spec)))
            conn.execute("INSERT INTO grant_specification_heads VALUES (?, ?) ON CONFLICT(opportunity_id) DO UPDATE SET version=excluded.version", (spec["opportunity_id"], spec["version"]))
        return self.latest(spec["opportunity_id"])
