"""Versioned, evidence-bound requirements and application structures."""
import hashlib
import json
import re
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field
from .config import now
from .funding_conditions import basic_requirements, reference, evaluate_requirements, AMOUNT_PATTERN, money_cents
from .profiles import fact_value

SPEC_VERSION = "grant-spec-2.2"
FIELDS = {"company.country", "company.province", "company.sme_self_declared", "project.primary_activity",
          "project.independent_sme_participant_count", "project.organisation_count", "project_budget_cents"}


class Rule(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["atomic", "all", "any", "if", "manual"]
    field: str | None = None
    operator: Literal["eq", "in", "gte", "lte"] | None = None
    expected: str | bool | int | list[str] | None = None
    children: list["Rule"] = Field(default_factory=list)


def validate_rule(rule, depth=0):
    rule = Rule.model_validate(rule)
    if depth > 8:
        raise ValueError("Requirement expression is too deep")
    if rule.kind == "atomic":
        if rule.field not in FIELDS or not rule.operator or rule.expected is None:
            raise ValueError("Unknown requirement field/operator")
        numeric = rule.field in {"project_budget_cents", "project.organisation_count", "project.independent_sme_participant_count"}
        if numeric and (type(rule.expected) is not int or rule.expected < 0 or rule.operator not in {"eq", "gte", "lte"}):
            raise ValueError("Invalid numeric condition")
        if rule.field == "company.sme_self_declared" and (type(rule.expected) is not bool or rule.operator != "eq"):
            raise ValueError("Invalid SME condition")
        if not numeric and rule.field != "company.sme_self_declared":
            if rule.operator == "eq" and not isinstance(rule.expected, str):
                raise ValueError("Invalid text condition")
            if rule.operator == "in" and (not isinstance(rule.expected, list) or not rule.expected or any(not isinstance(v, str) for v in rule.expected)):
                raise ValueError("Invalid alternatives")
            if rule.operator not in {"eq", "in"}:
                raise ValueError("Text ordering is unsupported")
    elif rule.kind in {"all", "any", "if"}:
        if not 1 <= len(rule.children) <= 20 or rule.kind == "if" and len(rule.children) != 2:
            raise ValueError("Invalid logical requirement")
        for child in rule.children:
            validate_rule(child, depth + 1)
    return rule.model_dump()


def evaluate_rule(rule, workspace, evidence=None):
    rule = validate_rule(rule)
    kind = rule["kind"]
    if kind == "manual":
        return "MANUAL_REVIEW"
    if kind == "atomic":
        outcome = evaluate_requirements({"requirements": [{"id": "atomic", "label": rule["field"],
            "field": rule["field"], "operator": rule["operator"], "expected": rule["expected"], "evidence": evidence or {}}]}, workspace)[0]
        return outcome["outcome"]
    outcomes = [evaluate_rule(child, workspace, evidence) for child in rule["children"]]
    if kind == "if":
        return "NOT_APPLICABLE" if outcomes[0] == "FAIL" else outcomes[1] if outcomes[0] == "PASS" else outcomes[0]
    if kind == "all" and "FAIL" in outcomes:
        return "FAIL"
    if kind == "any" and "PASS" in outcomes:
        return "PASS"
    if "CONFLICT" in outcomes:
        return "CONFLICT"
    if "UNKNOWN" in outcomes:
        return "UNKNOWN"
    if "MANUAL_REVIEW" in outcomes:
        return "MANUAL_REVIEW"
    if all(outcome == "NOT_APPLICABLE" for outcome in outcomes):
        return "NOT_APPLICABLE"
    return "PASS" if kind == "all" else "FAIL"


def stable_id(*parts):
    return hashlib.sha256("|".join(str(p) for p in parts).encode()).hexdigest()[:20]


def classify(text, heading=""):
    combined = (heading + " " + text).casefold()
    if re.search(r"attach|upload|meesturen|voeg.{0,25}bij|bijlagen|required documents|benodigde documenten", combined):
        return "attachment"
    if re.search(r"award criteria|assessment criteria|beoordelingscriteria|scoring|selection criteria|hoe.{0,25}beoordeeld|how.{0,25}assessed", combined):
        return "assessment"
    if re.search(r"maximum grant|grant rate|project budget|project costs|subsidiepercent|subsidie bedraagt|subsidie.{0,20}maximaal|eligible costs|subsidiabele kosten|financiering", combined):
        return "financial"
    if re.search(r"deadline|closing date|aanvraagperiode|indienen voor|uiterlijk|submission deadline", combined):
        return "timing"
    if re.search(r"eligib|voorwaarden|requirements|must |shall |moet|vereist|u bent|u heeft|uitsluitend|alleen voor|voor wie|wie kan.{0,20}aanvragen|who can apply", combined):
        return "eligibility"
    return None


COUNTRIES = {"netherlands": "Netherlands", "nederland": "Netherlands", "belgium": "Belgium", "belgië": "Belgium",
             "germany": "Germany", "duitsland": "Germany", "france": "France", "frankrijk": "France"}


def country_alternatives(text):
    match = re.search(r"(?i)(?:applicants must be (?:registered|established|based) in|uw bedrijf is gevestigd in)\s+(.*?)[.!;]?$", text)
    if not match:
        return None
    tail = match[1].strip().rstrip(".;").casefold()
    names = re.split(r"\s+(?:or|of)\s+|,\s*", tail)
    names = [re.sub(r"^the\s+", "", name.strip()) for name in names]
    if len(names) > 1 and all(name in COUNTRIES for name in names):
        return {"kind": "atomic", "field": "company.country", "operator": "in", "expected": [COUNTRIES[name] for name in names], "children": []}


def evidence_for(record, block, quote):
    if not quote or quote not in block["text"]:
        raise ValueError("Requirement quote is not supported by its source block")
    return reference(record, block, quote)


def build_specification(record, bundle, failures=None, model_rules=None, model_call=None):
    requirements, sections, attachments, assessment, financial, sources = [], [], [], [], [], []
    seen = set()
    for doc in bundle:
        current_section = None
        sources.append({k: doc.get(k) for k in ("id", "url", "title", "sha256", "format", "role", "warnings")})
        for block in doc["blocks"]:
            text = block["text"]
            ref = evidence_for(record, block, text)
            heading = block.get("locator", "")
            is_heading = bool(block.get("heading_level"))
            # Application structure comes from actual template headings/prompts.
            template = doc.get("role") == "template"
            table_prompt = template and block.get("column") == 1 and len(text) < 180 and bool(re.search(r"[A-Za-z]", text))
            if template and (is_heading or table_prompt or re.match(r"^\d+(?:\.\d+)*[.)]?\s+\S", text) and len(text) < 200 or text.endswith("?") and len(text) < 500):
                if len(text) > 2:
                    current_section = {"id": stable_id(doc["url"], heading, text), "heading": text,
                        "required": None, "evidence": ref, "max_words": None, "max_characters": None}
                    sections.append(current_section)
            if template and current_section:
                limit = re.search(r"(?i)(?:maximum|maximaal|max\.?)\s*(\d{1,5})\s*(words|woorden|characters|tekens)", text)
                if limit:
                    current_section["max_words" if limit[2].casefold() in {"words", "woorden"} else "max_characters"] = int(limit[1])
                    current_section["limit_evidence"] = ref
            if is_heading:
                continue
            for clause in re.split(r"(?<=[.!;])\s+(?=[A-ZÀ-Ý])", text):
                if not clause.strip() or len(clause) > 4000:
                    continue
                category = classify(clause, heading)
                if category is None:
                    continue
                key = (doc["url"], category, clause)
                if key in seen:
                    continue
                seen.add(key)
                proof = evidence_for(record, block, clause)
                single = {**record, "blocks": [{**block, "text": clause}]}
                basics = basic_requirements(single)
                rules = [{"kind": "atomic", "field": b["field"], "operator": b["operator"], "expected": b["expected"], "children": []} for b in basics]
                alternative = country_alternatives(clause)
                if alternative:
                    rules = [alternative]
                uncertain = bool(re.search(r"(?i)unless|except|tenzij|depending on|afhankelijk|\bif\b|\bindien\b|\bals\b|\bmits\b|voor zover|otherwise provided", clause))
                # An annex/guidance default can be overridden by a specific call.
                inherited = doc.get("role") in {"annex", "guidance"}
                rule = rules[0] if len(rules) == 1 else {"kind": "all", "children": rules} if rules else None
                if uncertain or inherited or category not in {"eligibility", "financial"}:
                    rule = None
                rid = stable_id(doc["url"], heading, category, clause)
                req = {"id": rid, "category": category, "label": clause[:180], "text": clause,
                       "rule": validate_rule(rule) if rule else None, "evidence": proof,
                       "scope": "call" if doc.get("role") in {"primary", "call"} else doc.get("role", "guidance"),
                       "conditional": uncertain, "review_required": not bool(rule), "interpretation": "basic"}
                requirements.append(req)
                if category == "attachment":
                    required = None if uncertain else False if re.search(r"(?i)optional|optioneel|may attach", clause) else True if re.search(r"(?i)must|shall|required|moet|vereist|verplicht", clause) else None
                    attachments.append({"id": rid, "title": clause[:180], "required": required, "conditional": uncertain, "evidence": proof})
                elif category == "assessment":
                    assessment.append({"id": rid, "criterion": clause, "evidence": proof})
                if category == "financial":
                    # Scalars are sourced observations, never a computed grant award.
                    money = re.search(r"(?i)(?:EUR|€)\s*" + AMOUNT_PATTERN, clause)
                    rate = re.search(r"\b(\d{1,2}(?:[.,]\d{1,2})?|100)\s*%", clause)
                    scope = "programme" if re.search(r"(?i)programme budget|call budget|subsidieplafond|totale budget", clause) else "project" if re.search(r"(?i)per project|per applicant|per aanvraag", clause) else "unspecified"
                    financial.append({"id": rid, "text": clause, "scope": scope,
                        "amount_cents": money_cents(money[1]) if money and not re.search(r"(?i)million|miljoen|\bUSD\b", clause) else None,
                        "currency": "EUR" if money else None, "rate_percent": rate[1].replace(",", ".") if rate else None, "evidence": proof})
    if model_rules:
        for rule in model_rules:
            expr = validate_rule({"kind": "atomic", "field": rule["field"], "operator": rule["operator"], "expected": rule["expected"], "children": []})
            proof = rule["evidence"]
            source = next((d for d in bundle if any(b["id"] == proof["block_id"] for b in d["blocks"])), None)
            block = next((b for b in source["blocks"] if b["id"] == proof["block_id"]), None) if source else None
            if not block or proof["quote"] not in block["text"]:
                raise ValueError("Model condition is not supported by the collected sources")
            inherited = source.get("role") in {"annex", "guidance"}
            if inherited or re.search(r"(?i)unless|except|tenzij|\bif\b|\bindien\b|\bals\b|\bmits\b|depending on|afhankelijk", block["text"]) or (
                    re.search(r"(?i)\bor\b|\bof\b", block["text"]) and expr["operator"] != "in"):
                expr = None
            requirements.append({"id": stable_id(proof["url"], rule["field"], proof["locator"], proof["quote"]), "category": "eligibility",
                "label": rule["label"], "text": proof["quote"], "rule": expr, "evidence": proof, "scope": source.get("role", "call"),
                "conditional": expr is None, "review_required": True, "interpretation": "model_proposed"})
    # A template may have no recognised headings; retain it as a source and issue.
    warnings = list(failures or [])
    for source in sources:
        warnings.extend({"url": source["url"], "error": warning} for warning in source.get("warnings") or [])
    conflicts = []
    atoms = {}
    for req in requirements:
        rule = req["rule"]
        if rule and rule["kind"] == "atomic":
            key = (rule["field"], rule["operator"])
            for other in atoms.get(key, []):
                if other["rule"]["expected"] != rule["expected"]:
                    conflicts.append({"field": rule["field"], "requirement_ids": [other["id"], req["id"]],
                                      "message": "Official sources give different conditions; applicability requires review."})
            atoms.setdefault(key, []).append(req)
    unique = {r["id"]: r for r in requirements}
    spec = {"opportunity_id": record["id"], "title": record["title"], "extractor_version": SPEC_VERSION,
        "processing_mode": "Model-assisted interpretation" if model_call else "Basic interpretation",
        "model_call": model_call, "requirements": list(unique.values()), "application_sections": list({s["id"]: s for s in sections}.values()),
        "attachments": attachments, "assessment_criteria": assessment, "financial_observations": financial,
        "templates": [{"url": d["url"], "title": d["title"], "format": d["format"], "sha256": d["sha256"],
                       "tables": d.get("tables", [])} for d in bundle if d.get("role") == "template"],
        "sources": sources, "conflicts": conflicts, "warnings": warnings,
        "coverage": "partial" if warnings or not requirements else "sources_read",
        "eligibility_review_required": True}
    spec["version"] = stable_id(json.dumps({k: v for k, v in spec.items() if k != "model_call"}, sort_keys=True, ensure_ascii=False))
    spec["created_at"] = now()
    return spec


def evaluate_specification(spec, workspace):
    conflicting = {rid for c in spec["conflicts"] for rid in c["requirement_ids"]}
    result = []
    for req in spec["requirements"]:
        outcome = "SOURCE_CONFLICT" if req["id"] in conflicting else evaluate_rule(req["rule"], workspace, req["evidence"]) if req["rule"] else "MANUAL_REVIEW"
        result.append({**req, "outcome": outcome})
    return result


class SpecificationStore:
    def __init__(self, store):
        self.store = store
        with store.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS grant_specifications (
                    opportunity_id TEXT NOT NULL, version TEXT NOT NULL, created_at TEXT NOT NULL,
                    state TEXT NOT NULL, PRIMARY KEY(opportunity_id, version));
                CREATE TABLE IF NOT EXISTS grant_specification_heads (
                    opportunity_id TEXT PRIMARY KEY, version TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS grant_specification_seen (
                    workspace_id TEXT NOT NULL, opportunity_id TEXT NOT NULL, version TEXT NOT NULL,
                    PRIMARY KEY(workspace_id, opportunity_id));
            """)

    def latest(self, rid):
        with self.store.connect() as conn:
            row = conn.execute("SELECT s.state FROM grant_specifications s JOIN grant_specification_heads h ON h.opportunity_id=s.opportunity_id AND h.version=s.version WHERE h.opportunity_id=?", (rid,)).fetchone()
        return json.loads(row[0]) if row else None

    def versions(self, rid):
        with self.store.connect() as conn:
            return [{"version": r[0], "created_at": r[1]} for r in conn.execute("SELECT version, created_at FROM grant_specifications WHERE opportunity_id=? ORDER BY created_at DESC", (rid,))]

    def get(self, rid, version):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM grant_specifications WHERE opportunity_id=? AND version=?", (rid, version)).fetchone()
        if not row:
            raise KeyError("Specification version not found")
        return json.loads(row[0])

    def seen(self, wid, rid):
        with self.store.connect() as conn:
            row = conn.execute("SELECT version FROM grant_specification_seen WHERE workspace_id=? AND opportunity_id=?", (wid, rid)).fetchone()
        return row[0] if row else None

    def mark_seen(self, wid, rid, version):
        self.store.load(wid)
        latest = self.latest(rid)
        if not latest or latest["version"] != version:
            raise ValueError("Grant conditions changed again. Reload before marking changes read.")
        with self.store.connect() as conn:
            conn.execute("INSERT INTO grant_specification_seen VALUES (?, ?, ?) ON CONFLICT(workspace_id, opportunity_id) DO UPDATE SET version=excluded.version", (wid, rid, version))

    def save(self, spec):
        previous = self.latest(spec["opportunity_id"])
        previous_requirements = {r["id"]: r for r in previous["requirements"]} if previous else {}
        current = {r["id"]: r for r in spec["requirements"]}
        def meaning(req):
            return {k: v for k, v in req.items() if k != "evidence"} | {
                "evidence": {k: v for k, v in req.get("evidence", {}).items() if k not in {"snapshot_hash", "block_id"}}}
        changes = {"previous_version": previous["version"] if previous else None,
            "added": sorted(set(current) - set(previous_requirements)), "removed": sorted(set(previous_requirements) - set(current)),
            "changed": [rid for rid in set(current) & set(previous_requirements) if meaning(current[rid]) != meaning(previous_requirements[rid])],
            "application_changed": bool(previous and (
                [(s["heading"], s.get("max_words"), s.get("max_characters")) for s in previous["application_sections"]] !=
                [(s["heading"], s.get("max_words"), s.get("max_characters")) for s in spec["application_sections"]]))}
        spec = {**spec, "changes": changes}
        with self.store.connect() as conn:
            conn.execute("INSERT OR IGNORE INTO grant_specifications VALUES (?, ?, ?, ?)", (spec["opportunity_id"], spec["version"], spec["created_at"], json.dumps(spec)))
            conn.execute("INSERT INTO grant_specification_heads VALUES (?, ?) ON CONFLICT(opportunity_id) DO UPDATE SET version=excluded.version", (spec["opportunity_id"], spec["version"]))
        return self.latest(spec["opportunity_id"])
