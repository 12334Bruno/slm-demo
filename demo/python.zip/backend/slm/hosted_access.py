"""Private browser workspaces for the hosted prototype, served on one origin."""
from contextvars import ContextVar
import hashlib
import os
import re
import secrets
from urllib.parse import urlsplit
from fastapi.responses import JSONResponse

current_owner = ContextVar("slm_browser_owner", default=None)


def hosted():
    return os.getenv("SLM_HOSTED") == "1"


def require_owner(conn, wid):
    owner = current_owner.get()
    if owner is not None and not conn.execute("SELECT 1 FROM workspace_owners WHERE workspace_id=? AND owner=?", (wid, owner)).fetchone():
        raise KeyError("Workspace not found")


def register(app, store):
    with store.connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS workspace_owners (workspace_id TEXT PRIMARY KEY, owner TEXT NOT NULL)")

    @app.middleware("http")
    async def browser_workspaces(request, call_next):
        if not hosted() or not request.url.path.startswith("/api/"):
            return await call_next(request)
        path = request.url.path
        if path.startswith("/api/analysis/"):
            return JSONResponse(status_code=404, content={"detail": "Not found"})
        public_url = os.getenv("SLM_PUBLIC_URL") or os.getenv("RENDER_EXTERNAL_URL")
        expected = urlsplit(public_url) if public_url else request.url
        origin = request.headers.get("origin")
        if request.method in {"POST", "PATCH", "PUT", "DELETE"} and origin:
            source = urlsplit(origin)
            if (source.scheme, source.netloc) != (expected.scheme, expected.netloc):
                return JSONResponse(status_code=403, content={"detail": "Use this application's own page to save changes."})
        secret = request.cookies.get("slm_visitor", "")
        fresh = not re.fullmatch(r"[A-Za-z0-9_-]{43}", secret)
        if fresh:
            secret = secrets.token_urlsafe(32)
        owner = hashlib.sha256(secret.encode()).hexdigest()
        marker = current_owner.set(owner)
        try:
            match = re.match(r"/api/workspaces/([^/]+)", path)
            wid = match[1] if match else request.query_params.get("workspace_id")
            if wid:
                with store.connect() as conn:
                    try:
                        require_owner(conn, wid)
                    except KeyError:
                        return JSONResponse(status_code=404, content={"detail": "Workspace not found"})
            response = await call_next(request)
            response.headers["Cache-Control"] = "no-store"
            if fresh:
                response.set_cookie("slm_visitor", secret, httponly=True, samesite="lax",
                    secure=os.getenv("SLM_COOKIE_SECURE", "1") == "1", max_age=60 * 60 * 24 * 30)
            return response
        finally:
            current_owner.reset(marker)
