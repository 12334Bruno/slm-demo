from uuid import uuid4
from .config import FORM, MAIN_GRANT, now
from .profiles import fact_value
from .budget import euro

SECTION_HINTS = {
    "route_to_market": "describe the intended route from study to development and market introduction",
    "novelty": "explain novelty with comparison evidence; no patent or certification is assumed",
    "bottlenecks": "describe technical and economic uncertainties",
    "market_perspective": "supply evidence for market size and customer needs; do not present hypotheses as research",
    "economic_analysis": "explain costs, revenues and economic assumptions with evidence",
    "intellectual_property": "describe any IP searches or strategy; do not invent patent rights",
    "market_approach": "describe the planned market approach",
    "feasibility_questions": "state concrete technical and economic questions",
    "activities": "describe planned work and how each activity answers a feasibility question",
    "third_party_roles": "identify suppliers and their proposed tasks and costs",
    "team": "describe team roles and provide supporting CVs where required",
    "technical_execution": "explain access to expertise, facilities and equipment",
    "planning": "provide a work schedule and explain execution within the budget",
    "results_and_decision": "describe intended outputs and who will make the later development decision",
}

# Conservative, explicit dependencies for narrative sections that mention cost
# mix, planning, team capacity or financing outside their primary mapped facts.
DEPENDENCIES = {
    "activities": ["budget", "project.primary_activity", "project.start_date", "project.end_date"],
    "planning": ["budget", "funding", "project.start_date", "project.end_date", "company.fte"],
    "economic_analysis": ["budget", "funding"],
    "third_party_roles": ["budget", "project.independent_sme_participant_count"],
    "team": ["company.fte", "budget"],
    "technical_execution": ["company.fte", "budget"],
    "budget_explanation": ["budget", "company.vat_recoverable"],
    "financing_explanation": ["budget", "funding", "company.vat_recoverable", "finance.external_funding_status"],
    "need_for_feasibility": ["project.prepares_later_development", "project.primary_activity"],
    "results_and_decision": ["project.start_date", "project.end_date", "project.prepares_later_development"],
    "provincial_relevance": ["company.city", "company.province"],
    "policy_framework_category": ["project.framework_category", "project.framework_alignment_notes"],
}


def generate_basic_sections(ws, evaluation):
    budget = evaluation["budget"]
    sections = []
    for spec in FORM["sections"]:
        sid = spec["id"]
        paths = list(dict.fromkeys(spec["fact_paths"] + [f"narrative.{sid}"]))
        dependencies = paths + ["context"] + DEPENDENCIES.get(sid, [])
        pieces, missing = [], []

        def take(path, label=None):
            if path not in paths:
                paths.append(path)
                dependencies.append(path)
            value = fact_value(ws, path, confirmed_only=True)
            if value is None:
                missing.append(path)
                pieces.append(f"[NEEDS INPUT: confirm {label or path}]")
            else:
                pieces.append(f"{label or path}: {value}.")
            return value

        narrative = fact_value(ws, f"narrative.{sid}", True)
        if narrative:
            pieces.append(narrative)
        elif sid == "innovation_description":
            take("project.description", "Proposed concept")
        elif sid == "company":
            for path, label in [("company.name", "Company"), ("company.city", "Registered city"),
                                ("company.province", "Province"), ("company.fte", "FTE")]:
                take(path, label)
            pieces.append("[NEEDS INPUT: describe relevant company experience and attach evidence where required]")
            missing.append("company experience")
        elif sid == "partners":
            take("project.independent_sme_participant_count", "Proposed independent SME participant count, including applicant")
            pieces.append("[NEEDS INPUT: explain partner independence and supplier roles; a paid supplier is not automatically a co-applicant]")
            missing.append("partner roles and independence")
        elif sid == "policy_framework":
            take("project.framework_alignment_notes", "Founder explanation for proposed policy / KIA alignment")
            pieces.append("Formal policy alignment and innovation risk still require human assessment.")
        elif sid == "policy_framework_category":
            take("project.framework_category", "Proposed KIA number and title")
            pieces.append("Formal policy alignment and innovation risk still require human assessment.")
        elif sid == "provincial_relevance":
            take("company.province", "Registered establishment province")
            pieces.append("[NEEDS INPUT: explain concrete benefits to Zuid-Holland with supporting evidence]")
            missing.append("provincial benefits evidence")
        elif sid == "need_for_feasibility":
            take("project.prepares_later_development", "Founder states study precedes a later development decision")
            pieces.append("[NEEDS INPUT: explain the investment decision and unresolved risks]")
            missing.append("decision and risks")
        elif sid == "previous_mit":
            take("company.previous_mit_five_years", "Previous MIT feasibility support in the last five calendar years")
        elif sid == "budget_explanation":
            dependencies.append("budget")
            for row in budget["rows"]:
                if row.get("confirmed") and row.get("state") != "conflict":
                    pieces.append(f"{row['id']} — {row['activity']}: {row['quantity']} {row['unit']} × {euro(row['rate_cents'])} = {euro(row['project_amount_cents'])}; proposed eligible {euro(row['eligible_amount_cents'])}; {row['activity_group']}; {row['cost_type']}.")
                else:
                    pieces.append(f"[NEEDS INPUT: confirm budget row {row['id']}]")
                    missing.append(f"budget row {row['id']}")
            if not budget["rows"]:
                pieces.append("[NEEDS INPUT: supply the project cost rows]")
                missing.append("budget")
            pieces.extend(budget["assumptions"])
        elif sid == "financing_explanation":
            dependencies.extend(["budget", "funding", "finance.external_funding_status"])
            for source in ws["funding_sources"]:
                if source["founder_confirmed"] and source.get("state") != "conflict":
                    pieces.append(f"{source['id']}: {source['kind']}, {euro(source['amount_cents'])}, {source['status']}. Founder declaration; commitment not legally authenticated. {source['note']}")
                else:
                    pieces.append(f"[NEEDS INPUT: confirm financing source {source['id']} and its status]")
                    missing.append(f"funding {source['id']}")
            pieces.append(f"Provisional requested grant: {euro(budget['requested_grant_cents'])}. Other financing required: {euro(budget['other_financing_required_cents'])}. Unconfirmed financing: {euro(budget['unconfirmed_financing_cents'])}.")
            if not ws["funding_sources"] or budget["unconfirmed_financing_cents"] != 0:
                pieces.append("[NEEDS INPUT: complete the financing plan and supply applicable commitment evidence]")
                missing.append("financing evidence")
        elif sid == "planning":
            take("project.start_date", "Planned start")
            take("project.end_date", "Planned finish")
            pieces.append(f"[NEEDS INPUT: {SECTION_HINTS[sid]}]")
            missing.append(f"narrative.{sid}")
        else:
            pieces.append(f"[NEEDS INPUT: {SECTION_HINTS.get(sid, 'complete this official section with evidence')}]")
            missing.append(f"narrative.{sid}")
        dependencies = list(dict.fromkeys(dependencies + paths))
        facts = [ws["facts"][p] for p in paths if p in ws["facts"] and ws["facts"][p]["state"] == "confirmed"]
        refs = [e for f in facts for e in f["evidence"]]
        if "budget" in dependencies:
            refs += [e for row in ws["budget_lines"] if row["confirmed"] for e in row["evidence"]]
        if "funding" in dependencies:
            refs += [e for s in ws["funding_sources"] if s["founder_confirmed"] for e in s["evidence"]]
        sections.append({"id": sid, "heading": spec["expected_heading"], "text": "\n\n".join(pieces),
                         "fact_ids": [f["id"] for f in facts], "evidence": refs, "dependencies": dependencies,
                         "missing_inputs": missing, "state": "generated", "user_edited": False,
                         "generated_for_profile_revision": ws["revision"], "grant_rule_version": next(g["rule_version"] for g in evaluation["grants"] if g["id"] == MAIN_GRANT)})
    return sections


def save_generated_draft(ws, evaluation, sections, mode="Template-assisted draft", regenerate=None, model_call=None, warnings=None):
    regenerate = set(regenerate or [])
    old = ws["draft"]
    if old:
        previous = {s["id"]: s for s in old["sections"]}
        sections = [previous[s["id"]] if s["id"] in previous and s["id"] not in regenerate else s for s in sections]
    ws["draft"] = {"id": old["id"] if old else uuid4().hex, "revision": old["revision"]+1 if old else 1,
                   "grant_id": MAIN_GRANT, "profile_revision": ws["revision"], "context": evaluation["label"],
                   "effective_datetime": evaluation["effective_datetime"], "rule_version": next(g["rule_version"] for g in evaluation["grants"] if g["id"] == MAIN_GRANT),
                   "generated_at": now(), "mode": mode, "model_call": model_call, "warnings": warnings or [],
                   "sections": sections, "stale": any(s["state"] == "stale" for s in sections)}
    return ws["draft"]
