"""Public catalogue storage; additive tables never replace workspace state."""
import hashlib
import json
import re
import sqlite3
import time
from uuid import uuid4
from .config import now


def identity(provider, external_id):
    return provider + "-" + hashlib.sha256(str(external_id).encode()).hexdigest()[:24]


class DiscoveryStore:
    def __init__(self, store):
        self.store = store
        with store.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS discovery_records (
                    id TEXT PRIMARY KEY, provider TEXT NOT NULL, external_id TEXT NOT NULL,
                    state TEXT NOT NULL, updated_at TEXT NOT NULL,
                    UNIQUE(provider, external_id));
                CREATE TABLE IF NOT EXISTS discovery_snapshots (
                    id TEXT PRIMARY KEY, opportunity_id TEXT NOT NULL, url TEXT NOT NULL,
                    sha256 TEXT NOT NULL, fetched_at TEXT NOT NULL, body TEXT NOT NULL,
                    UNIQUE(opportunity_id, url, sha256));
                CREATE TABLE IF NOT EXISTS discovery_runs (
                    provider TEXT PRIMARY KEY, state TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS discovery_saved (
                    workspace_id TEXT NOT NULL, opportunity_id TEXT NOT NULL, saved_at TEXT NOT NULL,
                    PRIMARY KEY(workspace_id, opportunity_id));
                CREATE TABLE IF NOT EXISTS discovery_match_runs (
                    workspace_id TEXT PRIMARY KEY, signature TEXT NOT NULL, state TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS discovery_provider ON discovery_records(provider);
                CREATE TABLE IF NOT EXISTS discovery_scenarios (
                    id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, name TEXT NOT NULL,
                    changes TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS discovery_scenarios_workspace ON discovery_scenarios(workspace_id);
                CREATE TABLE IF NOT EXISTS discovery_comparisons (
                    key TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, state TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS discovery_relevance (
                    input_hash TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, opportunity_id TEXT NOT NULL,
                    state TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS semantic_candidates (
                    workspace_id TEXT PRIMARY KEY, signature TEXT NOT NULL, state TEXT NOT NULL);
            """)

            try:
                conn.execute("CREATE VIRTUAL TABLE IF NOT EXISTS discovery_search USING fts5(id UNINDEXED, title, description, tags, tokenize='unicode61')")
                conn.execute("""INSERT INTO discovery_search
                    SELECT id, json_extract(state, '$.title'), json_extract(state, '$.description'), json_extract(state, '$.tags')
                    FROM discovery_records WHERE id NOT IN (SELECT id FROM discovery_search)""")
                self.fts = True
            except sqlite3.OperationalError:
                self.fts = False

    def upsert(self, record):
        record = dict(record)
        record.setdefault("id", identity(record["provider"], record["external_id"]))
        previous = self.get(record["id"], missing_ok=True)
        if previous:
            # Retain hydrated detail when an unchanged index row is encountered.
            if previous.get("index_hash") == record.get("index_hash"):
                record = {**previous, **record}
                for key in ("blocks", "requirements", "documents", "detail_fetched_at", "detail_hash", "detail_error", "model_call", "model_requirements", "model_source_hash",
                            "analysis_error", "kind", "spec_version", "spec_extractor", "spec_status", "spec_review_required", "spec_error"):
                    if key in previous:
                        record[key] = previous[key]
            elif previous.get("detail_fetched_at"):
                record["previous_detail_at"] = previous["detail_fetched_at"]
        record["indexed_at"] = now()
        with self.store.connect() as conn:
            conn.execute("INSERT INTO discovery_records VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET state=excluded.state, updated_at=excluded.updated_at",
                         (record["id"], record["provider"], str(record["external_id"]), json.dumps(record), now()))
            if self.fts:
                conn.execute("DELETE FROM discovery_search WHERE id=?", (record["id"],))
                conn.execute("INSERT INTO discovery_search VALUES (?, ?, ?, ?)", (record["id"], record["title"], record.get("description", ""), " ".join(record.get("tags", []))))
        return record

    def update(self, rid, **changes):
        with self.store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT state FROM discovery_records WHERE id=?", (rid,)).fetchone()
            if row is None:
                raise KeyError("Opportunity not found")
            record = json.loads(row[0])
            record.update(changes)
            conn.execute("UPDATE discovery_records SET state=?, updated_at=? WHERE id=?", (json.dumps(record), now(), rid))
        return record

    def get(self, rid, missing_ok=False):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM discovery_records WHERE id=?", (rid,)).fetchone()
        if row:
            return json.loads(row[0])
        if not missing_ok:
            raise KeyError("Opportunity not found")

    def records(self):
        with self.store.connect() as conn:
            return [json.loads(r[0]) for r in conn.execute("SELECT state FROM discovery_records")]

    def snapshot(self, rid, url, body):
        digest = hashlib.sha256(body.encode()).hexdigest()
        sid = identity(rid, url + digest)
        with self.store.connect() as conn:
            conn.execute("INSERT OR IGNORE INTO discovery_snapshots VALUES (?, ?, ?, ?, ?, ?)",
                         (sid, rid, url, digest, now(), body))
        return sid

    def search(self, text):
        terms = re.findall(r"[\w-]{3,}", text, re.UNICODE)[:80]
        if not self.fts or not terms:
            return self.records()
        query = " OR ".join('"' + term.replace('"', '') + '"' for term in terms)
        with self.store.connect() as conn:
            return [json.loads(r[0]) for r in conn.execute(
                "SELECT r.state FROM discovery_records r JOIN discovery_search s ON s.id=r.id WHERE discovery_search MATCH ? ORDER BY bm25(discovery_search)",
                (query,))]

    def run(self, provider, **changes):
        with self.store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT state FROM discovery_runs WHERE provider=?", (provider,)).fetchone()
            state = json.loads(row[0]) if row else {"provider": provider, "cursor": 0, "pages": 0, "records": 0}
            state.update(changes)
            conn.execute("INSERT INTO discovery_runs VALUES (?, ?) ON CONFLICT(provider) DO UPDATE SET state=excluded.state",
                         (provider, json.dumps(state)))
        return state

    def claim(self, provider, owner, seconds=120):
        with self.store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT state FROM discovery_runs WHERE provider=?", (provider,)).fetchone()
            state = json.loads(row[0]) if row else {"provider": provider, "cursor": 0, "pages": 0, "records": 0}
            if state.get("lease_until", 0) > time.time() and state.get("lease_owner") != owner:
                return False
            state.update(lease_owner=owner, lease_until=time.time() + seconds)
            conn.execute("INSERT INTO discovery_runs VALUES (?, ?) ON CONFLICT(provider) DO UPDATE SET state=excluded.state",
                         (provider, json.dumps(state)))
        return True

    def runs(self):
        with self.store.connect() as conn:
            return [json.loads(r[0]) for r in conn.execute("SELECT state FROM discovery_runs")]

    def saved(self, wid):
        with self.store.connect() as conn:
            return [r[0] for r in conn.execute("SELECT opportunity_id FROM discovery_saved WHERE workspace_id=? ORDER BY saved_at DESC", (wid,))]

    def save(self, wid, rid, enabled):
        self.store.load(wid)
        self.get(rid)
        with self.store.connect() as conn:
            if enabled:
                conn.execute("INSERT OR IGNORE INTO discovery_saved VALUES (?, ?, ?)", (wid, rid, now()))
            else:
                conn.execute("DELETE FROM discovery_saved WHERE workspace_id=? AND opportunity_id=?", (wid, rid))
        return self.saved(wid)

    def copy_saved(self, source, target):
        with self.store.connect() as conn:
            conn.execute("INSERT OR IGNORE INTO discovery_saved SELECT ?, opportunity_id, saved_at FROM discovery_saved WHERE workspace_id=?",
                         (target, source))

    def last_matched(self, wid):
        """When grants were last matched for this company, or None."""
        with self.store.connect() as conn:
            row = conn.execute("SELECT json_extract(state, '$.matched_at') FROM discovery_match_runs WHERE workspace_id=?", (wid,)).fetchone()
        return row[0] if row else None

    def latest_matches(self, wid):
        """The last saved matches of a company, whatever profile they were made for; None before the first matching."""
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM discovery_match_runs WHERE workspace_id=?", (wid,)).fetchone()
        return json.loads(row[0]) if row else None

    def cached_matches(self, wid, signature):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM discovery_match_runs WHERE workspace_id=? AND signature=?", (wid, signature)).fetchone()
        return json.loads(row[0]) if row else None

    def save_matches(self, wid, signature, result):
        with self.store.connect() as conn:
            conn.execute("INSERT INTO discovery_match_runs VALUES (?, ?, ?) ON CONFLICT(workspace_id) DO UPDATE SET signature=excluded.signature, state=excluded.state",
                         (wid, signature, json.dumps(result)))

    def catalogue_signature(self):
        """Cheap, exact fingerprint of the catalogue: every write stamps the record's update time."""
        with self.store.connect() as conn:
            rows = conn.execute("SELECT id, updated_at FROM discovery_records ORDER BY id").fetchall()
        return hashlib.sha256(json.dumps(rows).encode()).hexdigest()

    def spec_heads(self):
        with self.store.connect() as conn:
            try:
                return dict(conn.execute("SELECT opportunity_id, version FROM grant_specification_heads ORDER BY opportunity_id").fetchall())
            except sqlite3.OperationalError:
                return {}

    def scenarios(self, wid):
        with self.store.connect() as conn:
            rows = conn.execute("SELECT id, name, changes, created_at FROM discovery_scenarios WHERE workspace_id=? ORDER BY created_at, rowid", (wid,)).fetchall()
        return [{"id": r[0], "name": r[1], "changes": json.loads(r[2]), "created_at": r[3]} for r in rows]

    def scenario(self, wid, sid):
        found = next((s for s in self.scenarios(wid) if s["id"] == sid), None)
        if found is None:
            raise KeyError("Scenario not found")
        return found

    def save_scenario(self, wid, name, changes, limit=20):
        self.store.load(wid)
        with self.store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            if conn.execute("SELECT COUNT(*) FROM discovery_scenarios WHERE workspace_id=?", (wid,)).fetchone()[0] >= limit:
                raise ValueError(f"At most {limit} scenarios can be saved; delete one first")
            sid = uuid4().hex
            conn.execute("INSERT INTO discovery_scenarios VALUES (?, ?, ?, ?, ?)", (sid, wid, name, json.dumps(changes), now()))
        return self.scenario(wid, sid)

    def delete_scenario(self, wid, sid):
        self.scenario(wid, sid)
        with self.store.connect() as conn:
            conn.execute("DELETE FROM discovery_scenarios WHERE workspace_id=? AND id=?", (wid, sid))

    def cached_comparison(self, wid, key):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM discovery_comparisons WHERE workspace_id=? AND key=?", (wid, key)).fetchone()
        return json.loads(row[0]) if row else None

    def save_comparison(self, wid, key, result, keep=30):
        with self.store.connect() as conn:
            conn.execute("INSERT OR REPLACE INTO discovery_comparisons VALUES (?, ?, ?, ?)", (key, wid, json.dumps(result), now()))
            conn.execute("DELETE FROM discovery_comparisons WHERE workspace_id=? AND key NOT IN ("
                         "SELECT key FROM discovery_comparisons WHERE workspace_id=? ORDER BY created_at DESC, rowid DESC LIMIT ?)", (wid, wid, keep))

    def cached_relevance(self, wid, input_hash):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM discovery_relevance WHERE workspace_id=? AND input_hash=?", (wid, input_hash)).fetchone()
        return json.loads(row[0]) if row else None

    def relevance_for_workspace(self, wid):
        with self.store.connect() as conn:
            rows = conn.execute("SELECT state FROM discovery_relevance WHERE workspace_id=? ORDER BY created_at DESC", (wid,)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def save_relevance(self, wid, rid, input_hash, result, *, previous_hash=None):
        with self.store.connect() as conn:
            insert = "INSERT OR IGNORE" if previous_hash else "INSERT OR REPLACE"
            conn.execute(insert + " INTO discovery_relevance VALUES (?, ?, ?, ?, ?)", (input_hash, wid, rid, json.dumps(result), now()))
            if previous_hash and previous_hash != input_hash:
                conn.execute("DELETE FROM discovery_relevance WHERE workspace_id=? AND opportunity_id=? AND input_hash=?",
                             (wid, rid, previous_hash))

    def reset_workspace(self, wid):
        with self.store.connect() as conn:
            conn.execute("DELETE FROM discovery_saved WHERE workspace_id=?", (wid,))
            conn.execute("DELETE FROM discovery_match_runs WHERE workspace_id=?", (wid,))
            for table in ("discovery_scenarios", "discovery_comparisons", "discovery_relevance", "semantic_candidates"):
                conn.execute("DELETE FROM " + table + " WHERE workspace_id=?", (wid,))

    def clear(self):
        with self.store.connect() as conn:
            for table in ("discovery_match_runs", "discovery_comparisons", "discovery_relevance", "semantic_candidates", "discovery_snapshots", "discovery_records", "discovery_runs"):
                conn.execute("DELETE FROM " + table)
            if self.fts:
                conn.execute("DELETE FROM discovery_search")
