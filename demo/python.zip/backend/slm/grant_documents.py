"""Collect actual official call documents/templates and retain their bytes."""
import hashlib
import json
import re
import zipfile
from io import BytesIO
from urllib.parse import urlparse, urljoin, unquote
from xml.etree import ElementTree as ET
from bs4 import BeautifulSoup
from docx import Document
from pypdf import PdfReader
from .config import now
from .official_sources import official_url, canonical_url, funding_page
from .grant_providers import html_blocks

MAX_DOCUMENTS = 8
MAX_TOTAL_BYTES = 24_000_000
MAX_PAGES = 120


def role(title, url):
    text = (title + " " + unquote(urlparse(url).path).replace("_", " ")).casefold()
    if re.search(r"template|application.form|aanvraagformulier|projectplan|\bformat\b|begroting|budget.*table", text):
        return "template"
    if re.search(r"annex|bijlage|algemene subsidieregeling|wijziging|amendment", text):
        return "annex"
    if re.search(r"call.document|call.fiche|oproep|regeling|voorwaarden", text):
        return "call"
    return "guidance"


def parse_public_document(data, url, title="", content_type=""):
    suffix = urlparse(url).path.casefold()
    if suffix.endswith(".pdf") and not data.startswith(b"%PDF"):
        raise ValueError("Published PDF returned a different or unreadable format")
    if suffix.endswith((".docx", ".xlsx")) and not data.startswith(b"PK"):
        raise ValueError("Published office template returned a different or unreadable format")
    digest = hashlib.sha256(data).hexdigest()
    prefix = "doc-" + digest[:14]
    blocks, tables, links, warnings = [], [], [], []
    kind = "html"

    def add(text, locator, **attributes):
        text = " ".join(str(text).split())
        if text:
            if len(text) > 18000 and "A long source block was truncated; remaining text requires review." not in warnings:
                warnings.append("A long source block was truncated; remaining text requires review.")
            blocks.append({"id": prefix + "-" + str(len(blocks)), "text": text[:18000], "locator": locator,
                           "source_url": url, "snapshot_hash": digest, **attributes})

    if data.startswith(b"%PDF"):
        kind = "pdf"
        reader = PdfReader(BytesIO(data))
        for number, page in enumerate(reader.pages[:MAX_PAGES], 1):
            add(page.extract_text() or "", "PDF page " + str(number))
        if len(reader.pages) > MAX_PAGES:
            warnings.append("Only the first " + str(MAX_PAGES) + " PDF pages were read; remaining pages require review.")
        title = title or str(reader.metadata.title if reader.metadata and reader.metadata.title else urlparse(url).path.rsplit("/", 1)[-1])
    elif data.startswith(b"PK"):
        with zipfile.ZipFile(BytesIO(data)) as archive:
            if sum(i.file_size for i in archive.infolist()) > 40_000_000:
                raise ValueError("Expanded official document exceeds 40 MB")
            names = set(archive.namelist())
            if "word/document.xml" in names:
                kind = "docx"
                doc = Document(BytesIO(data))
                from docx.oxml.ns import qn
                from docx.text.paragraph import Paragraph
                from docx.table import Table
                paragraph, table_number = 0, 0
                for element in doc.element.body:
                    if element.tag == qn("w:p"):
                        p = Paragraph(element, doc)
                        paragraph += 1
                        style = p.style.name if p.style else ""
                        heading = re.search(r"(?i)heading\s*(\d)|kop\s*(\d)", style)
                        bold = bool(p.runs) and all(r.bold for r in p.runs if r.text.strip())
                        add(p.text, "DOCX paragraph " + str(paragraph),
                            heading_level=int(next(v for v in heading.groups() if v)) if heading else (3 if bold and len(p.text) < 180 else None),
                            style=style)
                    elif element.tag == qn("w:tbl"):
                        table_number += 1
                        t = Table(element, doc)
                        cells = []
                        for ri, row in enumerate(t.rows[:100], 1):
                            row_values = []
                            for ci, cell in enumerate(row.cells[:25], 1):
                                row_values.append(cell.text)
                                add(cell.text, f"DOCX table {table_number}, row {ri}, cell {ci}", table=table_number, row=ri, column=ci)
                            cells.append(row_values)
                        tables.append({"name": "Table " + str(table_number), "rows": cells})
            elif "xl/workbook.xml" in names:
                kind = "xlsx"
                ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
                strings = []
                if "xl/sharedStrings.xml" in names:
                    strings = ["".join(n.itertext()) for n in ET.fromstring(archive.read("xl/sharedStrings.xml")).findall("m:si", ns)]
                for sheet_path in sorted(n for n in names if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n))[:20]:
                    sheet = ET.fromstring(archive.read(sheet_path))
                    sheet_name = sheet_path.rsplit("/", 1)[-1]
                    rows = []
                    for row in sheet.findall("m:sheetData/m:row", ns)[:100]:
                        values = []
                        for cell in row.findall("m:c", ns)[:25]:
                            v = cell.find("m:v", ns)
                            text = v.text if v is not None else "".join(cell.find("m:is", ns).itertext()) if cell.find("m:is", ns) is not None else ""
                            if cell.get("t") == "s" and text.isdigit():
                                text = strings[int(text)]
                            # Formula results are source cells, never recalculated grant amounts.
                            values.append(text)
                            add(text, "XLSX " + sheet_name + ", cell " + cell.get("r", ""), sheet=sheet_name, cell=cell.get("r", ""))
                        rows.append(values)
                    tables.append({"name": sheet_name, "rows": rows})
            else:
                raise ValueError("Official ZIP is not a supported DOCX/XLSX document")
    else:
        text = data.decode("utf-8-sig", errors="replace")
        if "\x00" in text:
            raise ValueError("Official source is unreadable binary data")
        parsed, linked = html_blocks(text)
        soup = BeautifulSoup(text, "html.parser")
        title = title or (soup.find("h1").get_text(" ", strip=True) if soup.find("h1") else "")
        if parsed:
            for block in parsed:
                add(block["text"], block["locator"], **({"heading_level": block["heading_level"]} if block.get("heading_level") else {}))
        else:
            kind = "text"
            for number, line in enumerate(text.splitlines(), 1):
                add(line, "Text line " + str(number))
        links = [{"title": d["title"], "url": urljoin(url, d["url"])} for d in linked]
    if not blocks:
        raise ValueError("No readable text; scanned documents require OCR or a text copy")
    if len(blocks) > 700:
        blocks = blocks[:700]
        warnings.append("Document block limit reached; remaining content requires review.")
    return {"id": prefix, "url": url, "title": title or urlparse(url).path.rsplit("/", 1)[-1],
            "sha256": digest, "format": kind, "blocks": blocks, "tables": tables,
            "links": links, "warnings": warnings, "size": len(data), "retrieved_at": now()}


class DocumentStore:
    def __init__(self, store):
        self.store = store
        with store.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS grant_documents (
                    url TEXT NOT NULL, sha256 TEXT NOT NULL, fetched_at TEXT NOT NULL,
                    state TEXT NOT NULL, bytes BLOB NOT NULL, PRIMARY KEY(url, sha256));
                CREATE TABLE IF NOT EXISTS official_source_candidates (
                    url TEXT PRIMARY KEY, discovered_from TEXT NOT NULL, state TEXT NOT NULL);
            """)

    def latest(self, url):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM grant_documents WHERE url=? ORDER BY fetched_at DESC LIMIT 1", (url,)).fetchone()
        return json.loads(row[0]) if row else None

    def save(self, doc, data):
        with self.store.connect() as conn:
            conn.execute("INSERT INTO grant_documents VALUES (?, ?, ?, ?, ?) ON CONFLICT(url, sha256) DO UPDATE SET fetched_at=excluded.fetched_at, state=excluded.state",
                         (doc["url"], doc["sha256"], doc["retrieved_at"], json.dumps(doc), data))

    def candidate(self, url, parent, status):
        with self.store.connect() as conn:
            conn.execute("INSERT INTO official_source_candidates VALUES (?, ?, ?) ON CONFLICT(url) DO UPDATE SET discovered_from=excluded.discovered_from, state=excluded.state",
                         (url, parent, status))

    def candidates(self):
        with self.store.connect() as conn:
            return [{"url": r[0], "discovered_from": r[1], "status": r[2]} for r in conn.execute("SELECT * FROM official_source_candidates")]

    def bytes_for(self, url, digest):
        with self.store.connect() as conn:
            row = conn.execute("SELECT bytes FROM grant_documents WHERE url=? AND sha256=?", (url, digest)).fetchone()
        if not row:
            raise KeyError("Official document version not found")
        return row[0]


def collect_bundle(record, client, documents, force=False):
    primary_blocks = [{**b, "source_url": b.get("source_url", record["url"]), "snapshot_hash": b.get("snapshot_hash", record.get("detail_hash") or record["index_hash"])}
                      for b in record.get("blocks", []) if not b.get("source_url") or b["source_url"] == record["url"]]
    primary = {"id": "primary", "url": record["url"], "title": record["title"], "sha256": record.get("detail_hash") or record["index_hash"],
               "format": "html", "role": "primary", "blocks": primary_blocks, "warnings": [], "tables": []}
    bundle, failures, queue, seen, size = [primary], [], list(record.get("documents", [])), set(), 0
    queue.sort(key=lambda d: {"call": 0, "annex": 1, "template": 2, "guidance": 3}[role(d.get("title", ""), d["url"])])
    while queue and len(bundle) <= MAX_DOCUMENTS:
        item = queue.pop(0)
        target = urljoin(record["url"], item["url"])
        if target in seen:
            continue
        seen.add(target)
        cached = None
        try:
            target = canonical_url(target)
            if funding_page(target) and target != canonical_url(record["url"]):
                documents.candidate(target, record["url"], "separate_opportunity")
                failures.append({"url": target, "error": "Linked funding opportunity kept separate; cross-programme conditions require review."})
                continue
            documents.candidate(target, record["url"], "registered_official_origin")
            cached = documents.latest(target)
            if cached and not force:
                doc = cached
            else:
                data, final = client.request("GET", target)
                if size + len(data) > MAX_TOTAL_BYTES:
                    raise ValueError("Call document bundle exceeds 24 MB; remaining sources require review")
                doc = parse_public_document(data, final, item.get("title", ""))
                documents.save(doc, data)
                # Keep the requested URL lookup even if an official redirect changed it.
                if final != target:
                    documents.save({**doc, "url": target}, data)
            if size + doc.get("size", 0) > MAX_TOTAL_BYTES:
                raise ValueError("Call document bundle exceeds 24 MB; remaining sources require review")
            size += doc.get("size", 0)
            bundle.append({**doc, "role": role(item.get("title", ""), target)})
            queue.extend(d for d in doc.get("links", []) if re.search(r"(?i)annex|bijlage|call.document|template|application.form|aanvraag|projectplan", d["title"]))
        except Exception as exc:
            if cached and size + cached.get("size", 0) <= MAX_TOTAL_BYTES:
                bundle.append({**cached, "role": role(item.get("title", ""), target),
                               "warnings": cached.get("warnings", []) + ["Refresh failed; using the previous successfully read document."]})
                size += cached.get("size", 0)
            documents.candidate(target, record["url"], "blocked_or_unavailable")
            failures.append({"url": target, "title": item.get("title", ""), "error": type(exc).__name__ + ": " + str(exc)[:200]})
    if queue:
        failures.append({"url": record["url"], "error": "Document count limit reached; additional referenced sources require review"})
    return bundle, failures
