"""Collect actual official call documents/templates and retain their bytes."""
import hashlib
import json
import re
import zipfile
from io import BytesIO
from urllib.parse import urlparse, urljoin, unquote
from xml.etree import ElementTree as ET
from bs4 import BeautifulSoup
from docx import Document
from pypdf import PdfReader
from .config import now
from .official_sources import official_url, canonical_url, funding_page
from .grant_providers import html_blocks

MAX_DOCUMENTS = 8
MAX_TOTAL_BYTES = 24_000_000
MAX_PAGES = 120
MAX_BLOCKS = 1500
PARSER_VERSION = "documents-2"


POST_AWARD_DOCUMENT = re.compile(
    r"(?i)eindrapport|final report|vaststelling|controleprotocol|bestuursverklaring|voortgangsrapport|progress report|"
    r"accountantsverklaring|declaration of honour|grant agreement|\bMGA\b|\bAGA\b|model.{0,12}agreement|"
    r"realisatie|betaalverzoek|payment request|wijzigingsformulier|change request")
REFERENCE_DOCUMENT = re.compile(
    r"(?i)online manual|programme guide|programmagids|evaluation form|evaluatieformulier|terms and conditions|privacy|"
    r"decision|regulation|verordening|framework programme|work programme|werkprogramma|faq|veelgestelde|"
    r"guidance:|what do i need to know|legal entity validation|financial regulation|staatscourant|wet- en regelgeving|"
    r"toelichting|explanatory|toetsingskader|assessment framework|verordening|agvv|toets geen financi")


def role(title, url):
    """How a linked file relates to applying: call text, template to fill in, general rules or reference only."""
    text = (title + " " + unquote(urlparse(url).path).replace("_", " ")).casefold()
    if POST_AWARD_DOCUMENT.search(text):
        return "post_award"
    if re.search(r"template|application.form|aanvraagformulier|projectplan|\bformat\b|begroting|budget.*table|detailed budget|modelformulier|invulformulier", text):
        return "template"
    if REFERENCE_DOCUMENT.search(text):
        return "guidance"
    if re.search(r"call.document|call.fiche|call.specific|oproep|openstellingsbesluit|subsidieregeling|regeling|voorwaarden|conditions", text) and not re.search(r"general annex|algemene", text):
        return "call"
    if re.search(r"annex|bijlage|algemene subsidieregeling|general annexes|wijziging|amendment", text):
        return "annex"
    return "guidance"


def parse_public_document(data, url, title="", content_type=""):
    suffix = urlparse(url).path.casefold()
    if suffix.endswith(".pdf") and not data.startswith(b"%PDF"):
        raise ValueError("Published PDF returned a different or unreadable format")
    if suffix.endswith((".docx", ".xlsx")) and not data.startswith(b"PK"):
        raise ValueError("Published office template returned a different or unreadable format")
    digest = hashlib.sha256(data).hexdigest()
    prefix = "doc-" + digest[:14]
    blocks, tables, links, warnings = [], [], [], []
    kind = "html"

    def add(text, locator, **attributes):
        text = " ".join(str(text).split())
        if text:
            if len(text) > 18000 and "A long source block was truncated; remaining text requires review." not in warnings:
                warnings.append("A long source block was truncated; remaining text requires review.")
            blocks.append({"id": prefix + "-" + str(len(blocks)), "text": text[:18000], "locator": locator,
                           "source_url": url, "snapshot_hash": digest, **attributes})

    if data.startswith(b"%PDF"):
        kind = "pdf"
        reader = PdfReader(BytesIO(data))
        from .pdf_structure import structured_paragraphs
        for text, number, attributes in structured_paragraphs(reader, MAX_PAGES):
            end = attributes.pop("end_page", None)
            add(text, "PDF page " + str(number) + (f"–{end}" if end else ""), page=number, **attributes)
        if len(reader.pages) > MAX_PAGES:
            warnings.append("Only the first " + str(MAX_PAGES) + " PDF pages were read; remaining pages require review.")
        title = title or str(reader.metadata.title if reader.metadata and reader.metadata.title else urlparse(url).path.rsplit("/", 1)[-1])
    elif data.startswith(b"PK"):
        with zipfile.ZipFile(BytesIO(data)) as archive:
            if sum(i.file_size for i in archive.infolist()) > 40_000_000:
                raise ValueError("Expanded official document exceeds 40 MB")
            names = set(archive.namelist())
            if "word/document.xml" in names:
                kind = "docx"
                doc = Document(BytesIO(data))
                from docx.oxml.ns import qn
                from docx.text.paragraph import Paragraph
                from docx.table import Table
                paragraph, table_number = 0, 0
                for element in doc.element.body:
                    if element.tag == qn("w:p"):
                        p = Paragraph(element, doc)
                        paragraph += 1
                        style = p.style.name if p.style else ""
                        heading = re.search(r"(?i)heading\s*(\d)|kop\s*(\d)", style)
                        bold = bool(p.runs) and all(r.bold for r in p.runs if r.text.strip())
                        add(p.text, "DOCX paragraph " + str(paragraph),
                            heading_level=int(next(v for v in heading.groups() if v)) if heading else (3 if bold and len(p.text) < 180 else None),
                            style=style)
                    elif element.tag == qn("w:tbl"):
                        table_number += 1
                        t = Table(element, doc)
                        cells = []
                        for ri, row in enumerate(t.rows[:100], 1):
                            row_values = []
                            for ci, cell in enumerate(row.cells[:25], 1):
                                row_values.append(cell.text)
                                add(cell.text, f"DOCX table {table_number}, row {ri}, cell {ci}", table=table_number, row=ri, column=ci)
                            cells.append(row_values)
                        tables.append({"name": "Table " + str(table_number), "rows": cells})
            elif "xl/workbook.xml" in names:
                kind = "xlsx"
                ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
                strings = []
                if "xl/sharedStrings.xml" in names:
                    strings = ["".join(n.itertext()) for n in ET.fromstring(archive.read("xl/sharedStrings.xml")).findall("m:si", ns)]
                for sheet_path in sorted(n for n in names if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n))[:20]:
                    sheet = ET.fromstring(archive.read(sheet_path))
                    sheet_name = sheet_path.rsplit("/", 1)[-1]
                    rows = []
                    for row in sheet.findall("m:sheetData/m:row", ns)[:100]:
                        values = []
                        for cell in row.findall("m:c", ns)[:25]:
                            v = cell.find("m:v", ns)
                            text = v.text if v is not None else "".join(cell.find("m:is", ns).itertext()) if cell.find("m:is", ns) is not None else ""
                            if cell.get("t") == "s" and text.isdigit():
                                text = strings[int(text)]
                            # Formula results are source cells, never recalculated grant amounts.
                            values.append(text)
                            add(text, "XLSX " + sheet_name + ", cell " + cell.get("r", ""), sheet=sheet_name, cell=cell.get("r", ""))
                        rows.append(values)
                    tables.append({"name": sheet_name, "rows": rows})
            else:
                raise ValueError("Official ZIP is not a supported DOCX/XLSX document")
    else:
        text = data.decode("utf-8-sig", errors="replace")
        if "\x00" in text:
            raise ValueError("Official source is unreadable binary data")
        parsed, linked = html_blocks(text)
        soup = BeautifulSoup(text, "html.parser")
        title = title or (soup.find("h1").get_text(" ", strip=True) if soup.find("h1") else "")
        if parsed:
            for block in parsed:
                add(block["text"], block["locator"], **({"heading_level": block["heading_level"]} if block.get("heading_level") else {}),
                    **({"list_item": True} if block.get("list_item") else {}))
        else:
            kind = "text"
            for number, line in enumerate(text.splitlines(), 1):
                add(line, "Text line " + str(number))
        links = [{"title": d["title"], "url": urljoin(url, d["url"])} for d in linked]
    if not blocks:
        raise ValueError("No readable text; scanned documents require OCR or a text copy")
    if len(blocks) > MAX_BLOCKS:
        blocks = blocks[:MAX_BLOCKS]
        warnings.append("Document block limit reached; remaining content requires review.")
    return {"id": prefix, "url": url, "title": title or urlparse(url).path.rsplit("/", 1)[-1],
            "sha256": digest, "format": kind, "parser": PARSER_VERSION, "blocks": blocks, "tables": tables,
            "links": links, "warnings": warnings, "size": len(data), "retrieved_at": now()}


class DocumentStore:
    def __init__(self, store):
        self.store = store
        with store.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS grant_documents (
                    url TEXT NOT NULL, sha256 TEXT NOT NULL, fetched_at TEXT NOT NULL,
                    state TEXT NOT NULL, bytes BLOB NOT NULL, PRIMARY KEY(url, sha256));
                CREATE TABLE IF NOT EXISTS official_source_candidates (
                    url TEXT PRIMARY KEY, discovered_from TEXT NOT NULL, state TEXT NOT NULL);
            """)

    def latest(self, url):
        with self.store.connect() as conn:
            row = conn.execute("SELECT state FROM grant_documents WHERE url=? ORDER BY fetched_at DESC LIMIT 1", (url,)).fetchone()
        return json.loads(row[0]) if row else None

    def save(self, doc, data):
        with self.store.connect() as conn:
            conn.execute("INSERT INTO grant_documents VALUES (?, ?, ?, ?, ?) ON CONFLICT(url, sha256) DO UPDATE SET fetched_at=excluded.fetched_at, state=excluded.state",
                         (doc["url"], doc["sha256"], doc["retrieved_at"], json.dumps(doc), data))

    def candidate(self, url, parent, status):
        with self.store.connect() as conn:
            conn.execute("INSERT INTO official_source_candidates VALUES (?, ?, ?) ON CONFLICT(url) DO UPDATE SET discovered_from=excluded.discovered_from, state=excluded.state",
                         (url, parent, status))

    def candidates(self):
        with self.store.connect() as conn:
            return [{"url": r[0], "discovered_from": r[1], "status": r[2]} for r in conn.execute("SELECT * FROM official_source_candidates")]

    def bytes_for(self, url, digest):
        with self.store.connect() as conn:
            row = conn.execute("SELECT bytes FROM grant_documents WHERE url=? AND sha256=?", (url, digest)).fetchone()
        if not row:
            raise KeyError("Official document version not found")
        return row[0]


def scheme_page(record_url, target):
    """A page below the scheme's own URL (conditions, attachments, procedure) belongs to the same scheme."""
    try:
        base, child = urlparse(canonical_url(record_url)), urlparse(canonical_url(target))
    except ValueError:
        return False  # Pages outside the registered official origins are never part of a scheme.
    root = base.path.rstrip("/") + "/"
    return base.hostname == child.hostname and child.path.startswith(root) and child.path.rstrip("/") + "/" != root


def scheme_page_role(title, url):
    text = (title + " " + unquote(urlparse(url).path)).casefold()
    if re.search(r"na-uw-aanvraag|na uw aanvraag|voortgang|vaststelling|realisatie|controle|correctie|wijzig|"
                 r"infographic|10-jaar|feiten-en-cijfers|actualiteiten|kalender|rekenvoorbeeld|resultaten|projecten", text):
        return "post_award"
    if re.search(r"veelgestelde|faq|wet-en-regelgeving|officiele-bekendmakingen|achtergrond", text):
        return "guidance"
    return "call"


def collect_bundle(record, client, documents, force=False, scheme_pages=(), extra_documents=()):
    primary_blocks = [{**b, "source_url": b.get("source_url", record["url"]), "snapshot_hash": b.get("snapshot_hash", record.get("detail_hash") or record["index_hash"])}
                      for b in record.get("blocks", []) if not b.get("source_url") or b["source_url"] == record["url"]]
    primary = {"id": "primary", "url": record["url"], "title": record["title"], "sha256": record.get("detail_hash") or record["index_hash"],
               "format": "html", "role": "primary", "blocks": primary_blocks, "warnings": [], "tables": []}
    bundle, failures, seen, size = [primary], [], set(), 0
    queue = [{**d, "role": role(d.get("title", ""), urljoin(record["url"], d["url"]))} for d in record.get("documents", [])]
    # Sub-pages of the same scheme in the catalogue (conditions, required attachments, procedure).
    queue += [{"title": page["title"], "url": page["url"], "role": scheme_page_role(page["title"], page["url"])} for page in scheme_pages]
    # Hand-checked official forms of focus schemes (see official_forms.py), with their stated role.
    queue += [dict(document) for document in extra_documents]
    order = {"call": 0, "template": 1, "annex": 2, "guidance": 3, "post_award": 4}
    queue.sort(key=lambda d: order[d["role"]])
    fetched = 0
    while queue:
        item = queue.pop(0)
        target = urljoin(record["url"], item["url"])
        if target in seen:
            continue
        seen.add(target)
        cached = None
        kind = item["role"]
        try:
            target = canonical_url(target)
            own_page = scheme_page(record["url"], target)
            if own_page:
                kind = scheme_page_role(item.get("title", ""), target) if kind in {"guidance", "call"} else kind
            elif funding_page(target) and target != canonical_url(record["url"]):
                documents.candidate(target, record["url"], "separate_opportunity")
                continue  # A different opportunity; its conditions are not this call's conditions.
            if kind in {"guidance", "post_award"}:
                # Reference material and later-stage forms stay as links; they do not create tasks.
                bundle.append({"id": "link-" + hashlib.sha256(target.encode()).hexdigest()[:12], "url": target,
                               "title": item.get("title") or urlparse(target).path.rsplit("/", 1)[-1], "sha256": None,
                               "format": "link", "role": kind, "blocks": [], "warnings": [], "tables": [], "fetched": False})
                continue
            if fetched >= MAX_DOCUMENTS:
                failures.append({"url": target, "title": item.get("title", ""), "error": "Document count limit reached; this source was not read"})
                continue
            documents.candidate(target, record["url"], "registered_official_origin")
            cached = documents.latest(target)
            if cached and not force and cached.get("parser") != PARSER_VERSION:
                try:
                    stored = documents.bytes_for(cached["url"], cached["sha256"])
                    cached = {**parse_public_document(stored, cached["url"], cached.get("title", "")), "retrieved_at": cached.get("retrieved_at")}
                    documents.save(cached, stored)
                except Exception:
                    pass  # Keep the previous reading; a refresh will try again.
            if cached and not force:
                doc = cached
            else:
                data, final = client.request("GET", target)
                if size + len(data) > MAX_TOTAL_BYTES:
                    raise ValueError("Call document bundle exceeds 24 MB; remaining sources require review")
                doc = parse_public_document(data, final, item.get("title", ""))
                documents.save(doc, data)
                # Keep the requested URL lookup even if an official redirect changed it.
                if final != target:
                    documents.save({**doc, "url": target}, data)
            if size + doc.get("size", 0) > MAX_TOTAL_BYTES:
                raise ValueError("Call document bundle exceeds 24 MB; remaining sources require review")
            size += doc.get("size", 0)
            fetched += 1
            bundle.append({**doc, "title": item.get("title") or doc.get("title", ""), "role": kind, "fetched": True})
            queue.extend({**d, "role": role(d["title"], urljoin(target, d["url"]))} for d in doc.get("links", [])
                         if re.search(r"(?i)annex|bijlage|call.document|template|application.form|aanvraag|projectplan|format|begroting", d["title"]))
        except Exception as exc:
            if cached and size + cached.get("size", 0) <= MAX_TOTAL_BYTES:
                bundle.append({**cached, "role": kind, "fetched": True,
                               "warnings": cached.get("warnings", []) + ["Refresh failed; using the previous successfully read document."]})
                size += cached.get("size", 0)
            documents.candidate(target, record["url"], "blocked_or_unavailable")
            failures.append({"url": target, "title": item.get("title", ""), "error": type(exc).__name__ + ": " + str(exc)[:200]})
    return bundle, failures
