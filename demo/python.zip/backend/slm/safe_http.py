"""SSRF-safe, bounded HTTP reads of public web pages and allowlisted registry APIs.

Guarantees, in order of application:
* only http/https on the standard ports, never credentials in the URL;
* no loopback, private, link-local, reserved, multicast or embedded-IPv4 tricks, checked on the
  literal address, after DNS resolution before every request, and again when the socket connects;
* redirects are followed one hop at a time with the same checks, and may only stay on the same
  host (adding or removing `www.` is the single allowed change);
* a per-response size limit, a total byte limit, a request count and a wall-clock deadline;
* content-type allowlist; no JavaScript is ever executed; proxies and environment settings are ignored.
"""
import ipaddress
import re
import socket
import time
import urllib.robotparser
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit, urlunsplit

import httpcore
import httpx

USER_AGENT = "SLM-company-research/1.0 (+bounded public-page reader; honours robots.txt)"
ROBOTS_TOKEN = "SLM-company-research"
BLOCKED_SUFFIXES = (".localhost", ".local", ".internal", ".lan", ".home", ".corp", ".intranet", ".onion", ".arpa")
REDIRECTS = {301, 302, 303, 307, 308}
NAT64 = (ipaddress.ip_network("64:ff9b::/96"), ipaddress.ip_network("64:ff9b:1::/48"))


class FetchError(Exception):
    """A failure whose message can be shown to the founder."""

    def __init__(self, message, code="fetch_failed", status=None):
        super().__init__(message)
        self.code, self.status = code, status


def is_public(ip):
    if ip.version == 6:
        if ip.ipv4_mapped:
            return is_public(ip.ipv4_mapped)
        if ip.sixtofour:
            return is_public(ip.sixtofour)
        if ip.teredo or any(ip in network for network in NAT64):
            return False
    return ip.is_global and not ip.is_multicast


def site_key(host):
    return host[4:] if host.startswith("www.") else host


def check_host(host):
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip is not None:
        if not is_public(ip):
            raise FetchError("That address points to a private or reserved network and cannot be read.", "unsafe_url")
        return
    labels = host.split(".")
    if (host == "localhost" or host.endswith(BLOCKED_SUFFIXES) or len(labels) < 2 or len(host) > 253
            or not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in labels)
            or not re.fullmatch(r"[a-z]{2,63}|xn--[a-z0-9-]{2,59}", labels[-1])):
        raise FetchError("That does not look like a public website address.", "unsafe_url")


def clean_url(url, https_only=False, allowed_hosts=None):
    """Validate and normalise a URL (fragment removed). Raises FetchError."""
    url = (url or "").strip()
    if not url or len(url) > 2048 or any(ord(c) < 33 or ord(c) == 127 for c in url) or "\\" in url:
        raise FetchError("Enter a web address such as https://example.com.", "unsafe_url")
    if "://" not in url:
        url = "https://" + url
    try:
        parts = urlsplit(url)
        port = parts.port
        raw_host = parts.hostname or ""
    except ValueError:
        raise FetchError("That web address is not valid.", "unsafe_url") from None
    scheme = parts.scheme.lower()
    if scheme not in (("https",) if https_only else ("https", "http")):
        raise FetchError("Only http and https web addresses are accepted.", "unsafe_url")
    if parts.username is not None or parts.password is not None or "@" in parts.netloc:
        raise FetchError("Web addresses containing a username or password are not accepted.", "unsafe_url")
    if port not in (None, 80, 443):
        raise FetchError("Only standard web ports (80 and 443) are accepted.", "unsafe_url")
    try:
        host = raw_host.rstrip(".").lower().encode("idna").decode("ascii") if raw_host else ""
    except UnicodeError:
        raise FetchError("That web address is not valid.", "unsafe_url") from None
    if not host:
        raise FetchError("That web address has no host name.", "unsafe_url")
    check_host(host)
    if allowed_hosts is not None and host not in allowed_hosts:
        raise FetchError("This service may only contact approved hosts.", "unsafe_url")
    netloc = f"[{host}]" if ":" in host else host
    if port:
        netloc += f":{port}"
    return urlunsplit((scheme, netloc, parts.path or "/", parts.query, ""))


def default_resolver(host, port):
    return [info[4][0] for info in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)]


def resolve_public(host, port, resolver):
    """Resolve a host and require every answer to be a public address."""
    try:
        ipaddress.ip_address(host)
        return [host]
    except ValueError:
        pass
    try:
        addresses = list(dict.fromkeys(resolver(host, port)))
    except (OSError, UnicodeError):
        raise FetchError(f"The address {host} could not be found.", "unreachable") from None
    if not addresses:
        raise FetchError(f"The address {host} could not be found.", "unreachable")
    for address in addresses:
        try:
            ip = ipaddress.ip_address(address.split("%")[0])
        except ValueError:
            raise FetchError(f"The address {host} resolved to an unusable value.", "unsafe_url") from None
        if not is_public(ip):
            raise FetchError(f"{host} resolves to a private or reserved network address and cannot be read.", "unsafe_url")
    return addresses


class GuardedBackend(httpcore.NetworkBackend):
    """Connect only to addresses verified at connect time (defeats DNS rebinding)."""

    def __init__(self, resolver):
        self.resolver, self.inner = resolver, httpcore.SyncBackend()

    def connect_tcp(self, host, port, timeout=None, local_address=None, socket_options=None):
        error = None
        for address in resolve_public(host, port, self.resolver):
            try:
                return self.inner.connect_tcp(address, port, timeout=timeout, local_address=local_address, socket_options=socket_options)
            except httpcore.ConnectError as exc:
                error = exc
        raise error or httpcore.ConnectError("No address could be reached")

    def connect_unix_socket(self, path, timeout=None, socket_options=None):
        raise FetchError("Unix sockets are not permitted.", "unsafe_url")

    def sleep(self, seconds):
        time.sleep(seconds)


class GuardedTransport(httpx.HTTPTransport):
    def __init__(self, resolver):
        super().__init__(retries=0)
        self._pool.close()
        self._pool = httpcore.ConnectionPool(ssl_context=httpx.create_ssl_context(), max_connections=4, max_keepalive_connections=0,
                                             http1=True, http2=False, network_backend=GuardedBackend(resolver))


@dataclass
class Fetched:
    url: str
    status: int
    content_type: str
    body: bytes
    truncated: bool = False
    redirects: list = field(default_factory=list)

    def text(self):
        for encoding in ("utf-8", "windows-1252"):
            try:
                return self.body.decode(encoding)
            except UnicodeDecodeError:
                continue
        return self.body.decode("utf-8", "replace")


class SafeFetcher:
    def __init__(self, transport=None, resolver=None, user_agent=USER_AGENT, https_only=False, allowed_hosts=None,
                 max_response_bytes=1_500_000, max_total_bytes=6_000_000, deadline_seconds=45.0, request_timeout=10.0,
                 max_redirects=4, max_requests=16, clock=time.monotonic):
        self.resolver = resolver or default_resolver
        self.https_only, self.allowed_hosts = https_only, allowed_hosts
        self.max_response_bytes, self.max_total_bytes = max_response_bytes, max_total_bytes
        self.max_redirects, self.max_requests, self.clock = max_redirects, max_requests, clock
        self.started, self.deadline_seconds = clock(), deadline_seconds
        self.total, self.requests, self.anchor = 0, 0, None
        self.client = httpx.Client(transport=transport or GuardedTransport(self.resolver), follow_redirects=False, trust_env=False,
                                   timeout=httpx.Timeout(request_timeout, connect=min(5.0, request_timeout)),
                                   headers={"User-Agent": user_agent, "Accept-Language": "en,nl;q=0.8"})

    def close(self):
        self.client.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def tick(self):
        if self.clock() - self.started > self.deadline_seconds:
            raise FetchError("The research time limit was reached.", "limit")
        if self.requests >= self.max_requests:
            raise FetchError("The research request limit was reached.", "limit")
        self.requests += 1

    def get(self, url, accept=("text/html", "application/xhtml+xml"), max_bytes=None, truncate=False, headers=None):
        current = clean_url(url, self.https_only, self.allowed_hosts)
        if self.anchor is None:
            self.anchor = site_key(urlsplit(current).hostname)
        hops = []
        for _ in range(self.max_redirects + 1):
            self.tick()
            parts = urlsplit(current)
            host = parts.hostname
            if site_key(host) != self.anchor:
                raise FetchError(f"The site redirected to a different address ({host}). Enter that address instead.", "redirect")
            resolve_public(host, parts.port or (443 if parts.scheme == "https" else 80), self.resolver)
            try:
                with self.client.stream("GET", current, headers=headers) as response:
                    if response.status_code in REDIRECTS:
                        location = response.headers.get("location")
                        if not location:
                            raise FetchError("The site sent a redirect without a destination.", "redirect")
                        target = clean_url(urljoin(current, location), self.https_only, self.allowed_hosts)
                        if parts.scheme == "https" and urlsplit(target).scheme != "https":
                            raise FetchError("The site tried to redirect from https to plain http.", "redirect")
                        hops.append(current)
                        current = target
                        continue
                    return self.read(response, current, accept, max_bytes or self.max_response_bytes, truncate, hops)
            except FetchError:
                raise
            except httpx.TimeoutException:
                raise FetchError("The site took too long to respond.", "timeout") from None
            except (httpx.HTTPError, httpcore.TimeoutException, httpcore.NetworkError, httpcore.ProtocolError, OSError):
                raise FetchError("The site could not be reached.", "unreachable") from None
        raise FetchError("The site redirected too many times.", "redirect")

    def read(self, response, url, accept, limit, truncate, hops):
        status = response.status_code
        if status >= 400 or status < 200 or status == 204:
            raise FetchError(f"The site answered with HTTP {status}.", "http_error", status)
        content_type = response.headers.get("content-type", "").split(";")[0].strip().lower()
        if accept is not None and content_type not in accept:
            raise FetchError(f"The page type ({content_type or 'unknown'}) is not readable text.", "content_type", status)
        declared = response.headers.get("content-length", "")
        if declared.isdigit() and int(declared) > limit and not truncate:
            raise FetchError("The page is larger than the safe download limit.", "too_large", status)
        data, truncated = bytearray(), False
        for chunk in response.iter_bytes():
            data.extend(chunk)
            if self.clock() - self.started > self.deadline_seconds:
                raise FetchError("The research time limit was reached.", "limit")
            if len(data) > limit:
                if not truncate:
                    raise FetchError("The page is larger than the safe download limit.", "too_large", status)
                data, truncated = data[:limit], True
                break
        self.total += len(data)
        if self.total > self.max_total_bytes:
            raise FetchError("The total download limit for this research was reached.", "limit")
        return Fetched(url, status, content_type, bytes(data), truncated, hops)


class Robots:
    def __init__(self, parser=None, allow_all=False, disallow_all=False, note=""):
        self.parser, self.allow_all, self.disallow_all, self.note = parser, allow_all, disallow_all, note

    def allows(self, url):
        if self.disallow_all:
            return False
        if self.allow_all or self.parser is None:
            return True
        return self.parser.can_fetch(ROBOTS_TOKEN, url)


def load_robots(fetcher, any_url):
    parts = urlsplit(any_url)
    target = urlunsplit((parts.scheme, parts.netloc, "/robots.txt", "", ""))
    try:
        fetched = fetcher.get(target, accept=None, max_bytes=500_000, truncate=True)
    except FetchError as exc:
        if exc.status in (401, 403):
            return Robots(disallow_all=True, note="robots.txt restricts automated access")
        if exc.status is not None and 400 <= exc.status < 500:
            return Robots(allow_all=True, note="no robots.txt")
        raise FetchError("The site's robots.txt could not be checked, so no pages were read.", "robots") from None
    parser = urllib.robotparser.RobotFileParser()
    parser.parse(fetched.text().splitlines())
    return Robots(parser, note="robots.txt honoured")
