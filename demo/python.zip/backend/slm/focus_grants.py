"""A curated focus set: the funding most South-Holland startups should look at first.

Automatic discovery covers thousands of public records. Real founders mostly end up at
a small set of instruments, and those deserve hand-checked application routes: which
portal, which login, which official form, and what has to happen outside this app.
Every entry is sourced; facts that come only from third-party summaries are marked
``verify`` so the interface can say so. Amounts and windows are snapshots, not promises.
"""

import re

VERIFIED_ON = "2026-11-10"

ROUTES = {
    "mijn_rvo": {"portal": "Mijn RVO (eLoket)", "url": "https://mijn.rvo.nl", "login": "eHerkenning",
                 "note": "Arrange eHerkenning for your company before the deadline; it can take several working days."},
    "zh_portal": {"portal": "Subsidieportaal Provincie Zuid-Holland", "url": "https://subsidieportaal.zuid-holland.nl/inloggen",
                  "login": "eHerkenning",
                  "note": "The application cannot be supplemented after submission, so everything must be complete at once."},
    "eu_portal": {"portal": "EU Funding & Tenders Portal", "url": "https://ec.europa.eu/info/funding-tenders/opportunities/portal/",
                  "login": "EU Login account and a PIC for your organisation",
                  "note": "Register the organisation (PIC) first; Part A is filled in online, Part B is uploaded as PDF."},
    "eic_platform": {"portal": "EIC AI-based Platform", "url": "https://eic.ec.europa.eu/eic-funding-opportunities/eic-accelerator_en",
                     "login": "EU Login account",
                     "note": "Short application first (company, innovation, pitch video); a full proposal only after a positive short evaluation."},
    "iq_contact": {"portal": "InnovationQuarter (contact and Quickscan)", "url": "https://www.innovationquarter.nl/",
                   "login": "No portal login; start with the Quickscan or an intake conversation",
                   "note": "Investment instruments start with a conversation and a business case, not with a form."},
    "kvw": {"portal": "Kansen voor West (via an open call)", "url": "https://www.kansenvoorwest.nl/",
            "login": "eHerkenning", "note": "Apply only during an open call that fits your project; projects are usually collaborations."},
    "municipal": {"portal": "The municipality's subsidy page", "url": "", "login": "See the municipality's page",
                  "note": "Municipal schemes open in short rounds; check the current round and its application form on the municipality's page."},
    "via_fund": {"portal": "Apply to a participating investment fund", "url": "https://www.rvo.nl/subsidies-financiering/seed-capital",
                 "login": "No government login; you approach the fund", "note": "The government money flows through private funds that decide."},
    "via_bank": {"portal": "Through your bank or financier", "url": "https://www.rvo.nl/subsidies-financiering/bmkb",
                 "login": "No government login; the financier applies", "note": "You ask your bank; the bank arranges the guarantee with RVO."},
    "rabobank": {"portal": "Rabobank (information request on its website)",
                 "url": "https://www.rabobank.nl/bedrijven/zakelijk-financieren/alle-financieringsvormen/rabo-innovatielening/",
                 "login": "No government login; you request the loan from Rabobank",
                 "note": "After your information request Rabobank sends a brochure listing the documents it needs."},
    "delft_enterprises": {"portal": "Delft Enterprises (TU Delft's investment company)", "url": "https://delftenterprises.tudelftcampus.nl/funding/",
                          "login": "No government login; you apply to Delft Enterprises with its own form",
                          "note": "Contact info@delftenterprises.nl or +31 15 278 2122 if you are unsure whether your TU Delft link counts."},
    "nwo_isaac": {"portal": "ISAAC (NWO's application system)", "url": "https://www.isaac.nwo.nl/", "login": "ISAAC account",
                  "note": "Tell your university's valorisation office before you apply; NWO assumes it knows about the application."},
    "invest_nl": {"portal": "Invest-NL Deep Tech Fonds (contact the fund team)", "url": "https://www.invest-nl.nl/nl/themas/deep-tech",
                  "login": "No government login; you contact the fund", "note": "An investment follows talks and due diligence; prepare a pitch deck and a financial plan."},
}
BV = ["B.V.", "BV", "B.V", "Besloten vennootschap", "Besloten vennootschap met beperkte aansprakelijkheid"]
TU_DELFT_LINK = ["student", "employee", "alumnus", "research_spin_out"]

FOCUS = [
    {"key": "zh-mit-haalbaarheid", "url": "https://www.zuid-holland.nl/online-regelen/subsidies/subsidies/mkb-subsidies/mkb-haalbaarheidsprojecten-mit/",
     "provider": "zh", "title": "MIT Feasibility project (Province of South Holland)", "instrument": "grant", "region": "Zuid-Holland",
     "stages": ["feasibility"], "audience": "SMEs with a registered establishment in South Holland",
     "summary": "Up to 35% of the costs of a feasibility study (technical and economic) for a new product, process or service, maximum €20,000. "
                "The project starts within 4 months of the decision and is finished within 1 year.",
     "amount": "max €20,000 (35% of costs)", "window": "Yearly round; 2026 round: 7 Apr – 15 Sep 2026 (closed). Oversubscription is settled by lottery.",
     "route": "zh_portal", "portal_form": "zh_mit_feasibility",
     "form_url": "https://www.zuid-holland.nl/publish/pages/37713/model_projectplan_mit_haalbaarheidsprojecten_2026.docx",
     "documents": ["Project plan in the mandatory 'Model projectplan MIT Haalbaarheidsprojecten 2026' format",
                   "'Toets geen financiële moeilijkheden' (check that the company is not in financial difficulty) — keep for your records"],
     "sources": ["https://www.zuid-holland.nl/online-regelen/subsidies/subsidies/mkb-subsidies/mkb-haalbaarheidsprojecten-mit/",
                 "https://www.zuid-holland.nl/publish/pages/37713/eformulier_mit_zh_haalbaarheidsproject_2026_2_.pdf"]},
    {"key": "zh-mit-rd", "url": "https://www.zuid-holland.nl/online-regelen/subsidies/subsidies/research-development-samenwerkingsprojecten-mit/",
     "provider": "zh", "title": "MIT R&D collaboration project (Province of South Holland)", "instrument": "grant", "region": "Zuid-Holland",
     "stages": ["development"], "audience": "Two or more SMEs working together, lead partner established in South Holland",
     "summary": "Grant for SMEs that research and test a new product or service together. Partners pay at least 65% themselves and no "
                "partner pays more than 70% of the costs. A signed collaboration agreement is part of the mandatory project plan.",
     "amount": "max €350,000 per project", "window": "Yearly round; 2026 round: 9 Jun – 15 Sep 2026 (closed).",
     "route": "zh_portal", "portal_form": "generic_nl", "partners_required": True,
     "conditions": [{"field": "project.organisation_count", "operator": "gte", "expected": 2, "label": "Two or more SMEs working together",
                     "quote": "Two or more SMEs"}],
     "form_url": "https://www.zuid-holland.nl/online-regelen/subsidies/subsidies/research-development-samenwerkingsprojecten-mit/",
     "documents": ["Project plan in the 'Model projectplan MIT R&D projecten 2026' format, including the signed collaboration agreement"],
     "sources": ["https://www.zuid-holland.nl/online-regelen/subsidies/subsidies/research-development-samenwerkingsprojecten-mit/"]},
    {"key": "wbso", "url": "https://www.rvo.nl/subsidies-financiering/wbso", "provider": "rvo",
     "title": "WBSO — tax credit for R&D work", "instrument": "tax_relief", "region": "Netherlands", "stages": ["development", "research"],
     "audience": "Companies (including startups) that do their own technical R&D or software development",
     "summary": "Lowers the wage tax you pay for hours spent on your own technical development work (and related costs). You apply before the "
                "work starts, for a period of 3 to 12 months; starters get a higher rate.",
     "amount": "Reduction of payroll tax on R&D hours", "window": "Apply all year, at least one month before the R&D period starts.",
     "route": "mijn_rvo", "portal_form": "generic_nl", "official_form": "wbso-development", "cost_table": False,
     "documents": ["Project description per R&D project (technical problem, new solution, technical risks) entered in the online form"],
     "sources": ["https://www.rvo.nl/subsidies-financiering/wbso"]},
    {"key": "innovatiekrediet", "url": "https://www.rvo.nl/subsidies-financiering/innovatiekrediet", "provider": "rvo",
     "title": "Innovation Credit (Innovatiekrediet)", "instrument": "loan", "region": "Netherlands", "stages": ["development"],
     "audience": "Companies developing a technically risky new product with a strong market case, after proof of principle; project of at least "
                 "€150,000, and you finance at least 55% of the project yourself or with others",
     "summary": "A loan for part of the development costs of a risky technical or clinical project, repaid from the revenue of the result. "
                "The product must be on the market within 5 years; RVO takes a pledge on the IP and assets.",
     "amount": "Loan for 35–45% of project costs for SMEs (50% when collaborating), up to €10 million", "window": "Apply all year.",
     "route": "mijn_rvo", "portal_form": "generic_nl", "official_form": "innovatiekrediet-plan", "verified_on": "2026-11-15",
     "conditions": [
         {"field": "project_budget_cents", "operator": "gte", "expected": 15_000_000, "label": "Project of at least €150,000",
          "quote": "project of at least €150,000"},
         {"field": "finance.cofinancing_available", "operator": "eq", "expected": True, "label": "You finance at least 55% yourself or with others",
          "quote": "you finance at least 55% of the project yourself or with others"}],
     "sources": ["https://www.rvo.nl/subsidies-financiering/innovatiekrediet",
                 "https://www.rvo.nl/subsidies-financiering/innovatiekrediet/aanvraagproces/bijlagen-bij-aanvraag"]},
    {"key": "vff", "url": "https://www.rvo.nl/subsidies-financiering/vroegefasefinanciering", "provider": "rvo",
     "title": "Early-phase financing (Vroegefasefinanciering)", "instrument": "loan", "region": "Netherlands", "stages": ["feasibility", "idea"],
     "audience": "Innovative starters (at most 5 years old) and SMEs whose technical idea has reached proof of principle but is too early "
                 "for investors; an investor intends to invest once the project is done",
     "summary": "An interest-bearing loan to test whether a technically innovative idea can become a viable business, before investors step in. "
                "Starters from university research apply through NWO Take-off phase 2 instead.",
     "amount": "Loan of at least €50,000: up to 100% for innovative starters (max €450,000), 35–45% for SMEs",
     "window": "Open 1 Jan – 31 Dec 2026 while the budget lasts.", "route": "mijn_rvo", "portal_form": "generic_nl", "verified_on": "2026-11-15",
     "sources": ["https://www.rvo.nl/subsidies-financiering/vroegefasefinanciering"]},
    {"key": "eurostars", "url": "https://www.rvo.nl/subsidies-financiering/eurostars", "provider": "rvo",
     "title": "Eurostars — international market-oriented R&D", "instrument": "grant", "region": "Europe", "stages": ["development"],
     "audience": "R&D-performing SMEs working with a partner in another country", "partners_required": True,
     "conditions": [{"field": "project.organisation_count", "operator": "gte", "expected": 2, "label": "A partner in another country",
                     "quote": "working with a partner in another country"}],
     "summary": "Grant for an international R&D project led by an SME, with partners from at least two participating countries. Dutch partners also follow a national procedure at RVO.",
     "amount": "Grant (national funding rules)", "window": "Call-based; check the scheme page for the next cut-off.", "route": "mijn_rvo", "portal_form": "generic_nl",
     "sources": ["https://www.rvo.nl/subsidies-financiering/eurostars"]},
    {"key": "seed-capital", "url": "https://www.rvo.nl/subsidies-financiering/seed-capital", "provider": "rvo",
     "title": "Seed Capital (through participating investment funds)", "instrument": "equity", "region": "Netherlands", "stages": ["launch", "development"],
     "audience": "Technostarters less than seven years old (counted from the first sale) with a product based on a new technical invention",
     "route": "via_fund", "portal_form": None,
     "summary": "The government co-invests through private seed funds. You pitch to a participating fund, not to RVO.",
     "amount": "Investment of €100,000 to €5 million by a participating fund", "window": "Continuous; approach a fund.", "verified_on": "2026-11-15",
     "conditions": [{"field": "company.age_months", "operator": "lte", "expected": 84, "label": "Less than seven years old",
                     "quote": "less than seven years old"}],
     "sources": ["https://www.rvo.nl/subsidies-financiering/seed-capital"]},
    {"key": "bmkb", "url": "https://www.rvo.nl/subsidies-financiering/bmkb", "provider": "rvo",
     "title": "SME credit guarantee (BMKB)", "instrument": "guarantee", "region": "Netherlands", "stages": ["launch", "scale"],
     "audience": "SMEs with at most 250 FTE that need a bank loan but lack collateral", "route": "via_bank", "portal_form": None,
     "verified_on": "2026-11-15",
     "conditions": [{"field": "company.fte", "operator": "lte", "expected": 250, "label": "At most 250 FTE", "quote": "at most 250 FTE"}],
     "summary": "The government guarantees part of a bank loan so the bank can lend with less collateral. Your bank applies.",
     "amount": "Guarantee on a bank loan", "window": "Continuous, through your bank.",
     "sources": ["https://www.rvo.nl/subsidies-financiering/bmkb"]},
    {"key": "kansen-voor-west", "url": "https://www.zuid-holland.nl/online-regelen/subsidies/subsidies/kansen-voor-west-efro-2022-2027-zuid-holland/",
     "provider": "zh", "title": "Kansen voor West III (EU regional fund, West Netherlands)", "instrument": "grant", "region": "Zuid-Holland",
     "stages": ["development", "launch"], "audience": "Companies, governments and knowledge organisations; usually collaborations",
     "summary": "EU regional development money (EFRO) for innovation and climate projects in the Randstad. You apply to a specific open call; "
                "provincial co-financing is arranged automatically when it applies.",
     "amount": "Depends on the open call", "window": "Programme runs to 31 Dec 2027; apply during an open call.", "route": "kvw", "portal_form": "generic_nl",
     "sources": ["https://www.zuid-holland.nl/online-regelen/subsidies/subsidies/kansen-voor-west-efro-2022-2027-zuid-holland/",
                 "https://www.kansenvoorwest.nl/"]},
    {"key": "uniiq", "url": "https://www.innovationquarter.nl/en/how-we-help/funding/uniiq/", "provider": "iq",
     "title": "UNIIQ proof-of-concept fund (InnovationQuarter)", "instrument": "loan", "region": "Zuid-Holland", "stages": ["feasibility", "development"],
     "audience": "Companies established as a B.V., based in South Holland, no older than five years, with technology validated at TRL 3–5",
     "summary": "A convertible loan for the proof-of-concept phase, paid in stages against pre-agreed milestones, without a company valuation. "
                "UNIIQ looks for a strong team (or a plan to build one), unique technology with an IP strategy, a concrete validation plan "
                "for the next 12 months and a path to follow-on funding. The process takes about 4 months.",
     "amount": "Convertible loan up to €450,000 (interest 5% plus a reference rate)",
     "window": "No deadline on the official page; apply online, then a Quickscan decides go or no-go.", "route": "iq_contact",
     "portal_form": None, "verified_on": "2026-11-13",
     "documents": ["Pitch deck: the problem and who cares, why existing solutions fall short, the technological breakthrough, "
                   "what must be proven in the next 12 months and why the company becomes investable",
                   "A concrete validation plan for the next 12 months"],
     "conditions": [
         {"field": "company.legal_form", "operator": "in", "expected": BV, "label": "Established as a B.V.", "quote": "established as a B.V."},
         {"field": "company.province", "operator": "eq", "expected": "Zuid-Holland", "label": "Based in South Holland", "quote": "based in South Holland"},
         {"field": "company.age_months", "operator": "lte", "expected": 60, "label": "No older than five years", "quote": "no older than five years"},
         {"field": "project.trl", "operator": "gte", "expected": 3, "label": "Technology at TRL 3 or higher", "quote": "TRL 3–5"},
         {"field": "project.trl", "operator": "lte", "expected": 5, "label": "Technology at TRL 5 or lower", "quote": "TRL 3–5"}],
     "sources": ["https://www.innovationquarter.nl/en/how-we-help/funding/uniiq/", "https://uniiq.nl/en/apply-for-funding/"]},
    {"key": "eic-accelerator", "url": "https://eic.ec.europa.eu/eic-funding-opportunities/eic-accelerator_en", "provider": "eu",
     "title": "EIC Accelerator (European Innovation Council)", "instrument": "grant", "region": "Europe", "stages": ["development", "scale"],
     "audience": "Single startups and SMEs established in an EU member state or associated country, with a breakthrough innovation at "
                 "TRL 6 or higher",
     "summary": "Grant for development plus an optional equity investment. Starts with a short application (company, innovation, pitch video); "
                "a full proposal and an interview follow for selected companies. The grant covers TRL 6–8, the investment TRL 6–9.",
     "amount": "Grant up to €2.5 million; investment €1–10 million",
     "window": "Short applications any time; full proposals at cut-offs on 20 Jan, 17 Mar, 1 Sep and 4 Nov 2027.",
     "route": "eic_platform", "portal_form": None, "verified_on": "2026-11-15",
     "conditions": [{"field": "project.trl", "operator": "gte", "expected": 6, "label": "Technology at TRL 6 or higher", "quote": "TRL 6 or higher"}],
     "sources": ["https://eic.ec.europa.eu/eic-funding-opportunities/eic-accelerator_en"]},
    # The EU portal page shows no text to automated readers; the conditions come from the programme's own site.
    {"key": "women-techeu", "url": "https://womentecheurope.eu/", "provider": "eu",
     "title": "Women TechEU", "instrument": "grant", "region": "Europe", "stages": ["feasibility", "development"],
     "audience": "Deep-tech startups registered for at least six months and at most five years in an EU member state or associated country, "
                 "founded or co-founded by a woman in the top position (CEO or CTO) who holds at least 25% of the shares, at TRL 4–6 "
                 "and with less than €1 million in equity raised",
     "summary": "A €75,000 grant (no equity) plus mentoring and training for women-led deep-tech startups, before a high-fidelity product exists. "
                "An eligibility check comes before the full proposal; companies funded by the EIC Accelerator cannot apply.",
     "amount": "€75,000 grant plus coaching", "window": "Call 2026–2028 with four cut-offs; the next one is 14 Jan 2027 (EU funding portal).",
     "route": "eic_platform", "portal_form": None, "verified_on": "2026-11-15",
     "conditions": [
         {"field": "company.women_led", "operator": "eq", "expected": True, "label": "Woman founder in the top position",
          "quote": "a woman in the top position"},
         {"field": "company.age_months", "operator": "gte", "expected": 6, "label": "Registered for at least six months", "quote": "at least six months"},
         {"field": "company.age_months", "operator": "lte", "expected": 60, "label": "Registered for at most five years", "quote": "at most five years"},
         {"field": "project.trl", "operator": "gte", "expected": 4, "label": "Technology at TRL 4 or higher", "quote": "TRL 4–6"},
         {"field": "project.trl", "operator": "lte", "expected": 6, "label": "Technology at TRL 6 or lower", "quote": "TRL 4–6"}],
     "sources": ["https://womentecheurope.eu/",
                 "https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/competitive-calls-cs/48106227"]},
    {"key": "zorgtech-zh", "url": "https://www.medicaldelta.nl/en/news/new-subsidy-round-zorgtech-launched", "provider": "zh-regional",
     "topic": "health healthcare medical clinical patient hospital care zorg",
     "title": "ZorgTech innovation programme (South Holland, EU regional fund)", "instrument": "grant", "region": "Zuid-Holland",
     "stages": ["development", "launch"], "audience": "SMEs established in South Holland with a technological innovation for healthcare",
     "summary": "Subsidy for testing and validating a healthcare technology innovation in practice, preferably in South Holland. "
                "Check first with the programme team (InnovationQuarter, Medical Delta and TNO) whether your phase and idea fit.",
     "amount": "Depends on the round", "window": "Rounds announced by the programme; check the current round.", "route": "iq_contact",
     "portal_form": None, "verify": True,
     "sources": ["https://www.medicaldelta.nl/en/news/new-subsidy-round-zorgtech-launched", "https://zoek.officielebekendmakingen.nl/gmb-2025-442028.pdf"]},
    {"key": "rotterdam-circulair", "url": "https://www.rotterdam.nl/subsidies", "provider": "municipal", "cities": ["Rotterdam"],
     "topic": "circular recycling reuse waste repair refurbish secondhand",
     "title": "Circular entrepreneurship subsidy (Municipality of Rotterdam)", "instrument": "grant", "region": "Rotterdam",
     "stages": ["feasibility", "launch"], "audience": "Entrepreneurs registered with the KvK and established (or settling) in Rotterdam",
     "summary": "Up to 50% of the costs of a circular business initiative, with a maximum of €24,999 per initiative.",
     "amount": "max €24,999 (50% of costs)", "window": "2026 round: 2 Sep – 21 Oct 2026 (closed); check rotterdam.nl/subsidies for the next round.",
     "route": "municipal", "portal_form": None, "verify": True,
     "sources": ["https://zoek.officielebekendmakingen.nl/gmb-2026-274991.pdf"]},
    {"key": "denhaag-blauwe-economie", "url": "https://www.denhaag.nl/nl/subsidies/subsidie-vernieuwende-projecten-op-zee-aanvragen/",
     "provider": "municipal", "cities": ["Den Haag", "'s-Gravenhage", "The Hague"],
     "topic": "maritime sea offshore ocean harbour port vessel shipping fishing seaweed coastal",
     "title": "Innovative projects at sea – blue economy (Municipality of The Hague)", "instrument": "grant", "region": "Den Haag",
     "stages": ["development", "launch"], "audience": "Hague entrepreneurs developing innovations for the blue (maritime) economy",
     "summary": "Up to 50% of project costs for innovations in the blue economy, linked to the Scheveningen harbour vision.",
     "amount": "Up to 50% of project costs (€100,000 in total in the last round)", "window": "Check the municipality's page for the current round.",
     "route": "municipal", "portal_form": None, "verify": True,
     "sources": ["https://www.denhaag.nl/nl/subsidies/subsidie-vernieuwende-projecten-op-zee-aanvragen/"]},
    # Rabobank's page refuses automated reading; the figures below come from search results quoting it, hence ``verify``.
    {"key": "rabo-innovatielening", "url": "https://www.rabobank.nl/bedrijven/zakelijk-financieren/alle-financieringsvormen/rabo-innovatielening/",
     "provider": "rabobank", "title": "Rabo Innovation Loan (Rabo Innovatielening)", "instrument": "loan", "region": "Netherlands",
     "stages": ["development", "launch"],
     "audience": "Startup B.V.s with an innovative idea that cannot get a regular bank loan yet, because there are no proven results or cash flow",
     "summary": "A subordinated loan from Rabobank to finance an innovative idea. Rabobank asks no collateral; while the loan runs, "
                "new financing elsewhere needs Rabobank's consent.",
     "amount": "€25,000 to €200,000, 7 years, fixed 10% interest (per Rabobank's page, November 2026)",
     "window": "Continuous; start with an information request on Rabobank's website.", "route": "rabobank", "portal_form": None,
     "verify": True, "verified_on": "2026-11-13",
     "conditions": [{"field": "company.legal_form", "operator": "in", "expected": BV, "label": "Startup B.V.", "quote": "Startup B.V.s"}],
     "sources": ["https://www.rabobank.nl/bedrijven/zakelijk-financieren/alle-financieringsvormen/rabo-innovatielening/",
                 "https://www.rabobank.nl/en/business/startups-and-scale-ups/articles/011532615-rabo-innovation-loan-stimulates-growth-innovation-and-impact-of-dutch-startups"]},
    {"key": "techscout-venture-fund", "url": "https://delftenterprises.tudelftcampus.nl/funding/techscout-venture-fund/",
     "provider": "delft-enterprises", "title": "TechScout Venture Fund (Delft Enterprises)", "instrument": "loan", "region": "Netherlands",
     "stages": ["feasibility", "development"],
     "audience": "Spin-off companies whose innovation originates from research at TU Delft, no older than two years when they apply",
     "summary": "A convertible loan to show commercial feasibility, for example with a working software or device prototype or proof-of-concept "
                "evidence. It converts at a 25% discount. TU Delft employees in the project need prior written approval from their faculty; "
                "consultancy ideas are not eligible.",
     "amount": "€50,000 convertible loan", "window": "No deadline on the page; start with the Expression of Interest form (reply within 2 weeks).",
     "route": "delft_enterprises", "portal_form": None, "tu_delft_only": True, "verified_on": "2026-11-13",
     "conditions": [
         {"field": "company.tu_delft_affiliation", "operator": "eq", "expected": "research_spin_out", "label": "Innovation from TU Delft research",
          "quote": "originates from research at TU Delft"},
         {"field": "company.age_months", "operator": "lte", "expected": 24, "label": "No older than two years", "quote": "no older than two years"}],
     "sources": ["https://delftenterprises.tudelftcampus.nl/funding/techscout-venture-fund/",
                 "https://delftenterprises.tudelftcampus.nl/expression-of-interest-techscout-venture-fund/"]},
    # The voucher's own page could not be read (it redirects to a missing page); terms come from the funding overview and search results.
    {"key": "student-entrepreneurship-voucher", "url": "https://www.tudelftcampus.nl/entrepreneurship/student-entrepreneurship-voucher/",
     "provider": "delft-enterprises", "title": "Student Entrepreneurship Voucher (Delft Enterprises)", "instrument": "grant", "region": "Netherlands",
     "stages": ["idea", "feasibility"], "audience": "Entrepreneurial TU Delft students developing an idea, for example into a prototype",
     "summary": "Covers the first costs of developing an idea. Only realised, eligible costs count; Delft Enterprises takes no shares and does not "
                "claim your intellectual property. The application includes a project plan of at most 300 words.",
     "amount": "Up to €2,500", "window": "Application rounds with deadlines; check the page for the next deadline.",
     "route": "delft_enterprises", "portal_form": None, "tu_delft_only": True, "verify": True, "verified_on": "2026-11-13",
     "conditions": [{"field": "company.tu_delft_affiliation", "operator": "eq", "expected": "student", "label": "TU Delft student",
                     "quote": "TU Delft students"}],
     "sources": ["https://delftenterprises.tudelftcampus.nl/funding/", "https://tudelftcampus.nl/entrepreneurship/application-de-startup-voucher"]},
    {"key": "dick-plettenburg-fund", "url": "https://delftenterprises.tudelftcampus.nl/funding/dick-plettenburg-fund/",
     "provider": "delft-enterprises", "title": "Dick Plettenburg Fund (Delft Enterprises)", "instrument": "grant", "region": "Netherlands",
     "stages": ["idea", "feasibility"],
     "topic": "disability disabilities disabled impairment impaired rehabilitation prosthesis prosthetic assistive orthosis wheelchair",
     "audience": "People and (pre-)start-ups with a clear link to TU Delft that work on treatment or support for people with a physical or cognitive disability",
     "summary": "A grant plus coaching for projects that help people with physical or cognitive disabilities. A clinical advisor or healthcare "
                "institution must be involved, and the project may not have raised more than €50,000 in subsidies, investments or income.",
     "amount": "€25,000 grant", "window": "No deadline on the page; apply with Delft Enterprises' application form.",
     "route": "delft_enterprises", "portal_form": None, "tu_delft_only": True, "verified_on": "2026-11-13",
     "conditions": [{"field": "company.tu_delft_affiliation", "operator": "in", "expected": TU_DELFT_LINK, "label": "Clear link with TU Delft",
                     "quote": "a clear link to TU Delft"}],
     "sources": ["https://delftenterprises.tudelftcampus.nl/funding/dick-plettenburg-fund/",
                 "https://delftenterprises.tudelftcampus.nl/application-form/"]},
    {"key": "nwo-take-off-1", "url": "https://zoek.officielebekendmakingen.nl/stcrt-2026-1039.html", "provider": "nwo",
     "title": "NWO Take-off phase 1 – feasibility study", "instrument": "grant", "region": "Netherlands", "stages": ["idea", "feasibility"],
     "audience": "Founders employed as a researcher at a Dutch university, university medical centre or KNAW or NWO institute "
                 "(not as a PhD candidate) who explore a startup based on their research",
     "summary": "A grant for a feasibility study of up to 6 months that answers whether research results can become a viable company: "
                "is there demand, what must the product do, and can a business be built on it. It ends in a strategic business report.",
     "amount": "€30,000 to €60,000", "window": "Apply any time in 2026; applications are assessed in batches of 40.",
     "route": "nwo_isaac", "portal_form": None, "verified_on": "2026-11-15",
     "conditions": [{"field": "company.founder_employed_researcher", "operator": "eq", "expected": True,
                     "label": "Founder employed as a university researcher", "quote": "employed as a researcher"}],
     "sources": ["https://zoek.officielebekendmakingen.nl/stcrt-2026-1039.html"]},
    {"key": "nwo-take-off-2", "url": "https://zoek.officielebekendmakingen.nl/stcrt-2026-22150.html", "provider": "nwo",
     "title": "NWO Take-off phase 2 – early-stage loan for academic startups", "instrument": "loan", "region": "Netherlands",
     "stages": ["feasibility", "development"],
     "audience": "Startups registered with the KvK for less than five years, built on research taken over or licensed from a Dutch "
                 "university, university of applied sciences or TO2 institute",
     "summary": "An interest-bearing loan for up to 24 months to launch a company built on research results, for staff, equipment and "
                "knowledge transfer. Repayment starts three years after the agreement. This is the route for academic starters within "
                "Vroegefasefinanciering.",
     "amount": "Loan of €50,000 to €450,000", "window": "Two rounds a year; the autumn 2026 round closed on 1 Sep 2026.",
     "route": "nwo_isaac", "portal_form": None, "verified_on": "2026-11-15",
     "conditions": [
         {"field": "company.university_spin_out", "operator": "eq", "expected": True, "label": "Built on Dutch university research",
          "quote": "built on research taken over or licensed from a Dutch university"},
         {"field": "company.age_months", "operator": "lte", "expected": 60, "label": "Registered for less than five years",
          "quote": "less than five years"}],
     "sources": ["https://zoek.officielebekendmakingen.nl/stcrt-2026-22150.html"]},
    {"key": "innovationquarter-capital", "url": "https://www.innovationquarter.nl/hoe-wij-helpen/financiering/innovationquarter-capital/",
     "provider": "iq", "title": "InnovationQuarter Capital (scale-up investment)", "instrument": "equity", "region": "Zuid-Holland",
     "stages": ["launch", "scale"], "audience": "Scale-ups based in South Holland with technology at TRL 6–9",
     "summary": "Investment by South Holland's regional development agency in technology scale-ups, alongside other investors. "
                "Start with the Quickscan.",
     "amount": "From €250,000, total exposure up to €5 million (equity or convertible loan)", "window": "Continuous; start with the Quickscan.",
     "route": "iq_contact", "portal_form": None, "verified_on": "2026-11-15",
     "conditions": [
         {"field": "company.province", "operator": "eq", "expected": "Zuid-Holland", "label": "Based in South Holland", "quote": "based in South Holland"},
         {"field": "project.trl", "operator": "gte", "expected": 6, "label": "Technology at TRL 6 or higher", "quote": "TRL 6–9"}],
     "sources": ["https://www.innovationquarter.nl/hoe-wij-helpen/financiering/innovationquarter-capital/"]},
    {"key": "energietransitiefonds-rotterdam", "url": "https://www.innovationquarter.nl/hoe-wij-helpen/financiering/energietransitiefonds-rotterdam/",
     "provider": "iq", "title": "Energietransitiefonds Rotterdam (energy and circular scale-ups)", "instrument": "equity", "region": "Zuid-Holland",
     "topic": "energy hydrogen electrolyser electrolysis renewable solar wind heat battery storage grid emission emissions carbon co2 circular recycling",
     "stages": ["launch", "scale"],
     "audience": "Energy and circular-economy scale-ups with technology at TRL 6 or higher, a separate legal entity and demonstrable "
                 "impact on Rotterdam and the region",
     "summary": "A €100 million fund of the Municipality of Rotterdam, managed by InnovationQuarter, that invests in scaling up energy and "
                "circular technology with impact on the Rotterdam region.",
     "amount": "€1 million to €10 million per investment (shares, loans, guarantees or a mix)", "window": "Continuous; start with a conversation.",
     "route": "iq_contact", "portal_form": None, "verified_on": "2026-11-15",
     "conditions": [{"field": "project.trl", "operator": "gte", "expected": 6, "label": "Technology at TRL 6 or higher", "quote": "TRL 6 or higher"}],
     "sources": ["https://www.innovationquarter.nl/hoe-wij-helpen/financiering/energietransitiefonds-rotterdam/"]},
    # Invest-NL's page states no ticket size; the amount is the fund size.
    {"key": "deep-tech-fonds", "url": "https://www.invest-nl.nl/nl/themas/deep-tech", "provider": "invest-nl",
     "title": "Deep Tech Fonds (Invest-NL)", "instrument": "equity", "region": "Netherlands", "stages": ["development", "scale"],
     "topic": "quantum photonics photonic optical semiconductor semiconductors chip chips lithography nanotechnology mechatronics robotics "
              "imaging biotechnology cybersecurity electrolyser battery",
     "audience": "Deep-tech companies based in the Netherlands with a large capital need, working on a key technology from the national "
                 "technology strategy (such as quantum, photonics or semiconductors) at TRL 3–9",
     "summary": "Venture capital from Invest-NL for deep-tech companies in the early phase that have to cross the 'valley of death'. "
                "Invest-NL looks at societal impact, a disruptive technology, R&D and jobs in the Netherlands, and a strong team.",
     "amount": "Venture capital from a €250 million fund", "window": "Continuous; contact the fund team.",
     "route": "invest_nl", "portal_form": None, "verify": True, "verified_on": "2026-11-15",
     "conditions": [
         {"field": "company.country", "operator": "eq", "expected": "Netherlands", "label": "Based in the Netherlands", "quote": "based in the Netherlands"},
         {"field": "project.trl", "operator": "gte", "expected": 3, "label": "Technology at TRL 3 or higher", "quote": "TRL 3–9"}],
     "sources": ["https://www.invest-nl.nl/nl/themas/deep-tech"]},
    # Only the DEI+ overview was read (the energy sub-page was closed); hence ``verify``.
    {"key": "dei-energie-klimaat", "url": "https://www.rvo.nl/subsidies-financiering/dei/energie-en-klimaatinnovaties", "provider": "rvo",
     "title": "DEI+: Energy and climate innovations (pilots and demonstrations)", "instrument": "grant", "region": "Netherlands",
     "topic": "energy climate hydrogen electrolyser electrolysis renewable solar wind heat battery storage grid emission emissions carbon co2",
     "stages": ["development", "launch"],
     "audience": "Companies in the Netherlands that run a pilot or demonstration project which lowers CO2 emissions in the Netherlands",
     "summary": "Subsidy for a pilot or demonstration of a new energy or climate technology. Your project must lower CO2 emissions in "
                "the Netherlands within 10 years of its start.",
     "amount": "Part of the project costs; you finance the rest", "window": "Temporarily closed; it opens in yearly rounds, check the page.",
     "route": "mijn_rvo", "portal_form": "generic_nl", "verify": True, "verified_on": "2026-11-15",
     "sources": ["https://www.rvo.nl/subsidies-financiering/dei", "https://www.rvo.nl/subsidies-financiering/dei/energie-en-klimaatinnovaties"]},
]

# Fields of the online application forms. Each maps to a profile path, an application value
# or "manual" when only the founder can supply it on the portal itself.
PORTAL_FORMS = {
    "zh_mit_feasibility": {
        "title": "Online form: MIT Feasibility project (Province of South Holland)",
        "source": "https://www.zuid-holland.nl/publish/pages/37713/eformulier_mit_zh_haalbaarheidsproject_2026_2_.pdf",
        "sections": [
            ("1.1 Organisation", [("Naam (company name)", "company.name"), ("Rechtsvorm (legal form)", "company.legal_form"),
                                  ("KvK-nummer", "company.registration_number"), ("Vestigingsadres", "company.address"),
                                  ("Postcode en plaats", "company.postcode+city"), ("Telefoonnummer", "company.phone"),
                                  ("E-mailadres", "company.email"), ("Website", "company.website"), ("Bankrekening (IBAN)", "manual")]),
            ("1.2 Contact person", [("Naam", "contact.name"), ("Functie", "contact.role"), ("Telefoonnummer", "contact.phone"),
                                    ("E-mailadres", "contact.email")]),
            ("1.3 Other applicant details", [("BTW-plichtig voor de projectkosten? (VAT liable)", "company.vat_liable"),
                                             ("In financiële moeilijkheden? (Use the 'Toets geen financiële moeilijkheden')", "manual"),
                                             ("Other public aid for this activity?", "manual"),
                                             ("Partner or linked companies that also apply this year?", "manual")]),
            ("2.1 Project", [("Projectnaam (public)", "project.name"), ("Startdatum (within 4 months of the decision)", "project.start_date"),
                             ("Einddatum (within 12 months of the start)", "project.end_date"),
                             ("Openbare samenvatting (public summary, no confidential details)", "answer:summary")]),
            ("2.3 Project fit", [("Mission or key technology of the KIA's (choose one)", "answer:kia"),
                                 ("Is the innovation technically or financially risky enough to justify the project?", "answer:risk")]),
            ("2.4 Costs", [("Costs of the feasibility study (at least 60%)", "budget:study"),
                           ("Industrial research / experimental development (at most 40%)", "budget:development")]),
            ("2.5 Financing", [("Eigen bijdrage (own contribution)", "budget:own"), ("Gevraagde subsidie (requested grant)", "budget:requested")]),
            ("3 Signature", [("Declarations and signature by an authorised person", "manual")]),
        ]},
    "generic_nl": {
        "title": "Online application form (typical fields)",
        "source": None,
        "sections": [
            ("Organisation", [("Company name", "company.name"), ("KvK number", "company.registration_number"),
                              ("Address", "company.address"), ("Website", "company.website"), ("IBAN", "manual")]),
            ("Contact person", [("Name", "contact.name"), ("Role", "contact.role"), ("E-mail", "contact.email")]),
            ("Project", [("Project name", "project.name"), ("Start date", "project.start_date"), ("End date", "project.end_date"),
                         ("Short project description", "answer:summary")]),
            ("Budget", [("Total project costs", "budget:total"), ("Requested amount", "budget:requested")]),
            ("Declarations", [("SME status, de minimis / state aid and other declarations, signed by an authorised person", "manual")]),
        ]},
}


def focus_by_url():
    from .official_sources import canonical_url
    result = {}
    for entry in FOCUS:
        try:
            result[canonical_url(entry["url"])] = entry
        except ValueError:
            continue  # Third-party or not yet registered origins are matched by key only.
    return result


def focus_entry(record):
    """The curated entry for a catalogue record, if it is one of the focus instruments."""
    if not record:
        return None
    from .official_sources import canonical_url
    try:
        url = canonical_url(record.get("url", ""))
    except ValueError:
        return None
    return focus_by_url().get(url)


def route_for(entry, provider=None):
    key = (entry or {}).get("route") or {"rvo": "mijn_rvo", "zh": "zh_portal", "eu": "eu_portal", "snn": None}.get(provider or "")
    return {"key": key, **ROUTES[key]} if key in ROUTES else None


def focus_for_spec(spec):
    primary = next((s for s in spec.get("sources", []) if s.get("role") == "primary"), None)
    if not primary:
        return None
    return focus_entry({"url": primary.get("url", "")})


def portal_sheet(ws, app, spec, questions, calc):
    """What to type into the funder's online form, in the form's own order."""
    entry = focus_for_spec(spec)
    provider = spec.get("provider") or str(spec.get("opportunity_id", "")).split("-")[0]
    key = (entry or {}).get("portal_form", "generic_nl" if provider in {"rvo", "zh", "snn"} else None)
    form = PORTAL_FORMS.get(key or "")
    if not form:
        return None

    def fact(path):
        f = ws["facts"].get(path) or {}
        return f.get("value"), f.get("state", "missing")

    def answer(*patterns):
        import re
        for q in questions:
            if any(re.search(p, q["heading"], re.I) for p in patterns):
                text = (app["answers"].get(q["id"]) or {}).get("text", "").strip()
                if text:
                    return text, "Application answer: " + q["heading"]
        return None, None

    def euros(cents):
        return None if cents is None else f"€ {cents / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

    sections, ready, total = [], 0, 0
    for title, fields in form["sections"]:
        rows = []
        for label, source in fields:
            value, origin, status = None, None, "missing"
            if source == "manual":
                status, origin = "manual", "Fill in on the portal yourself"
            elif source.startswith("answer:"):
                kind = source.split(":", 1)[1]
                patterns = {"summary": [r"samenvatting|summary|korte omschrijving|naam en korte"], "kia": [r"\bKIA", r"kennis- en innovatie"],
                            "risk": [r"risico|knelpunt|noodzaak|risk"]}[kind]
                value, origin = answer(*patterns)
                if value is None and kind == "summary":
                    value, state = fact("project.description")
                    origin = "Profile: project description" if value else None
                status = "ready" if value else "missing"
            elif source.startswith("budget:"):
                kind = source.split(":", 1)[1]
                requested, total_cents = calc.get("requested_grant_cents"), calc.get("total_cents") if calc.get("lines") else None
                cents = {"total": total_cents, "requested": requested,
                         "own": None if requested is None or total_cents is None else max(0, total_cents - requested)}.get(kind)
                if kind in {"study", "development"}:
                    status, origin = ("check", "Split your budget total between the study (at least 60%) and development (at most 40%)") if total_cents else ("missing", None)
                    value = euros(total_cents) and "Total " + euros(total_cents)
                else:
                    value, origin, status = euros(cents), "Application budget", "ready" if cents is not None else "missing"
            else:
                paths = source.split("+")
                values = [fact(p) for p in paths]
                if any(v is not None for v, _ in values):
                    value = " ".join(str(v) for v, _ in values if v is not None)
                    if isinstance(values[0][0], bool):
                        value = "Ja" if values[0][0] else "Nee"
                    status = "check" if any(s != "confirmed" for v, s in values if v is not None) else "ready"
                    origin = "Profile"
            total += 1
            ready += status == "ready"
            rows.append({"label": label, "value": value, "status": status, "origin": origin, "source": source})
        sections.append({"title": title, "fields": rows})
    return {"title": form["title"], "source": form["source"], "sections": sections, "ready": ready, "total": total}


def verified_on(entry):
    """The day an entry was last checked against its sources; entries re-checked later carry their own date."""
    return entry["verified_on"] if "verified_on" in entry else VERIFIED_ON


def curated_condition(record, block, index, condition):
    """A hand-checked eligibility condition, quoting the "Who can apply" text it comes from."""
    from .funding_conditions import reference
    if condition["quote"] not in block["text"]:
        raise ValueError(f"Condition quote {condition['quote']!r} of {record['focus_key']} is not in its audience text")
    return {"id": f"curated-condition-{index}", "field": condition["field"], "operator": condition["operator"],
            "expected": condition["expected"], "label": condition["label"], "evidence": reference(record, block, condition["quote"]),
            "interpretation": "curated"}


def curated_record(entry):
    """A catalogue record for a focus instrument without an importable official page."""
    import hashlib
    from .funding_conditions import basic_requirements
    text = [("Purpose", entry["summary"]), ("Who can apply", entry["audience"]), ("Funding", entry["amount"]),
            ("Application period", entry["window"])]
    blocks = [{"id": f"curated-{i}", "locator": heading, "text": value, "source_url": entry["url"]} for i, (heading, value) in enumerate(text)]
    digest = hashlib.sha256(repr(sorted(entry.items())).encode()).hexdigest()
    record = {"provider": entry["provider"], "external_id": "focus:" + entry["key"], "title": entry["title"], "url": entry["url"],
                "description": entry["summary"], "tags": ["Startups", entry["region"]], "programme": entry["title"],
                "instrument": entry["instrument"], "kind": "opportunity", "language": "en", "opens_at": None, "deadlines": [],
                "source_status": None, "index_hash": digest, "detail_hash": digest, "blocks": blocks, "documents": [],
                "listing_state": "curated", "curated": True, "focus_key": entry["key"], "detail_fetched_at": verified_on(entry) + "T00:00:00+00:00",
                "cities": entry.get("cities", []), "focus_topic": entry.get("topic"), "tu_delft_only": "tu_delft_only" in entry,
                "rolling": "any time" in entry["window"].casefold() or "continuous" in entry["window"].casefold()}
    record["requirements"] = basic_requirements(record) + [curated_condition(record, blocks[1], i, condition)
                                                           for i, condition in enumerate(entry.get("conditions", []))]
    return record


def focus_requirements(key):
    """The hand-checked conditions of one focus scheme, quoting its "Who can apply" text."""
    entry = next(entry for entry in FOCUS if entry["key"] == key)
    return [condition for condition in curated_record(entry)["requirements"] if condition["interpretation"] == "curated"]


def install_focus(service, import_pages=False):
    """Mark focus instruments in the catalogue; add curated records; optionally import missing official pages."""
    from .official_sources import canonical_url, funding_page
    by_url = {}
    for record in service.db.records():
        try:
            by_url[canonical_url(record["url"])] = record
        except ValueError:
            continue
    # A scheme taken off the focus list (for example because it closed) is an ordinary catalogue record again.
    current = {entry["key"] for entry in FOCUS}
    for record in service.db.records():
        if record.get("focus_key") and record["focus_key"] not in current:
            service.db.update(record["id"], focus_key=None)
    installed = []
    for entry in FOCUS:
        try:
            url = canonical_url(entry["url"])
            importable = funding_page(url)
        except ValueError:
            url, importable = None, False
        record = by_url.get(url) if url else None
        if record is None and importable and import_pages:
            try:
                record = service.import_official(entry["url"])
            except Exception:
                record = None
        if record is None and not importable:
            record = service.db.upsert(curated_record(entry))
        rolling = bool(re.search(r"(?i)all year|any time|continuous", entry["window"]))
        if record is not None and (record.get("focus_key") != entry["key"] or bool(record.get("rolling")) != rolling
                                   or record.get("instrument") != entry["instrument"] or record.get("focus_topic") != entry.get("topic")):
            record = service.db.update(record["id"], focus_key=entry["key"], rolling=rolling, instrument=entry["instrument"],
                                       focus_topic=entry.get("topic"))
        if record is not None:
            installed.append(record["id"])
    return installed
