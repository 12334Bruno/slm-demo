"""Bounded Groq requests. Secrets stay on the server; no paid-provider fallback."""
import json
import re
import os
from copy import deepcopy
import httpx


def request_tokens(payload):
    # Conservative estimate, including schema, instructions and source metadata.
    return (len(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")) + 2) // 3


def source_groups(pieces):
    documents = {}
    for piece in pieces:
        doc = documents.setdefault(piece["document_id"], {"document_id": piece["document_id"],
            "filename": piece["filename"], "blocks": []})
        doc["blocks"].append({"block_id": piece["block_id"], "text": piece["text"]})
    return list(documents.values())


INFORMATIVE = ("kvk", "kamer van koophandel", "rechtsvorm", "b.v.", "bv ", "handelsnaam", "naam", "adres", "vestig", "opgericht",
               "medewerkers", "fte", "omzet", "turnover", "employees", "founded", "samenvatting", "summary", "project", "product",
               "dienst", "innovat", "doel", "idee", "markt", "klant", "team", "begroting", "budget", "investering", "financier",
               "subsid", "patent", "octrooi", "prototype", "pilot", "planning", "mission", "missie")


def passage_score(text, founder_answer):
    """How likely a passage states facts about this company, rather than template help or a contents line."""
    folded = text.casefold()
    if founder_answer:
        return 1000.0
    if re.search(r"\s\d{1,3}$", text.strip()) and len(text) < 120:
        return 0.0  # A table-of-contents line ("4.2 De doelgroep 12").
    score = sum(folded.count(word) for word in INFORMATIVE)
    score += 3 * len(re.findall(r"(?:^|\s)[A-ZÀ-Ý][\w/ -]{1,30}:\s", text))  # Labelled fields.
    score += 4 * len(re.findall(r"\b\d{8}\b|€\s?\d|\bEUR\s?\d|\b\d{4}\s?[A-Z]{2}\b", text))  # KvK numbers, amounts, postcodes.
    score += 2 * len(re.findall(r"(?i)\b(?:ik|wij|we|mijn|onze|ons|our|us)\b", text))  # The company speaking about itself.
    score -= 3 * len(re.findall(r"(?i)\b(?:tip|hier beschrijft u|beschrijf|geef aan|vermeld|u kunt|vul hier|laat zien)\b", text))
    return max(0.0, score) / (1 + len(text) / 2000)


class AnalysisError(Exception):
    def __init__(self, message, retry_after=None, checkpoint=None):
        super().__init__(message)
        self.retry_after = retry_after
        self.checkpoint = checkpoint


def strict_schema(schema):
    schema = deepcopy(schema)
    def visit(node):
        if isinstance(node, dict):
            node.pop("default", None)
            alternatives = node.get("anyOf")
            if isinstance(alternatives, list) and any(item.get("type") == "number" for item in alternatives):
                # JSON Schema numbers already include integers. Groq rejects an
                # overlapping integer/number union emitted by Pydantic.
                node["anyOf"] = [item for item in alternatives if item.get("type") != "integer"]
            if node.get("type") == "object":
                node["additionalProperties"] = False
                node["required"] = list(node.get("properties", {}))
            for value in node.values():
                visit(value)
        elif isinstance(node, list):
            for item in node:
                visit(item)
    visit(schema)
    return schema


class GroqCompanyAnalyzer:
    def __init__(self, transport=None):
        self.transport = transport

    @property
    def configured(self):
        from .structured_ai import configured
        return configured()

    @property
    def model(self):
        return os.getenv("GROQ_MODEL", "qwen/qwen3.8-27b")

    def __call__(self, packet):
        from .company_analysis import CompanyResult
        if not self.configured:
            raise AnalysisError("Automatic analysis is not configured on this server.")
        schema = strict_schema(CompanyResult.model_json_schema())
        confirmed = {p: f["value"] for p, f in packet["inputs"]["current_facts"].items()
                     if f["state"] == "confirmed"}

        def payload_for(pieces):
            payload = {"model": self.model, "temperature": 0, "max_completion_tokens": 900,
                "messages": [{"role": "system", "content": packet["instructions"] +
                    " Return at most four material facts from this chunk. Use one short, sufficient exact quote per fact, at most 160 characters. "
                    "Keep each value concise, at most 250 characters, preserving qualifications. Return at most two short open questions. "
                    "Do not repeat already confirmed facts unless the source contradicts them."},
                    {"role": "user", "content": json.dumps({"evidence": source_groups(pieces),
                        "confirmed_facts": confirmed, "project_primary_activity_allowed_values": packet["allowed_activity_values"]},
                        ensure_ascii=False, separators=(",", ":"))}],
                "response_format": {"type": "json_schema", "json_schema": {
                    "name": "company_analysis", "strict": True, "schema": schema}}}
            if self.model.startswith("openai/gpt-oss-"):
                # Reasoning tokens share the completion budget; leave room for the JSON itself.
                payload.update(reasoning_effort="low", include_reasoning=False, max_completion_tokens=3000)
            return payload

        # Group source IDs once per document, rather than repeating a filename
        # and UUID on every small PDF/DOCX paragraph. Budget the whole request.
        token_budget = max(2500, min(6000, int(os.getenv("SLM_AI_INPUT_TOKEN_BUDGET", "4500"))))
        batches, batch, size = [], [], 0

        def add_piece(piece):
            nonlocal batch, size
            if batch and (size + len(piece["text"]) > 7000 or request_tokens(payload_for(batch + [piece])) > token_budget):
                batches.append(batch)
                batch, size = [], 0
            if request_tokens(payload_for([piece])) > token_budget:
                if len(piece["text"]) <= 1:
                    raise AnalysisError("The saved company details exceed the AI input limit. Shorten the saved description before retrying analysis.")
                middle = len(piece["text"]) // 2
                add_piece({**piece, "text": piece["text"][:middle]})
                add_piece({**piece, "text": piece["text"][middle:]})
                return
            batch.append(piece)
            size += len(piece["text"])

        for doc in packet["inputs"]["documents"]:
            for block in doc["blocks"]:
                text = block["text"]
                for offset in range(0, len(text), 5000):
                    piece = {"document_id": doc["id"], "filename": doc["filename"],
                             "block_id": block["id"], "text": text[offset:offset + 5000]}
                    add_piece(piece)
        if batch:
            batches.append(batch)
        max_batches = max(1, min(8, int(os.getenv("SLM_AI_MAX_BATCHES", "4"))))
        total_pieces = sum(len(b) for b in batches)
        if len(batches) > max_batches:
            # Long plans: analyse the most informative passages (company details, summary, project, team,
            # finances) in document order, and report the coverage instead of failing.
            pieces = [piece for b in batches for piece in b]
            def informative(piece):
                return passage_score(piece["text"], piece.get("document_id") == "founder-answers")
            ranked = sorted(range(len(pieces)), key=lambda i: (-informative(pieces[i]), i))
            budget, chosen = max_batches * 5500, []
            for index in ranked:
                if sum(len(pieces[i]["text"]) for i in chosen) + len(pieces[index]["text"]) <= budget:
                    chosen.append(index)
            while True:
                batches, batch, size = [], [], 0
                for i in sorted(chosen):
                    add_piece(pieces[i])
                if batch:
                    batches.append(batch)
                if len(batches) <= max_batches or not chosen:
                    break
                chosen.remove(min(chosen, key=lambda i: informative(pieces[i])))  # Drop the least informative passage.
        analysed_pieces = sum(len(b) for b in batches)
        checkpoint = packet.get("checkpoint") or {}
        previous = CompanyResult.model_validate({"facts": checkpoint.get("facts", []), "open_questions": checkpoint.get("open_questions", [])})
        facts, questions, calls = list(previous.facts), list(previous.open_questions), list(checkpoint.get("calls", []))
        skipped = list(checkpoint.get("skipped", []))
        with httpx.Client(transport=self.transport, timeout=float(os.getenv("GROQ_TIMEOUT_SECONDS", "35")),
                          follow_redirects=False) as client:
            for batch_index, batch in enumerate(batches):
                if batch_index < checkpoint.get("next_batch", 0):
                    continue
                payload = payload_for(batch)
                try:
                    for attempt in range(2):
                        from .structured_ai import post_paced
                        response = post_paced(client, payload, {"Authorization": "Bearer " + os.environ["GROQ_API_KEY"]}, real=self.transport is None)
                        # One bounded retry for a generation failure. Never use
                        # failed_generation as data or expose upstream contents.
                        try:
                            generation_failed = response.status_code == 400 and response.json().get("error", {}).get("code") == "json_validate_failed"
                        except (ValueError, AttributeError):
                            generation_failed = False
                        if not generation_failed or attempt == 1:
                            break
                        payload["messages"][0]["content"] += " The previous attempt did not match the JSON schema. Return at most TWO facts and no open questions, using exact evidence IDs and short quote strings."
                except httpx.TimeoutException:
                    raise AnalysisError("Analysis timed out. Your saved information is safe; try again shortly.", 60) from None
                except httpx.HTTPError:
                    raise AnalysisError("The analysis service is temporarily unreachable.", 60) from None
                if response.status_code == 429:
                    try:
                        delay = max(30, min(3600, int(response.headers.get("retry-after", "60"))))
                    except ValueError:
                        delay = 60
                    from .structured_ai import daily_limit_reached
                    message = ("The AI plan's daily token allowance is used up. Analysis continues automatically when it frees up."
                               if daily_limit_reached(response) else "AI capacity is temporarily limited. Analysis will retry automatically.")
                    raise AnalysisError(message, delay,
                        {"facts": [f.model_dump() for f in facts], "open_questions": list(dict.fromkeys(questions))[:10],
                         "calls": calls, "next_batch": batch_index, "skipped": skipped})
                if response.status_code in {401, 403}:
                    raise AnalysisError("The server's AI credentials need attention. You can continue reviewing your information.")
                if response.status_code == 413:
                    raise AnalysisError("This request exceeds the AI provider’s input-token limit. Your saved information is safe; the server needs a smaller analysis batch size.")
                if response.status_code >= 500:
                    raise AnalysisError("The analysis service is temporarily unavailable.", 60)
                if response.is_error and generation_failed and len(batches) > 1:
                    skipped.append(batch_index)  # One unreadable chunk should not discard the rest of the analysis.
                    continue
                if response.is_error:
                    if generation_failed:
                        raise AnalysisError("The AI could not produce a valid analysis. Your saved information is unchanged. Please retry analysis.")
                    raise AnalysisError("The analysis request could not be processed. The server configuration needs review.")
                try:
                    data = response.json()
                    choice = data["choices"][0]
                    if choice.get("finish_reason") != "stop" or choice["message"].get("refusal"):
                        raise ValueError("Incomplete output")
                    result = CompanyResult.model_validate_json(choice["message"]["content"])
                except (KeyError, IndexError, TypeError, ValueError):
                    raise AnalysisError("The AI returned an incomplete or invalid analysis. Your information has not been changed.") from None
                facts.extend(result.facts)
                if len(facts) > 60:
                    raise AnalysisError("The extracted information exceeds this prototype's review limit. Use a smaller document set.")
                questions.extend(result.open_questions)
                calls.append({"response_id": data.get("id"), "model": data.get("model", self.model), "usage": data.get("usage")})
        unique = {(f.path, json.dumps(f.value, sort_keys=True), json.dumps([s.model_dump() for s in f.support], sort_keys=True)): f for f in facts}
        if skipped and len(skipped) == len(batches):
            raise AnalysisError("The AI could not produce a valid analysis. Your saved information is unchanged. Please retry analysis.")
        return CompanyResult(facts=list(unique.values()), open_questions=list(dict.fromkeys(questions))[:10]), {
            "executor": "Groq", "provider": "groq", "model": self.model, "calls": calls,
            "skipped_parts": len(skipped), "parts": len(batches), "coverage": round(analysed_pieces / max(1, total_pieces), 2)}
