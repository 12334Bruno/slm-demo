"""Bounded Groq requests. Secrets stay on the server; no paid-provider fallback."""
import json
import os
from copy import deepcopy
import httpx


class AnalysisError(Exception):
    def __init__(self, message, retry_after=None, checkpoint=None):
        super().__init__(message)
        self.retry_after = retry_after
        self.checkpoint = checkpoint


def strict_schema(schema):
    schema = deepcopy(schema)
    def visit(node):
        if isinstance(node, dict):
            node.pop("default", None)
            alternatives = node.get("anyOf")
            if isinstance(alternatives, list) and any(item.get("type") == "number" for item in alternatives):
                # JSON Schema numbers already include integers. Groq rejects an
                # overlapping integer/number union emitted by Pydantic.
                node["anyOf"] = [item for item in alternatives if item.get("type") != "integer"]
            if node.get("type") == "object":
                node["additionalProperties"] = False
                node["required"] = list(node.get("properties", {}))
            for value in node.values():
                visit(value)
        elif isinstance(node, list):
            for item in node:
                visit(item)
    visit(schema)
    return schema


class GroqCompanyAnalyzer:
    def __init__(self, transport=None):
        self.transport = transport

    @property
    def configured(self):
        return bool(os.getenv("GROQ_API_KEY")) and os.getenv("SLM_AI_ENABLED", "1") == "1"

    @property
    def model(self):
        return os.getenv("GROQ_MODEL", "qwen/qwen3.8-27b")

    def __call__(self, packet):
        from .company_analysis import CompanyResult
        if not self.configured:
            raise AnalysisError("Automatic analysis is not configured on this server.")
        # Short documents usually need one call. Long evidence is split without
        # changing the original source IDs; quotes are validated against originals.
        batches, batch, size = [], [], 0
        for doc in packet["inputs"]["documents"]:
            for block in doc["blocks"]:
                text = block["text"]
                for offset in range(0, len(text), 5000):
                    piece = {"document_id": doc["id"], "filename": doc["filename"],
                             "block_id": block["id"], "locator": block["locator"], "text": text[offset:offset + 5000]}
                    if batch and size + len(piece["text"]) > 7000:
                        batches.append(batch)
                        batch, size = [], 0
                    batch.append(piece)
                    size += len(piece["text"])
        if batch:
            batches.append(batch)
        max_batches = max(1, min(8, int(os.getenv("SLM_AI_MAX_BATCHES", "4"))))
        if len(batches) > max_batches:
            # Fail visibly rather than treating a partial company review as complete.
            raise AnalysisError("These documents need more analysis than this server's limit. Use a shorter project description or smaller document set.")
        checkpoint = packet.get("checkpoint") or {}
        previous = CompanyResult.model_validate({"facts": checkpoint.get("facts", []), "open_questions": checkpoint.get("open_questions", [])})
        facts, questions, calls = list(previous.facts), list(previous.open_questions), list(checkpoint.get("calls", []))
        schema = strict_schema(CompanyResult.model_json_schema())
        confirmed = {p: f["value"] for p, f in packet["inputs"]["current_facts"].items()
                     if f["state"] == "confirmed"}
        with httpx.Client(transport=self.transport, timeout=float(os.getenv("GROQ_TIMEOUT_SECONDS", "35")),
                          follow_redirects=False) as client:
            for batch_index, batch in enumerate(batches):
                if batch_index < checkpoint.get("next_batch", 0):
                    continue
                payload = {"model": self.model, "temperature": 0.1, "max_completion_tokens": 3000,
                    "messages": [{"role": "system", "content": packet["instructions"] +
                        " Return at most twelve material facts from this chunk. Use short, sufficient exact quotes."},
                        {"role": "user", "content": json.dumps({"evidence": batch,
                            "confirmed_facts": confirmed, "project_primary_activity_allowed_values": packet["allowed_activity_values"]})}],
                    "response_format": {"type": "json_schema", "json_schema": {
                        "name": "company_analysis", "strict": True, "schema": schema}}}
                if self.model.startswith("openai/gpt-oss-"):
                    payload.update(reasoning_effort="medium", include_reasoning=False)
                try:
                    response = client.post("https://api.groq.com/openai/v1/chat/completions", json=payload,
                        headers={"Authorization": "Bearer " + os.environ["GROQ_API_KEY"]})
                except httpx.TimeoutException:
                    raise AnalysisError("Analysis timed out. Your saved information is safe; try again shortly.", 60) from None
                except httpx.HTTPError:
                    raise AnalysisError("The analysis service is temporarily unreachable.", 60) from None
                if response.status_code == 429:
                    try:
                        delay = max(30, min(3600, int(response.headers.get("retry-after", "60"))))
                    except ValueError:
                        delay = 60
                    raise AnalysisError("AI capacity is temporarily limited. Analysis will retry automatically.", delay,
                        {"facts": [f.model_dump() for f in facts], "open_questions": list(dict.fromkeys(questions))[:10],
                         "calls": calls, "next_batch": batch_index})
                if response.status_code in {401, 403}:
                    raise AnalysisError("The server's AI credentials need attention. You can continue reviewing your information.")
                if response.status_code >= 500:
                    raise AnalysisError("The analysis service is temporarily unavailable.", 60)
                if response.is_error:
                    raise AnalysisError("The analysis request could not be processed. The server configuration needs review.")
                try:
                    data = response.json()
                    choice = data["choices"][0]
                    if choice.get("finish_reason") != "stop" or choice["message"].get("refusal"):
                        raise ValueError("Incomplete output")
                    result = CompanyResult.model_validate_json(choice["message"]["content"])
                except (KeyError, IndexError, TypeError, ValueError):
                    raise AnalysisError("The AI returned an incomplete or invalid analysis. Your information has not been changed.") from None
                facts.extend(result.facts)
                if len(facts) > 60:
                    raise AnalysisError("The extracted information exceeds this prototype's review limit. Use a smaller document set.")
                questions.extend(result.open_questions)
                calls.append({"response_id": data.get("id"), "model": data.get("model", self.model), "usage": data.get("usage")})
        unique = {(f.path, json.dumps(f.value, sort_keys=True), json.dumps([s.model_dump() for s in f.support], sort_keys=True)): f for f in facts}
        return CompanyResult(facts=list(unique.values()), open_questions=list(dict.fromkeys(questions))[:10]), {
            "executor": "Groq", "provider": "groq", "model": self.model, "calls": calls}
