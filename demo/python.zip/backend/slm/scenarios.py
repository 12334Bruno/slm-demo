"""Module 4: what-if scenarios.

A scenario is a named set of overrides. Comparing one runs the ordinary matching pipeline on a deep
copy of the workspace, so the founder's saved facts are never touched; they change only when the
founder explicitly applies a scenario (through the same fact path as a follow-up answer).
"""
from copy import deepcopy
import hashlib
import json
from .budget import calculate
from .discovery_api import apply_answer
from .domain import validate_value
from .live_matching import evaluate_all
from .matching_depth import (GROUP_ORDER, RANKING_VERSION, build_groups, check_leaves, describe_check, empty_reason,
                             evaluation_key)
from .profiles import fact_value
from .storage import touch

SCENARIO_FIELDS = {
    "project_budget_cents": "Project budget",
    "project.organisation_count": "Number of organisations",
    "project.independent_sme_participant_count": "Independent SME partners",
    "project.primary_activity": "Project activity",
    "project.start_date": "Planned start date",
    "project.description": "Project description",
}
STATUS_RANK = {"POTENTIAL_MATCH": 0, "NEEDS_INFORMATION": 1, "NEEDS_REVIEW": 2, "FIT_UNCLEAR": 3, "LOW_RELEVANCE": 4, "DOES_NOT_FIT": 5}
OUTCOME_RANK = {"PASS": 0, "NOT_APPLICABLE": 0, "MANUAL_REVIEW": 1, "UNKNOWN": 2, "CONFLICT": 2, "FAIL": 3}
DISCLAIMER = ("Scenario results are not saved to your project. They show how the conditions read from each call would "
              "evaluate if these details were different; they do not establish eligibility.")


def normalise_changes(changes):
    if not isinstance(changes, dict) or not changes:
        raise ValueError("Choose at least one change to compare")
    clean = {}
    for field, value in changes.items():
        if field not in SCENARIO_FIELDS:
            raise ValueError("Unsupported scenario field: " + str(field))
        label = SCENARIO_FIELDS[field]
        if value is None or (isinstance(value, str) and not value.strip()):
            raise ValueError(label + " needs a value")
        if field == "project_budget_cents":
            if type(value) is not int or not 0 <= value <= 100_000_000_000:
                raise ValueError("Project budget must be nonnegative EUR cents")
        elif field == "project.organisation_count":
            if type(value) is not int or not 1 <= value <= 1000:
                raise ValueError("Organisation count must be a positive whole number")
        elif field == "project.independent_sme_participant_count":
            if type(value) is not int or not 0 <= value <= 1000:
                raise ValueError("Independent SME partners must be a whole number from 0 to 1000")
            value = validate_value(field, value)
        elif field == "project.description":
            if not isinstance(value, str) or not 5 <= len(value.strip()) <= 12000:
                raise ValueError("Project description must be 5 to 12000 characters")
            value = value.strip()
        else:
            value = validate_value(field, value)
        clean[field] = value
    return clean


def current_value(ws, field):
    intake = ws.get("discovery_intake", {})
    if field == "project_budget_cents":
        return calculate(ws)["project_total_cents"] if ws["budget_lines"] else intake.get("budget_cents")
    if field == "project.organisation_count":
        return intake.get("organisation_count")
    value = fact_value(ws, field)
    return value[:300] + "…" if isinstance(value, str) and len(value) > 300 else value


def scenario_workspace(ws, changes):
    """A throw-away copy with the overrides applied; the original is never modified."""
    copy, notes = deepcopy(ws), []
    for field, value in changes.items():
        if field == "project_budget_cents" and copy["budget_lines"]:
            copy["budget_lines"] = []
            notes.append("The scenario budget replaces your uploaded budget table for this comparison only.")
        apply_answer(copy, field, value, "Scenario (not applied)")
    return copy, notes


def snapshot(item):
    if item is None:
        return None
    ranking = item["ranking"]
    return {"status": item["match_status"], "group": item["group"], "position": ranking["position"], "of": ranking["of"],
            "schedule": item["schedule"]["status"], "summary": ranking["summary"],
            "ranking_information": ranking["information"]["value"],
            "actionable_changes": [c["change"] for c in item["actionable_changes"]]}


def transition_text(before, after, check):
    verb = {"PASS": "Now meets", "NOT_APPLICABLE": "No longer applies", "MANUAL_REVIEW": "Now needs a person's judgement",
            "UNKNOWN": "Now unknown", "CONFLICT": "Now conflicting"}.get(after)
    if after == "FAIL":
        verb = "No longer meets" if before == "PASS" else "Now does not meet"
    return f"{verb}: {describe_check(check)}"


def changed_checks(before, after):
    if before is None or after is None:
        return []
    previous = {c["id"]: c for c in before["checks"]}
    changed = []
    for check in after["checks"]:
        old = previous.get(check["id"])
        if old is None or old["outcome"] == check["outcome"]:
            continue
        leaves = check_leaves(check)
        changed.append({"id": check["id"], "label": check.get("label"), "field": check.get("field") or (leaves[0]["field"] if len(leaves) == 1 else None),
                        "before": old["outcome"], "after": check["outcome"],
                        "direction": "better" if OUTCOME_RANK[check["outcome"]] < OUTCOME_RANK[old["outcome"]] else "worse",
                        "text": transition_text(old["outcome"], check["outcome"], check),
                        "actual_before": check_leaves(old)[0]["actual"] if len(check_leaves(old)) == 1 else None,
                        "actual_after": leaves[0]["actual"] if len(leaves) == 1 else None,
                        "evidence": check.get("evidence")})
    return changed


def movement(before, after, checks):
    if before is None:
        return "newly_relevant"
    if after is None:
        return "no_longer_relevant"
    old = (GROUP_ORDER.index(before["ranking"]["group"]), STATUS_RANK[before["match_status"]])
    new = (GROUP_ORDER.index(after["ranking"]["group"]), STATUS_RANK[after["match_status"]])
    if new != old:
        return "improved" if new < old else "worsened"
    directions = {c["direction"] for c in checks}
    return "improved" if directions == {"better"} else "worsened" if directions == {"worse"} else "unchanged"


def side_summary(text, items):
    groups = build_groups(items, items)
    return {"counts": {key: groups[key]["count"] for key in GROUP_ORDER}, "empty_reason": empty_reason(text, items),
            "top": [i["id"] for i in items if i["group"] == "pursue_now"][:3]}


def used_fields(*item_lists):
    fields = set()
    for items in item_lists:
        for item in items:
            for check in item["checks"]:
                fields.update(leaf["field"] for leaf in check_leaves(check))
    return fields


def compare(service, ws, changes, mode="basic"):
    """Before/after matching for a set of overrides; cached by facts, changes, specifications and catalogue."""
    if mode not in {"basic", "model"}:
        raise ValueError("Unknown processing mode")
    changes = normalise_changes(changes)
    signature, heads = service.db.catalogue_signature(), service.db.spec_heads()
    clock = service.clock() if service.clock else None
    from .relevance import current_assessments
    records = service.db.records()
    after_ws, notes = scenario_workspace(ws, changes)
    before_fit = current_assessments(service, ws, records)
    after_fit = current_assessments(service, after_ws, records)
    fit_key = hashlib.sha256(json.dumps([before_fit, after_fit], sort_keys=True).encode()).hexdigest()
    key = evaluation_key(ws, signature, heads, clock, changes, scope="scenario:" + fit_key)
    cached = service.db.cached_comparison(ws["id"], key)
    if cached is not None:
        service.cache_hits += 1
        return {**cached, "cached": True}
    service.scenario_runs += 1
    before_text, before_items = evaluate_all(records, ws, clock, service.retained_specifications(service.open_candidates(records, ws, clock)), relevance=before_fit)
    after_text, after_items = evaluate_all(records, after_ws, clock, service.retained_specifications(service.open_candidates(records, after_ws, clock)), relevance=after_fit)
    before_by_id, after_by_id = {i["id"]: i for i in before_items}, {i["id"]: i for i in after_items}
    rows = []
    for rid in dict.fromkeys([i["id"] for i in before_items] + [i["id"] for i in after_items]):
        before, after = before_by_id.get(rid), after_by_id.get(rid)
        source = after or before
        checks = changed_checks(before, after)
        move = movement(before, after, checks)
        rows.append({"id": rid, "title": source["title"], "provider": source["provider"], "url": source["url"],
                     "instrument": source["instrument"], "movement": move, "before": snapshot(before), "after": snapshot(after),
                     "group_changed": bool(before and after and before["group"] != after["group"]),
                     "position_change": (before["ranking"]["position"] - after["ranking"]["position"]) if before and after else None,
                     "changed_checks": checks})
    order = {"improved": 0, "newly_relevant": 1, "worsened": 2, "no_longer_relevant": 3, "unchanged": 4}
    rows.sort(key=lambda r: (order[r["movement"]], (r["after"] or r["before"])["position"]))
    unchanged = [r for r in rows if r["movement"] == "unchanged"]
    shown = [r for r in rows if r["movement"] != "unchanged"] + unchanged[:10]
    counts = {name: sum(r["movement"] == name for r in rows) for name in order}
    used = used_fields(before_items, after_items)
    for field in changes:
        if field == "project.start_date":
            notes.append("The planned start date is not tested by any condition read from these calls; it only appears in timing notes.")
        elif field != "project.description" and field not in used:
            notes.append(f"No condition read from the retained calls depends on {SCENARIO_FIELDS[field].lower()}, so this change cannot alter any outcome yet.")
    result = {"workspace_id": ws["id"], "mode": mode, "cached": False, "key": key, "algorithm": RANKING_VERSION,
              "changes": [{"field": f, "label": SCENARIO_FIELDS[f], "before": current_value(ws, f), "after": v,
                           "no_change": current_value(ws, f) == v} for f, v in changes.items()],
              "notes": notes, "disclaimer": DISCLAIMER, "grants": shown, "unchanged_total": len(unchanged),
              "summary": {**counts, "text": ", ".join(f"{n} {name.replace('_', ' ')}" for name, n in counts.items() if n) or "No matching options either way"},
              "before": side_summary(before_text, before_items), "after": side_summary(after_text, after_items)}
    service.db.save_comparison(ws["id"], key, result)
    return result


def apply_scenario(store, wid, changes, expected_revision, name=None):
    """Explicitly write a scenario into the real profile, via the follow-up answer path."""
    changes = normalise_changes(changes)
    with store.edit(wid, expected_revision) as ws:
        if "project_budget_cents" in changes and ws["budget_lines"]:
            raise ValueError("Your project budget comes from your uploaded budget table. Edit the table to change it; "
                             "a scenario cannot overwrite it.")
        paths = []
        for field, value in changes.items():
            apply_answer(ws, field, value, "Founder applied scenario")
            paths += [field, "budget"] if field == "project_budget_cents" else [field]
        touch(ws, paths, "Founder applied scenario" + (": " + name if name else ""))
    return store.load(wid)
