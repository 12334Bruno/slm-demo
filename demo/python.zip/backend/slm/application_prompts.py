"""Distinguish applicant input prompts from conditions and document references."""
import re


def reference_fragment(text):
    return bool(re.match(
        r"(?i)^\s*(?:(?:as\s+)?(?:described|defined|specified|set out|laid down|detailed|listed|referred to)\s+(?:in|under)|"
        r"(?:see|refer to|according to|in accordance with)\s+(?:the\s+)?(?:annex|appendix|article|section)|"
        r"(?:zoals\s+)?(?:beschreven|bepaald|vermeld)\s+in)\b", text))


def input_prompt(text, heading=False):
    """Headings are allowed only for sourced form sections, never arbitrary rules."""
    text = re.sub(r"^\s*\d+(?:\.\d+)*[.)]?\s+", "", text).strip()
    if not text or reference_fragment(text):
        return False
    request = re.sub(r"(?i)^(?:the\s+)?(?:applicants?|you)\s+(?:must|should|shall|are required to)\s+", "", text)
    if re.match(r"(?i)^(?:please\s+)?(?:describe|explain|outline|summari[sz]e|detail|demonstrate|justify|provide|list|indicate|show|"
                r"beschrijf|licht toe|motiveer|onderbouw|geef aan|geef een|omschrijf|leg uit|toon aan|maak (?:duidelijk|aannemelijk))\b", request):
        return True
    if re.match(r"(?i)^(?:what|how|why|when|which|who|is|are|does|do|wat|hoe|waarom|wanneer|welke|wie|is|zijn|heeft|bent)\b", text) and "?" in text:
        return heading or bool(re.search(r"(?i)\b(?:your|you|project|proposal|organisation|organization|uw|jouw|voorstel)\b", text))
    if not heading:
        return False
    if re.search(r"(?i)\b(?:not eligible|ineligible|are eligible|is eligible|must be established|must be registered|"
                 r"are not eligible|is not eligible|cannot participate|may not participate|are excluded|"
                 r"niet in aanmerking|komen in aanmerking)\b", text):
        return False
    if re.match(r"(?i)^(?:only\s+)?(?:legal entities|entities|applicants?|beneficiaries|participants?|undertakings|companies)\b", text) and re.search(
            r"(?i)\b(?:must|shall|cannot|may not|are required|are|is)\b", text):
        return False
    if re.match(r"(?i)^(?:general (?:conditions|annexes|instructions)|legal basis|eligibility conditions|"
                r"terms and conditions|references|instructions|how to apply|who can apply)\b", text):
        return False
    return True
