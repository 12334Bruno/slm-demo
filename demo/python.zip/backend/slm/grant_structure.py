"""Turn official grant documents into a small set of applicable, readable items.

Official pages mix four very different things: what the call is for, who may apply,
what to submit, and what happens after an award. Treating every sentence as a
requirement produced hundreds of checks. Here every block inherits the section it
sits in (its heading chain), list items stay attached to their lead-in sentence,
and each resulting item gets one plain kind:

* ``condition``  - something the applicant or project must meet (eligibility)
* ``document``   - a file to prepare and attach
* ``step``       - something to do on the funder's website
* ``funding``    - amounts, rates and cost rules
* ``assessment`` - how proposals are scored
* ``timing``     - dates and deadlines
* ``info``       - context that is useful to read but needs no action

Later-stage material (reporting, payments, changes after an award), definitions and
reference lists never become tasks. All text is kept verbatim; labels are shortened
only at word or sentence boundaries and the full text always travels with them.
"""
import re
from .application_prompts import input_prompt

SECTION_PATTERNS = [
    ("post_award", r"na uw aanvraag|na de aanvraag|na toekenning|na afloop|als uw project wijzigt|wijzigingen? (?:doorgeven|melden)|"
                   r"voortgang|vaststelling|verantwoord|rapportage|eindrapport|uitbetal|bevoorschot|betaling|controle|tijdens uw project|"
                   r"uw verplichtingen|after (?:you apply|submission|the award|award|selection)|grant agreement preparation|"
                   r"reporting|payments?\b|amendments?|terminat|audits?\b|checks and audits|obligations of (?:the )?beneficiar|"
                   r"during the project|project implementation and|communication, dissemination and visibility obligations|"
                   r"results? ownership"),
    ("definitions", r"^(?:wat is|wat zijn|what is|what are)\b|definiti|begrippen|glossary|uitleg van|explanation of terms|^example"),
    ("reference", r"wijzigingen in \d{4}|changes in \d{4}|what'?s new|wat verandert|actualiteit|nieuws|aandachtspunten|intermediair|"
                  r"wel of geen intermediair|publicaties|quick ?scan|wijzer$|^tips?\b|webinar|vragenuur"),
    ("reference", r"additional documents|meer informatie|meer weten|more information|^contact|hulp nodig|vragen\?|downloads?$|gerelateerd|related|"
                  r"wet- en regelgeving|regelgeving|legal basis|officiële bekendmakingen|nieuws|^footnotes?|^links?$|"
                  r"veelgestelde vragen|frequently asked|history of changes|table of contents|inhoudsopgave|informatieve documenten|"
                  r"application and evaluation forms|evaluation form templates|model grant agreement"),
    ("assessment", r"beoordel|award criteria|award:|evaluation|rangschik|tender|selection criteria|scoring|score|"
                   r"aspects to be taken into account|hoe.{0,20}beoordeeld|how.{0,20}assessed"),
    ("timing", r"aanvraagperiode|openstelling|deadline|wanneer|timeline|tijdlijn|planning en|termijn|dates|aanvraagperiode|closing|"
               r"opening|indicative timeline|submission deadline"),
    ("funding", r"beschikbaar|per aanvrager|lening|rente|aflossing|aflossen|terugbetal|repay|interest rate|pandovereenkomst|hoeveel|bedrag|subsidiebedrag|subsidiepercentage|subsidiabele kosten|budget|kosten|costs?\b|funding rate|"
                r"financial and operational|legal and financial|financ|lump sum|forfait|de hoogte"),
    ("apply", r"aanvragen|aanvraag doen|aanvraag indienen|zo vraagt u|hoe vraagt|how to apply|submission|indienen|application form|"
              r"aanvraagformulier|wat stuurt u mee|stuurt u mee|bijlagen|attachments|supporting documents|documents to|documenten|^documents?$|"
              r"required documents|what to submit|nodig om (?:een )?aanvraag|needed to apply|doorgeven|aanleveren|invullen|bsn|burgerservicenummer|"
              r"stappen|aanvraagproces|proposal page limit|admissibility|layout"),
    ("eligibility", r"voor wie|wie kan|wie komt|who can|who may|eligib|voorwaarden|conditions|uzelf|uw groep|aanvragers?|\beisen\b|doelgroep|"
                    r"applicants?|participants?|consortium|samenwerkingsverband|deelnemers|uw project|your project|"
                    r"wat moet u|requirements|vereisten|restrictions|beperkingen|exclusion|uitsluiting"),
    ("purpose", r"doel|expected outcome|expected impact|objectives?|scope|waarvoor|wat houdt|achtergrond|over deze|introduction|"
                r"inleiding|background|purpose|aim\b|topic description|description|focus|thema|wat kunt u"),
]
COMPILED = [(kind, re.compile(pattern, re.I)) for kind, pattern in SECTION_PATTERNS]
# Short labels such as "Expected Outcome:" act as headings inside long call descriptions.
PSEUDO_HEADING = re.compile(r"(?i)^(?:expected outcomes?|expected impact|scope|objectives?|specific conditions|"
                            r"technology readiness level|legal and financial set-up|eligibility|admissibility|doel|"
                            r"voorwaarden|voor wie|hoeveel subsidie)\b[^.]{0,80}:$")
UI_LABEL = re.compile(r"(?i)^(?:naar de |naar het |ga naar |doe de |aanvraag beheren|wijziging doorgeven|voortgang doorgeven|direct (?:aanvragen|regelen)|"
                      r"inloggen|naar (?:het )?(?:e-?loket|mijn rvo)|lees (?:meer|verder)|bekijk|download|apply now|"
                      r"read more|see also|open|sluiten|terug|home|print|deel deze pagina|share)\b")
LATER_STAGE = re.compile(
    r"(?i)after (?:the )?(?:award|grant agreement|signature|selection)|during (?:the )?grant (?:agreement )?preparation|"
    r"grant preparation stage|if (?:your project|the proposal) is (?:selected|funded)|successful applicants|selected (?:beneficiaries|proposals)|"
    r"invited to (?:start )?grant agreement|beneficiaries must|the beneficiary (?:must|shall)|na toekenning|na afloop van uw project|"
    r"tijdens (?:de uitvoering|uw project)|bij (?:de )?vaststelling|voortgangsrapport|eindrapport|na afloop van (?:uw|het) project|"
    r"periodic report|final report|payment request|interim payment|pre-?financing|after the end of the (?:action|project)|"
    r"granting authority may,? (?:up to|at any time)|object to a transfer|exclusive licensing of results|"
    r"tijdens het intakegesprek|nadat (?:u (?:uw|een) aanvraag|de adviseurs)|na ontvangst van uw aanvraag|managementoverleg|"
    r"after (?:you have )?submi(?:t|ssion)|once (?:you have )?submitted|after receiving your application")
CONDITIONAL = re.compile(r"(?i)\bunless\b|\bexcept\b|\btenzij\b|depending on|\bafhankelijk\b|\bif\b|\bindien\b|\bmits\b|"
                         r"voor zover|otherwise provided|where (?:applicable|relevant)|in some cases|for some calls")
DOCUMENT_WORDS = re.compile(
    r"(?i)\b(financ(?:ial|ing) (?:statement|plan|report)s?|annual (?:accounts|report)s?|audited accounts|jaarrekening(?:en)?|"
    r"bank statement|business ?plan|ondernemingsplan|project ?plan|projectplan|work plan|consortium agreement|samenwerkingsovereenkomst|"
    r"letters? of (?:support|intent|commitment)|support(?:ing)? letters?|intentieverklaring|steunbrief|"
    r"(?:signed|completed|ondertekend(?:e)?) (?:application )?(?:form|declaration|verklaring)|de minimis(?:-verklaring)?|"
    r"certificate|registration (?:extract|document)|uittreksel|kvk-uittreksel|proof of|curriculum vitae|\bCVs?\b|"
    r"budget (?:spreadsheet|breakdown|table)|begroting|liquiditeitsbegroting|offertes?|quotations?|insurance|ethics (?:self-assessment|statement|approval)|"
    r"data management plan|technical report|feasibility report|impact report|participation (?:sheet|form)s?|deelnemersformulier|"
    r"machtigingsformulier|machtiging|bijlagen?|annex(?:es)?|attachments?|part b|technical description|"
    r"financieringsverklaring|exploitatiebegroting|marktanalyse|market analysis)\b")
UPLOAD_WORDS = re.compile(r"(?i)\b(upload(?:ed|ing)?|attach(?:ed|ing)?|enclose|meesturen|stuurt u mee|voeg(?:t)? .{0,30}bij|bijvoegen|"
                          r"must (?:be )?(?:provide|submit)|provide|submit|indienen|lever(?:t)? .{0,20}aan|aanleveren)\b")
STEP_WORDS = re.compile(r"(?i)\b(eherkenning|e-?loket|mijn rvo|mijn snn|portal|submission system|online (?:form|application)|"
                        r"participant register|\bPIC\b|register (?:your|the) organisation|log in|inloggen|digitaal indienen|"
                        r"via (?:the )?(?:website|portal)|machtig(?:ing|en)|aanvraagformulier invullen|funder'?s? website|"
                        r"on the (?:funder'?s? )?website|op de website|online (?:via|in)|webform|web forms?)\b")
DESCRIPTIVE = re.compile(r"(?i)^(?:het|de|deze|dit|this|the|a|an)\s+(?:[\w-]+\s+){0,4}(?:is|zijn|was|are)\s+(?:een|a|an|bedoeld|intended|meant)\b|"
                         r"^(?:voor|for)\s+(?:het|de|this|the)\s+[\w-]+\s+(?:maken|make)\s+wij")
# Who or what a condition is about: the applicant, the company or the project.
SCHEME_GIVES = re.compile(r"(?i)^[\w&’'-]+(?:\s[\w&’'-]+)?\s+(?:geeft|biedt|verstrekt|provides|offers|gives)\b")
APPLICANT = re.compile(r"(?i)\b(?:u|uw|je|jij|jouw|jullie|you|your|applicants?|aanvrager[s]?|onderneming(?:en)?|bedrijf|bedrijven|ondernemers?|"
                       r"entrepreneurs?|compan(?:y|ies)|organi[sz]ations?|firms?|businesses|founders?|"
                       r"mkb|smes?|startups?|starters?|projects?|project(?:en)?|ontwikkeling|onderzoek|research|development|aanvraag|"
                       r"application|product(?:en)?|proces|consortium|partners?|samenwerking|kosten|costs?)\b")
POSSIBILITY = re.compile(r"(?i)^(?:in een aantal situaties|in sommige gevallen|in overleg met|twijfelt u|om ervoor te zorgen|in some cases|if in doubt)\b|"
                         r"\b(?:kunt u rekenen op|is het mogelijk|kunt u extra|you can (?:also )?(?:get|receive)|it is possible)\b")
COST_RULE = re.compile(r"(?i)\b(?:loonkosten|uurtarief|uurloon|productieve uren|hourly rates?|personnel costs?|subsidiepercentages?|funding rates?)\b")
MONEY_FACT = re.compile(r"(?i)€|\bEUR\b|%|\bprocent\b|\bbedraagt\b|\bborg voor\b|subsidiepercentage")
STRONG_MODAL = re.compile(r"(?i)\b(?:must|shall|required|moet(?:en)?|dient|dienen|verplicht|vereist|only|alleen|uitsluitend|"
                          r"cannot|may not|niet|geen|not eligible|minimaal|maximaal|at least|ten minste|maximum|minimum)\b")
META_CONDITION = re.compile(r"(?i)\b(?:aan|meet|satisfy|fulfil)\b.{0,30}\b(?:verschillende|de volgende|een aantal|enkele|alle|deze|these|the following|several|all (?:the )?)\b.{0,20}"
                            r"\b(?:voorwaarden|eisen|criteria|conditions|requirements)\b|gelden (?:enkele|de volgende) regels|"
                            r"(?:the following|de volgende) (?:conditions|requirements|voorwaarden|eisen) (?:apply|gelden)|"
                            r"\b\d+\s+(?:kern)?criteria (?:gedefinieerd|vastgesteld)|criteria (?:gedefinieerd|vastgesteld) die bepalen|"
                            r"(?:zijn|gelden) (?:er )?(?:verschillende|een aantal|enkele|diverse) (?:aanvullende |andere )?(?:voorwaarden|eisen|regels)|"
                            r"(?:there are|are) (?:several|a number of|some) (?:additional |other )?(?:conditions|requirements)|"
                            r"hieronder staan de voorwaarden|below (?:are|you find) the conditions")
ACTION_WORDS = re.compile(r"(?i)\b(must|shall|should|required|need to|have to|may only|only|cannot|may not|not eligible|eligible|"
                          r"moet(?:en)?|dient|dienen|verplicht|vereist|alleen|uitsluitend|minimaal|maximaal|ten minste|tenminste|"
                          r"niet|geen|mag|mogen|kunt|kan|komt in aanmerking|voldoe[nt]|maximum|minimum|at least|at most|up to|"
                          r"no more than|not more than|limited to)\b")


def clean(text):
    return " ".join(re.sub(r"[\ufeff\u200b\u200c\u200d\u00ad]", "", str(text)).split())


FILE_NOTE = re.compile(r"\s*\((?:pdf|docx?|xlsx?|odt|zip)(?:,\s*[\d.,]+\s*[kKmM]?B)?\)|\s*(?:PDF|Word|Excel) document\s*\|\s*[\d.,]+\s*[KM]B", re.I)


def short_label(text, limit=150):
    """A readable label: the first sentence or clause, cut only at a word boundary."""
    text = re.sub(r"\s+([.,;:])", r"\1", FILE_NOTE.sub("", clean(text)))
    if len(text) <= limit:
        return text
    sentence = re.match(r"^(.{40,%d}?[.!?;:])(?:\s|$)" % limit, text)
    if sentence:
        if sentence[1].endswith(":"):
            return sentence[1] + " …"  # A lead-in: the list it introduces continues in the full text.
        return sentence[1].rstrip(";")
    clause = re.match(r"^(.{50,%d}?)[,–—(](?:\s|$)" % limit, text)
    if clause:
        return clause[1].rstrip(" ,") + "…"
    cut = text.rfind(" ", 0, limit)
    return text[:cut if cut > limit // 2 else limit].rstrip(" ,;:-–") + "…"


def heading_title(text):
    """Heading text without numbering noise or trailing colons."""
    text = re.sub(r"^\s*Topic\s*/\s*\w+\s*/\s*", "", clean(text))
    return text.rstrip(":").strip()


def section_kind(path):
    """Kind of the nearest heading that we recognise; parent headings fill gaps."""
    for heading in reversed(path):
        title = heading_title(heading)
        for kind, pattern in COMPILED:
            if pattern.search(title):
                return kind
    return None


def block_heading(block, doc):
    """HTML providers store the nearest heading text in the locator."""
    locator = block.get("locator", "")
    if doc.get("format") in {"html", "text"} or doc.get("role") == "primary":
        if locator.startswith("Topic /"):
            return heading_title(locator.split("/")[-1])
        if locator and locator not in {"Official page", "Published application status"}:
            return locator
    return None


def walk(doc):
    """Yield (block, heading path, is_heading) keeping a heading stack per document."""
    stack = []
    for block in doc.get("blocks", []):
        text = clean(block.get("text", ""))
        level = block.get("heading_level")
        if not level and PSEUDO_HEADING.match(text):
            level = 6
        if level:
            stack = [entry for entry in stack if entry[0] < level] + [(level, text)]
            yield block, [t for _, t in stack], True
            continue
        path = [t for _, t in stack]
        located = block_heading(block, doc)
        if located and (not path or heading_title(path[-1]) != heading_title(located)):
            path = path + [located]
        yield block, path, False


def looks_like_list_item(block, previous):
    if block.get("list_item"):
        return True
    if "list_item" in (previous or {}):
        return False
    text = clean(block["text"])
    return len(text) < 260 and not re.match(r"(?i)^(?:let op|note|meer informatie|lees|bekijk)\b", text) and (
        text[:1].islower() or text.endswith((";", ",")) or re.search(r"(?i)\b(?:of|en|or|and)$", text) or not text.endswith("."))


def grouped_items(doc):
    """Paragraphs, with list items attached to the lead-in sentence that introduces them."""
    items, lead = [], None
    previous_block = None
    for block, path, is_heading in walk(doc):
        if is_heading:
            lead = None
            previous_block = None
            continue
        text = clean(block["text"])
        if not text:
            continue
        if lead is not None and lead["path"] == path and len(lead["parts"]) < 25 and looks_like_list_item(block, previous_block if previous_block is not lead["blocks"][0] else None):
            lead["parts"].append(text)
            lead["blocks"].append(block)
            if text.endswith(".") and not block.get("list_item"):
                lead = None  # A full stop closes a list written as separate lines.
            previous_block = block
            continue
        item = {"text": text, "parts": [], "blocks": [block], "path": path}
        items.append(item)
        lead = item if text.endswith(":") else None
        previous_block = block
    result = []
    for item in items:
        parts = item["parts"]
        sentences = [p for p in parts if p[:1].isupper() and (len(p) > 60 or len(p) > 40 and p.rstrip().endswith((".", "?", "!", ";")))]
        if parts and len(sentences) * 2 > len(parts):
            # Full-sentence list items are separate points; the lead-in stays as their context.
            result.append({**item, "parts": [], "blocks": item["blocks"][:1], "lead": True})
            for part, block in zip(parts, item["blocks"][1:]):
                result.append({"text": part, "parts": [], "blocks": [block], "path": item["path"], "context": item["text"]})
            continue
        if parts:
            item["text"] = item["text"] + " " + " ".join("• " + part.rstrip(";,") for part in parts)
        result.append(item)
    return result


def background_kind(text):
    """"funding" or "info" for a sentence in a conditions list that states no condition; None when it may be one."""
    first = re.split(r"(?<=[.!?:])\s", text, maxsplit=1)[0]
    if STRONG_MODAL.search(first):
        return None
    if MONEY_FACT.search(first) or COST_RULE.search(first):
        return "funding"  # "The maximum grant is EUR 500,000 per project", "RVO uses 1650 productive hours": budget facts.
    if POSSIBILITY.search(first) or SCHEME_GIVES.match(first):
        return "info"  # "In some situations you can get extra support", "Eurostars gives projects financial support".
    if not APPLICANT.search(first):
        return "info"  # Neither about the applicant nor the project, and no rule: background ("The cabinet's policy stays stable").
    return None


def item_kind(text, section, context=""):
    """One plain kind per item; the section decides first, wording second."""
    if section in {"post_award", "definitions", "reference"}:
        return None
    if re.match(r"(?i)^(?:wilt|wil|bent|heeft|gaat|kunt|zoekt|do you|are you|would you|want to|need)\b[^.!]{0,200}\?", text):
        return "info"  # An introductory question addressed to the reader.
    if re.match(r"(?i)^(?:deze|de volgende|onderstaande|the following|these|below)\s+(?:bijlagen|documenten|documents|attachments)\b", text):
        return "info"  # Introduces the documents list.
    if META_CONDITION.search(text) and len(text) < 260:
        return "info"  # "You must meet the following conditions:" introduces checks; it is not one.
    if context and section == "eligibility" and (ACTION_WORDS.search(context) or context.endswith(":")):
        if DOCUMENT_WORDS.search(text) and UPLOAD_WORDS.search(text):
            return "document"
        return background_kind(text) or "condition"
    if LATER_STAGE.search(text):
        return None
    has_document = bool(DOCUMENT_WORDS.search(text))
    if section == "apply":
        if STEP_WORDS.search(text):
            return "step"
        if UPLOAD_WORDS.search(text) and (has_document or re.search(r"(?i)\b(?:documents?|bestand(?:en)?|files?|bijlagen?)\b", text)):
            return "document"
        if UPLOAD_WORDS.search(text):
            return "step"
        return "document" if has_document and len(text) < 160 else "info"
    if section == "assessment":
        return "assessment"
    if section == "timing":
        return "timing"
    if section == "funding":
        return "funding"
    if section == "eligibility":
        if has_document and UPLOAD_WORDS.search(text):
            return "document"
        first = re.split(r"(?<=[.!?])\s", text, maxsplit=1)[0]
        if META_CONDITION.search(first) and len(first) < 260:
            return "info"
        if not STRONG_MODAL.search(text) and re.search(r"(?i)\b(?:see|zie|lees|consult|raadpleeg|more information|meer informatie)\b", text):
            return "info"  # Background with a pointer elsewhere, not a condition to answer.
        if DESCRIPTIVE.match(text) and not ACTION_WORDS.search(text.split(".")[0]):
            return "info"  # "The Innovation Credit is a loan ..." describes the scheme; it is not a condition.
        if re.match(r"(?i)^(?:let op|note|tip|lees|bekijk|zie|see|meer informatie|bijvoorbeeld|for example|voorbeeld)\b", text) and not ACTION_WORDS.search(text):
            return "info"
        return background_kind(text) or "condition"
    if section == "purpose":
        return "purpose"
    # Unknown section: rely on wording, conservatively.
    if UPLOAD_WORDS.search(text) and (has_document or re.search(r"(?i)\bdocuments?\b", text)) and not STEP_WORDS.search(text):
        return "document"
    if re.search(r"(?i)\b(must|shall|moet|dient|verplicht|vereist|uitsluitend|only (?:legal entities|applicants|smes?|companies))\b", text) and re.search(
            r"(?i)\b(applicants?|aanvragers?|u |uw |company|bedrijf|onderneming|entity|entities|consortium|project|smes?|mkb)", text):
        return "condition"
    if re.search(r"(?i)(?:EUR|€)\s*\d|\d\s*%", text) and re.search(r"(?i)subsidie|grant|funding|bijdrage|contribution", text):
        return "funding"
    return None


def junk(text):
    """Navigation labels, bare link titles and page furniture."""
    if len(text) < 18 and not re.search(r"\d", text) and not DOCUMENT_WORDS.search(text):
        return True  # Short labels are navigation, unless they name a document ("Projectplan", "Begroting").
    if re.match(r"(?i)^(?:de inhoud van deze pagina is gecontroleerd|this page (?:was )?(?:last )?(?:checked|updated|reviewed)|"
                r"laatst (?:gewijzigd|bijgewerkt)|last (?:updated|modified)|succes met uw aanvraag|ministerie van|"
                r"vraag .{3,60} aan\.?$|apply for .{3,60}\.?$)", text):
        return True
    if UI_LABEL.match(text) and len(text) < 80:
        return True
    if re.search(r"(?i)\b(?:PDF|Word|Excel) document\s*\|\s*[\d.,]+\s*[KM]B\b", text):
        return True  # A download link label, not a sentence.
    if re.fullmatch(r"\[\d+\].*", text) or re.match(r"(?i)^(?:page \d+|pagina \d+)\b", text):
        return True
    words = re.findall(r"[A-Za-zÀ-ÿ]{2,}", text)
    return len(words) < 3 and not DOCUMENT_WORDS.search(text)


def with_heading(text, path):
    """A fragment that starts mid-sentence ("described in Annex B ...") reads better with its heading."""
    if text[:1].islower() and path:
        return heading_title(path[-1]) + ": " + text
    return text


# --- application form structure ----------------------------------------------------------------

FORM_SKIP = re.compile(r"(?i)^(?:table of contents|contents$|inhoud(?:sopgave)?$|history of changes|definitions|title of the proposal|"
                       r"list of participants|cover page|annex(?:es)? to (?:the )?proposal|important notice|instructions?)\b")
PART_A = re.compile(r"(?i)\bpart a\b|administrative (?:forms|data)|application forms? proposal id")
PART_B = re.compile(r"(?i)technical description\s*\(?\s*part b|proposal template:?\s*part b|part b\)?:?\s*technical description|"
                    r"^(?:format |model )?project ?plan\b|^projectplan\b|^aanvraagformulier\b|^application form\b")
TABLE_HEADING = re.compile(r"(?i)^table\s+\d")
PAGE_HINT = re.compile(r"\[(?:e\.g\.\s*)?([^\]]*?\b(\d{1,3})\s*pages?\b[^\]]*)\]", re.I)
LIMIT = re.compile(r"(?i)(?:maximum|maximaal|max\.?|no more than|niet meer dan|up to)\s*(\d{1,5})\s*(words|woorden|characters|tekens|pages|pagina'?s)")


def form_sections(doc):
    """Writing sections of an official form/template: numbered headings plus their instructions.

    Part A of EU forms is filled in online; only Part B (the narrative) becomes writing
    sections. Tables belong to the section that introduces them. A form printed twice
    (instructions, then a blank copy) yields each section once.
    """
    blocks = table_questions(doc.get("blocks", []))
    marker = lambda text: bool(PART_B.search(text[:160])) and not PART_A.search(text[:160])
    has_part_b = any(marker(clean(b["text"])) for b in blocks)
    in_part_b = not has_part_b
    sections, current, group = [], None, None
    seen = set()
    for block in blocks:
        text = clean(block["text"])
        level = block.get("heading_level")
        if has_part_b and not in_part_b and marker(text):
            in_part_b = True
        if not in_part_b:
            continue
        table_prompt = not level and block.get("column") == 1 and len(text) < 180 and re.search(r"[A-Za-z]", text) and input_prompt(text)
        if table_prompt:
            level = 3
        if level and not TABLE_HEADING.match(text):
            title = re.sub(r"\s*\[[^\]]*\]\s*", " ", text).strip()
            title = re.sub(r"^[\[\]\s]+|[\[\]\s]+$", "", title)  # Stray template brackets ("dienst]").
            if not input_prompt(title, heading=True):
                current = None  # Legal prose or a reference fragment formatted as a heading.
                continue
            numbered = re.match(r"^(\d+(?:\.\d+)*)\.?\s+(.*)$", title)
            if FORM_SKIP.match(re.sub(r"^\d+(?:\.\d+)*\.?\s*", "", title)):
                current = None
                continue
            depth = numbered[1].count(".") + 1 if numbered else level
            if table_prompt:
                depth = sections[-1]["depth"] if sections else 1  # A prompt cell is a sibling, not a child, of the current section.
            if block.get("form_number"):
                numbered, depth = True, 1 if block["form_number"].isdigit() else 2
                title = block["form_number"].rstrip(".") + ". " + title
            key = re.sub(r"\W+", " ", title.casefold()).strip()
            if depth == 1 and numbered:
                group = {"title": title, "aspects": [], "evidence_block": block}
                current = None
                # A top-level heading becomes a section only if no subsections follow; decided below.
                section = {"heading": title, "group": None, "instructions": [], "block": block, "depth": 1,
                           "page_hint": None, "limits": {}, "key": key, "group_ref": group}
                if key not in seen:
                    seen.add(key)
                    sections.append(section)
                    current = section
                else:
                    current = None
                continue
            if key in seen:
                current = None
                continue
            seen.add(key)
            hint = PAGE_HINT.search(text)
            section = {"heading": title, "group": group["title"] if group else None, "instructions": [], "block": block,
                       "depth": depth, "page_hint": hint[1].strip() if hint else None, "limits": {}, "key": key, "group_ref": group}
            limit = LIMIT.search(text)
            if limit:
                section["limits"][limit[2].casefold()] = int(limit[1])
            sections.append(section)
            current = section
            continue
        if re.match(r"(?i)^example\b|example, not to be completed", text):
            continue
        if current is not None:
            if current["depth"] == 1 and group is not None and current.get("group_ref") is group and re.search(r"(?i)aspects to be taken into account|will be assessed|wordt beoordeeld", text):
                group["aspects"].append(text)
                continue
            current["instructions"].append({"text": text, "block": block})
            limit = LIMIT.search(text)
            if limit and not current["limits"]:
                current["limits"][limit[2].casefold()] = int(limit[1])
    # A heading followed by deeper headings is a group label; its text becomes context for its subsections.
    result = []
    for index, section in enumerate(sections):
        following = sections[index + 1] if index + 1 < len(sections) else None
        asks = any(input_prompt(i["text"]) for i in section["instructions"][:3])
        if following and following["depth"] > section["depth"]:
            if asks:
                result.append(dict(section))  # A parent heading that asks something is also a question.
            for child in sections[index + 1:]:
                if child["depth"] <= section["depth"]:
                    break
                child["group"] = child.get("group") if child.get("group") and child.get("group_ref") is section.get("group_ref") and section["depth"] == 1 else section["heading"]
                child.setdefault("group_context", []).extend(i["text"] for i in section["instructions"])
                if section.get("group_ref") and not child.get("group_ref"):
                    child["group_ref"] = section["group_ref"]
            continue
        result.append(section)
    for section in result:
        group = section.get("group_ref")
        section["assessment_aspects"] = list(group["aspects"]) if group else []
        section["budget"] = bool(BUDGET_SECTION.search((section.get("group") or "") + " " + section["heading"]))
    return result


BUDGET_SECTION = re.compile(r"(?i)begroting|projectkosten|kostenoverzicht|financieringsoverzicht|financiering van|budget|financial plan|"
                            r"funding request|cost(?:s| breakdown| overview)|eigen bijdrage")


def table_questions(blocks):
    """Forms laid out as tables: a number column for groups ("1") and letters for questions ("a").

    The text cell becomes a heading with its form number; label cells disappear; explanatory rows stay
    as instructions. Block text is never changed, so source quotes remain exact.
    """
    rows = {}
    for block in blocks:
        if block.get("table") and block.get("row") and block.get("column"):
            rows.setdefault((block["table"], block["row"]), {})[block["column"]] = block
    numbered_rows = [r for r in rows.values() if 1 in r and 2 in r and re.fullmatch(r"\d{1,2}|[a-z]|\d{1,2}[a-z]|\d{1,2}\.\d{1,2}", clean(r[1]["text"]))]
    if len(numbered_rows) < 3:
        return blocks
    result, group_number = [], None
    for block in blocks:
        row = rows.get((block.get("table"), block.get("row"))) if block.get("table") else None
        if not row or 1 not in row or 2 not in row:
            result.append(block)
            continue
        label = clean(row[1]["text"])
        if not re.fullmatch(r"\d{1,2}|[a-z]|\d{1,2}[a-z]|\d{1,2}\.\d{1,2}", label):
            if block.get("column") == 1 and not label:
                continue
            result.append({k: v for k, v in block.items() if k != "column"} if block.get("column") == 2 else block)
            continue
        if block.get("column") == 1:
            continue  # The label itself.
        if block.get("column") != 2:
            result.append(block)
            continue
        if label.isdigit():
            group_number = label
            result.append({**block, "heading_level": 1, "form_number": label, "column": None})
        else:
            number = label if label[0].isdigit() else (group_number or "") + label
            result.append({**block, "heading_level": 2, "form_number": number, "column": None})
    return result


ATTACHMENT_PAGE = re.compile(r"(?i)bijlagen|attachments|supporting documents|required documents|documents to (?:submit|include|attach)|"
                             r"wat stuurt u mee|stuurt u mee|benodigde documenten|meesturen")


def document_heading(path):
    """On an attachments page, each numbered or document-named sub-heading names one file to provide."""
    if len(path) < 2:
        return None
    nearest = heading_title(path[-1])
    if not any(ATTACHMENT_PAGE.search(heading_title(h)) for h in path[:-1]):
        return None
    if re.match(r"^\d{1,2}[.)]\s+\S", nearest) or DOCUMENT_WORDS.search(nearest):
        return re.sub(r"^\d{1,2}[.)]\s+", "", nearest).strip()
    return None
