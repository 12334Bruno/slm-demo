"""Saved company profiles on this laptop: rename, duplicate and export one company.

Each company is one workspace (its facts, documents, applications) plus its uploaded files.
Deleting lives in operations.py, next to the backup tools.
"""
import json
import re
from io import BytesIO
from zipfile import ZIP_DEFLATED, ZipFile

from fastapi.responses import Response
from pydantic import Field

from .config import now
from .domain import Strict

EXPORT_FORMAT = "slm-company-export-v1"


class CompanyName(Strict):
    label: str = Field(min_length=1, max_length=120)


def export_zip(store, discovery, wid) -> bytes:
    """One ZIP with workspace.json (all saved details, evidence and applications) and the original documents."""
    ws = store.load(wid)
    buffer = BytesIO()
    with ZipFile(buffer, "w", ZIP_DEFLATED) as archive:
        archive.writestr("workspace.json", json.dumps({"format": EXPORT_FORMAT, "exported_at": now(), "workspace": ws,
                                                       "saved_grant_ids": discovery.db.saved(wid)}, ensure_ascii=False, indent=1))
        for doc in ws["documents"]:
            path = store.root / "uploads" / doc["storage_name"]
            if path.is_file():  # Unreadable uploads were never stored.
                archive.write(path, f"documents/{doc['id'][:8]}-{doc['filename']}")
    return buffer.getvalue()


def file_slug(text):
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-")[:60] or "company"


def register(app, store, discovery, view):
    @app.patch("/api/workspaces/{wid}/label")
    def rename(wid: str, body: CompanyName):
        store.rename(wid, body.label.strip())
        return view(store.load(wid))

    @app.post("/api/workspaces/{wid}/duplicate")
    def duplicate(wid: str, body: CompanyName):
        copy = store.duplicate(wid, body.label.strip())
        discovery.db.copy_saved(wid, copy["id"])
        return view(store.load(copy["id"]))

    @app.get("/api/workspaces/{wid}/export")
    def export(wid: str):
        ws = store.load(wid)
        name = file_slug(ws.get("label") or str(ws["facts"]["company.name"]["value"] or "company"))
        return Response(export_zip(store, discovery, wid), media_type="application/zip",
                        headers={"Content-Disposition": f'attachment; filename="SLM-{name}-{now()[:10]}.zip"'})
