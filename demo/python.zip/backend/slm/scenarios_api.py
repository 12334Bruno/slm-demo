"""Module 4 scenario comparison endpoints."""
from typing import Any
from pydantic import BaseModel, Field
from .relevance import assess_relevance
from .scenarios import apply_scenario, compare, normalise_changes


class CompareBody(BaseModel):
    changes: dict[str, Any]
    mode: str = "basic"


class ScenarioBody(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    changes: dict[str, Any]


class ApplyBody(BaseModel):
    expected_revision: int
    changes: dict[str, Any] | None = None


class RelevanceBody(BaseModel):
    refresh: bool = False


def register(app, discovery, workspace_view):
    """Routes live under /api/workspaces/{wid}/ so hosted ownership checks apply."""
    store = app.state.store

    @app.post("/api/workspaces/{wid}/scenarios/compare")
    def compare_scenario(wid: str, body: CompareBody):
        return compare(discovery, store.load(wid), body.changes, body.mode)

    @app.get("/api/workspaces/{wid}/scenarios")
    def list_scenarios(wid: str):
        store.load(wid)
        return {"scenarios": discovery.db.scenarios(wid)}

    @app.post("/api/workspaces/{wid}/scenarios")
    def save_scenario(wid: str, body: ScenarioBody):
        name = body.name.strip()
        if not name:
            raise ValueError("Give the scenario a name")
        return discovery.db.save_scenario(wid, name, normalise_changes(body.changes))

    @app.delete("/api/workspaces/{wid}/scenarios/{sid}")
    def delete_scenario(wid: str, sid: str):
        store.load(wid)
        discovery.db.delete_scenario(wid, sid)
        return {"scenarios": discovery.db.scenarios(wid)}

    @app.post("/api/workspaces/{wid}/scenarios/apply")
    def apply_changes(wid: str, body: ApplyBody):
        if body.changes is None:
            raise ValueError("Say which changes to apply")
        return workspace_view(apply_scenario(store, wid, body.changes, body.expected_revision))

    @app.post("/api/workspaces/{wid}/scenarios/{sid}/apply")
    def apply_saved(wid: str, sid: str, body: ApplyBody):
        store.load(wid)
        scenario = discovery.db.scenario(wid, sid)
        return workspace_view(apply_scenario(store, wid, scenario["changes"], body.expected_revision, scenario["name"]))

    @app.post("/api/workspaces/{wid}/opportunities/{rid}/relevance")
    def relevance(wid: str, rid: str, body: RelevanceBody | None = None):
        return assess_relevance(discovery, store.load(wid), rid, refresh=bool(body and body.refresh))
