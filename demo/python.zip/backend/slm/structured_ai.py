"""Bounded Groq structured requests shared by optional interpretation tasks."""
import json
import os
from datetime import datetime, timezone
import httpx
from .config import now
from .groq_analysis import strict_schema

MAX_INPUT_CHARS = 40000


class StructuredRequestError(ValueError):
    def __init__(self, code, message, retryable=False, retry_after=60):
        super().__init__(message)
        self.code, self.retryable, self.retry_after = code, retryable, retry_after


_WINDOW, _LOCK = [], __import__("threading").Lock()


def estimated_tokens(payload):
    return len(json.dumps(payload.get("messages", []), ensure_ascii=False)) // 3 + 50


def pace(tokens, sleep=None):
    """Keep this server under the provider's input-tokens-per-minute limit instead of failing jobs.

    Groq's free tier allows a few thousand input tokens per minute; requests are spaced
    so a multi-batch analysis finishes instead of repeatedly hitting the limit.
    """
    import time
    sleep = sleep or time.sleep
    limit = int(os.getenv("SLM_AI_INPUT_TOKENS_PER_MINUTE", "6500"))
    if limit <= 0:
        return
    waited = 0.0
    while True:
        with _LOCK:
            moment = time.monotonic()
            _WINDOW[:] = [(t, n) for t, n in _WINDOW if moment - t < 60]
            used = sum(n for _, n in _WINDOW)
            if not _WINDOW or used + tokens <= limit:
                _WINDOW.append((moment, tokens))
                return
            wait = 60 - (moment - _WINDOW[0][0]) + 0.5
        if waited + wait > 120:
            raise StructuredRequestError("rate_limit", "AI capacity is busy. It will retry automatically.", True, wait)
        sleep(wait)
        waited += wait


def post_paced(client, payload, headers, sleep=None, real=True):
    """POST with pacing; one in-line wait-and-retry when the provider still asks to slow down."""
    import time
    if not real:  # Controlled test transports are never paced.
        return client.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers=headers)
    sleep = sleep or time.sleep
    pace(estimated_tokens(payload), sleep)
    response = client.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers=headers)
    if response.status_code == 429:
        try:
            delay = float(response.headers.get("retry-after", "30"))
        except ValueError:
            delay = 30.0
        if delay <= 65:
            sleep(delay + 1)
            response = client.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers=headers)
    return response


def daily_limit_reached(response):
    """Groq refuses with 429 both when a minute's tokens and when a day's tokens are used up (free plan: 200,000 a day).
    Only the per-minute limit clears within a minute, so the two must not be reported the same way."""
    return response.status_code == 429 and "tokens per day" in response.text


def configured():
    from .ai_settings import cloud_ai_allowed
    return bool(os.getenv("GROQ_API_KEY")) and os.getenv("SLM_AI_ENABLED", "1") == "1" and cloud_ai_allowed()


def reserve():
    from .storage import Store
    store = Store()
    day = datetime.now(timezone.utc).date().isoformat()
    with store.connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS ai_feature_usage (day TEXT PRIMARY KEY, calls INTEGER NOT NULL)")
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT calls FROM ai_feature_usage WHERE day=?", (day,)).fetchone()
        limit = int(os.getenv("SLM_AI_DAILY_REQUESTS", "40"))
        if limit != -1 and (row[0] if row else 0) >= max(0, limit):
            raise StructuredRequestError("daily_limit", "The daily request limit has been reached. Your saved work is unchanged.", retry_after=3600)
        conn.execute("INSERT INTO ai_feature_usage VALUES (?, 1) ON CONFLICT(day) DO UPDATE SET calls=calls+1", (day,))


def call(schema, system, supplied, transport=None):
    if not configured():
        raise StructuredRequestError("not_configured", "The project-fit check is not available right now.")
    content = json.dumps(supplied, ensure_ascii=False)
    if len(content) > MAX_INPUT_CHARS:
        raise StructuredRequestError("input_limit", "The source text is too long for this check.")
    model = os.getenv("GROQ_MODEL", "qwen/qwen3.8-27b")
    payload = {"model": model, "temperature": 0.1, "max_completion_tokens": 4000,
               "messages": [{"role": "system", "content": system}, {"role": "user", "content": content}],
               "response_format": {"type": "json_schema", "json_schema": {"name": schema.__name__, "strict": True,
                                    "schema": strict_schema(schema.model_json_schema())}}}
    if model.startswith("openai/gpt-oss-"):
        payload.update(reasoning_effort="medium", include_reasoning=False)
    for attempt in range(2):
        reserve()  # Each real attempt counts against the request limit.
        try:
            with httpx.Client(transport=transport, timeout=float(os.getenv("GROQ_TIMEOUT_SECONDS", "35")), follow_redirects=False) as client:
                response = post_paced(client, payload, {"Authorization": "Bearer " + os.environ["GROQ_API_KEY"]}, real=transport is None)
            if response.status_code == 429:
                try:
                    delay = max(30, min(3600, float(response.headers.get("retry-after", "60"))))
                except ValueError:
                    delay = 60
                if daily_limit_reached(response):
                    raise StructuredRequestError("daily_limit", "The AI plan's daily token allowance is used up.", True, delay)
                raise StructuredRequestError("rate_limit", "The fit check is busy. Try again shortly.", True, delay)
            if response.status_code >= 500:
                raise StructuredRequestError("service_unavailable", "The fit check is temporarily unavailable.", True)
            if response.is_error:
                try:
                    invalid_json = response.json().get("error", {}).get("code") == "json_validate_failed"
                except ValueError:
                    invalid_json = False
                if invalid_json and attempt == 0:
                    continue
                raise StructuredRequestError("invalid_output" if invalid_json else "request_rejected", "The fit check could not be completed.")
            data = response.json()
            choice = data["choices"][0]
            if choice["message"].get("refusal"):
                raise StructuredRequestError("refused", "The fit check could not be completed for this text.")
            if choice.get("finish_reason") != "stop":
                if attempt == 0:
                    payload["max_completion_tokens"] = 6000
                    continue
                raise StructuredRequestError("incomplete_output", "The fit check returned an incomplete result.", True)
            output = schema.model_validate_json(choice["message"]["content"])
            break
        except StructuredRequestError:
            raise
        except httpx.HTTPError:
            raise StructuredRequestError("connection", "The fit check could not connect. Try again shortly.", True) from None
        except (ValueError, KeyError, IndexError, TypeError, AttributeError):
            if attempt == 0:
                payload["messages"][0]["content"] = system + " Return one JSON result matching the schema, not the schema itself. Keep the answer concise."
                continue
            raise StructuredRequestError("invalid_output", "The fit check returned a result that could not be read.", True) from None
    return output, {"provider": "Groq", "response_id": data.get("id"), "model": model, "at": now(),
                    "status": "completed", "usage": data.get("usage")}
