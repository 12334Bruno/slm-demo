"""Optional OCR through the system `tesseract` program.

Nothing here invents text: when tesseract or Pillow is missing, or when
recognition fails, the caller receives an explicit reason and the document
keeps its "no readable text" status. Recognised paragraphs are always flagged
as OCR so the founder knows to check them.
"""
import os
import re
import shutil
import subprocess
import time
from io import BytesIO
from pathlib import Path

OCR_UNAVAILABLE = "OCR unavailable on this server"
OCR_NOTICE = "Text was read from an image with OCR and may contain recognition errors. Check names and figures before confirming."
MAX_IMAGE_BYTES = 10 * 1024 * 1024
MAX_PIXELS = 25_000_000
MIN_SIDE = 24
MAX_OUTPUT_BYTES = 2_000_000
PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


def _int_env(name, default):
    try:
        return max(1, int(os.getenv(name, str(default))))
    except ValueError:
        return default


def timeout_seconds():
    return _int_env("SLM_OCR_TIMEOUT", 40)


def total_seconds():
    return _int_env("SLM_OCR_TOTAL_SECONDS", 120)


def max_pages():
    return _int_env("SLM_OCR_MAX_PAGES", 8)


class OcrUnavailable(Exception):
    """OCR cannot run on this server (missing program or library)."""


class OcrError(Exception):
    """OCR ran but this input could not be read."""


def _pillow():
    try:
        from PIL import Image
    except Exception:  # Missing library, or a runtime such as the browser demo.
        return None
    return Image


# Where Tesseract's Windows installer (UB Mannheim) puts the program; it does not add itself to PATH.
WINDOWS_TESSERACT = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe"


def tesseract_path():
    """The tesseract program on PATH, or in its standard Windows install folder."""
    found = shutil.which("tesseract")
    if found is None and os.name == "nt" and WINDOWS_TESSERACT.is_file():
        return str(WINDOWS_TESSERACT)
    return found


def status():
    """Honest availability report, without running recognition."""
    if os.getenv("SLM_OCR_ENABLED", "1") == "0":
        return {"available": False, "reason": "OCR is switched off by the server configuration."}
    if not tesseract_path():
        return {"available": False, "reason": "The tesseract program is not installed on this server."}
    if _pillow() is None:
        return {"available": False, "reason": "The Pillow image library is not installed on this server."}
    return {"available": True, "reason": None, "engine": "tesseract", "languages": ["eng"]}


def available():
    return status()["available"]


def _prepare(data):
    """Validate and normalise an image to a bounded greyscale PNG."""
    Image = _pillow()
    if Image is None:
        raise OcrUnavailable(OCR_UNAVAILABLE)
    if len(data) > MAX_IMAGE_BYTES:
        raise OcrError("The image exceeds the 10 MB limit.")
    if not (data.startswith(PNG_MAGIC) or data.startswith(b"\xff\xd8\xff")):
        raise OcrError("The file content is not a PNG or JPEG image.")
    try:
        with Image.open(BytesIO(data)) as image:
            width, height = image.size  # Reads the header only.
            if min(width, height) < MIN_SIDE:
                raise OcrError("The image is too small to contain readable text.")
            if width * height > MAX_PIXELS:
                raise OcrError("The image has too many pixels (limit 25 megapixels); reduce its size.")
            image.load()
            from PIL import ImageOps
            image = ImageOps.exif_transpose(image).convert("L")
    except OcrError:
        raise
    except Exception as exc:  # Corrupt, truncated or decompression-bomb images.
        raise OcrError("The image could not be decoded (" + type(exc).__name__ + ").") from None
    short = min(image.size)
    if short < 800:
        # Small screenshots recognise far better when enlarged; stay bounded.
        scale = min(3.0, 800 / short)
        image = image.resize((int(image.width * scale), int(image.height * scale)), Image.LANCZOS)
    if image.width * image.height > MAX_PIXELS:
        raise OcrError("The image has too many pixels (limit 25 megapixels); reduce its size.")
    out = BytesIO()
    image.save(out, format="PNG")
    return out.getvalue()


def _environment():
    # Do not hand server secrets (API keys) to a child process.
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "OMP_THREAD_LIMIT": "1", "LC_ALL": "C", "LANG": "C"}
    # TESSDATA_PREFIX points at the language files; Windows programs cannot start without SYSTEMROOT.
    for key in ("TESSDATA_PREFIX", "SYSTEMROOT"):
        if os.environ.get(key):
            env[key] = os.environ[key]
    return env


def parse_tsv(tsv):
    """Group tesseract TSV words into paragraphs: [{text, confidence}]."""
    paragraphs, order = {}, []
    for row in tsv.splitlines()[1:]:
        parts = row.split("\t")
        if len(parts) < 12 or parts[0] != "5":
            continue
        text = parts[11].strip()
        try:
            confidence = float(parts[10])
        except ValueError:
            continue
        if not text or confidence < 0:
            continue
        key = (parts[2], parts[3])
        if key not in paragraphs:
            paragraphs[key] = {}
            order.append(key)
        paragraphs[key].setdefault(parts[4], []).append((text, confidence))
    result = []
    for key in order:
        lines, scores = [], []
        for line in paragraphs[key].values():
            lines.append(" ".join(word for word, _ in line))
            scores.extend(score for _, score in line)
        text = "\n".join(lines).strip()
        if len(re.findall(r"[A-Za-z0-9]", text)) >= 2:
            result.append({"text": text, "confidence": round(sum(scores) / len(scores), 1)})
    return result


def recognise(data, timeout=None):
    """Return paragraphs read from PNG/JPEG bytes. Raises OcrUnavailable/OcrError."""
    state = status()
    if not state["available"]:
        raise OcrUnavailable(OCR_UNAVAILABLE + ": " + state["reason"])
    png = _prepare(data)
    try:
        run = subprocess.run([tesseract_path(), "stdin", "stdout", "-l", "eng", "--psm", "3", "tsv"], input=png,
                             capture_output=True, timeout=timeout or timeout_seconds(), env=_environment(), check=False)
    except subprocess.TimeoutExpired:
        raise OcrError("OCR timed out; use a smaller or clearer image.") from None
    except OSError:
        raise OcrUnavailable(OCR_UNAVAILABLE + ": tesseract could not be started.") from None
    if run.returncode != 0:
        raise OcrError("OCR could not read this image.")
    if len(run.stdout) > MAX_OUTPUT_BYTES:
        raise OcrError("OCR output exceeded the size limit.")
    return parse_tsv(run.stdout.decode("utf-8", "replace"))


def pdf_page_images(page, limit=3):
    """Embedded raster images on a PDF page, as encoded PNG/JPEG bytes.

    Only top-level image XObjects are read. Declared dimensions are checked
    before pypdf decodes anything, so oversized images are skipped cheaply.
    """
    if _pillow() is None:
        raise OcrUnavailable(OCR_UNAVAILABLE)
    found = []
    try:
        resources = page.get("/Resources")
        xobjects = resources.get_object().get("/XObject") if resources is not None else None
        if xobjects is None:
            return found
        for name, ref in xobjects.get_object().items():
            obj = ref.get_object()
            if obj.get("/Subtype") != "/Image":
                continue
            width, height = int(obj.get("/Width", 0)), int(obj.get("/Height", 0))
            if min(width, height) < MIN_SIDE or width * height > MAX_PIXELS:
                continue
            try:
                image = page.images[name]
                data = image.data
                if len(data) <= MAX_IMAGE_BYTES:
                    if image.name.lower().endswith((".png", ".jpg", ".jpeg")) or data[:2] == b"\xff\xd8" or data.startswith(PNG_MAGIC):
                        found.append(data)
                    else:
                        found.append(_to_png(image.image))
            except Exception:
                continue  # One undecodable image does not stop the rest of the page.
            if len(found) >= limit:
                break
    except Exception:
        return found
    return found


def _to_png(image):
    out = BytesIO()
    image.convert("L").save(out, format="PNG")
    return out.getvalue()


class Budget:
    """Wall-clock budget for all OCR work in one document."""

    def __init__(self, seconds=None):
        self.deadline = time.monotonic() + (seconds or total_seconds())

    def remaining(self):
        return self.deadline - time.monotonic()
