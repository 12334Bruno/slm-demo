"""Decide whether a website (or registry record) belongs to the founder's company.

Names are compared after removing case, diacritics, punctuation and legal-form
words (B.V., N.V., Holding, Ltd, GmbH ...). A Dutch KVK number (8 digits next to
"KVK" / "Chamber of Commerce") is compared with any KVK the founder supplied.
The result is a verdict with the exact snippets it rests on; it is never
silently applied: a mismatch holds the document until the founder chooses.
"""
import re
import unicodedata
from difflib import SequenceMatcher
from urllib.parse import urlsplit
from .config import now

VERDICTS = ("confirmed_match", "probable_match", "mismatch", "unverifiable")
LEGAL_FORMS = (r"b\.?\s?v\.?", r"n\.?\s?v\.?", r"v\.?\s?o\.?\s?f\.?", r"c\.?\s?v\.?", r"holdings?", r"ltd\.?", r"limited", r"gmbh",
               r"ag", r"s\.?\s?a\.?", r"sas", r"sarl", r"srl", r"llc", r"inc\.?", r"incorporated", r"corp\.?", r"corporation",
               r"plc", r"ug", r"bvba", r"stichting", r"eenmanszaak", r"co\.?")
LEGAL_RE = re.compile(r"(?<![\w])(?:" + "|".join(LEGAL_FORMS) + r")(?![\w])", re.I)
SUFFIX_RE = r"(?:B\.?\s?V\.?|N\.?\s?V\.?|V\.?O\.?F\.?|Holding|Holdings|Ltd\.?|Limited|GmbH|Inc\.?|LLC|PLC|S\.?A\.?|AG)"
LEGAL_NAME = re.compile(r"((?:(?:[A-Z][\w'’\-]*|&)\s+){1,5}" + SUFFIX_RE + r")(?![\w])")
COPYRIGHT = re.compile(r"(?:©|\(c\)|copyright)\s*(?:(?:19|20)\d{2}(?:\s*[-–]\s*(?:19|20)?\d{2})?)?\s*([A-Za-z0-9][^|•·\n]{2,80}?)(?=\s*(?:\.\s|\.$|[|•·\n]|all rights|alle rechten|$))", re.I)
KVK = re.compile(r"(?i)(?:kvk(?:[-\s]?(?:nummer|number|nr\.?|no\.?))?|chamber\s+of\s+commerce|kamer\s+van\s+koophandel)\D{0,25}?(?<!\d)(\d(?:[ .]?\d){7})(?!\d)")
SEPARATORS = re.compile(r"\s+[|\-–—·•:]\s+|\s{2,}")
CONFIRMED, PROBABLE = 0.99, 0.82


def fold_char(char):
    base = "".join(c for c in unicodedata.normalize("NFKD", char) if not unicodedata.combining(c)).casefold()
    return base if len(base) == 1 else char.lower()


def fold(text):
    """Lower-case, diacritic-free text of identical length (so positions map back to the original)."""
    return "".join(fold_char(c) for c in text)


def normalise_name(name):
    """Comparable form of a company name: no legal-form words, diacritics, case or punctuation."""
    text = LEGAL_RE.sub(" ", fold(str(name)).replace("&", " and "))
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text).split())


def similarity(a, b):
    """0..1 similarity of two already-normalised names."""
    if not a or not b:
        return 0.0
    if a == b or a.replace(" ", "") == b.replace(" ", ""):
        return 1.0
    ta, tb = a.split(), b.split()
    short, long_ = sorted((ta, tb), key=len)
    # A leading run of the same words, unless the shared part is one short generic word.
    if long_[:len(short)] == short and (len(short) >= 2 or len(short[0]) >= 7):
        return 0.9
    jaccard = len(set(ta) & set(tb)) / len(set(ta) | set(tb))
    return max(SequenceMatcher(None, a, b).ratio(), jaccard)


def kvk_numbers(text):
    """[(number, start, end)] for KVK numbers written next to a KVK label."""
    found = []
    for match in KVK.finditer(text or ""):
        digits = re.sub(r"\D", "", match[1])
        if len(digits) == 8:
            found.append((digits, match.start(), match.end()))
    return found


def window(text, start, end, size=110):
    """An exact slice of `text` around a match, trimmed to sentence-like edges."""
    left = max(text.rfind(c, 0, start) for c in ".!?\n")
    right_candidates = [i for i in (text.find(c, end) for c in ".!?\n") if i != -1]
    left = max(left + 1, start - size)
    right = min([end + size] + [i + 1 for i in right_candidates])
    return text[left:right].strip()


def workspace_identity(ws):
    """Names and KVK numbers the founder (or earlier documents) already supplied."""
    names, kvks = [], []
    for path, bucket in (("company.name", names), ("company.registration_number", kvks)):
        fact = ws["facts"].get(path) or {}
        values = [fact.get("value")] + [c["value"] for c in fact.get("candidates", [])]
        for value in values:
            if isinstance(value, str) and value.strip() and value.strip() not in bucket:
                bucket.append(value.strip())
    numbers = []
    for value in kvks:
        numbers.extend(re.findall(r"(?<!\d)\d{8}(?!\d)", re.sub(r"(?<=\d)[ .](?=\d)", "", value)))
    return {"names": names, "kvk": list(dict.fromkeys(numbers))}


def site_identity(doc):
    """Names and KVK numbers a website states about itself, each with its exact source snippet."""
    names, kvks = [], []

    def name(value, source, rank, block, snippet):
        value = value.strip(" ,;-–—|")
        if len(normalise_name(value)) >= 2 and not any(n["value"].casefold() == value.casefold() for n in names):
            names.append({"value": value, "source": source, "rank": rank, "block_id": block["id"],
                          "locator": block["locator"], "snippet": snippet})

    for block in doc["blocks"]:
        text, role = block["text"], block.get("role")
        if role == "structured":
            for line in text.splitlines()[1:]:
                key, _, value = line.partition(": ")
                if key == "legalName":
                    name(value, "legal name in the site's structured data", 1, block, line)
                elif key in {"name", "alternateName"}:
                    name(value, "organisation name in the site's structured data", 2, block, line)
        elif role == "site_name":
            name(text.removeprefix("Site name: "), "site name", 3, block, text)
        elif role == "title":
            for segment in SEPARATORS.split(text):
                name(segment, "page title", 4, block, segment.strip())
        for match in COPYRIGHT.finditer(text):
            name(match[1], "copyright notice", 2, block, match[0].strip())
        for match in LEGAL_NAME.finditer(text):
            name(match[1], "company name with legal form", 3, block, window(text, match.start(), match.end()))
        for number, start, end in kvk_numbers(text):
            if not any(k["value"] == number for k in kvks):
                kvks.append({"value": number, "block_id": block["id"], "locator": block["locator"], "snippet": window(text, start, end)})
    return {"names": sorted(names, key=lambda n: n["rank"]), "kvk": kvks}


def mentions(doc, expected_names, limit=3):
    """Blocks that mention one of the expected names in running text, with exact snippets."""
    found = []
    for expected in expected_names:
        tokens = normalise_name(expected).split()
        if not tokens or len("".join(tokens)) < 4:
            continue
        pattern = re.compile(r"(?<![a-z0-9])" + r"[^a-z0-9]{1,3}".join(map(re.escape, tokens)) + r"(?![a-z0-9])")
        for block in doc["blocks"]:
            folded = fold(block["text"])
            match = pattern.search(folded)
            if match:
                found.append({"name": expected, "block_id": block["id"], "locator": block["locator"],
                              "snippet": window(block["text"], match.start(), match.end())})
                if len(found) >= limit:
                    return found
    return found


def domain_matches(host, expected_names):
    """Weak signal: the site's domain label equals or contains a known company name."""
    labels = (host or "").lower().split(".")
    if labels and labels[0] == "www":
        labels = labels[1:]
    if len(labels) < 2:
        return None
    label = labels[-3] if len(labels) >= 3 and labels[-2] in {"co", "com", "org", "net", "ac", "gov"} else labels[-2]
    squashed = re.sub(r"[^a-z0-9]", "", fold(label))
    for expected in expected_names:
        target = normalise_name(expected).replace(" ", "")
        if len(target) >= 4 and len(squashed) >= 4 and (squashed == target or target in squashed or squashed in target):
            return expected
    return None


def check_website(ws, doc):
    """Verdict on whether `doc` (a website document) is the founder's company."""
    expected, site = workspace_identity(ws), site_identity(doc)
    host = urlsplit(doc.get("url") or "").hostname or ""
    evidence, conflicts, reasons = [], [], []
    verdict = "unverifiable"

    # 1. KVK number: a unique identifier outweighs any name similarity.
    shared = [k for k in site["kvk"] if k["value"] in expected["kvk"]]
    if shared:
        evidence.append({"kind": "kvk", "supports": "match", "snippet": shared[0]["snippet"], "locator": shared[0]["locator"], "value": shared[0]["value"]})
        verdict = "confirmed_match"
        reasons.append(f"The KVK number {shared[0]['value']} on the site matches the one you gave.")
    elif site["kvk"] and expected["kvk"]:
        for entry in site["kvk"][:3]:
            evidence.append({"kind": "kvk", "supports": "conflict", "snippet": entry["snippet"], "locator": entry["locator"], "value": entry["value"]})
        conflicts.append({"field": "company.registration_number", "existing": expected["kvk"], "found": site["kvk"][0]["value"]})
        verdict = "mismatch"
        reasons.append(f"The site shows KVK number {site['kvk'][0]['value']}, but you gave {', '.join(expected['kvk'])}.")

    # 2. Company name.
    best = None
    for candidate in site["names"]:
        for known in expected["names"]:
            score = similarity(normalise_name(candidate["value"]), normalise_name(known))
            if best is None or score > best[0]:
                best = (score, candidate, known)
    mention = mentions(doc, expected["names"])
    name_level = None
    if expected["names"]:
        if best and best[0] >= CONFIRMED:
            name_level = "exact"
        elif mention:
            name_level = "mentioned"
        elif best and best[0] >= PROBABLE:
            name_level = "similar"
        elif domain_matches(host, expected["names"]):
            name_level = "domain"
        elif site["names"] or doc["blocks"]:
            name_level = "different"
    if verdict == "unverifiable" and expected["names"]:
        if name_level == "exact":
            verdict = "confirmed_match"
            reasons.append(f"The company name on the site ({best[1]['value']}) matches yours ({best[2]}) once legal forms and punctuation are ignored.")
            evidence.append({"kind": "name", "supports": "match", "snippet": best[1]["snippet"], "locator": best[1]["locator"], "value": best[1]["value"]})
        elif name_level in {"mentioned", "similar", "domain"}:
            verdict = "probable_match"
            if name_level == "similar":
                reasons.append(f"The name on the site ({best[1]['value']}) is similar to yours ({best[2]}) but not identical.")
                evidence.append({"kind": "name", "supports": "match", "snippet": best[1]["snippet"], "locator": best[1]["locator"], "value": best[1]["value"]})
                if best[1]["rank"] <= 2:
                    conflicts.append({"field": "company.name", "existing": expected["names"], "found": best[1]["value"]})
            elif name_level == "mentioned":
                reasons.append("Your company name appears in the site text, but no official name or KVK number confirms it.")
            else:
                reasons.append("The website address resembles your company name, but the pages do not confirm it.")
            for item in mention[:2]:
                evidence.append({"kind": "name", "supports": "match", "snippet": item["snippet"], "locator": item["locator"], "value": item["name"]})
        elif name_level == "different":
            verdict = "mismatch"
            shown = site["names"][0] if site["names"] else None
            reasons.append("Your company name was not found on these pages." + (f" The site calls itself {shown['value']}." if shown else ""))
            for entry in site["names"][:2]:
                evidence.append({"kind": "name", "supports": "conflict", "snippet": entry["snippet"], "locator": entry["locator"], "value": entry["value"]})
            if shown:
                conflicts.append({"field": "company.name", "existing": expected["names"], "found": shown["value"]})
    elif verdict == "confirmed_match" and name_level == "different" and site["names"]:
        verdict = "probable_match"
        reasons.append("The names differ (a trading name may be used), so please check.")
        conflicts.append({"field": "company.name", "existing": expected["names"], "found": site["names"][0]["value"]})
        evidence.append({"kind": "name", "supports": "conflict", "snippet": site["names"][0]["snippet"], "locator": site["names"][0]["locator"], "value": site["names"][0]["value"]})
    if verdict == "unverifiable":
        reasons.append("There was no company name or KVK number to compare against." if not expected["names"] and not expected["kvk"]
                       else "The pages did not state a name or KVK number that could be compared.")
    return {"verdict": verdict, "summary": " ".join(reasons), "checked_at": now(), "expected": expected,
            "found": {"names": [{k: n[k] for k in ("value", "source", "rank", "block_id", "locator", "snippet")} for n in site["names"][:6]],
                      "kvk": [{k: n[k] for k in ("value", "block_id", "locator", "snippet")} for n in site["kvk"][:4]]},
            "evidence": evidence[:8], "conflicts": conflicts, "held": verdict == "mismatch", "decision": None}


def check_registry_record(ws, record):
    """Compare an official registry record with what the founder already said. Proposals only."""
    expected = workspace_identity(ws)
    conflicts, notes = [], []
    if expected["kvk"] and record["kvk_number"] not in expected["kvk"]:
        conflicts.append({"field": "company.registration_number", "existing": expected["kvk"], "found": record["kvk_number"]})
    names = [n for n in expected["names"] if similarity(normalise_name(n), normalise_name(record["name"])) < PROBABLE]
    if expected["names"] and len(names) == len(expected["names"]):
        conflicts.append({"field": "company.name", "existing": expected["names"], "found": record["name"]})
    if conflicts:
        notes.append("The official record differs from what you entered; both values are kept for you to resolve.")
    return {"conflicts": conflicts, "notes": notes}
