"""Only arithmetic authority. EUR cents and exact Decimal ratios throughout."""
from decimal import Decimal, ROUND_HALF_UP
from .config import CATALOGUE, MAIN_GRANT
from .profiles import fact_value


def rounded(value):
    return int(Decimal(value).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def euro(cents):
    return "Unknown" if cents is None else f"EUR {Decimal(cents) / 100:,.2f}"


def calculate(ws):
    formula = next(g["formula"] for g in CATALOGUE["grants"] if g["id"] == MAIN_GRANT)
    metadata = ws["budget_metadata"]
    rows, warnings, assumptions = [], [], []
    eligible_known = bool(ws["budget_lines"])
    vat = fact_value(ws, "company.vat_recoverable")
    if vat is None:
        warnings.append("VAT recovery unresolved. Values use a provisional excluding-VAT assumption; confirm VAT treatment.")
    elif vat is False:
        warnings.append("Non-recoverable VAT requires manual review. This calculator does not invent a gross-cost basis.")
        eligible_known = False
    if any(not line.get("confirmed") for line in ws["budget_lines"]):
        warnings.append("Budget rows remain unconfirmed by founder.")
    if any(line["eligibility_review"] == "proposed" for line in ws["budget_lines"]):
        assumptions.append("Proposed cost eligibility and study/research classifications await scheme-specific review.")
    totals = {"study_eligible_cents": 0, "research_eligible_cents": 0,
              "research_internal_personnel_eligible_cents": 0, "research_equipment_eligible_cents": 0,
              "research_buildings_eligible_cents": 0, "research_external_service_eligible_cents": 0,
              "research_other_costs_eligible_cents": 0}
    project_rows = excluded_rate = 0
    study_exact = research_exact = 0
    for line in ws["budget_lines"]:
        quantity = Decimal(line["quantity"])
        amount = rounded(quantity * line["rate_cents"])
        project_rows += amount
        eligible_rate = line["rate_cents"]
        unknown = line.get("state") == "conflict" or line["eligibility_review"] == "unknown"
        if line["eligibility_review"] == "excluded":
            eligible = 0
        elif unknown or line["activity_group"] == "other":
            eligible = None
        elif line["cost_type"] == "internal_personnel" and line["unit"] != "hours":
            eligible = None
            warnings.append(f"{line['id']}: internal personnel must be classified in hours before applying the hourly cap.")
        elif line["cost_type"] in {"equipment", "buildings", "other"} and line["eligibility_review"] != "reviewed":
            eligible = None
            warnings.append(f"{line['id']}: non-standard costs require explicit eligibility review.")
        else:
            if line["cost_type"] == "internal_personnel":
                eligible_rate = min(eligible_rate, formula["internal_personnel_rate_cap_cents"])
            eligible = rounded(quantity * eligible_rate)
            if eligible_rate < line["rate_cents"]:
                excluded_rate += amount - eligible
                warnings.append(f"{line['id']}: project spending remains {euro(amount)}; {euro(amount-eligible)} exceeds the eligible personnel rate cap.")
        rows.append({**line, "project_amount_cents": amount, "eligible_amount_cents": eligible,
                     "excluded_cents": None if eligible is None else amount - eligible})
        if eligible is None:
            eligible_known = False
        elif line["activity_group"] == "feasibility_study":
            totals["study_eligible_cents"] += eligible
            study_exact += eligible
        elif line["activity_group"] == "related_research":
            totals["research_eligible_cents"] += eligible
            research_exact += eligible
            key = {"internal_personnel": "research_internal_personnel_eligible_cents", "equipment": "research_equipment_eligible_cents",
                   "buildings": "research_buildings_eligible_cents", "external_service": "research_external_service_eligible_cents"}.get(line["cost_type"], "research_other_costs_eligible_cents")
            totals[key] += eligible
    outside = metadata["other_project_costs_cents"]
    revenues = metadata["project_revenues_cents"]
    if revenues is None or revenues != 0:
        eligible_known = False
        warnings.append("Confirm project revenues as zero or obtain manual review of their allocation to eligible cost categories.")
    spending_conflict = any(r.get("state") == "conflict" for r in rows)
    project_total = project_rows + outside if rows and outside is not None and not spending_conflict else None
    if spending_conflict:
        warnings.append("Conflicting budget rows leave the complete project total unresolved. Resolve the row candidates before calculating financing.")
        for row in rows:
            if row.get("state") == "conflict":
                row["project_amount_cents"] = None
    if outside is None:
        warnings.append("Other project costs have not been specified; the complete project total is unknown.")
    elif outside:
        assumptions.append(f"Other project costs of {euro(outside)} are included in spending and excluded from proposed eligible costs.")
    eligible_total = study_exact + research_exact if eligible_known else None
    if eligible_total is not None and eligible_total <= 0:
        study_share = research_share = None
    elif eligible_total is not None:
        # Return a display value, but rules compare exact numerator/denominator.
        study_share = rounded(Decimal(study_exact) * 10000 / eligible_total)
        research_share = rounded(Decimal(research_exact) * 10000 / eligible_total)
    else:
        study_share = research_share = None
    ceiling = min(rounded(Decimal(eligible_total) * formula["rate_basis_points"] / 10000), formula["cap_cents"]) if eligible_total is not None else None
    requested = metadata.get("requested_grant_cents")
    if requested is None:
        requested = ceiling
    if requested is not None and ceiling is not None and requested > ceiling:
        warnings.append("Requested grant exceeds the provisional ceiling. Correct the requested amount; it is not silently capped.")
    sources = ws["funding_sources"]
    if any(s.get("state") == "conflict" for s in sources):
        warnings.append("Conflicting funding sources are excluded from the recorded committed total until explicitly resolved; their availability is unknown.")
    if any(s["kind"] in {"other", "unknown"} and s["amount_cents"] for s in sources):
        warnings.append("Classify other/unknown financing as own cash, private or public before using the official financing table.")
    committed = sum(s["amount_cents"] for s in sources if s["status"] == "committed" and s.get("state") != "conflict")
    if any(s["status"] == "committed" and not s["founder_confirmed"] for s in sources):
        assumptions.append("Committed source amounts are document-reported until founder confirmation; no bank or legal verification.")
    ceiling_required = max(0, project_total - ceiling) if project_total is not None and ceiling is not None else None
    required = max(0, project_total - requested) if project_total is not None and requested is not None else None
    gap = max(0, required - committed) if required is not None else None
    result = {**totals, "rows": rows, "project_total_cents": project_total, "project_rows_cents": project_rows,
              "proposed_eligible_cents": eligible_total,
              "study_share_basis_points": study_share, "research_share_basis_points": research_share,
              "study_share_passes": study_exact * 10000 >= formula["minimum_study_basis_points"] * eligible_total if eligible_total else None,
              "research_share_passes": research_exact * 10000 <= formula["maximum_related_research_basis_points"] * eligible_total if eligible_total else None,
              "excluded_rate_portion_cents": excluded_rate,
              "non_eligible_cents": project_total - eligible_total if project_total is not None and eligible_total is not None else None,
              "project_revenues_cents": revenues, "grant_ceiling_cents": ceiling, "requested_grant_cents": requested,
              "other_financing_required_cents": required, "other_financing_at_ceiling_cents": ceiling_required,
              "committed_other_finance_cents": committed, "unconfirmed_financing_cents": gap,
              "own_cash_cents": sum(s["amount_cents"] for s in sources if s["kind"] == "own_cash" and s.get("state") != "conflict"),
              "other_private_cents": sum(s["amount_cents"] for s in sources if s["kind"] in {"private_loan", "other_private"} and s.get("state") != "conflict"),
              "other_public_cents": sum(s["amount_cents"] for s in sources if s["kind"] == "other_public" and s.get("state") != "conflict"),
              "assumptions": ["All amounts exclude VAT. Grant amounts are provisional ceilings, not awards."] + assumptions,
              "warnings": warnings, "status": "provisional",
              "budget_confirmed": bool(rows) and metadata["confirmed"] and all(l.get("confirmed") and l.get("state") != "conflict" for l in rows)}
    result["total_financing_cents"] = sum(result[k] for k in ("own_cash_cents", "other_private_cents", "other_public_cents")) + requested if requested is not None else None
    if any(s["kind"] in {"other", "unknown"} and s["amount_cents"] for s in sources):
        result["total_financing_cents"] = None
    if not eligible_known:
        for key in totals:
            result[key] = None
    return result
