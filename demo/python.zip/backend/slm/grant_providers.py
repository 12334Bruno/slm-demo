"""Real public-source adapters. No company names or selected grant mappings."""
import hashlib
import json
import re
import time
from urllib.parse import urljoin, urlparse
import httpx
from bs4 import BeautifulSoup
from .config import now
from .official_sources import AUTHORITIES, official_url, funding_page, canonical_url

EU_API = "https://api.tech.ec.europa.eu/search-api/prod/rest/search"
RVO_API = "https://www.rvo.nl/api/v1/opendata/subsidies"
ALLOWED = set(AUTHORITIES)
MAX_BYTES = 8_000_000


def safe_url(url):
    return official_url(url)


def clean(text):
    return " ".join(BeautifulSoup(str(text or ""), "html.parser").get_text(" ", strip=True).split())


def value(metadata, key, default=""):
    result = metadata.get(key, default)
    return result[0] if isinstance(result, list) and result else result


def fingerprint(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


class PublicClient:
    def __init__(self, transport=None):
        self.client = httpx.Client(timeout=20, transport=transport, follow_redirects=False,
                                   headers={"User-Agent": "SLM-grant-prototype/2.0 (official public funding discovery)"})

    def close(self):
        self.client.close()

    def request(self, method, url, **kwargs):
        for attempt in range(3):
            current = safe_url(url)
            for _ in range(4):
                with self.client.stream(method, current, **kwargs) as response:
                    if response.is_redirect:
                        current = safe_url(urljoin(current, response.headers["location"]))
                        continue
                    if response.status_code in {429, 502, 503, 504} and attempt < 2:
                        break
                    response.raise_for_status()
                    data = bytearray()
                    for part in response.iter_bytes():
                        data.extend(part)
                        if len(data) > MAX_BYTES:
                            raise ValueError("Official response exceeds retrieval limit")
                    return bytes(data), current
            if attempt < 2:
                time.sleep(min(2 ** attempt, 4))
        raise ValueError("Official source did not return a usable response")

    def json(self, method, url, **kwargs):
        body, final = self.request(method, url, **kwargs)
        return json.loads(body), final


def normalize_rvo(row):
    if not isinstance(row, dict) or not row.get("id") or not row.get("url") or not row.get("title"):
        raise ValueError("RVO index schema changed")
    title = clean(row["title"])
    url = safe_url(urljoin("https://www.rvo.nl", row["url"]))
    supporting = bool(re.search(r"(?i)^(publicaties|offici[eë]le bekendmakingen|aanvraaginformatie|na uw aanvraag|veelgestelde vragen|wijzigingen|projectbeheer|handleiding|documenten)", title))
    return {"provider": "rvo", "external_id": row["id"], "title": title, "url": url,
            "programme": "", "description": clean(row.get("intro")), "instrument": instrument(title + " " + clean(row.get("intro"))),
            "tags": list(dict.fromkeys(row.get("sectors", []) + row.get("subjects", []) + row.get("tags", []))),
            "source_geography": row.get("countries", []), "targets": row.get("targets", []),
            "kind": "supporting" if supporting else "opportunity", "language": "nl",
            "opens_at": None, "deadlines": [], "source_status": None,
            "index_hash": fingerprint(row), "source_changed_at": row.get("changed"), "raw": row}


def normalize_eu(row):
    m = row.get("metadata", {})
    identifier = value(m, "identifier")
    if str(value(m, "type")) not in {"1", "2", "8"} or not identifier:
        raise ValueError("EU returned unrelated results; query/filter contract failed")
    title = clean(value(m, "title") or row.get("summary"))
    raw_url = value(m, "url") or row.get("url", "")
    safe_url(raw_url)
    blocks = []
    for name in ("descriptionByte", "description", "topicConditions", "conditions", "objective", "scope"):
        for text in m.get(name, []) if isinstance(m.get(name), list) else [m.get(name, "")]:
            text = clean(text)
            if text:
                blocks.append({"id": "eu-" + str(len(blocks)), "locator": "EU topic " + name, "text": text})
    tags = m.get("keywords", []) + m.get("focusArea", [])
    return {"provider": "eu", "external_id": identifier, "title": title,
            "url": ("https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/" + identifier) if "/topicDetails/" in raw_url else raw_url,
            "detail_url": raw_url, "programme": str(value(m, "callIdentifier") or identifier),
            "description": "\n".join(b["text"] for b in blocks) or title,
            "instrument": instrument(title + " " + ("\n".join(b["text"] for b in blocks))[:300]), "tags": [clean(t) for t in tags], "targets": [], "kind": "opportunity",
            "language": row.get("language", "en"), "opens_at": value(m, "startDate") or None,
            "deadlines": m.get("deadlineDate", []), "source_status": str(value(m, "status")) or None,
            "index_hash": fingerprint(m), "blocks": blocks, "raw": m}


def instrument(text):
    text = text.casefold()
    if re.search(r"\b(wbso|belasting|tax relief|fiscaal|aftrek)\b", text):
        return "tax_relief"
    if re.search(r"\b(borgstelling|garantie|guarantee)\b", text):
        return "guarantee"
    if re.search(r"\b(krediet|kredieten|lening|leningen|loans?)\b", text):
        return "loan"
    if re.search(r"\b(risicokapitaal|equity|venture capital|investeringsfondsen)\b", text):
        return "equity"
    return "grant"


def index_page(client, provider, cursor):
    if provider == "rvo":
        data, _ = client.json("GET", RVO_API, params={"page": cursor})
        if not isinstance(data, list):
            raise ValueError("RVO returned an invalid index")
        return [normalize_rvo(r) for r in data], (cursor + 1 if len(data) == 50 else None), None
    if provider == "snn":
        return snn_page(client, cursor)
    if provider != "eu":
        raise ValueError("Unknown funding provider")
    query = {"bool": {"must": [{"terms": {"type": ["1", "2", "8"]}},
                              {"terms": {"status": ["31094501", "31094502"]}},
                              {"term": {"language": "en"}}]}}
    data, _ = client.json("POST", EU_API, params={"apiKey": "SEDIA", "text": "***", "pageSize": 100, "pageNumber": cursor + 1},
                          files={"query": (None, json.dumps(query), "application/json")})
    if not isinstance(data, dict) or "results" not in data or "totalResults" not in data:
        raise ValueError("EU search schema changed")
    rows = [normalize_eu(r) for r in data["results"]]
    if any(r["language"] != "en" for r in rows):
        raise ValueError("EU language filter was not applied")
    total = int(data["totalResults"])
    if not rows and cursor * 100 < total:
        raise ValueError("EU pagination ended before its reported total")
    return rows, (cursor + 1 if (cursor + 1) * 100 < total else None), total


def snn_page(client, cursor):
    from urllib.parse import parse_qs
    url = "https://www.snn.nl/zakelijke-subsidies/subsidies-voor-zakelijk"
    data, final = client.request("GET", url, params={"page": cursor})
    soup = BeautifulSoup(data, "html.parser")
    main = soup.find("main")
    if main is None or not main.find("h1"):
        raise ValueError("SNN catalogue structure changed")
    records, seen, next_pages = [], set(), []
    for anchor in main.find_all("a", href=True):
        target = urljoin(final, anchor["href"])
        parsed = urlparse(target)
        page = parse_qs(parsed.query).get("page")
        if page and page[0].isdigit() and int(page[0]) > cursor:
            next_pages.append(int(page[0]))
        if parsed.hostname not in {"www.snn.nl", "snn.nl"} or not parsed.path.startswith("/zakelijke-subsidies/") or parsed.path.rstrip("/") == urlparse(url).path:
            continue
        title = clean(anchor.get_text(" ", strip=True))
        if not title or target in seen:
            continue
        seen.add(target)
        card = anchor.find_parent("article") or anchor.find_parent(class_=re.compile("views-row|teaser|card")) or anchor
        intro = clean(card.get_text(" ", strip=True))
        records.append({"provider": "snn", "external_id": parsed.path.rstrip("/"), "url": safe_url(target),
            "title": title, "description": intro, "programme": "", "tags": [], "targets": [],
            "instrument": instrument(title + " " + intro), "kind": "opportunity", "language": "nl",
            "opens_at": None, "deadlines": [], "source_status": None,
            "index_hash": fingerprint({"url": target, "title": title, "description": intro}),
            "source_geography": [{"name": "Northern Netherlands", "meaning": "publishing authority region"}]})
    if not records:
        raise ValueError("SNN catalogue yielded no opportunity records")
    return records, min(next_pages) if next_pages else None, None


def html_blocks(html):
    soup = BeautifulSoup(html, "html.parser")
    main = soup.find("main") or soup
    for element in main(["script", "style", "nav", "footer", "header"]):
        element.decompose()
    blocks, heading = [], ""
    for element in main.find_all(["h1", "h2", "h3", "h4", "h5", "h6", "p", "li"]):
        if element.find_parent(["aside", "nav"]) or any(
                any(re.search(r"(?i)(?:^|[-_])(card|teaser|related)(?:$|[-_])", cls) for cls in parent.get("class", []))
                for parent in element.parents if parent is not main):
            continue
        # Do not duplicate nested list/paragraph text.
        if element.name in {"p", "li"} and element.find_parent("li"):
            continue
        text = " ".join(element.get_text(" ", strip=True).split())
        if element.name.startswith("h"):
            heading = text
        if text:
            blocks.append({"id": "block-" + str(len(blocks)), "locator": heading or "Official page",
                           "text": text[:18000], **({"heading_level": int(element.name[1])} if element.name.startswith("h") else {})})
    documents = []
    # Status badges are often spans outside paragraphs; keep their exact text.
    for element in main.find_all(["span", "strong"]):
        if any(any("card" in cls or "related" in cls for cls in p.get("class", [])) for p in element.parents if p is not main):
            continue
        text = " ".join(element.get_text(" ", strip=True).split())
        bare_label = re.fullmatch(r"(?i)open|gesloten|tijdelijk gesloten", text) and any(
            any("status" in cls or "label" in cls for cls in p.get("class", [])) for p in [element, *element.parents] if p is not main)
        if bare_label or re.fullmatch(r"(?i)(tijdelijk )?gesloten voor aanvragen|open voor aanvragen|closed for applications", text):
            blocks.append({"id": "status-" + str(len(blocks)), "locator": "Published application status", "text": text})
    for anchor in main.find_all("a", href=True):
        if anchor.find_parent(["aside", "nav"]) or any(
                any(re.search(r"(?i)(?:^|[-_])(card|teaser|related)(?:$|[-_])", cls) for cls in parent.get("class", []))
                for parent in anchor.parents if parent is not main):
            continue
        if re.search(r"\.(pdf|docx|xlsx)(?:$|\?)", anchor["href"], re.I) or re.search(r"(?i)voorwaarden|conditions|handleiding|guidance|bijlagen|call document|application form", anchor.get_text(" ", strip=True)):
            documents.append({"title": anchor.get_text(" ", strip=True), "url": anchor["href"]})
    return blocks, documents


def detail(client, record):
    if record["provider"] != "eu":
        data, final = client.request("GET", record["url"])
        body = data.decode("utf-8", errors="replace")
        blocks, documents = html_blocks(body)
        for document in documents:
            document["url"] = urljoin(final, document["url"])
        soup = BeautifulSoup(body, "html.parser")
        related = []
        for link in (soup.find("main") or soup).find_all("a", href=True):
            target = urljoin(final, link["href"])
            try:
                if funding_page(target) and canonical_url(target) != canonical_url(record["url"]):
                    related.append({"url": canonical_url(target), "title": clean(link.get_text(" ", strip=True))})
            except ValueError:
                pass
    else:
        related = []
        try:
            data, final = client.json("GET", record["detail_url"])
        except (httpx.HTTPError, ValueError):
            query = {"bool": {"must": [{"term": {"identifier": record["external_id"]}}, {"term": {"language": "en"}},
                                       {"terms": {"type": ["1", "2", "8"]}}]}}
            response, final = client.json("POST", EU_API, params={"apiKey": "SEDIA", "text": record["external_id"], "pageSize": 10},
                files={"query": (None, json.dumps(query), "application/json")})
            match = next((r for r in response.get("results", []) if value(r.get("metadata", {}), "identifier") == record["external_id"]
                          and str(value(r.get("metadata", {}), "type")) in {"1", "2", "8"}), None)
            if not match:
                raise ValueError("EU topic details are unavailable; index retained")
            data = match["metadata"]
        body = json.dumps(data, ensure_ascii=False)
        blocks, documents = [], []

        def visit(item, path="Topic"):
            if isinstance(item, dict):
                for key, child in item.items():
                    if key.lower() in {"url", "downloadurl"} and isinstance(child, str) and re.search(r"\.(pdf|docx|xlsx)(?:$|\?)", child, re.I):
                        documents.append({"title": str(item.get("title") or item.get("name") or "Official document"), "url": child})
                    if key.lower() not in {"latestinfos", "faq", "keywords", "translations"}:
                        visit(child, path + " / " + key)
            elif isinstance(item, list):
                for child in item:
                    visit(child, path)
            elif isinstance(item, str) and len(item) > 50 and not item.startswith("http"):
                if not re.search(r"(?i)description|conditions|scope|objective|eligib|admissib|destination|criteria|abstract|expectedoutcome", path):
                    return
                extracted, linked = html_blocks(item) if "<" in item else ([], [])
                if extracted:
                    for block in extracted:
                        blocks.append({**block, "id": "block-" + str(len(blocks)), "locator": path + " / " + block["locator"]})
                    documents.extend(linked)
                else:
                    text = clean(item)
                    if text:
                        blocks.append({"id": "block-" + str(len(blocks)), "locator": path, "text": text[:18000]})
        visit(data)
    if not blocks:
        raise ValueError("Official detail returned no readable text")
    # The shared document collector reads linked files once and retains their
    # call/annex/template scope, rather than flattening PDF text into this page.
    overview = any(re.search(r"(?i)voor welke (?:innovatie|subsidie)|welke subsid", b["text"]) for b in blocks if len(b["text"]) < 200)
    return {"blocks": blocks[:250], "documents": documents[:60], "detail_fetched_at": now(),
            "document_errors": [], "related_opportunities": list({item["url"]: item for item in related}.values())[:30],
            **({"kind": "programme"} if overview and record["provider"] == "rvo" else {}),
            "detail_hash": hashlib.sha256(body.encode()).hexdigest(), "detail_error": None}, final, body
