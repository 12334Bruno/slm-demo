"""Call the existing application endpoints in a browser worker, without HTTP.

All parsing, validation, calculations and exports use the normal services.
The worker provides a private SQLite filesystem persisted in IndexedDB.
"""
import base64
import inspect
import json
from tempfile import SpooledTemporaryFile
import re
from urllib.parse import parse_qs, unquote, urlsplit

from fastapi import HTTPException, UploadFile
from fastapi.routing import APIRoute
from starlette.responses import Response

from .main import app
from .storage import RevisionConflict
from .browser_runtime import ensure_specification, register_ocr
from .ingestion import MAX_FILE


def uploaded_file(item):
    # Starlette reads in-memory spooled uploads directly. BytesIO would select
    # its thread-pool path, which is unavailable in the WebAssembly runtime.
    file = SpooledTemporaryFile(max_size=MAX_FILE + 1)
    file.write(base64.b64decode(item["content"]))
    file.seek(0)
    return UploadFile(filename=item["name"], file=file)


async def request(serialized):
    payload = json.loads(serialized)
    url = urlsplit("/api" + payload["path"])
    method = payload.get("method", "GET")
    try:
        if url.path == "/api/beta-signups":
            raise ValueError("Beta signup needs a connected server; it is not stored in this browser demo.")
        if url.path.startswith("/api/sources/") and method != "GET":
            raise ValueError("This version uses a published grant snapshot. Check the official source for live updates.")
        register_ocr(payload.get("files", []))
        target = re.match(r"/api/(?:workspaces/[^/]+/(?:applications|opportunities)|opportunities)/([^/]+)", url.path)
        if target:
            ensure_specification(app.state.discovery, target[1])
        for route in app.routes:
            if not isinstance(route, APIRoute) or method not in route.methods:
                continue
            match = route.path_regex.fullmatch(url.path)
            if match is None:
                continue
            arguments = {key: unquote(value) for key, value in match.groupdict().items()}
            query = parse_qs(url.query)
            for field in route.dependant.query_params:
                value = query.get(field.alias, [field.default])[0]
                typed, errors = field.validate(value, {}, loc=("query", field.alias))
                if errors:
                    raise ValueError("Invalid query parameter: " + field.alias)
                arguments[field.name] = typed
            for field in route.dependant.body_params:
                if field.name == "files":
                    arguments[field.name] = [
                        uploaded_file(item)
                        for item in payload.get("files", [])
                    ]
                else:
                    typed, errors = field.validate(payload.get("body") or {}, {}, loc=("body",))
                    if errors:
                        raise ValueError("The supplied information is not valid. Check the fields and try again.")
                    arguments[field.name] = typed
            result = route.endpoint(**arguments)
            if inspect.isawaitable(result):
                result = await result
            if url.path == "/api/status":
                result.update(
                    data_storage="Private browser storage (IndexedDB); documents are processed on this device.",
                    model_notice="Selected text is sent to Groq when cloud AI is enabled. Projects stay in this browser.",
                    browser_runtime=True,
                )
            if isinstance(result, Response):
                if result.media_type == "application/json":
                    return json.dumps({"status": result.status_code, "data": json.loads(result.body)})
                return json.dumps({"status": result.status_code, "content_type": result.media_type,
                                   "headers": dict(result.headers), "content": base64.b64encode(result.body).decode("ascii")})
            return json.dumps({"status": 200, "data": result})
        return json.dumps({"status": 404, "data": {"detail": "Unknown demo action"}})
    except HTTPException as exc:
        return json.dumps({"status": exc.status_code, "data": {"detail": exc.detail}})
    except RevisionConflict as exc:
        return json.dumps({"status": 409, "data": {"detail": str(exc)}})
    except KeyError as exc:
        return json.dumps({"status": 404, "data": {"detail": str(exc)}})
    except ValueError as exc:
        return json.dumps({"status": 422, "data": {"detail": str(exc)}})
