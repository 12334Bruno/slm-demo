"""Call the existing application endpoints in a browser worker, without HTTP.

All parsing, validation, calculations and exports use the normal services.
The worker provides a private SQLite filesystem persisted in IndexedDB.
"""
import base64
import inspect
import json
from tempfile import SpooledTemporaryFile
from urllib.parse import parse_qs, unquote, urlsplit

from fastapi import HTTPException, UploadFile
from fastapi.routing import APIRoute
from starlette.responses import Response

from .main import app
from .storage import RevisionConflict


def uploaded_file(item):
    # Starlette reads in-memory spooled uploads directly. BytesIO would select
    # its thread-pool path, which is unavailable in the WebAssembly runtime.
    file = SpooledTemporaryFile(max_size=10 * 1024 * 1024 + 1)
    file.write(base64.b64decode(item["content"]))
    file.seek(0)
    return UploadFile(filename=item["name"], file=file)


async def request(serialized):
    payload = json.loads(serialized)
    url = urlsplit("/api" + payload["path"])
    method = payload.get("method", "GET")
    try:
        if url.path == "/api/beta-signups":
            raise ValueError("Beta signup needs a connected server; it is not stored in this browser demo.")
        if "/analysis" in url.path:
            raise ValueError("Assisted analysis requires the local server and an active Codex session.")
        if url.path.startswith("/api/sources/") and method != "GET":
            raise ValueError("Live source refresh is available in the local server app. Official source links remain available in this demo.")
        for route in app.routes:
            if not isinstance(route, APIRoute) or method not in route.methods:
                continue
            match = route.path_regex.fullmatch(url.path)
            if match is None:
                continue
            arguments = {key: unquote(value) for key, value in match.groupdict().items()}
            query = parse_qs(url.query)
            for field in route.dependant.query_params:
                arguments[field.name] = query.get(field.alias, [field.default])[0]
            for field in route.dependant.body_params:
                if field.name == "files":
                    arguments[field.name] = [
                        uploaded_file(item)
                        for item in payload.get("files", [])
                    ]
                else:
                    arguments[field.name] = field.type_.model_validate(payload.get("body") or {})
            result = route.endpoint(**arguments)
            if inspect.isawaitable(result):
                result = await result
            if url.path == "/api/status":
                result.update(
                    model_configured=False,
                    data_storage="Private browser storage (IndexedDB); documents are processed on this device.",
                    model_notice="This public demo uses basic mode without external model calls.",
                )
            if isinstance(result, Response):
                return json.dumps({"status": result.status_code, "content_type": result.media_type,
                                   "content": base64.b64encode(result.body).decode("ascii")})
            return json.dumps({"status": 200, "data": result})
        return json.dumps({"status": 404, "data": {"detail": "Unknown demo action"}})
    except HTTPException as exc:
        return json.dumps({"status": exc.status_code, "data": {"detail": exc.detail}})
    except RevisionConflict as exc:
        return json.dumps({"status": 409, "data": {"detail": str(exc)}})
    except KeyError as exc:
        return json.dumps({"status": 404, "data": {"detail": str(exc)}})
    except ValueError as exc:
        return json.dumps({"status": 422, "data": {"detail": str(exc)}})
