"""Browser-only adapters; normal server execution continues to use its native services."""
from collections import deque
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import httpx


class BrowserQueue:
    def __init__(self):
        self.jobs = deque()

    def submit(self, function, *args):
        self.jobs.append((function, args))


class BrowserTransport(httpx.BaseTransport):
    def handle_request(self, request):
        # XMLHttpRequest runs inside the dedicated worker, leaving the interface responsive.
        from js import slm_http
        if str(request.url).split("/", 3)[:3] != ["https:", "", "api.groq.com"]:
            raise httpx.ConnectError("This browser build uses a static grant catalogue. Upload or paste website text instead.", request=request)
        try:
            result = json.loads(slm_http(str(request.url), request.method, json.dumps(dict(request.headers)), request.content.decode("utf-8")))
            return httpx.Response(result["status"], headers=result["headers"], content=result["body"].encode(), request=request)
        except Exception as exc:
            raise httpx.ConnectError("The browser could not reach Groq. Check your connection and API key.", request=request) from exc


def enable(app, snapshot, version):
    original = httpx.Client.__init__

    def client_init(self, *args, **kwargs):
        kwargs.setdefault("transport", BrowserTransport())
        return original(self, *args, **kwargs)

    httpx.Client.__init__ = client_init
    from .company_analysis import AnalysisService
    AnalysisService.start = lambda self: None
    app.state.discovery.pool = BrowserQueue()
    app.state.discovery.enabled = False
    root = app.state.store.root
    marker = root / "catalogue-version.txt"
    if not marker.exists() or marker.read_text() != version:
        with sqlite3.connect(snapshot) as source, app.state.store.connect() as target:
            for table in ("discovery_records", "grant_documents", "grant_specifications", "grant_specification_heads"):
                if table in {"discovery_records", "grant_specification_heads"}:
                    target.execute('DELETE FROM "' + table + '"')
                rows = source.execute('SELECT * FROM "' + table + '"').fetchall()
                if rows:
                    target.executemany('INSERT OR IGNORE INTO "' + table + '" VALUES (' + ','.join('?' for _ in rows[0]) + ')', rows)
        marker.write_text(version)
    # A closed tab cannot keep a lease alive. Resume saved browser work immediately.
    with app.state.store.connect() as conn:
        for tid, raw in conn.execute("SELECT id, state FROM analysis_tasks"):
            task = json.loads(raw)
            if task.get("status") == "processing":
                task.update(status="interrupted", lease_until=0)
                conn.execute("UPDATE analysis_tasks SET state=? WHERE id=?", (json.dumps(task), tid))
    install_ocr(app)


def ensure_specification(service, rid):
    if service.specifications.latest(rid):
        return
    from .grant_specification import build_specification
    record = service.db.get(rid)
    blocks = record.get("blocks") or [{"id": "snapshot-description", "text": record.get("description") or record["title"],
        "locator": "Public catalogue description", "source_url": record["url"]}]
    source = {"id": rid, "url": record["url"], "title": record["title"], "sha256": record.get("detail_hash") or record.get("index_hash") or rid,
              "format": "html", "role": "call", "fetched": True, "blocks": blocks, "warnings": []}
    service.specifications.save(build_specification(record, [source], failures=[{"url": record["url"],
        "error": "This static snapshot contains the catalogue text. Check the official website for application documents not retained in the snapshot."}]))


def tick(app):
    jobs = app.state.discovery.pool.jobs
    if jobs:
        function, args = jobs.popleft()
        function(*args)
        return True
    return app.state.analysis.run_one()


OCR_RESULTS = {}
PDF_IMAGES = {}


def register_ocr(files):
    import base64
    for item in files:
        data = base64.b64decode(item["content"])
        info = item.get("ocr") or {}
        if "paragraphs" in info:
            OCR_RESULTS[hashlib.sha256(data).hexdigest()] = info["paragraphs"]
        pages = {}
        for page in info.get("pages", []):
            png = base64.b64decode(page["png"])
            OCR_RESULTS[hashlib.sha256(png).hexdigest()] = page["paragraphs"]
            pages[page["number"]] = png
        if pages:
            PDF_IMAGES[hashlib.sha256(data).hexdigest()] = pages


def install_ocr(app):
    from . import ocr, main
    original = main.parse_document
    original_images = ocr.pdf_page_images
    ocr.status = lambda: {"available": True, "reason": None, "engine": "tesseract.js", "languages": ["eng"]}

    def recognize(data, timeout=None):
        found = OCR_RESULTS.get(hashlib.sha256(data).hexdigest())
        if found is None:
            raise ocr.OcrUnavailable("OCR has not been prepared for this image. Upload the image again.")
        return found

    def parse_document(name, content):
        pages = PDF_IMAGES.get(hashlib.sha256(content).hexdigest())
        if pages:
            ocr.pdf_page_images = lambda page, limit=3: [pages[page.page_number + 1]] if page.page_number + 1 in pages else []
        try:
            return original(name, content)
        finally:
            ocr.pdf_page_images = original_images

    ocr.recognise = recognize
    main.parse_document = parse_document
