"""Module 3 company research endpoints: website research, entity checks, registry enrichment.

Every route lives under /api/workspaces/{wid}/ so the hosted per-visitor ownership
middleware applies. Website research is a short background job (progress is polled);
the registry lookup is a single bounded request. Nothing here confirms a fact.
"""
import hashlib
import logging
import os
import re
import threading
from typing import Literal
from urllib.parse import urlsplit
from uuid import uuid4

from fastapi import HTTPException
from pydantic import Field

from . import ocr, registry
from .config import now
from .domain import Strict
from .entity_resolution import CONFIRMED, check_registry_record, check_website, normalise_name, similarity, workspace_identity
from .ingestion import evidence
from .profiles import merge_fact
from .safe_http import FetchError, SafeFetcher, clean_url, site_key
from .storage import touch
from .website_research import ResearchError, build_document, plain_text, research_site

LOG = logging.getLogger(__name__)
MAX_DOCUMENTS = 100
MAX_REGISTRY_LOOKUPS = 5


class WebsiteRequest(Strict):
    url: str = Field(min_length=1, max_length=2048)
    expected_revision: int


class DecisionRequest(Strict):
    document_id: str = Field(min_length=1, max_length=64)
    decision: Literal["use_anyway", "discard"]
    expected_revision: int


class RemovePageRequest(Strict):
    document_id: str = Field(min_length=1, max_length=64)
    url: str = Field(min_length=1, max_length=2048)
    expected_revision: int


class RegistryRequest(Strict):
    expected_revision: int
    kvk_number: str | None = Field(default=None, max_length=20)
    name: str | None = Field(default=None, max_length=200)


class Superseded(Exception):
    """The workspace was reset, or newer research replaced this job."""


def website_enabled():
    return os.getenv("SLM_WEBSITE_RESEARCH", "1") != "0"


def website_docs(ws):
    return [d for d in ws["documents"] if d.get("source_type") == "website"]


def remove_document(store, ws, doc):
    (store.root / "uploads" / doc["storage_name"]).unlink(missing_ok=True)
    ws["documents"].remove(doc)


def propose_identity(ws, doc, check, forced=False):
    """Add website-derived identity details as proposals; differing values become visible conflicts."""
    if check["held"] and not forced:
        return
    blocks = {b["id"]: b for b in doc["blocks"]}
    expected = workspace_identity(ws)

    def merge(path, value, entry):
        block = blocks.get(entry.get("block_id"))
        if block is not None and entry["snippet"] in block["text"]:
            merge_fact(ws, path, value, [evidence(doc, block, entry["snippet"])])

    numbers = {k["value"]: k for k in check["found"]["kvk"]}
    if len(numbers) == 1:
        number, entry = next(iter(numbers.items()))
        if number not in expected["kvk"]:
            merge("company.registration_number", number, entry)
    stated = site_facts(doc)
    for path, (value, block, snippet) in stated.items():
        current = ws["facts"].get(path) or {}
        if current.get("state") == "confirmed" or path == "company.name" and expected["names"]:
            continue  # Founder-confirmed details and an existing name are never replaced by website text.
        merge_fact(ws, path, value, [evidence(doc, block, snippet)])
    names = [n for n in check["found"]["names"] if n.get("rank", 9) <= 2]
    if names and "company.name" not in stated:
        top = names[0]
        known = expected["names"]
        different = all(similarity(normalise_name(top["value"]), normalise_name(k)) < CONFIRMED for k in known)
        if not known or different and any(c["field"] == "company.name" for c in check["conflicts"]):
            merge("company.name", top["value"], top)


PROVINCE_NAMES = {"south holland": "Zuid-Holland", "zuid-holland": "Zuid-Holland", "zuid holland": "Zuid-Holland",
                  "north holland": "Noord-Holland", "noord-holland": "Noord-Holland", "noord holland": "Noord-Holland",
                  "north brabant": "Noord-Brabant", "noord-brabant": "Noord-Brabant", "utrecht": "Utrecht", "gelderland": "Gelderland",
                  "overijssel": "Overijssel", "limburg": "Limburg", "zeeland": "Zeeland", "friesland": "Friesland", "fryslân": "Friesland",
                  "groningen": "Groningen", "drenthe": "Drenthe", "flevoland": "Flevoland"}
CITY_PROVINCE = {city: province for province, cities in {
    "Zuid-Holland": "rotterdam den haag 's-gravenhage the hague delft leiden dordrecht zoetermeer gouda schiedam vlaardingen rijswijk "
                    "westland naaldwijk alphen aan den rijn leidschendam voorburg katwijk capelle aan den ijssel spijkenisse ridderkerk "
                    "barendrecht wassenaar noordwijk gorinchem oegstgeest zwijndrecht pijnacker nootdorp bleiswijk berkel en rodenrijs "
                    "maassluis hellevoetsluis krimpen aan den ijssel papendrecht sliedrecht leiderdorp voorschoten waddinxveen",
    "Noord-Holland": "amsterdam haarlem zaandam alkmaar hilversum amstelveen hoofddorp purmerend hoorn den helder",
    "Utrecht": "utrecht amersfoort nieuwegein veenendaal zeist houten",
    "Noord-Brabant": "eindhoven tilburg breda 's-hertogenbosch den bosch helmond oss roosendaal",
    "Gelderland": "arnhem nijmegen apeldoorn ede wageningen doetinchem",
    "Overijssel": "enschede zwolle deventer hengelo almelo", "Limburg": "maastricht venlo heerlen sittard roermond",
    "Groningen": "groningen", "Friesland": "leeuwarden", "Drenthe": "assen emmen", "Flevoland": "almere lelystad",
    "Zeeland": "middelburg vlissingen goes terneuzen"}.items()
    for city in [c.replace("_", " ") for c in cities.replace("den haag", "den_haag").replace("the hague", "the_hague").replace("alphen aan den rijn", "alphen_aan_den_rijn")
                 .replace("capelle aan den ijssel", "capelle_aan_den_ijssel").replace("krimpen aan den ijssel", "krimpen_aan_den_ijssel")
                 .replace("berkel en rodenrijs", "berkel_en_rodenrijs").replace("den bosch", "den_bosch").split()]}
CITY_NAMES = "|".join(re.escape(city) for city in sorted(CITY_PROVINCE, key=len, reverse=True))
STATED_CITY = re.compile(r"(?i)\b(?:(?:based|located|gevestigd|headquartered|founded|opgericht|registered|ingeschreven|established)\s+in|"
                         r"(?:startup|start-up|scale-up|company|bedrijf|onderneming|team)\s+(?:from|uit))\s+(" + CITY_NAMES + r")\b")


def stated_city(text):
    """A Dutch city the company says it is based in ("founded in Delft", "startup uit Leiden"): (city, province, sentence part)."""
    found = STATED_CITY.search(text)
    return (found[1], CITY_PROVINCE[found[1].casefold()], found.group(0)) if found else None


LEGAL_NAME = re.compile(r"((?<![\w])(?:[A-Z0-9][\w&'’!\-]*\.?\s){1,4}?)(B\.\s?V\.|BV|N\.\s?V\.|V\.O\.F\.|VOF|C\.V\.)(?=[\s,|.;:)]|$)")


def site_facts(doc):
    """Plain facts a company states about itself on its own website, each with the exact sentence."""
    facts = {}
    has_kvk = any(re.search(r"(?i)\b(?:kvk|kamer van koophandel|chamber of commerce)\b[^0-9]{0,25}\d{8}\b", b["text"]) for b in doc["blocks"])

    def add(path, value, block, snippet):
        if path not in facts and value and snippet in block["text"]:
            facts[path] = (value, block, snippet)

    for block in doc["blocks"]:
        text = block["text"]
        kvk = re.search(r"(?i)\b(?:kvk|kamer van koophandel|chamber of commerce|coc)\b[^0-9]{0,25}(\d{8})\b", text)
        legal = LEGAL_NAME.search(text)
        if legal and (kvk or has_kvk or re.search(r"(?i)registered|ingeschreven|is a (?:registered )?dutch company|copyright|©|all rights reserved", text)):
            name = (legal[1].strip() + " " + legal[2].replace(" ", "")).strip()
            add("company.name", name, block, legal.group(0).strip())
            add("company.legal_form", {"BV": "B.V.", "NV": "N.V.", "VOF": "V.O.F."}.get(legal[2].replace(".", "").replace(" ", ""), legal[2]), block, legal.group(0).strip())
        if kvk:
            add("company.country", "Netherlands", block, kvk.group(0))
        place = re.search(r"(?i)\b(?:based in|located in|gevestigd in|registered in|located at|vestiging in|headquartered in)\s+(?:the\s+)?"
                          r"(south holland|north holland|north brabant|zuid[- ]holland|noord[- ]holland|noord-brabant|utrecht|gelderland|overijssel|"
                          r"limburg|zeeland|friesland|fryslân|groningen|drenthe|flevoland)\b", text)
        if place:
            add("company.province", PROVINCE_NAMES[place[1].casefold().replace("  ", " ")], block, place.group(0))
            add("company.country", "Netherlands", block, place.group(0))
        address = re.search(r"\b([A-Z][\w'’.\- ]{2,40}?\s\d{1,4}[a-zA-Z]?),?\s+(\d{4}\s?[A-Z]{2})\s+([A-Z][a-zà-ÿ'’\- ]{2,30})\b", text)
        if address:
            add("company.address", address[1].strip(), block, address.group(0))
            add("company.postcode", address[2], block, address.group(0))
            add("company.city", address[3].strip(), block, address.group(0))
            add("company.country", "Netherlands", block, address.group(0))
            province = CITY_PROVINCE.get(address[3].strip().casefold())
            if province:
                add("company.province", province, block, address.group(0))
        city = stated_city(text)
        if city:
            add("company.city", city[0], block, city[2])
            add("company.province", city[1], block, city[2])
            add("company.country", "Netherlands", block, city[2])
        email = re.search(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b", text)
        if email and not re.search(r"(?i)@example\.(?:com|org|net|nl)$|no-?reply", email.group(0)):
            add("company.email", email.group(0), block, email.group(0))
        phone = re.search(r"(?:\+31|\b0)[\s-]?\d(?:[\s-]?\d){7,9}\b", text)
        if phone:
            add("company.phone", phone.group(0).strip(), block, phone.group(0).strip())
    first = next((b for b in doc["blocks"] if b.get("source_url") or doc.get("url")), None)
    host = urlsplit(doc.get("url") or "").hostname
    if host and first:
        root = "https://" + host + "/"
        header = next((b for b in doc["blocks"] if root.rstrip("/") in b["text"]), None)
        if header:
            add("company.website", root, header, root.rstrip("/"))
    return facts


class ResearchService:
    def __init__(self, store, analysis):
        self.store, self.analysis = store, analysis
        # Tests install controlled transports/resolvers; production leaves these as None.
        self.transport = self.registry_transport = self.resolver = None
        self.synchronous = False
        self.slots = threading.BoundedSemaphore(3)
        self.active, self.lock = set(), threading.Lock()

    def fetcher(self, **options):
        return SafeFetcher(transport=self.transport, resolver=self.resolver, **options)

    # ---- website research -------------------------------------------------
    def update(self, wid, job_id, **changes):
        with self.store.edit(wid) as ws:
            state = ws.get("research", {}).get("website")
            if not state or state.get("job_id") != job_id:
                raise Superseded()
            state.update(changes)

    def run_website(self, wid, job_id, url):
        try:
            # Site builders inline large scripts and styles; text is still bounded by the document limits.
            with self.fetcher(max_response_bytes=4_000_000, max_total_bytes=16_000_000) as client:
                result = research_site(url, client, progress=lambda message: self.update(wid, job_id, progress=message))
            doc = build_document(result)
            if doc["status"] != "parsed":
                raise ResearchError("The pages contained no readable text.")
            self.commit_website(wid, job_id, doc, result)
        except Superseded:
            pass
        except KeyError:
            pass  # Workspace deleted.
        except ResearchError as exc:
            self.fail(wid, job_id, str(exc))
        except Exception:
            LOG.exception("Website research failed unexpectedly")
            self.fail(wid, job_id, "Research could not be completed. Your saved information is unchanged.")
        finally:
            with self.lock:
                self.active.discard(job_id)
            self.slots.release()

    def fail(self, wid, job_id, message):
        try:
            with self.store.edit(wid) as ws:
                state = ws.get("research", {}).get("website")
                if state and state.get("job_id") == job_id:
                    state.update(status="failed", error=message, finished_at=now(), progress="")
        except KeyError:
            pass

    def commit_website(self, wid, job_id, doc, result):
        with self.store.edit(wid) as ws:
            state = ws.get("research", {}).get("website")
            if not state or state.get("job_id") != job_id:
                return
            for old in [d for d in website_docs(ws) if site_key(urlsplit(d.get("url", "")).hostname or "") == site_key(result["host"])]:
                remove_document(self.store, ws, old)
            if len(ws["documents"]) >= MAX_DOCUMENTS:
                state.update(status="failed", error="Workspace limit is 100 documents. Remove a document or reset first.", finished_at=now(), progress="")
                return
            check = check_website(ws, doc)
            doc["entity_check"] = check
            if check["held"]:
                doc["status"] = "held"
            (self.store.root / "uploads" / doc["storage_name"]).write_text(plain_text(doc), encoding="utf-8")
            ws["documents"].append(doc)
            doc["extracted_modes"] = []
            propose_identity(ws, doc, check)
            state.update(status="completed", document_id=doc["id"], finished_at=now(), progress="", error=None,
                         pages=[{k: p[k] for k in ("url", "topic", "title", "status", "bytes", "retrieved_at")} for p in doc["pages"]],
                         skipped=result["skipped"], robots=result["robots"], url=result["final_url"], verdict=check["verdict"])
            touch(ws, ["*"], "Added website research; review suggested company details before use")

    def start_website(self, wid, body):
        if not website_enabled():
            raise ValueError("Website research is switched off on this server.")
        try:
            url = clean_url(body.url)
        except FetchError as exc:
            raise ValueError(str(exc)) from None
        if not self.slots.acquire(blocking=False):
            raise HTTPException(status_code=429, detail="Website research is busy. Please try again in a minute.")
        job_id = uuid4().hex
        try:
            with self.store.edit(wid, body.expected_revision) as ws:
                state = ws.get("research", {}).get("website")
                if state and state.get("status") == "running" and state.get("job_id") in self.active:
                    raise ValueError("Website research is already running for this project.")
                if len(ws["documents"]) >= MAX_DOCUMENTS:
                    raise ValueError("Workspace limit is 100 documents. Reset or use a new workspace.")
                ws.setdefault("research", {})["website"] = {
                    "status": "running", "job_id": job_id, "url": url, "host": urlsplit(url).hostname, "started_at": now(),
                    "finished_at": None, "progress": "Starting", "error": None, "document_id": None, "pages": [], "skipped": []}
                touch(ws, ["research"], "Started website research")
        except BaseException:
            self.slots.release()
            raise
        with self.lock:
            self.active.add(job_id)
        if self.synchronous:
            self.run_website(wid, job_id, url)
        else:
            threading.Thread(target=self.run_website, args=(wid, job_id, url), daemon=True, name="slm-website-research").start()

    def decide(self, wid, body):
        with self.store.edit(wid, body.expected_revision) as ws:
            doc = next((d for d in website_docs(ws) if d["id"] == body.document_id), None)
            if doc is None:
                raise ValueError("That website document was not found.")
            state = ws.setdefault("research", {}).get("website") or {}
            if body.decision == "discard":
                remove_document(self.store, ws, doc)
                state.update(status="discarded", document_id=None, progress="", verdict=None)
                touch(ws, ["*"], "Discarded website research")
                return
            if doc["status"] != "held":
                raise ValueError("This website is not waiting for a decision.")
            doc["status"] = "parsed"
            check = doc["entity_check"]
            check.update(held=False, decision="use_anyway", decided_at=now())
            propose_identity(ws, doc, check, forced=True)
            touch(ws, ["*"], "Founder chose to use a website that may belong to another company")

    def remove_page(self, wid, body):
        """Drop one fetched page's text from the website document, e.g. a page about another company."""
        with self.store.edit(wid, body.expected_revision) as ws:
            doc = next((d for d in website_docs(ws) if d["id"] == body.document_id), None)
            if doc is None:
                raise ValueError("That website document was not found.")
            if not any(p["url"] == body.url for p in doc["pages"]):
                raise ValueError("That page is not part of this website research.")
            doc["pages"] = [p for p in doc["pages"] if p["url"] != body.url]
            doc["blocks"] = [b for b in doc["blocks"] if b.get("url") != body.url]
            state = ws.setdefault("research", {}).get("website") or {}
            state["pages"] = [p for p in state.get("pages", []) if p["url"] != body.url]
            if doc["blocks"]:
                doc["sha256"] = hashlib.sha256("\n".join(b["text"] for b in doc["blocks"]).encode()).hexdigest()
                (self.store.root / "uploads" / doc["storage_name"]).write_text(plain_text(doc), encoding="utf-8")
            else:
                remove_document(self.store, ws, doc)
                state.update(status="discarded", document_id=None, progress="", verdict=None)
            touch(ws, ["*"], "Removed a website page from research")

    # ---- registry ---------------------------------------------------------
    def lookup_registry(self, wid, body):
        ws = self.store.load(wid)
        if ws["revision"] != body.expected_revision:
            from .storage import RevisionConflict
            raise RevisionConflict("Workspace changed. Reload before looking up the registry.")
        state = ws.get("research", {}).get("registry") or {}
        if state.get("lookups", 0) >= MAX_REGISTRY_LOOKUPS:
            raise ValueError("The registry lookup limit for this project has been reached.")
        identity = workspace_identity(ws)
        try:
            kvk = registry.kvk_digits(body.kvk_number) if body.kvk_number else (identity["kvk"][0] if len(identity["kvk"]) == 1 else None)
        except registry.RegistryError as exc:
            raise ValueError(str(exc)) from None
        name = (body.name or "").strip() or (identity["names"][0] if identity["names"] else None)
        use_open_dataset = not registry.configured()
        if use_open_dataset and kvk is None:
            raise ValueError(registry.OPEN_NEEDS_KVK)
        if kvk is None and not name:
            raise ValueError("Enter a KVK number or a company name to look up.")
        try:
            registry.reserve()
            with registry.fetcher(self.registry_transport or self.transport, self.resolver) as client:
                if kvk is None:
                    outcome = {"status": "candidates", "candidates": registry.search_by_name(name, client), "record": None,
                               "proposals": [], "conflicts": [], "error": None}
                elif use_open_dataset:
                    record = registry.fetch_open_record(kvk, client)
                    outcome = {"status": "found", "candidates": [], "record": record, "proposals": registry.open_proposals(record),
                               "conflicts": [], "error": None}
                else:
                    record = registry.fetch_profile(kvk, client)
                    outcome = {"status": "found", "candidates": [], "record": record, "proposals": registry.proposals(record),
                               "conflicts": check_registry_record(ws, record)["conflicts"], "error": None}
        except registry.RegistryError as exc:
            outcome = {"status": "failed", "candidates": [], "record": None, "proposals": [], "conflicts": [], "error": str(exc)}
        with self.store.edit(wid, body.expected_revision) as current:
            previous = current.setdefault("research", {}).get("registry") or {}
            current["research"]["registry"] = {**outcome, "lookups": previous.get("lookups", 0) + 1, "checked_at": now()}
            for item in outcome["proposals"]:
                if item["path"]:
                    merge_fact(current, item["path"], item["value"], [item["evidence"]])
            touch(current, ["research"] + [i["path"] for i in outcome["proposals"] if i["path"]], "Registry lookup; official details are proposals")

    # ---- status -------------------------------------------------------------
    def website_view(self, ws):
        state = (ws.get("research") or {}).get("website")
        if not state:
            return None
        view = dict(state)
        if view["status"] == "running" and view.get("job_id") not in self.active:
            view.update(status="failed", error="Research was interrupted. Please run it again.", progress="")
        view.pop("job_id", None)
        doc = next((d for d in website_docs(ws) if d["id"] == view.get("document_id")), None)
        view["entity_check"] = doc.get("entity_check") if doc else None
        view["document_status"] = doc["status"] if doc else None
        return view

    def status(self, ws):
        ocr_state = ocr.status()
        registry_state = dict((ws.get("research") or {}).get("registry") or {})
        registry_state.pop("lookups", None)
        return {"website": self.website_view(ws), "website_enabled": website_enabled(), "registry_configured": registry.configured(),
                "registry": registry_state or None, "ocr_available": ocr_state["available"],
                "ocr_message": None if ocr_state["available"] else ocr.OCR_UNAVAILABLE}


def register(app, store, analysis, workspace_view):
    """Routes live under /api/workspaces/{wid}/ so hosted ownership checks apply."""
    service = ResearchService(store, analysis)
    app.state.research = service

    @app.get("/api/workspaces/{wid}/research")
    def research_status(wid: str):
        return service.status(store.load(wid))

    @app.get("/api/workspaces/{wid}/research/website")
    def website_status(wid: str):
        return service.status(store.load(wid))["website"]

    @app.post("/api/workspaces/{wid}/research/website")
    def research_website(wid: str, body: WebsiteRequest):
        service.start_website(wid, body)
        return workspace_view(store.load(wid))

    @app.post("/api/workspaces/{wid}/research/website/decision")
    def website_decision(wid: str, body: DecisionRequest):
        service.decide(wid, body)
        return workspace_view(store.load(wid))

    @app.post("/api/workspaces/{wid}/research/website/remove-page")
    def website_remove_page(wid: str, body: RemovePageRequest):
        service.remove_page(wid, body)
        return workspace_view(store.load(wid))

    @app.post("/api/workspaces/{wid}/research/registry")
    def research_registry(wid: str, body: RegistryRequest):
        service.lookup_registry(wid, body)
        return workspace_view(store.load(wid))
