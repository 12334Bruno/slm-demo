from copy import deepcopy
from pathlib import Path
from typing import Annotated
from uuid import uuid4
from contextlib import asynccontextmanager
import os
from fastapi import FastAPI, File, UploadFile, HTTPException, Request
from fastapi.responses import Response, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from .config import CATALOGUE, FORM, KIT, ROOT, MAIN_GRANT, now
from .storage import Store, RevisionConflict, touch
from .domain import (ALL_PATHS, BOOL_PATHS, INT_PATHS, DATE_PATHS, ProfilePatch, BudgetPatch, FundingPatch,
                     ContextChange, ExtractionRequest, DraftRequest, DraftEdit, LinkLetter)
from .ingestion import parse_document, founder_evidence, MAX_FILE
from .extraction import basic_extract, apply_extraction, LABELS
from .profiles import apply_profile_patch, correct_fact
from .rules import evaluate
from .drafting import generate_basic_sections, save_generated_draft
from .questions import missing_questions
from .model_adapter import configured, extract_with_model, write_with_model
from .sources import FUNDING_SOURCES, refresh_source
from .export import official_docx, checklist, template_validation
from .examples import open_filled_example


def field_metadata():
    fields = []
    for path in sorted(ALL_PATHS):
        label = next(iter(LABELS.get(path, [])), path.split(".", 1)[1].replace("_", " ")).capitalize()
        if path.startswith("narrative."):
            label = next(s["expected_heading"] for s in FORM["sections"] if s["id"] == path.split(".")[1])
        kind = "boolean" if path in BOOL_PATHS else "date" if path in DATE_PATHS else "number" if path in INT_PATHS or path == "company.fte" else "text"
        fields.append({"path": path, "label": label, "type": kind, "money_cents": path.endswith("_cents")})
    return fields


def create_app(store=None, discovery_service=None, analysis_executor=None):
    from .hosted_access import register as register_hosted, hosted
    from .beta import register as register_beta
    from .company_analysis import AnalysisService
    from .analysis_api import register as register_analysis
    from .discovery import DiscoveryService
    from .discovery_api import register
    workspace_store = store or Store()
    discovery = discovery_service or DiscoveryService(workspace_store, enabled=store is None and os.getenv("SLM_DISCOVERY_ENABLED", "1") == "1")

    @asynccontextmanager
    async def lifespan(app):
        discovery.start()
        analysis.start()
        yield
        analysis.close()
        discovery.close()

    app = FastAPI(title="SLM grant preparation", version="1.1.0", lifespan=lifespan)
    app.state.store = workspace_store
    register_hosted(app, workspace_store)
    register_beta(app, workspace_store)
    app.state.discovery = discovery
    analysis = AnalysisService(workspace_store, executor=analysis_executor)
    app.state.analysis = analysis
    allowed_origins = {"http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:8000", "http://127.0.0.1:8000"}
    allowed_origins.update(o.strip() for o in os.getenv("SLM_ALLOWED_ORIGINS", "").split(",") if o.strip())
    app.add_middleware(CORSMiddleware, allow_origins=sorted(allowed_origins),
                       allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE"], allow_headers=["Content-Type"])

    @app.middleware("http")
    async def local_origin(request: Request, call_next):
        origin = request.headers.get("origin")
        if not hosted() and request.method in {"POST", "PATCH", "PUT", "DELETE"} and origin and origin not in allowed_origins:
            return JSONResponse(status_code=403, content={"detail": "This local workspace accepts changes only from its local interface."})
        return await call_next(request)

    @app.exception_handler(KeyError)
    async def key_error(request, exc):
        return JSONResponse(status_code=404, content={"detail": str(exc)})

    @app.exception_handler(ValueError)
    async def value_error(request, exc):
        return JSONResponse(status_code=422, content={"detail": str(exc)})

    @app.exception_handler(RevisionConflict)
    async def revision_error(request, exc):
        return JSONResponse(status_code=409, content={"detail": str(exc)})

    def view(ws):
        analysis.sync(ws)
        return {**ws, "evaluation": evaluate(ws)}

    register(app, discovery, view)
    register_analysis(app, analysis, view)

    @app.get("/api/status")
    def status():
        return {"mode": "Basic extraction / Template-assisted draft", "model_configured": configured(),
                "server_time": now(), "data_storage": "Private browser-session workspaces on this server." if hosted() else "Local SQLite and local upload files; no user accounts or encryption at rest.",
                "automatic_analysis": {"configured": analysis.automatic, "provider": "Groq"},
                "temporary_storage": os.getenv("SLM_EPHEMERAL") == "1",
                "model_notice": "Selecting model mode sends document text / confirmed facts to OpenAI. Rules and arithmetic remain deterministic.",
                "catalogue_notice": "Automatic RVO/EU discovery with supported-condition screening. The worked application retains its three reviewed records."}

    @app.get("/api/catalogue")
    def catalogue():
        return {**CATALOGUE, "sources": list(FUNDING_SOURCES.values()), "sections": FORM["sections"], "fields": field_metadata()}

    @app.get("/api/workspaces")
    def list_workspaces():
        return app.state.store.list()

    @app.post("/api/workspaces")
    def create_workspace():
        return view(app.state.store.create())

    @app.post("/api/examples/filled-application")
    def filled_example():
        return view(open_filled_example(app.state.store))

    @app.get("/api/workspaces/{wid}")
    def get_workspace(wid: str):
        return view(app.state.store.load(wid))

    @app.post("/api/workspaces/{wid}/reset")
    def reset_workspace(wid: str):
        result = app.state.store.reset(wid)
        analysis.reset(wid)
        discovery.db.reset_workspace(wid)
        return view(result)

    def save_documents(wid, items):
        parsed = [parse_document(name, data) for name, data in items]
        with app.state.store.edit(wid) as ws:
            if len(ws["documents"]) + len(parsed) > 100:
                raise ValueError("Workspace limit is 100 documents. Reset or use a new workspace.")
            for doc, (_, data) in zip(parsed, items):
                if doc["status"] == "parsed":
                    (app.state.store.root / "uploads" / doc["storage_name"]).write_bytes(data)
                doc["extracted_modes"] = []
                ws["documents"].append(doc)
            touch(ws, ["*"], "Uploaded documents; extract and confirm before use")
        return view(app.state.store.load(wid))

    @app.post("/api/workspaces/{wid}/documents")
    async def upload(wid: str, files: Annotated[list[UploadFile], File()]):
        if len(files) > 10:
            raise ValueError("Upload up to 10 files at a time")
        items = []
        for file in files:
            items.append((file.filename or "document", await file.read(MAX_FILE+1)))
            await file.close()
        return save_documents(wid, items)

    @app.post("/api/workspaces/{wid}/samples/{pack}")
    def sample(wid: str, pack: str):
        folders = {"baseline": "input_documents", "financing": "follow_up_documents", "conflict": "edge_case_documents", "prose": "edge_case_documents"}
        if pack not in folders:
            raise ValueError("Unknown sample pack")
        paths = sorted((KIT / folders[pack]).iterdir())
        if pack in {"conflict", "prose"}:
            paths = [p for p in paths if p.name.startswith("05_" if pack == "conflict" else "06_")]
        # Explicit sample convenience only. Exactly the same bytes/parser as upload.
        return save_documents(wid, [(p.name, p.read_bytes()) for p in paths if p.suffix in {".pdf", ".docx", ".txt"}])

    @app.post("/api/workspaces/{wid}/extract")
    def extract(wid: str, body: ExtractionRequest):
        initial = app.state.store.load(wid)
        docs = [d for d in initial["documents"] if d["status"] == "parsed" and body.mode not in d["extracted_modes"]]
        if not docs:
            return view(initial)
        result = basic_extract(docs)
        used_mode, warnings, call = "Basic extraction", [], None
        if body.mode == "model":
            try:
                model_result, call = extract_with_model(docs, ALL_PATHS)
                # Model interpretation replaces overlapping basic fact proposals;
                # matching/calculation never consume model decisions.
                model_paths = {f["path"] for f in model_result["facts"]}
                result["facts"] = [f for f in result["facts"] if f["path"] not in model_paths] + model_result["facts"]
                known_rows = {r["id"] for r in result["budget_lines"]}
                result["budget_lines"] += [r for r in model_result["budget_lines"] if r["id"] not in known_rows]
                known_sources = {s["id"] for s in result["funding_sources"]}
                result["funding_sources"] += [s for s in model_result["funding_sources"] if s["id"] not in known_sources]
                used_mode = "Model extraction (validated proposals)"
            except Exception as exc:
                warnings.append(str(exc) if isinstance(exc, ValueError) else f"Model request failed ({type(exc).__name__}); basic extraction used. Existing work is preserved.")
                used_mode = "Basic extraction — model unavailable / invalid output"
        with app.state.store.edit(wid, initial["revision"]) as ws:
            apply_extraction(ws, result, used_mode, warnings, call)
            processed = {d["id"] for d in docs}
            for doc in ws["documents"]:
                if doc["id"] in processed:
                    doc["extracted_modes"].append(body.mode)
        return view(app.state.store.load(wid))

    @app.patch("/api/workspaces/{wid}/profile")
    @app.post("/api/workspaces/{wid}/answers")
    def patch_profile(wid: str, body: ProfilePatch):
        with app.state.store.edit(wid, body.expected_revision) as ws:
            apply_profile_patch(ws, body)
        return view(app.state.store.load(wid))

    @app.patch("/api/workspaces/{wid}/budget")
    def patch_budget(wid: str, body: BudgetPatch):
        if len({l.id for l in body.lines}) != len(body.lines):
            raise ValueError("Budget row IDs must be unique")
        with app.state.store.edit(wid, body.expected_revision) as ws:
            old = {l["id"]: l for l in ws["budget_lines"]}
            rows = []
            for line in body.lines:
                item = line.model_dump()
                item["confirmed"], item["state"] = True, "confirmed"
                item["evidence"] = old.get(line.id, {}).get("evidence", []) + [founder_evidence(f"{line.id}: {line.activity_group}; {line.cost_type}; {line.quantity} {line.unit} × {line.rate_cents} cents", "Founder saved budget row")]
                item["history"] = old.get(line.id, {}).get("history", []) + ([{k: deepcopy(v) for k, v in old[line.id].items() if k != "history"}] if line.id in old else [])
                rows.append(item)
            ws["budget_lines"] = rows
            ws["budget_metadata"].update(project_revenues_cents=body.project_revenues_cents,
                                         other_project_costs_cents=body.other_project_costs_cents,
                                         requested_grant_cents=body.requested_grant_cents, confirmed=True)
            ws["budget_metadata"]["evidence"].append(founder_evidence(str(body.model_dump(exclude={"lines"})), "Founder saved budget metadata"))
            touch(ws, ["budget"], "Founder edited budget; calculations recomputed")
        return view(app.state.store.load(wid))

    @app.patch("/api/workspaces/{wid}/funding")
    def patch_funding(wid: str, body: FundingPatch):
        if len({s.id for s in body.sources}) != len(body.sources):
            raise ValueError("Funding source IDs must be unique")
        with app.state.store.edit(wid, body.expected_revision) as ws:
            old = {s["id"]: s for s in ws["funding_sources"]}
            sources = []
            for source in body.sources:
                item = source.model_dump()
                item["state"] = "confirmed"
                item["founder_confirmed"] = True
                item["evidence"] = old.get(source.id, {}).get("evidence", []) + [founder_evidence(f"{source.id}: {source.kind}; {source.amount_cents} cents; {source.status}; {source.note}", "Founder confirmed funding entry; no legal verification")]
                item["history"] = old.get(source.id, {}).get("history", []) + ([{k: deepcopy(v) for k, v in old[source.id].items() if k != "history"}] if source.id in old else [])
                sources.append(item)
            ws["funding_sources"] = sources
            touch(ws, ["funding"], "Founder edited financing plan")
        return view(app.state.store.load(wid))

    @app.post("/api/workspaces/{wid}/funding/link-letter")
    def link_letter(wid: str, body: LinkLetter):
        with app.state.store.edit(wid, body.expected_revision) as ws:
            letter = next((l for l in ws["funding_letters"] if l["id"] == body.letter_id), None)
            source = next((s for s in ws["funding_sources"] if s["id"] == body.funding_source_id), None)
            if not letter or not source:
                raise ValueError("Select an existing letter and funding source")
            if letter["linked_source_id"] and letter["linked_source_id"] != source["id"]:
                raise ValueError("This letter is already linked to another source")
            if letter["amount_cents"] != source["amount_cents"] or letter["kind"] != source["kind"]:
                raise ValueError("Letter amount/type differs from funding source; correct the financing plan first")
            letter.update(linked_source_id=source["id"], state="founder_linked")
            source.setdefault("history", []).append({"at": now(), "status": source["status"], "note": source["note"], "amount_cents": source["amount_cents"]})
            source.update(status="committed", founder_confirmed=True, state="confirmed")
            source["note"] = "Founder confirmed the uploaded letter supports this contribution. Previous proposal wording is retained in evidence/history. Commitment is not legally authenticated."
            source["evidence"] += letter["evidence"] + [founder_evidence(source["id"], "Founder confirmed recipient, project, amount and letter link; no legal authentication")]
            touch(ws, ["funding"], "Founder linked commitment evidence")
        return view(app.state.store.load(wid))

    @app.post("/api/workspaces/{wid}/context")
    def set_context(wid: str, body: ContextChange):
        with app.state.store.edit(wid) as ws:
            if ws["context"]["mode"] != body.mode:
                ws["context"]["mode"] = body.mode
                touch(ws, ["context"], "Changed evaluation date context")
        return view(app.state.store.load(wid))

    @app.post("/api/workspaces/{wid}/evaluate")
    def run_evaluation(wid: str):
        with app.state.store.edit(wid) as ws:
            ws["last_evaluation"] = evaluate(ws)
        return view(app.state.store.load(wid))

    @app.get("/api/workspaces/{wid}/questions")
    def questions(wid: str, grant_id: str = MAIN_GRANT):
        ws = app.state.store.load(wid)
        return missing_questions(ws, evaluate(ws), grant_id)

    @app.post("/api/workspaces/{wid}/drafts")
    def generate_draft(wid: str, body: DraftRequest):
        if body.grant_id != MAIN_GRANT:
            raise ValueError("Drafting is supported only for the MIT feasibility worked application")
        initial = app.state.store.load(wid)
        if initial["revision"] != body.expected_revision:
            raise RevisionConflict("Profile changed; reload before generating the draft")
        evaluation = evaluate(initial)
        sections = generate_basic_sections(initial, evaluation)
        mode, call, warnings = "Template-assisted draft", None, []
        if body.mode == "model":
            try:
                sections, call = write_with_model(initial, sections, next(g for g in evaluation["grants"] if g["id"] == MAIN_GRANT))
                mode = "Model-assisted draft — review required"
            except Exception as exc:
                sections = generate_basic_sections(initial, evaluation)
                warnings.append(str(exc) if isinstance(exc, ValueError) else f"Model writing failed ({type(exc).__name__}); template-assisted draft used.")
        valid_ids = {s["id"] for s in FORM["sections"]}
        if not set(body.regenerate_sections) <= valid_ids:
            raise ValueError("Invalid section regeneration selection")
        with app.state.store.edit(wid, initial["revision"]) as ws:
            save_generated_draft(ws, evaluation, sections, mode, body.regenerate_sections, call, warnings)
            ws["last_evaluation"] = evaluation
        return view(app.state.store.load(wid))

    @app.patch("/api/workspaces/{wid}/drafts/{draft_id}")
    def edit_draft(wid: str, draft_id: str, body: DraftEdit):
        with app.state.store.edit(wid) as ws:
            draft = ws["draft"]
            if not draft or draft["id"] != draft_id:
                raise ValueError("Draft not found")
            if draft["revision"] != body.expected_draft_revision:
                raise RevisionConflict("Draft changed; reload before saving")
            if not set(body.sections) <= {s["id"] for s in draft["sections"]}:
                raise ValueError("Unknown draft section")
            for section in draft["sections"]:
                if section["id"] in body.sections:
                    text = body.sections[section["id"]]
                    if len(text) > 20000:
                        raise ValueError("Section exceeds 20,000 characters")
                    section.setdefault("edit_history", []).append({"at": now(), "text": section["text"], "state": section["state"]})
                    section["text"] = text
                    section["user_edited"] = True
                    section["state"] = "user_edited" if text.strip() else "stale"
                    section["edited_at"] = now()
                    section["evidence"].append(founder_evidence(text, "Founder draft edit; not independently verified"))
                    section["missing_inputs"] = [] if "[NEEDS INPUT:" not in text and text.strip() else section["missing_inputs"]
            draft["revision"] += 1
            draft["stale"] = any(s["state"] == "stale" for s in draft["sections"])
        return view(app.state.store.load(wid))

    @app.get("/api/workspaces/{wid}/exports/{kind}")
    def export(wid: str, kind: str):
        ws = app.state.store.load(wid)
        evaluation = evaluate(ws)
        if kind == "docx":
            return Response(official_docx(ws, evaluation), media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            headers={"Content-Disposition": 'attachment; filename="MIT-feasibility-DRAFT.docx"'})
        if kind == "checklist":
            return Response(checklist(ws, evaluation), media_type="text/plain; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="SLM-checklist.txt"'})
        raise ValueError("Export type must be docx or checklist")

    @app.get("/api/sources")
    def sources():
        return [{**s, "retrieval": app.state.store.retrieval(sid)} for sid, s in FUNDING_SOURCES.items()]

    @app.post("/api/sources/{source_id}/refresh")
    def refresh(source_id: str):
        if source_id not in FUNDING_SOURCES:
            raise ValueError("Only allowlisted official funding source IDs can be refreshed")
        return refresh_source(app.state.store, source_id)

    @app.get("/api/template-status")
    def export_status():
        try:
            template_validation()
            return {"official_format": True, "message": "Original template hash, section map and table labels verified."}
        except ValueError as exc:
            return {"official_format": False, "message": str(exc)}

    dist = ROOT / "frontend" / "dist"
    if (dist / "assets").exists():
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

    @app.get("/")
    def index():
        if (dist / "index.html").exists():
            return FileResponse(dist / "index.html")
        return {"message": "Backend running. Run npm run dev in frontend, or npm run build to serve the app here."}

    return app


app = create_app()
