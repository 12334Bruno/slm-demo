"""Local grant preparation prototype. Runtime never imports operator material."""
