"""Live discovery endpoints; existing application routes remain compatible."""
import re
from fastapi import Query
from fastapi.responses import Response
from pydantic import BaseModel, Field
from .domain import ALL_PATHS, validate_value
from .extraction import basic_extract, apply_extraction
from .ingestion import parse_document, evidence, founder_evidence
from .profiles import correct_fact
from .storage import touch
from .model_adapter import extract_with_model
from .live_matching import public_record
from .funding_conditions import basic_requirements, schedule, money_cents, AMOUNT_PATTERN


class Intake(BaseModel):
    description: str = Field(min_length=5, max_length=12000)
    expected_revision: int
    mode: str = "basic"


class FollowUp(BaseModel):
    field: str
    value: str | bool | int | None
    expected_revision: int


class Saved(BaseModel):
    saved: bool = True


class OfficialImport(BaseModel):
    url: str = Field(min_length=10, max_length=4096)
    mode: str = "basic"


class SpecificationRead(BaseModel):
    version: str


def register(app, service, workspace_view):
    @app.get("/api/discovery/status")
    def discovery_status():
        return service.status()

    @app.post("/api/discovery/sync")
    def sync_sources():
        service.ensure_sync(force=True)
        return service.status()

    @app.post("/api/opportunities/import")
    def import_official(body: OfficialImport):
        if body.mode not in {"basic", "model"}:
            raise ValueError("Unknown processing mode")
        record = service.import_official(body.url, body.mode == "model")
        return {**public_record(record), "schedule": schedule(record)}

    @app.get("/api/discovery/source-candidates")
    def source_candidates():
        return service.documents.candidates()

    @app.get("/api/opportunities/{rid}/specification")
    def specification(rid: str, mode: str = "basic", workspace_id: str | None = None):
        if mode not in {"basic", "model"}:
            raise ValueError("Unknown processing mode")
        result = service.specification(rid, mode == "model")
        if workspace_id and result["specification"]:
            from .grant_specification import evaluate_specification
            result["evaluation"] = evaluate_specification(result["specification"], app.state.store.load(workspace_id))
            seen = service.specifications.seen(workspace_id, rid)
            if seen is None:
                service.specifications.mark_seen(workspace_id, rid, result["specification"]["version"])
            result["review_required"] = bool(seen and seen != result["specification"]["version"])
        return result

    @app.post("/api/workspaces/{wid}/opportunities/{rid}/specification/read")
    def mark_specification_read(wid: str, rid: str, body: SpecificationRead):
        service.specifications.mark_seen(wid, rid, body.version)
        return {"review_required": False}

    @app.post("/api/opportunities/{rid}/specification/refresh")
    def refresh_specification(rid: str, mode: str = "basic"):
        if mode not in {"basic", "model"}:
            raise ValueError("Unknown processing mode")
        return service.specification(rid, model=mode == "model", force=True)

    @app.get("/api/opportunities/{rid}/specification/versions/{version}")
    def specification_version(rid: str, version: str):
        return service.specifications.get(rid, version)

    @app.get("/api/opportunities/{rid}/documents/{digest}")
    def published_template(rid: str, digest: str):
        spec = service.specifications.latest(rid)
        item = next((t for t in spec["templates"] if t["sha256"] == digest), None) if spec else None
        if not item:
            raise KeyError("Published template not found for this grant")
        media = {"docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                 "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                 "pdf": "application/pdf"}.get(item["format"], "application/octet-stream")
        return Response(service.documents.bytes_for(item["url"], digest), media_type=media,
            headers={"Content-Disposition": 'attachment; filename="official-template.' + item["format"] + '"',
                     "X-Content-SHA256": digest})

    @app.get("/api/opportunities")
    def search_opportunities(q: str = "", provider: str = "", status: str = "", page: int = Query(1, ge=1),
                             page_size: int = Query(20, ge=1, le=100), workspace_id: str | None = None, saved: bool = False):
        saved_ids = None
        if saved:
            if not workspace_id:
                raise ValueError("Choose a workspace for saved opportunities")
            app.state.store.load(workspace_id)
            saved_ids = service.db.saved(workspace_id)
        return service.catalogue(q[:500], provider, status, page, page_size, saved_ids)

    @app.get("/api/opportunities/{rid}")
    def opportunity(rid: str):
        record = service.db.get(rid)
        service.investigate([rid])
        return {**public_record(record), "schedule": schedule(record), "blocks": record.get("blocks", []),
                "requirements": record["requirements"] if "requirements" in record else basic_requirements(record),
                "detail_hash": record.get("detail_hash"), "analysis_error": record.get("analysis_error")}

    @app.get("/api/workspaces/{wid}/matches")
    def company_matches(wid: str, mode: str = "basic"):
        if mode not in {"basic", "model"}:
            raise ValueError("Unknown processing mode")
        return service.matches(app.state.store.load(wid), mode == "model")

    @app.put("/api/workspaces/{wid}/opportunities/{rid}")
    def save_opportunity(wid: str, rid: str, body: Saved):
        return {"saved_ids": service.db.save(wid, rid, body.saved)}

    @app.get("/api/workspaces/{wid}/opportunities")
    def saved_opportunities(wid: str):
        app.state.store.load(wid)
        return service.catalogue(saved_ids=service.db.saved(wid), page_size=100)

    @app.post("/api/workspaces/{wid}/discovery/intake")
    def intake(wid: str, body: Intake):
        if body.mode not in {"basic", "model"}:
            raise ValueError("Unknown processing mode")
        doc = parse_document("Project description.txt", body.description.encode())
        doc["extracted_modes"] = [body.mode]
        result = basic_extract([doc])
        call, warnings, used_mode = None, [], "Basic extraction"
        if body.mode == "model":
            try:
                interpreted, call = extract_with_model([doc], ALL_PATHS)
                model_paths = {f["path"] for f in interpreted["facts"]}
                result["facts"] = [f for f in result["facts"] if f["path"] not in model_paths] + interpreted["facts"]
                used_mode = "Model extraction (validated proposals)"
            except Exception as exc:
                warnings.append("Model extraction unavailable; basic extraction used (" + type(exc).__name__ + ").")
        # Explicit ordinary prose facts; no inference of legal SME/VAT status.
        patterns = {
            "company.country": r"(?i)(?:based|established|registered|gevestigd)\s+(?:in\s+)?(?:the\s+)?(Netherlands|Nederland)\b",
            "company.fte": r"(?i)\b(\d+(?:\.\d+)?)\s+(?:FTE|full.time (?:employees|staff)|voltijdmedewerkers)\b",
        }
        for path, pattern in patterns.items():
            found = re.search(pattern, body.description)
            if found:
                prefix = body.description[max(0, found.start() - 16):found.start()]
                if re.search(r"(?i)\b(not|niet|never|no longer)\s*$", prefix):
                    continue
                block = next((b for b in doc["blocks"] if found[0] in b["text"]), None)
                if block is None:
                    block = {"id": doc["id"] + "-description", "text": body.description,
                             "locator": "Founder description, full text", "kind": "description"}
                    doc["blocks"].append(block)
                result["facts"].append({"path": path, "value": float(found[1]) if path.endswith("fte") else found[1],
                                        "evidence": [evidence(doc, block, found[0])]})
        budget = re.search(r"(?i)(?:project budget|projectbudget|budget)\s*(?:is|of|van|:)?\s*(?:EUR|€)\s*" + AMOUNT_PATTERN, body.description)
        if budget and re.match(r"(?i)\s*(?:k|m|million|miljoen)\b", body.description[budget.end():]):
            budget = None
        with app.state.store.edit(wid, body.expected_revision) as ws:
            if len(ws["documents"]) >= 100:
                raise ValueError("Workspace document limit reached")
            ws["documents"].append(doc)
            (app.state.store.root / "uploads" / doc["storage_name"]).write_bytes(body.description.encode())
            apply_extraction(ws, result, used_mode, warnings, call)
            correct_fact(ws, "project.description", body.description, "Founder supplied project description")
            previous_budget = ws.get("discovery_intake", {}).get("budget_cents")
            ws.setdefault("discovery_intake", {})["description_authoritative"] = True
            if budget:
                ws.setdefault("discovery_intake", {}).update(budget_cents=money_cents(budget[1]), budget_confirmed=False,
                    evidence=[founder_evidence(budget[0], "Budget extracted from supplied description; confirm if used")])
            elif not ws.get("discovery_intake", {}).get("budget_confirmed"):
                for key in ("budget_cents", "budget_confirmed", "evidence"):
                    ws.get("discovery_intake", {}).pop(key, None)
            changed_budget = previous_budget != ws.get("discovery_intake", {}).get("budget_cents")
            touch(ws, ["project.description", "budget"] if changed_budget else ["project.description"], "Updated discovery information")
        workspace = app.state.store.load(wid)
        service.matches(workspace, body.mode == "model")
        return workspace_view(workspace)

    @app.post("/api/workspaces/{wid}/discovery/answer")
    def answer(wid: str, body: FollowUp):
        allowed = {"company.country", "company.province", "company.sme_self_declared", "project.primary_activity",
                   "project.independent_sme_participant_count", "project.organisation_count", "project_budget_cents"}
        if body.field not in allowed:
            raise ValueError("Unsupported follow-up field")
        with app.state.store.edit(wid, body.expected_revision) as ws:
            if body.field == "project.organisation_count":
                if type(body.value) is not int or not 1 <= body.value <= 1000:
                    raise ValueError("Organisation count must be a positive whole number")
                ws.setdefault("discovery_intake", {}).update(organisation_count=body.value,
                    organisation_evidence=[founder_evidence(body.value, "Founder confirmed participating organisations")])
            elif body.field == "project_budget_cents":
                if type(body.value) is not int or not 0 <= body.value <= 100_000_000_000:
                    raise ValueError("Budget must be nonnegative EUR cents")
                ws.setdefault("discovery_intake", {}).update(budget_cents=body.value, budget_confirmed=True,
                    evidence=[founder_evidence(body.value, "Founder confirmed proposed project budget")])
            else:
                correct_fact(ws, body.field, validate_value(body.field, body.value), "Founder answered matching question")
            touch(ws, [body.field, "budget"] if body.field == "project_budget_cents" else [body.field], "Answered matching follow-up")
        return workspace_view(app.state.store.load(wid))
