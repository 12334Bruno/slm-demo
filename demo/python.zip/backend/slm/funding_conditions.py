"""Evidence-bound basic interpretation and deterministic condition evaluation."""
import re
from datetime import datetime, date
from zoneinfo import ZoneInfo
from .extraction import cents
from .profiles import fact_value
from .budget import calculate

MONTHS = {name: i for i, pair in enumerate([
    ("januari", "january"), ("februari", "february"), ("maart", "march"), ("april", "april"),
    ("mei", "may"), ("juni", "june"), ("juli", "july"), ("augustus", "august"),
    ("september", "september"), ("oktober", "october"), ("november", "november"), ("december", "december")], 1) for name in pair}
DAY_PATTERN = r"\b(\d{1,2})\s+(" + "|".join(MONTHS) + r")\s+(20\d{2})\b"
PROVINCES = ("Zuid-Holland", "Noord-Holland", "Utrecht", "Noord-Brabant", "Gelderland", "Overijssel",
             "Limburg", "Zeeland", "Friesland", "Fryslân", "Groningen", "Drenthe", "Flevoland")
AMOUNT_PATTERN = r"(\d{1,3}(?:[ \u00a0]\d{3})+(?:[.,]\d{2})?|\d+(?:[.,]\d{3})*(?:[.,]\d{1,2})?)"


def money_cents(raw):
    raw = raw.strip().rstrip(".,").replace("\u00a0", "").replace(" ", "")
    # Grouped thousands in whole project budgets are not decimal unit rates.
    if re.fullmatch(r"\d{1,3}(?:[.,]\d{3})+", raw):
        raw = raw.replace(",", "").replace(".", "")
    return cents(raw)


def reference(record, block, quote=None):
    return {"url": block.get("source_url", record["url"]), "block_id": block["id"], "locator": block["locator"],
            "quote": quote or block["text"], "snapshot_hash": block.get("snapshot_hash", record.get("detail_hash", record.get("index_hash")))}


def dates_in(text):
    found = []
    for match in re.finditer(DAY_PATTERN, text, re.I):
        try:
            found.append((date(int(match[3]), MONTHS[match[2].lower()], int(match[1])).isoformat(), match[0]))
        except ValueError:
            pass
    return found


def application_dates(text):
    """Keep published local times; never infer an unstated year or opening."""
    found = []
    pattern = DAY_PATTERN + r"(?:\s*(?:om|at)?\s*(\d{1,2})[:.](\d{2})(?:\s*(?:uur|hours?))?)?"
    for match in re.finditer(pattern, text, re.I):
        try:
            args = (int(match[3]), MONTHS[match[2].lower()], int(match[1]))
            value = datetime(*args, int(match[4]), int(match[5]), tzinfo=ZoneInfo("Europe/Amsterdam")).isoformat() if match[4] else date(*args).isoformat()
            if value not in found:
                found.append(value)
        except ValueError:
            pass
    return found


def date_value(value):
    if not value:
        return None
    try:
        # Source precision is retained; date-only comparisons include the stated day.
        if len(value) == 10:
            return date.fromisoformat(value)
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None


def schedule(record, clock=None):
    clock = clock or datetime.now(ZoneInfo("Europe/Amsterdam"))
    opens, deadlines, refs = record.get("opens_at"), list(record.get("deadlines") or []), []
    explicit_closed, rolling, reported_open, conflicting_times = False, False, False, False
    for block in record.get("blocks", []):
        text = block["text"]
        # Avoid the publisher's reviewed date and project implementation periods.
        application = block.get("locator") == "Published application status" or bool(re.search(r"(?i)aanvrag|aanvraagperiode|applications?|submission|deadline|call opens|opening date|closing date", text))
        if not application or len(text) > 1800:
            continue
        found = application_dates(text)
        if len(found) == 2 and re.search(r"(?i)(vanaf|van|from|opens).{0,80}\d", text) and re.search(r"(?i)tot|until|through|closes", text):
            if not opens and not deadlines:
                opens, deadlines = found[0], [found[1]]
                refs.append(reference(record, block))
        elif found and not deadlines and re.search(r"(?i)(sluit|uiterlijk|deadline|closing|until|tot en met|t/m)", text):
            # Repeated deadline dates with different explicit times are a source
            # disagreement, rather than an opening/closing range.
            if len({d[:10] for d in found}) != 1:
                continue
            precise = [d for d in found if len(d) > 10]
            deadlines = precise or found
            conflicting_times = len(precise) > 1
            refs.append(reference(record, block))
        if re.search(r"(?i)((?:tijdelijk )?gesloten voor aanvragen|closed for applications|aanvragen is niet meer mogelijk|u kunt geen aanvraag meer)", text):
            explicit_closed = True
            refs.append(reference(record, block))
        if block.get("locator") == "Published application status":
            if re.fullmatch(r"(?i)(?:tijdelijk )?gesloten", text):
                explicit_closed = True
                refs.append(reference(record, block))
            if re.fullmatch(r"(?i)open(?: voor aanvragen)?", text):
                reported_open = True
                refs.append(reference(record, block))
        if re.search(r"(?i)(doorlopend aanvragen|applications.*rolling basis)", text):
            rolling = True
    valid = [(value, date_value(value)) for value in deadlines if date_value(value)]

    def future(value):
        return value.date() >= clock.date() if isinstance(value, datetime) and value.tzinfo is None else (
            value >= clock if isinstance(value, datetime) else value >= clock.date())

    remaining = [(raw, parsed) for raw, parsed in valid if future(parsed)]
    deadline = min(remaining, key=lambda item: item[0])[0] if remaining else (max((x[0] for x in valid), default=None))
    opening = date_value(opens)
    not_open = opening is not None and (opening > clock if isinstance(opening, datetime) and opening.tzinfo else (opening.date() if isinstance(opening, datetime) else opening) > clock.date())
    if conflicting_times or explicit_closed and remaining:
        state = "CONFLICT"
    elif explicit_closed or valid and not remaining:
        state = "CLOSED"
    elif not_open:
        state = "UPCOMING"
    elif remaining and opening:
        state = "WITHIN_WINDOW"
    elif remaining:
        state = "DEADLINE_PUBLISHED"
    elif rolling:
        state = "ROLLING"
    elif reported_open:
        state = "REPORTED_OPEN"
    else:
        state = "UNKNOWN"
    return {"status": state, "opens_at": opens, "deadline": deadline, "deadlines": deadlines,
            "evidence": refs, "source_status": record.get("source_status"),
            "date_precision": "date" if deadline and len(deadline) == 10 else "timestamp" if deadline else None}


def basic_requirements(record):
    result, seen = [], set()

    def add(field, operator, expected, label, block):
        key = (field, operator, str(expected))
        if key in seen:
            return
        seen.add(key)
        result.append({"id": "condition-" + str(len(result)), "field": field, "operator": operator,
                       "expected": expected, "label": label, "evidence": reference(record, block), "interpretation": "basic"})

    segments = []
    for original in record.get("blocks", []):
        for text in re.split(r"(?<=[.;])\s+(?=[A-ZÀ-Ý])", original["text"]):
            if text.strip():
                segments.append({**original, "text": text.strip()})
    for block in segments:
        text = block["text"]
        # Exceptions/alternatives require deeper interpretation rather than a false hard exclusion.
        if len(text) > 2000 or re.search(r"(?i)tenzij|except|\bif\b|\bindien\b|\bals\b|\bmits\b|depending on|afhankelijk|\bor\b|\bof\b|\bnot\b|\bniet\b|\bgeen\b|\bnon[- ]", text):
            continue
        if re.search(r"(?i)(uw (?:onderneming|bedrijf) is|u bent|applicants must be|only|uitsluitend|alleen).{0,35}\b(mkb|sme|small and medium)", text):
            add("company.sme_self_declared", "eq", True, "SME applicant", block)
        if re.search(r"(?i)(uw (?:bedrijf|onderneming).{0,35}(?:gevestigd|geregistreerd)|applicants must be (?:based|established)).{0,15}(?:in )?(?:nederland|the netherlands)", text):
            add("company.country", "eq", "Netherlands", "Established in the Netherlands", block)
        for province in PROVINCES:
            if re.search(r"(?i)(?:uw (?:onderneming|bedrijf)|u).{0,30}(?:gevestigd|vestiging).{0,15}" + re.escape(province), text):
                add("company.province", "eq", province, "Establishment in " + province, block)
        for match in re.finditer(r"(?i)(?:minimaal|at least)\s+(\d{1,2})\s+(?:onafhankelijke\s+)?(?:mkb[- ]?(?:bedrijven|ondernemingen)|independent SMEs)", text):
            add("project.independent_sme_participant_count", "gte", int(match[1]), "Independent SME partners", block)
        for match in re.finditer(r"(?i)(?:at least|minimaal)\s+(three|two|one|\d{1,2})\s+(?:independent\s+)?(?:legal entities|organisations|organizations)", text):
            number = {"one": 1, "two": 2, "three": 3}.get(match[1].lower(), int(match[1]) if match[1].isdigit() else 0)
            add("project.organisation_count", "gte", number, "Number of participating organisations", block)
        for pattern, operator, label in [
            (r"(?i)(?:projectkosten|project budget|project costs).{0,20}(?:minimaal|at least|minimum)\s*(?:EUR|€|£)?\s*" + AMOUNT_PATTERN, "gte", "Minimum project budget"),
            (r"(?i)(?:projectkosten|project budget|project costs).{0,20}(?:maximaal|at most|maximum)\s*(?:EUR|€|£)?\s*" + AMOUNT_PATTERN, "lte", "Maximum project budget"),
            (r"(?i)minimum financial size of (?:the )?(?:actions?|projects?).{0,50}?(?:EUR|€)\s*" + AMOUNT_PATTERN, "gte", "Minimum project budget")]:
            match = re.search(pattern, text)
            if match and not re.search(r"(?i)miljoen|million|\bmln\b|\bGBP\b|\bUSD\b|£|\$", text):
                add("project_budget_cents", operator, money_cents(match[1]), label, block)
        if re.search(r"(?i)(?:uitsluitend|alleen|only).{0,25}(?:haalbaarheidsstudie|feasibility stud)", text):
            add("project.primary_activity", "eq", "feasibility_study", "Feasibility study", block)
    return result


def evaluate_requirements(record, workspace):
    conditions = record["requirements"] if "requirements" in record else basic_requirements(record)
    result = []
    for rule in conditions:
        field = rule["field"]
        extra_key = {"project_budget_cents": "budget_cents", "project.organisation_count": "organisation_count"}.get(field)
        actual = workspace.get("discovery_intake", {}).get(extra_key) if extra_key else fact_value(workspace, field)
        budget_conflict = False
        if field == "project_budget_cents" and workspace["budget_lines"]:
            # Use the same arithmetic as the worked budget/export. A contradictory
            # headline total cannot silently override the uploaded line items.
            calculated = calculate(workspace)["project_total_cents"]
            budget_conflict = any(row.get("state") == "conflict" for row in workspace["budget_lines"]) or (
                calculated is not None and actual is not None and actual != calculated)
            actual = None if budget_conflict else calculated
        fact = workspace["facts"].get(field)
        expected = rule["expected"]
        if field == "company.country" and isinstance(actual, str):
            actual = {"nl": "Netherlands", "nederland": "Netherlands", "the netherlands": "Netherlands"}.get(actual.casefold(), actual)
        if actual is None:
            outcome = "CONFLICT" if budget_conflict or fact and fact["state"] == "conflict" else "UNKNOWN"
        elif rule["operator"] == "eq":
            outcome = "PASS" if (actual.casefold() == expected.casefold() if isinstance(actual, str) and isinstance(expected, str) else actual == expected) else "FAIL"
        elif rule["operator"] == "in":
            outcome = "PASS" if (actual.casefold() in [v.casefold() for v in expected] if isinstance(actual, str) and all(isinstance(v, str) for v in expected) else actual in expected) else "FAIL"
        else:
            outcome = "PASS" if (actual >= expected if rule["operator"] == "gte" else actual <= expected) else "FAIL"
        extra = workspace.get("discovery_intake", {})
        result.append({**rule, "actual": actual, "outcome": outcome,
                       "company_evidence": fact.get("evidence", []) if fact else extra.get("organisation_evidence" if field == "project.organisation_count" else "evidence", []),
                       "confirmed": fact["state"] == "confirmed" if fact else (actual is not None if field == "project.organisation_count" else extra.get("budget_confirmed", False))})
    return result
