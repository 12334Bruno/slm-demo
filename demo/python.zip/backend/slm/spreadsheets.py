"""Bounded XLSX reader using only the standard library.

Values are the results saved by the spreadsheet program: formulas are never
recalculated. Encrypted, corrupt or expanding (zip-bomb) workbooks are rejected
with a plain message. Hidden sheets are not read.
"""
import re
import zipfile
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from io import BytesIO
from xml.etree import ElementTree as ET

MAX_SHEETS = 12
MAX_ROWS = 500
MAX_COLUMNS = 30
MAX_CELLS = 6000
MAX_CELL_CHARS = 2000
MAX_ENTRIES = 300
MAX_PART_BYTES = 25 * 1024 * 1024
MAX_UNCOMPRESSED = 40 * 1024 * 1024
MAX_RATIO = 150
OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
BUILTIN_DATES = {14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 45, 46, 47, 50, 51, 52, 53, 54, 55, 56, 57, 58}
PERCENT_FORMATS = {9, 10}
ERROR_VALUES = {"#NULL!", "#DIV/0!", "#VALUE!", "#REF!", "#NAME?", "#NUM!", "#N/A"}


class WorkbookError(ValueError):
    """The workbook cannot be read; the message is shown to the founder."""


def local(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def column_number(letters):
    number = 0
    for char in letters:
        number = number * 26 + ord(char) - 64
    return number


def column_letters(number):
    letters = ""
    while number:
        number, rest = divmod(number - 1, 26)
        letters = chr(65 + rest) + letters
    return letters


class Limited:
    """File wrapper that stops a part from yielding more than a fixed byte count."""

    def __init__(self, raw, limit):
        self.raw, self.left = raw, limit

    def read(self, size=-1):
        data = self.raw.read(size if size and size > 0 else 65536)
        self.left -= len(data)
        if self.left < 0:
            raise WorkbookError("A workbook part is larger than the safe limit after decompression")
        return data

    def close(self):
        self.raw.close()


def inspect_archive(content):
    if content[:8] == OLE_MAGIC:
        raise WorkbookError("This workbook is password-protected or in the old binary Excel format. Save an unprotected .xlsx copy and upload that")
    if not content.startswith(b"PK"):
        raise WorkbookError("Not a valid XLSX workbook")
    try:
        archive = zipfile.ZipFile(BytesIO(content))
    except zipfile.BadZipFile:
        raise WorkbookError("The workbook archive is corrupt") from None
    entries = archive.infolist()
    if len(entries) > MAX_ENTRIES:
        raise WorkbookError("The workbook contains too many internal files")
    if any(entry.flag_bits & 0x1 for entry in entries):
        raise WorkbookError("This workbook is encrypted; upload an unprotected copy")
    if sum(entry.file_size for entry in entries) > MAX_UNCOMPRESSED:
        raise WorkbookError("The workbook expands to more than 40 MB (rejected as a possible zip bomb)")
    for entry in entries:
        if entry.file_size > 1_000_000 and entry.file_size / max(entry.compress_size, 1) > MAX_RATIO:
            raise WorkbookError("The workbook has an abnormal compression ratio (rejected as a possible zip bomb)")
    names = {entry.filename for entry in entries}
    if "xl/workbook.xml" not in names:
        raise WorkbookError("Not an Excel workbook: xl/workbook.xml is missing")
    return archive, names


def open_part(archive, name):
    """Open an XML part after rejecting entity declarations (billion-laughs protection)."""
    with archive.open(name) as probe:
        head = probe.read(8192)
    if b"<!ENTITY" in head or b"<!DOCTYPE" in head:
        raise WorkbookError("The workbook contains XML entity declarations and was rejected")
    return Limited(archive.open(name), MAX_PART_BYTES)


def read_xml(archive, name):
    stream = open_part(archive, name)
    try:
        return ET.fromstring(stream.read(MAX_PART_BYTES + 1))
    except ET.ParseError:
        raise WorkbookError("A workbook part is not valid XML") from None
    finally:
        stream.close()


def relationship_target(base, target):
    if target.startswith("/"):
        return target.lstrip("/")
    parts = base.split("/")[:-1]
    for piece in target.split("/"):
        if piece == "..":
            parts and parts.pop()
        elif piece and piece != ".":
            parts.append(piece)
    return "/".join(parts)


def attribute(node, name):
    for key, value in node.attrib.items():
        if local(key) == name:
            return value
    return None


def shared_strings(archive, names):
    if "xl/sharedStrings.xml" not in names:
        return []
    strings = []
    stream = open_part(archive, "xl/sharedStrings.xml")
    try:
        for _, element in ET.iterparse(stream, events=("end",)):
            if local(element.tag) == "si":
                parts = []
                for child in element:
                    kind = local(child.tag)
                    if kind == "t":
                        parts.append(child.text or "")
                    elif kind == "r":
                        parts.extend(t.text or "" for t in child if local(t.tag) == "t")
                strings.append("".join(parts))
                element.clear()
                if len(strings) > 200_000:
                    raise WorkbookError("The workbook has too many distinct text values")
    except ET.ParseError:
        raise WorkbookError("The shared-strings part is not valid XML") from None
    finally:
        stream.close()
    return strings


def style_kinds(archive, names):
    """Map cell style index -> 'date' | 'percent' | None from the saved number formats."""
    if "xl/styles.xml" not in names:
        return []
    root = read_xml(archive, "xl/styles.xml")
    custom = {}
    for node in root.iter():
        if local(node.tag) == "numFmt":
            custom[node.get("numFmtId")] = node.get("formatCode", "")
    kinds = []
    for node in root.iter():
        if local(node.tag) != "cellXfs":
            continue
        for xf in node:
            if local(xf.tag) != "xf":
                continue
            fid = xf.get("numFmtId", "0")
            code = custom.get(fid)
            kind = None
            if code is not None:
                stripped = re.sub(r'"[^"]*"|\[[^\]]*\]|\\.', "", code)
                if re.search(r"[ymdhs]", stripped, re.I) and not re.fullmatch(r"\s*General\s*", stripped, re.I):
                    kind = "date"
                elif "%" in stripped:
                    kind = "percent"
            elif fid.isdigit() and int(fid) in BUILTIN_DATES:
                kind = "date"
            elif fid.isdigit() and int(fid) in PERCENT_FORMATS:
                kind = "percent"
            kinds.append(kind)
        break
    return kinds


def number_text(raw):
    try:
        value = Decimal(raw.strip())
    except (InvalidOperation, AttributeError):
        return None
    if not value.is_finite() or abs(value.adjusted()) > 40:
        return None
    if value.as_tuple().exponent < -10:
        value = value.quantize(Decimal("1e-10"))
    text = format(value.normalize(), "f")
    return "0" if text in {"-0", ""} else text


def sheet_cells(archive, name, strings, kinds, date1904, state):
    """Yield dict cells from one worksheet, honouring the row/cell limits."""
    stream = open_part(archive, name)
    row_number, rows_seen, last_column = 0, 0, 0
    try:
        for event, element in ET.iterparse(stream, events=("start", "end")):
            tag = local(element.tag)
            if event == "start":
                if tag == "row":
                    row_number = int(element.get("r") or row_number + 1)
                    last_column = 0
                    rows_seen += 1
                    if rows_seen > MAX_ROWS:
                        state["rows_truncated"] = True
                        return
                continue
            if tag != "c":
                continue
            ref = element.get("r") or ""
            match = re.fullmatch(r"([A-Z]{1,3})(\d+)", ref)
            if match:
                column, row = column_number(match[1]), int(match[2])
            else:
                column, row = last_column + 1, row_number
            last_column = column
            if column > MAX_COLUMNS:
                state["columns_truncated"] = True
                element.clear()
                continue
            cell = cell_value(element, strings, kinds, date1904, state)
            element.clear()
            if cell is None:
                continue
            if state["cells"] >= MAX_CELLS:
                state["cells_truncated"] = True
                return
            state["cells"] += 1
            yield {"ref": column_letters(column) + str(row), "row": row, "column": column, **cell}
    except ET.ParseError:
        raise WorkbookError("A worksheet is not valid XML") from None
    finally:
        stream.close()


def cell_value(element, strings, kinds, date1904, state):
    kind = element.get("t", "n")
    formula = any(local(child.tag) == "f" for child in element)
    value = next((child for child in element if local(child.tag) == "v"), None)
    inline = next((child for child in element if local(child.tag) == "is"), None)
    raw = value.text if value is not None and value.text is not None else None
    if formula and raw is None and inline is None:
        state["formula_without_result"] += 1
        return None
    if kind == "inlineStr" and inline is not None:
        text, value_type = "".join(t.text or "" for t in inline.iter() if local(t.tag) == "t"), "text"
    elif raw is None:
        return None
    elif kind == "s":
        if not raw.strip().isdigit() or int(raw) >= len(strings):
            return None
        text, value_type = strings[int(raw)], "text"
    elif kind == "str":
        text, value_type = raw, "text"
    elif kind == "b":
        text, value_type = "TRUE" if raw.strip() == "1" else "FALSE", "boolean"
    elif kind == "e":
        state["errors"] += 1
        return None
    elif kind == "d":
        text, value_type = raw.strip()[:10], "date"
    else:
        style = element.get("s")
        style_kind = kinds[int(style)] if style and style.isdigit() and int(style) < len(kinds) else None
        text, value_type = number_text(raw), "number"
        if text is None:
            return None
        if style_kind == "date" and Decimal(text) >= 1:
            base = date(1904, 1, 1) if date1904 else date(1899, 12, 30)
            try:
                text, value_type = (base + timedelta(days=int(Decimal(text)))).isoformat(), "date"
            except (OverflowError, ValueError):
                pass
        elif style_kind == "percent":
            text, value_type = (number_text(str(Decimal(text) * 100)) or text) + "%", "number"
    text = text.replace("\r\n", "\n").strip()
    if not text or text.upper() in ERROR_VALUES:
        if text:
            state["errors"] += 1
        return None
    if len(text) > MAX_CELL_CHARS:
        text = text[:MAX_CELL_CHARS]
        state["long_cells"] += 1
    if formula:
        state["formulas"] += 1
    return {"text": text, "value_type": value_type, "cached_formula": formula}


def workbook_sheets(archive, names):
    root = read_xml(archive, "xl/workbook.xml")
    date1904 = any(local(node.tag) == "workbookPr" and node.get("date1904") in {"1", "true"} for node in root.iter())
    relationships = {}
    if "xl/_rels/workbook.xml.rels" in names:
        for node in read_xml(archive, "xl/_rels/workbook.xml.rels"):
            relationships[node.get("Id")] = relationship_target("xl/workbook.xml", node.get("Target", ""))
    sheets = []
    for node in root.iter():
        if local(node.tag) == "sheet":
            target = relationships.get(attribute(node, "id"))
            sheets.append({"name": (node.get("name") or "Sheet")[:80], "state": node.get("state", "visible"), "part": target})
    return sheets, date1904


def read_workbook(content):
    """Return {'sheets': [{'name', 'cells'}], 'warnings': [...]} or raise WorkbookError."""
    archive, names = inspect_archive(content)
    with archive:
        sheets, date1904 = workbook_sheets(archive, names)
        if not sheets:
            raise WorkbookError("The workbook contains no worksheets")
        strings, kinds = shared_strings(archive, names), style_kinds(archive, names)
        warnings, result = [], []
        state = {"cells": 0, "formulas": 0, "formula_without_result": 0, "errors": 0, "long_cells": 0}
        hidden = [s["name"] for s in sheets if s["state"] != "visible"]
        if hidden:
            warnings.append("Hidden sheets were not read: " + ", ".join(hidden[:5]) + ("…" if len(hidden) > 5 else ""))
        visible = [s for s in sheets if s["state"] == "visible"]
        if len(visible) > MAX_SHEETS:
            warnings.append(f"Only the first {MAX_SHEETS} sheets were read.")
        for sheet in visible[:MAX_SHEETS]:
            if not sheet["part"] or sheet["part"] not in names:
                warnings.append(f"Sheet '{sheet['name']}' could not be located and was skipped.")
                continue
            state.update(rows_truncated=False, columns_truncated=False, cells_truncated=False)
            cells = list(sheet_cells(archive, sheet["part"], strings, kinds, date1904, state))
            if state["rows_truncated"]:
                warnings.append(f"Sheet '{sheet['name']}': only the first {MAX_ROWS} rows were read.")
            if state["columns_truncated"]:
                warnings.append(f"Sheet '{sheet['name']}': columns beyond {column_letters(MAX_COLUMNS)} were not read.")
            if state["cells_truncated"]:
                warnings.append(f"Workbook cell limit ({MAX_CELLS}) reached; remaining cells were not read.")
            result.append({"name": sheet["name"], "cells": cells})
            if state["cells_truncated"]:
                break
        if state["formulas"]:
            warnings.append(f"{state['formulas']} cells contain formulas. Their saved results are shown exactly as stored; nothing was recalculated.")
        if state["formula_without_result"]:
            warnings.append(f"{state['formula_without_result']} formula cells have no saved result and were skipped. Open and save the workbook in a spreadsheet program, then upload it again.")
        if state["errors"]:
            warnings.append(f"{state['errors']} cells contain spreadsheet errors (such as #REF!) and were skipped.")
        if state["long_cells"]:
            warnings.append(f"{state['long_cells']} very long cells were shortened to {MAX_CELL_CHARS} characters.")
        if any(name.startswith("xl/externalLinks/") for name in names):
            warnings.append("The workbook links to external files; only the values saved in this file were read.")
        return {"sheets": result, "warnings": warnings}


def workbook_blocks(content):
    """Convert a workbook into evidence blocks. Returns (blocks, warnings)."""
    book = read_workbook(content)
    blocks = []
    for sheet in book["sheets"]:
        labels = {}
        for cell in sheet["cells"]:
            if cell["column"] == 1 and cell["value_type"] == "text":
                labels[cell["row"]] = cell["text"]
        for cell in sheet["cells"]:
            label = labels.get(cell["row"], "") if cell["column"] > 1 else ""
            block = {"id": "b" + str(len(blocks) + 1), "text": cell["text"],
                     "locator": f"XLSX {sheet['name']}, cell {cell['ref']}", "kind": "cell", "label": label,
                     "sheet": sheet["name"], "cell": cell["ref"], "row": cell["row"], "column": cell["column"],
                     "value_type": cell["value_type"]}
            if cell["cached_formula"]:
                block["cached_formula"] = True
            blocks.append(block)
    return blocks, book["warnings"]
