from pathlib import Path
import json
import os
from datetime import datetime, timezone
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]
KIT = ROOT / "SLM_Prototype_Kit"
load_dotenv(ROOT / ".env")


def read_seed(name: str):
    return json.loads((KIT / "starter_data" / name).read_text())


CATALOGUE = read_seed("grants.json")
SOURCES = {s["id"]: s for s in read_seed("sources.json")["sources"]}
FORM = read_seed("official_form_sections.json")
QUESTIONS = read_seed("questions.json")["questions"]
CORE_PATHS = read_seed("schema.json")["core_fact_paths"]
MAIN_GRANT = "ZH_MIT_FEASIBILITY_2026"


def now():
    return datetime.now(timezone.utc).isoformat()


def data_dir():
    return Path(os.environ.get("SLM_DATA_DIR", str(ROOT / "data"))).resolve()
