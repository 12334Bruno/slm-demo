"""On-demand retrieval of curated official URLs; never mutates reviewed rules."""
import hashlib
from io import BytesIO
from urllib.parse import urlparse, urljoin
import httpx
from bs4 import BeautifulSoup
from docx import Document
from pypdf import PdfReader
from .config import SOURCES, now

FUNDING_SOURCES = {k: s for k, s in SOURCES.items() if s["kind"] in {"official_html", "official_pdf", "official_docx"}}
ALLOWED_HOSTS = {urlparse(s["url"]).hostname for s in FUNDING_SOURCES.values()}
MAX_RETRIEVAL = 5 * 1024 * 1024


def validate_url(url):
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_HOSTS or parsed.port not in {None, 443} or parsed.username or parsed.password:
        raise ValueError("Redirect outside the allowlisted official HTTPS hosts was blocked")


def source_text(data, kind):
    if kind == "official_pdf":
        pdf = PdfReader(BytesIO(data))
        if len(pdf.pages) > 100:
            raise ValueError("Source PDF exceeds page limit")
        return "\n".join(p.extract_text() or "" for p in pdf.pages)[:200_000]
    if kind == "official_docx":
        import zipfile
        with zipfile.ZipFile(BytesIO(data)) as z:
            if sum(i.file_size for i in z.infolist()) > 40*1024*1024:
                raise ValueError("Expanded DOCX exceeds limit")
        return "\n".join(p.text for p in Document(BytesIO(data)).paragraphs)[:200_000]
    soup = BeautifulSoup(data, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header"]):
        tag.decompose()
    return (soup.find("main") or soup).get_text(" ", strip=True)[:200_000]


def refresh_source(store, source_id, transport=None):
    source = FUNDING_SOURCES[source_id]
    previous = store.retrieval(source_id) or {}
    attempted = now()
    try:
        url = source["url"]
        with httpx.Client(timeout=12, follow_redirects=False, transport=transport, headers={"User-Agent": "SLM-local-prototype/1.0 (on-demand official-source check)"}) as client:
            for redirect in range(4):
                validate_url(url)
                with client.stream("GET", url) as response:
                    if response.is_redirect:
                        if redirect == 3:
                            raise ValueError("Too many redirects")
                        url = urljoin(url, response.headers["location"])
                        validate_url(url)
                        continue
                    response.raise_for_status()
                    if int(response.headers.get("content-length", "0")) > MAX_RETRIEVAL:
                        raise ValueError("Source exceeds 5 MB retrieval limit")
                    chunks, size = [], 0
                    for chunk in response.iter_bytes():
                        size += len(chunk)
                        if size > MAX_RETRIEVAL:
                            raise ValueError("Source exceeds 5 MB retrieval limit")
                        chunks.append(chunk)
                    data = b"".join(chunks)
                    break
        text = source_text(data, source["kind"])
        if not text.strip():
            raise ValueError("Source returned no readable text")
        digest = hashlib.sha256(text.encode()).hexdigest()
        baseline = previous.get("baseline_hash") or digest
        state = {"status": "CHANGED_REVIEW_NEEDED" if digest != baseline else "FETCHED_SUCCESSFULLY",
                 "attempted_at": attempted, "fetched_at": now(), "final_url": url,
                 "content_hash": hashlib.sha256(data).hexdigest(), "text_hash": digest,
                 "baseline_hash": baseline, "text": text, "error": None,
                 "note": "Compared with first local fetch, not a historical/legal snapshot. Reviewed catalogue unchanged; human rule review is required."}
    except Exception as exc:
        state = {**previous, "status": "REFRESH_FAILED", "attempted_at": attempted,
                 "error": f"{type(exc).__name__}: {str(exc)[:220]}",
                 "note": f"Refresh failed; using reviewed data from {source['reviewed_on']}. Last successful fetched text, if any, is retained."}
    store.save_retrieval(source_id, state)
    return state
