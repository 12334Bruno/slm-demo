"""Private, revision-checked application endpoints for any retained grant."""
from fastapi.responses import Response, JSONResponse
from typing import Literal
from pydantic import Field
from . import applications as engine
from .config import now
from .domain import Strict
from .storage import touch


class Change(Strict):
    expected_revision: int


class Answer(Change):
    text: str = Field(max_length=24000)
    fact_paths: list[str] = Field(default_factory=list, max_length=60)
    evidence: list[dict] = Field(default_factory=list, max_length=30)
    save_to_profile: bool = False


class AnswerDraft(Strict):
    text: str = Field(max_length=24000)


class BudgetChange(Change):
    budget: engine.Budget


class BudgetPreview(Strict):
    budget: engine.Budget


class AnswerUpdate(Strict):
    id: str
    text: str = Field(max_length=24000)
    fact_paths: list[str] = Field(default_factory=list, max_length=60)
    evidence: list[dict] = Field(default_factory=list, max_length=30)
    save_to_profile: bool = False


class SaveApplication(Change):
    answers: list[AnswerUpdate] = Field(default_factory=list, max_length=200)
    budget: engine.Budget | None = None
    notes: dict[str, str] = Field(default_factory=dict, max_length=200)


class Draft(Change):
    section_ids: list[str] | None = None


class FormVariant(Change):
    variant: str = Field(min_length=1, max_length=60)


class DraftEdit(Change):
    text: str = Field(max_length=24000)


class Attachment(Change):
    document_id: str | None = None
    acknowledged: bool = False
    not_applicable: bool = False
    composed: bool = False


class ChecklistItem(Change):
    checked: bool


class Review(Change):
    fingerprint: str
    note: str = Field(default="", max_length=3000)
    acknowledged: bool = False
    answer: Literal["yes", "no", "unsure", "na"] | None = None


class WbsoInput(Strict):
    hours: int = Field(ge=0, le=100_000)
    hourly_wage_cents: int = Field(ge=0, le=100_000)
    starter: bool
    actual_costs_cents: int | None = Field(ge=0, le=10_000_000_000)


def register(app, discovery, workspace_view):
    store = app.state.store

    @app.post("/api/schemes/wbso/estimate")
    def wbso_estimate(body: WbsoInput):
        from .scheme_calculations import wbso_estimate
        return wbso_estimate(body.hours, body.hourly_wage_cents, body.starter, body.actual_costs_cents)

    def context(wid, rid):
        ws = store.load(wid)
        selected = engine.application(ws, rid)
        if selected.get("editing_version", 0) < 2:
            with store.edit(wid) as current:
                saved = engine.application(current, rid)
                if engine.migrate_answers(saved):
                    saved["revision"] += 1
                    touch(current, ["applications"], "Consolidated document edits into application answers")
            ws = store.load(wid)
            selected = engine.application(ws, rid)
        spec = engine.with_variant(discovery.specifications.get(rid, selected["spec_version"]), selected)
        return ws, selected, spec, discovery.specifications.latest(rid)

    def result(wid, rid):
        return engine.view(*context(wid, rid))

    def edit(wid, rid, body, action):
        # Upgrade old editors before accepting a revision, so a stale client
        # cannot overwrite or resurrect the separate document snapshot.
        context(wid, rid)
        with store.edit(wid) as ws:
            selected = engine.application(ws, rid)
            spec = engine.with_variant(discovery.specifications.get(rid, selected["spec_version"]), selected)
            engine.mutate(selected, body.expected_revision)
            action(ws, selected, spec)
            touch(ws, ["applications"], "Updated application: " + selected["title"])
        return result(wid, rid)

    @app.get("/api/workspaces/{wid}/applications")
    def list_applications(wid: str):
        ws = store.load(wid)
        rows = []
        for a in ws.get("applications", {}).values():
            spec = engine.with_variant(discovery.specifications.get(a["id"], a["spec_version"]), a)
            state = engine.view(ws, a, spec, discovery.specifications.latest(a["id"]))
            record = discovery.db.get(a["id"], missing_ok=True)
            from .funding_conditions import schedule
            rows.append({"id": a["id"], "title": a["title"], "created_at": a["created_at"],
                         "updated_at": a.get("updated_at", a["created_at"]), "progress": state["progress"],
                         "section_status": state["section_status"], "schedule": schedule(record) if record else {}})
        return sorted(rows, key=lambda row: row["updated_at"], reverse=True)

    @app.post("/api/workspaces/{wid}/applications/{rid}/suggestions/{qid}")
    def suggest_answer(wid: str, rid: str, qid: str):
        from .application_suggestions import tailored_suggestion
        ws, selected, spec, _ = context(wid, rid)
        question = next((q for q in engine.questions(spec) if q["id"] == qid), None)
        if question is None:
            raise ValueError("This question is no longer in the application")
        return tailored_suggestion(ws, question, spec)

    @app.post("/api/workspaces/{wid}/applications/{rid}/check/{qid}")
    def check_answer(wid: str, rid: str, qid: str, body: AnswerDraft):
        from .application_suggestions import check_answer as review
        ws, selected, spec, _ = context(wid, rid)
        question = next((q for q in engine.questions(spec) if q["id"] == qid), None)
        if question is None:
            raise ValueError("This question is no longer in the application")
        return review(ws, question, body.text)

    @app.post("/api/workspaces/{wid}/applications/{rid}")
    def start(wid: str, rid: str):
        ws = store.load(wid)
        if rid in ws.get("applications", {}):
            return result(wid, rid)
        record = discovery.db.get(rid)
        spec = discovery.specifications.latest(rid)
        if spec is None:
            source = discovery.specification(rid)
            spec = source["specification"]
            if spec is None:
                if source.get("error") and not source.get("refreshing"):
                    raise ValueError("The official requirements could not be read yet. Retry reading requirements or check the grant's official website.")
                return JSONResponse(status_code=202, content={"status": "preparing", "message": "Reading this grant’s official requirements before creating your application…"})
        with store.edit(wid) as ws:
            engine.start(ws, record, spec)
        discovery.db.save(wid, rid, True)
        return result(wid, rid)

    @app.get("/api/workspaces/{wid}/applications/{rid}")
    def get_application(wid: str, rid: str):
        return result(wid, rid)

    @app.put("/api/workspaces/{wid}/applications/{rid}/save")
    def save_application(wid: str, rid: str, body: SaveApplication):
        def save(ws, selected, spec):
            for answer in body.answers:
                engine.save_answer(ws, selected, spec, answer.id, answer.text, answer.fact_paths, answer.evidence, answer.save_to_profile)
            if body.budget is not None:
                if len({row.id for row in body.budget.lines}) != len(body.budget.lines):
                    raise ValueError("Budget rows must have unique identifiers")
                selected["budget"] = body.budget.model_dump()
                engine.calculate(selected, spec, ws)
            findings = {f["id"]: f for f in engine.findings(ws, selected, spec, discovery.specifications.latest(rid))}
            for ident, note in body.notes.items():
                if ident not in findings or len(note) > 3000:
                    raise ValueError("A review note needs checking before this application can be saved")
                old = selected["reviews"].get(ident, {})
                selected["reviews"][ident] = {"note": note.strip(), "acknowledged": bool(old.get("acknowledged") and old.get("fingerprint") == findings[ident]["fingerprint"]),
                    "fingerprint": findings[ident]["fingerprint"], "at": now()}
        return edit(wid, rid, body, save)

    @app.put("/api/workspaces/{wid}/applications/{rid}/answers/{qid}")
    def answer(wid: str, rid: str, qid: str, body: Answer):
        return edit(wid, rid, body, lambda ws, selected, spec:
                    engine.save_answer(ws, selected, spec, qid, body.text, body.fact_paths, body.evidence, body.save_to_profile))

    @app.put("/api/workspaces/{wid}/applications/{rid}/budget")
    def budget(wid: str, rid: str, body: BudgetChange):
        if len({r.id for r in body.budget.lines}) != len(body.budget.lines):
            raise ValueError("Budget row identifiers must be unique")

        def save(ws, selected, spec):
            selected["budget"] = body.budget.model_dump()
            engine.calculate(selected, spec, ws)
        return edit(wid, rid, body, save)

    @app.post("/api/workspaces/{wid}/applications/{rid}/budget/preview")
    def budget_preview(wid: str, rid: str, body: BudgetPreview):
        ws, selected, spec, _ = context(wid, rid)
        return engine.calculate({**selected, "budget": body.budget.model_dump()}, spec, ws)

    @app.post("/api/workspaces/{wid}/applications/{rid}/draft")
    def draft(wid: str, rid: str, body: Draft):
        return edit(wid, rid, body, lambda ws, selected, spec: engine.generate(ws, selected, spec, body.section_ids))

    @app.put("/api/workspaces/{wid}/applications/{rid}/draft/{qid}")
    def draft_edit(wid: str, rid: str, qid: str, body: DraftEdit):
        def save(ws, selected, spec):
            if qid not in {q["id"] for q in engine.questions(spec)}:
                raise ValueError("Unknown draft section")
            old = selected["drafts"].get(qid, {})
            selected["history"].append({"kind": "draft", "id": qid, "previous": old, "at": now()})
            fields = list(old.get("dependencies", {})) or ["specification", "answer:" + qid]
            selected["drafts"][qid] = {"text": body.text, "user_edited": True, "at": now(),
                                      "dependencies": engine.dependencies(ws, selected, fields)}
            if selected.get("editing_version", 0) >= 2:
                original = selected["answers"].get(qid, {})
                engine.save_answer(ws, selected, spec, qid, body.text,
                    [path for path in original.get("dependencies", {}) if path in ws["facts"]], original.get("evidence", []))
        return edit(wid, rid, body, save)

    @app.put("/api/workspaces/{wid}/applications/{rid}/checklist/{aid}")
    def checklist_item(wid: str, rid: str, aid: str, body: ChecklistItem):
        def save(ws, selected, spec):
            task = next((item for item in engine.evidence_tasks(spec) if item["id"] == aid), None)
            if task is None:
                raise ValueError("Unknown checklist item")
            selected.setdefault("checklist", {})[aid] = {"checked": body.checked, "fingerprint": task["fingerprint"]}
        return edit(wid, rid, body, save)

    @app.put("/api/workspaces/{wid}/applications/{rid}/attachments/{aid}")
    def attachment(wid: str, rid: str, aid: str, body: Attachment):
        def save(ws, selected, spec):
            task = next((item for item in engine.evidence_tasks(spec) if item["id"] == aid), None)
            if task is None:
                raise ValueError("Unknown evidence requirement")
            if body.not_applicable:
                if task.get("required") is True and not task.get("conditional"):
                    raise ValueError("This required document cannot be marked not applicable")
                selected["attachments"][aid] = {"not_applicable": True, "fingerprint": task["fingerprint"], "at": now()}
            elif body.composed:
                if not task.get("compose"):
                    raise ValueError("Only a free-form plan can be written from your answers")
                selected["attachments"][aid] = {"composed": True, "fingerprint": task["fingerprint"], "at": now()}
            elif task["kind"] in {"instruction", "step"}:
                if body.document_id:
                    raise ValueError("This is a step on the funder's website, not a document request")
                if body.acknowledged:
                    selected["attachments"][aid] = {"kind": "instruction", "acknowledged": True,
                        "fingerprint": task["fingerprint"], "at": now()}
                else:
                    selected["attachments"].pop(aid, None)
            elif body.acknowledged:
                raise ValueError("This requirement needs a supporting document")
            elif body.document_id is None:
                selected["attachments"].pop(aid, None)
            elif engine.linked_document(ws, task, {"document_id": body.document_id}):
                selected["attachments"][aid] = {"document_id": body.document_id, "at": now()}
            else:
                raise ValueError("Choose a readable document in the format requested by this grant")
        return edit(wid, rid, body, save)

    @app.put("/api/workspaces/{wid}/applications/{rid}/reviews/{fid}")
    def review(wid: str, rid: str, fid: str, body: Review):
        def save(ws, selected, spec):
            issue = next((i for i in engine.findings(ws, selected, spec, discovery.specifications.latest(rid)) if i["id"] == fid), None)
            if not issue or issue["fingerprint"] != body.fingerprint:
                raise ValueError("This finding changed. Reload before recording a review note.")
            if body.answer and not issue.get("condition_question"):
                raise ValueError("This check is not a yes/no condition")
            if not body.note.strip() and not body.acknowledged and not body.answer:
                raise ValueError("Answer the question, write a note or mark this check as reviewed")
            old = selected["reviews"].get(fid, {})
            keep = old if old.get("fingerprint") == body.fingerprint else {}
            selected["reviews"][fid] = {"note": body.note.strip() if body.note.strip() or body.answer is None else keep.get("note", ""),
                "acknowledged": body.acknowledged or body.answer in {"yes", "na"},
                "answer": body.answer or keep.get("answer"), "fingerprint": body.fingerprint, "at": now()}
        return edit(wid, rid, body, save)

    @app.put("/api/workspaces/{wid}/applications/{rid}/form-variant")
    def choose_form(wid: str, rid: str, body: FormVariant):
        """Switch the checked form this application fills (WBSO: physical product or software)."""
        def choose(ws, selected, spec):
            variants = discovery.specifications.get(rid, selected["spec_version"]).get("form_variants") or {}
            if body.variant not in variants:
                raise ValueError("This grant does not offer that form: choose one of " + ", ".join(variants))
            selected["history"].append({"kind": "form_variant", "previous": selected.get("form_variant"), "at": now()})
            selected["form_variant"] = body.variant
        return edit(wid, rid, body, choose)

    @app.post("/api/workspaces/{wid}/applications/{rid}/requirements")
    def update_requirements(wid: str, rid: str, body: Change):
        def update(ws, selected, spec):
            latest = discovery.specifications.latest(rid)
            selected["history"].append({"kind": "specification", "version": selected["spec_version"], "at": now()})
            selected["spec_version"] = latest["version"]
            # Old answers and human draft edits remain stored, including removed questions.
        return edit(wid, rid, body, update)

    @app.get("/api/workspaces/{wid}/applications/{rid}/export/{kind}")
    def export(wid: str, rid: str, kind: str):
        ws, selected, spec, latest = context(wid, rid)
        if kind == "docx":
            content, mime, filename = engine.docx_bytes(ws, selected, spec, latest), "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application-draft.docx"
        elif kind == "package":
            content, mime, filename = engine.package(ws, selected, spec, latest, store, discovery.documents), "application/zip", "application-package.zip"
        elif kind == "template":
            content = engine.official_template(selected, spec, discovery.documents, ws)
            pdf = content.startswith(b"%PDF")
            mime = "application/pdf" if pdf else "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            filename = "official-form-filled.pdf" if pdf else "official-form-draft.docx"
        else:
            raise ValueError("Choose docx, template or package")
        return Response(content, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{filename}"'})
