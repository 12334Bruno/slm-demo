from copy import deepcopy
from .config import now
from .domain import validate_value
from .ingestion import founder_evidence
from .storage import touch


def same(a, b):
    if isinstance(a, str) and isinstance(b, str):
        return a.casefold().strip() == b.casefold().strip()
    return type(a) == type(b) and a == b or (not isinstance(a, bool) and not isinstance(b, bool) and a == b)


def merge_fact(ws, path, value, refs):
    value = validate_value(path, value)
    if value is None:
        return
    fact = ws["facts"][path]
    # Re-processing the same source is idempotent, including after a founder
    # deliberately corrected, cleared or resolved its extracted value.
    if refs and all(ref in fact["evidence"] for ref in refs):
        return
    candidate = next((c for c in fact["candidates"] if same(c["value"], value)), None)
    if candidate:
        for ref in refs:
            if ref not in candidate["evidence"]:
                candidate["evidence"].append(ref)
    else:
        fact["candidates"].append({"value": value, "evidence": refs})
    for ref in refs:
        if ref not in fact["evidence"]:
            fact["evidence"].append(ref)
    # Founder overrides remain in history and among candidates. New, disagreeing
    # evidence always demands an explicit new resolution.
    values = [c["value"] for c in fact["candidates"]]
    if fact["value"] is not None and not any(same(fact["value"], v) for v in values):
        values.append(fact["value"])
    if fact["state"] == "confirmed" and same(fact["value"], value):
        pass
    elif len(values) > 1:
        fact["state"], fact["value"] = "conflict", None
        fact["confirmed_at"] = None
    elif fact["state"] != "confirmed":
        fact["value"], fact["state"] = value, "proposed"
    fact["revision"] = ws["revision"] + 1


def correct_fact(ws, path, value, note):
    value = validate_value(path, value)
    fact = ws["facts"][path]
    fact["history"].append({"value": fact["value"], "state": fact["state"], "at": now(), "note": note})
    ref = founder_evidence(value, note)
    if not any(same(c["value"], value) for c in fact["candidates"]):
        fact["candidates"].append({"value": value, "evidence": [ref]})
    fact["value"] = value
    fact["state"] = "missing" if value is None else "confirmed"
    fact["confirmed_at"] = now() if value is not None else None
    fact["evidence"].append(ref)
    fact["revision"] = ws["revision"] + 1


def apply_profile_patch(ws, patch, confirmation_note=None):
    for change in patch.changes:
        correct_fact(ws, change.path, change.value, change.note)
    for path in patch.confirm_paths:
        if path not in ws["facts"]:
            raise ValueError("Unknown fact path")
        fact = ws["facts"][path]
        if fact["state"] == "conflict":
            raise ValueError(f"Resolve conflicting values for {path} explicitly")
        if fact["value"] is not None:
            correct_fact(ws, path, fact["value"], confirmation_note or "Founder confirmed extracted value; document not authenticated")
    if patch.confirm_budget:
        for line in ws["budget_lines"]:
            if line["state"] == "conflict":
                raise ValueError("Resolve budget row conflicts by saving the budget table")
            line["confirmed"] = True
            line["state"] = "confirmed"
            line["evidence"].append(founder_evidence(line["id"], confirmation_note or "Founder confirmed proposed cost row; scheme eligibility still requires review"))
        ws["budget_metadata"]["confirmed"] = True
    if patch.confirm_funding:
        for source in ws["funding_sources"]:
            if source["state"] == "conflict":
                raise ValueError("Resolve funding source conflicts explicitly")
            source["founder_confirmed"] = True
            source["state"] = "confirmed"
            source["evidence"].append(founder_evidence(source["id"], confirmation_note or "Founder confirmed funding status; not legal verification"))
    paths = [c.path for c in patch.changes] + patch.confirm_paths
    if patch.confirm_budget:
        paths.append("budget")
    if patch.confirm_funding:
        paths.append("funding")
    if paths:
        touch(ws, paths, "Founder profile confirmation / correction")


def fact_value(ws, path, confirmed_only=False):
    f = ws["facts"].get(path)
    if not f or f["state"] in {"missing", "conflict"} or (confirmed_only and f["state"] != "confirmed"):
        return None
    return f["value"]


def merge_row(rows, row, keys):
    existing = next((r for r in rows if r["id"] == row["id"]), None)
    if not existing:
        rows.append(row)
        return
    if row["evidence"] and all(ref in existing["evidence"] for ref in row["evidence"]):
        return
    if all(existing.get(k) == row.get(k) for k in keys):
        for ref in row["evidence"]:
            if ref not in existing["evidence"]:
                existing["evidence"].append(ref)
    else:
        existing.setdefault("candidates", []).append(deepcopy(row))
        existing["state"] = "conflict"
        existing["confirmed"] = False
        if "founder_confirmed" in existing:
            existing["founder_confirmed"] = False
