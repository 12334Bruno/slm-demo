"""Grant-specific preparation, dependency tracking and deterministic finances.

Applications are additive workspace state. A retained specification is pinned so a
source refresh never erases answers or edits. All calculations use Decimal/cents.
"""
from copy import deepcopy
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import csv
import hashlib
from io import BytesIO, StringIO
import json
import re
from zipfile import ZipFile, ZIP_DEFLATED
from typing import Literal

from docx import Document
from pydantic import Field, field_validator

from .config import now
from .application_prompts import input_prompt, reference_fragment
from .application_controls import answer_control, answer_guidance, evidence_control, evidence_prompt, profile_field, validate_answer, FORMATS
from .domain import Strict
from .grant_specification import evaluate_specification
from .profiles import correct_fact, fact_value
from .grant_tasks import source_scope, document_title, later_stage
from .storage import RevisionConflict, touch


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


class Cost(Strict):
    id: str = Field(min_length=1, max_length=80)
    description: str = Field(min_length=1, max_length=1000)
    category: str = Field(default="other", min_length=1, max_length=100)
    partner: str = Field(default="Applicant", min_length=1, max_length=200)
    quantity: str = "1"
    unit_cost_cents: int = Field(ge=0, le=100_000_000_000, strict=True)
    eligible: bool = False
    eligibility_review: Literal["needs_review", "eligible", "ineligible"] | None = None

    @field_validator("quantity")
    @classmethod
    def check_quantity(cls, value):
        try:
            amount = Decimal(value)
        except InvalidOperation:
            raise ValueError("Quantity must be a valid decimal number") from None
        if not amount.is_finite() or not 0 <= amount <= 1_000_000_000:
            raise ValueError("Quantity must be a finite nonnegative number")
        return str(amount)


class Budget(Strict):
    lines: list[Cost] = Field(default_factory=list, max_length=200)
    requested_grant_cents: int | None = Field(default=None, ge=0, le=100_000_000_000, strict=True)
    confirmed_financing_cents: int = Field(default=0, ge=0, le=100_000_000_000, strict=True)


COMMON_QUESTIONS = [
    ("project-summary", "Project summary",
     "Describe in a few sentences what you want to do, why it matters and what the result will be.", ["project.description"]),
    ("common-innovation", "What is new about your project?",
     "Explain the problem, your solution and how it differs from what already exists.", ["narrative.innovation_description"]),
    ("common-activities", "Activities and planning",
     "List the main activities, who carries them out and roughly when.", ["narrative.activities"]),
    ("common-team", "Team and partners",
     "Who will carry out the project, and why are you and any partners able to do it?", ["company.activities"]),
    ("common-results", "Expected results and impact",
     "What will the project deliver, who benefits and what changes afterwards? Use numbers where you can.", ["narrative.expected_results"]),
]


def structured(spec):
    return str(spec.get("extractor_version", "")).startswith("grant-spec-3")


def questions(spec):
    """Writing sections: the official form when we could read it, otherwise clearly labelled common questions."""
    result = []
    for section in spec.get("application_sections", []):
        if evidence_prompt(section["heading"]):
            continue
        if input_prompt(section["heading"], heading=True):
            result.append({**section, "origin": "official_template", "dependencies": []})
    # Without a readable form, explicit requests for applicant input in the call text are grant-specific questions.
    if not result:
        for req in spec["requirements"]:
            if req.get("scope", "call") in {"annex", "guidance"}:
                continue
            if req["category"] != "attachment" and input_prompt(req["text"]):
                result.append({"id": req["id"], "heading": req["text"], "required": None,
                               "max_words": None, "max_characters": None, "evidence": req["evidence"],
                               "origin": "application_instruction", "dependencies": []})
    if not result:
        result = [{"id": ident, "heading": heading, "required": None, "max_words": None, "max_characters": None,
                   "evidence": None, "origin": "common_question", "prompt": prompt, "dependencies": fields}
                  for ident, heading, prompt, fields in (COMMON_QUESTIONS if structured(spec) else COMMON_QUESTIONS[:1])]
    # A hand-checked form states its own answer type (choice, date, number); otherwise it is inferred from the heading.
    return [{**question, "control": question.get("control") or answer_control(question), "guidance": answer_guidance(question),
             "profile_field": profile_field(question)} for question in result]


STEP_TOPICS = [
    (r"(?i)eherkenning", "eherkenning"), (r"(?i)\bPIC\b|participant register|register (?:your|the) organisation", "pic"),
    (r"(?i)part a|web forms?|administrative forms?", "part-a"), (r"(?i)part b|upload", "upload"),
    (r"(?i)deadline|submit|indienen|sluitingsdatum|closing date", "submit"), (r"(?i)aanvraagformulier|application form|e-?loket|mijn rvo|mijn snn", "form"),
]


def step_topic(text):
    return next((topic for pattern, topic in STEP_TOPICS if re.search(pattern, text)), None)


def task_formats(text):
    return [extension for extension, names in FORMATS.items()
            if any(re.search(r"(?i)\b" + re.escape(name) + r"\b", text) for name in names)]


def significant_words(text):
    return set(re.findall(r"[a-zà-ÿ]{4,}", text.casefold())) - {"completed", "official", "template", "document", "format",
                                                                  "word", "excel", "your", "with", "voor", "van", "bij"}


def evidence_tasks(spec):
    """Files to upload and steps to take on the funder's website, one completion method each."""
    if not structured(spec):
        return legacy_evidence_tasks(spec)
    from .grant_tasks import provider_steps, NARRATIVE_DOCUMENTS
    templates = {t["url"]: t for t in spec.get("templates", [])}
    documents, template_uploads, extra = [], [], []
    seen = set()
    loose = [item for item in spec.get("attachments", []) if not item.get("source")]
    loose += [{**section, "title": section["heading"]} for section in spec.get("application_sections", []) if evidence_prompt(section["heading"])]
    for item in spec.get("attachments", []):
        text = item.get("instruction") or (item.get("evidence") or {}).get("quote") or item["title"]
        if not item.get("source"):
            continue
        if item.get("source") == "template":
            template_uploads.append(item)
            continue
        if later_stage(text):
            continue
        documents.append({**item, "kind": "document", "instruction": text, "accepted_types": task_formats(text),
                          "compose": bool(NARRATIVE_DOCUMENTS.search(item["title"])), "origin": "call", "template": None})
    # Items saved without a source type (and file fields printed in a form) are classified by their wording.
    for item in loose:
        control = evidence_control(item)
        text = (item.get("evidence") or {}).get("quote") or item.get("text") or item["title"]
        key = (control["kind"], re.sub(r"\W+", "", text.casefold()))
        if control["kind"] is None or key in seen or later_stage(text):
            continue
        seen.add(key)
        if control["kind"] == "document":
            documents.append({**item, "kind": "document", "title": document_title(item), "instruction": text,
                              "accepted_types": control["accepted_types"], "compose": False, "origin": "call", "template": None})
        else:
            extra.append({"id": item["id"], "title": document_title(item) if len(item["title"]) > 90 else item["title"].rstrip("."),
                          "instruction": text, "origin": "call", "evidence": item.get("evidence"), "conditional": True})
    for item in template_uploads:
        template = templates.get(item.get("template_url")) or {"url": item.get("template_url"), "title": item["title"], "sha256": item.get("template_sha256")}
        words = significant_words(template.get("title") or "")
        match = max(documents, key=lambda d: len(words & significant_words(d["title"] + " " + d["instruction"][:200])), default=None)
        reference = {"url": template.get("url"), "title": template.get("title"), "sha256": template.get("sha256"), "format": template.get("format")}
        if match and len(words & significant_words(match["title"] + " " + match["instruction"][:200])) >= 1 and not match["template"]:
            match["template"] = reference  # The published form for a requested document.
            continue
        documents.append({**item, "kind": "document", "instruction": item.get("instruction", ""), "accepted_types": task_formats(item["title"]),
                          "compose": False, "origin": "template", "template": reference})
    steps = provider_steps(spec)
    by_topic = {step_topic(s["id"].split("-", 2)[-1] + " " + s["title"]): s for s in steps}
    for found in spec.get("submission_steps", []):
        if later_stage(found["text"]):
            continue
        topic = step_topic(found["text"])
        if topic in by_topic:
            by_topic[topic].setdefault("official", []).append(found["text"])
        elif len(extra) < 4:
            extra.append({"id": found["id"], "title": found["label"], "instruction": found["text"], "origin": "call", "evidence": found.get("evidence")})
    result = []
    for task in documents:
        task["fingerprint"] = digest({"title": task["title"], "instruction": task["instruction"], "required": task.get("required"),
                                      "template": task.get("template")})
        result.append(task)
    for step in steps[:-1] + extra + steps[-1:]:
        step = {"conditional": False, **step, "kind": "step", "required": True, "accepted_types": [],
                "instruction": step["instruction"] + (" Official wording: " + " ".join(step["official"]) if step.get("official") else "")}
        step.pop("official", None)
        step["fingerprint"] = digest({"title": step["title"], "instruction": step["instruction"]})
        result.append(step)
    return result


def legacy_evidence_tasks(spec):
    result = []
    items = list(spec.get("attachments", []))
    items.extend({**section, "title": section["heading"]} for section in spec.get("application_sections", []) if evidence_prompt(section["heading"]))
    seen = set()
    for item in items:
        if source_scope(spec, item) in {"annex", "guidance"}:
            continue
        if item["id"] in seen:
            continue
        seen.add(item["id"])
        control = evidence_control(item)
        if control["kind"] is None:
            continue  # Metadata and incidental uses of "attached" are not user tasks.
        semantic_key = (control["kind"], tuple(control["accepted_types"]), item.get("required"), re.sub(r"\W+", "", ((item.get("evidence") or {}).get("quote") or item["title"]).casefold()))
        if semantic_key in seen:
            continue
        seen.add(semantic_key)
        full_requirement = next((req.get("text") for req in spec.get("requirements", []) if req["id"] == item["id"]), None)
        task = {**item, **control, "instruction": (item.get("evidence") or {}).get("quote") or item.get("text") or full_requirement or item["title"]}
        task["title"] = document_title(item)
        if later_stage(task["instruction"]):
            continue
        task["fingerprint"] = digest({"title": item["title"], "control": control,
            "required": item.get("required"), "quote": (item.get("evidence") or {}).get("quote")})
        result.append(task)
    return result


def linked_document(ws, task, link):
    doc = next((d for d in ws["documents"] if link and d["id"] == link.get("document_id") and d["status"] == "parsed" and d.get("source_type") != "website"), None)
    accepted = task.get("accepted_types", [])
    return doc if doc and (not accepted or doc["type"].replace("jpeg", "jpg") in accepted) else None


def evidence_complete(ws, task, link):
    if link and link.get("not_applicable") and (task.get("conditional") or task.get("required") is not True):
        return link.get("fingerprint") == task["fingerprint"]
    if task["kind"] in {"instruction", "step"}:
        return bool(link and link.get("acknowledged") and link.get("fingerprint") == task["fingerprint"])
    if link and link.get("composed") and task.get("compose"):
        return True  # The applicant writes this plan from their answers in this application.
    return bool(linked_document(ws, task, link))


def migrate_answers(app):
    """Keep previous human draft edits when consolidating into one answer editor."""
    if app.get("editing_version", 0) >= 2:
        return False
    for qid, draft in app.get("drafts", {}).items():
        answer = app["answers"].get(qid)
        if not draft.get("text", "").strip() or "[Answer required:" in draft["text"]:
            continue
        if not draft.get("user_edited") and answer:
            continue  # A generated snapshot must not replace a newer answer.
        if answer:
            app["history"].append({"kind": "answer_before_editor_merge", "id": qid, "previous": deepcopy(answer), "at": now()})
        deps = {**(answer or {}).get("dependencies", {}), **draft.get("dependencies", {})}
        deps.pop("answer:" + qid, None)
        app["answers"][qid] = {**(answer or {}), "text": draft["text"], "dependencies": deps,
            "evidence": (answer or {}).get("evidence", []), "at": now(), "author": "founder"}
    app["editing_version"] = 2
    return True


def document_answer(app, qid):
    if app.get("editing_version", 0) >= 2:
        return app["answers"].get(qid)
    return app["drafts"].get(qid) or app["answers"].get(qid)


def start(ws, record, spec):
    applications = ws.setdefault("applications", {})
    if record["id"] in applications:
        return applications[record["id"]]
    app = {"id": record["id"], "title": record["title"], "url": record["url"], "created_at": now(), "updated_at": now(),
           "instrument": record.get("instrument", "grant"),
           "revision": 0, "editing_version": 2, "spec_version": spec["version"], "answers": {}, "drafts": {},
           "budget": Budget().model_dump(), "attachments": {}, "reviews": {}, "history": [],
           **({"form_variant": default_variant(ws, spec)} if spec.get("form_variants") else {})}
    applications[record["id"]] = app
    touch(ws, ["applications"], "Started application for " + record["title"])
    return app


def application(ws, rid):
    app = ws.get("applications", {}).get(rid)
    if app is None:
        raise KeyError("Application not found")
    return app


def mutate(app, expected):
    if app["revision"] != expected:
        raise RevisionConflict("This application changed. Reload before saving; your edits have not been overwritten.")
    app["revision"] += 1
    app["updated_at"] = now()


def dependency(ws, app, field):
    if field == "budget":
        return digest(app["budget"])
    if field == "specification":
        return app["spec_version"]
    if field.startswith("answer:"):
        return digest(app["answers"].get(field[7:], {}))
    fact = ws["facts"].get(field, {})
    return digest({k: fact.get(k) for k in ("value", "state")})


def dependencies(ws, app, fields):
    return {field: dependency(ws, app, field) for field in fields}


def stale_reasons(ws, app, entry):
    return [field for field, value in entry.get("dependencies", {}).items() if dependency(ws, app, field) != value]


def validate_evidence(ws, refs):
    if len(refs) > 30:
        raise ValueError("Attach at most 30 evidence passages per answer")
    result = []
    for ref in refs:
        doc = next((d for d in ws["documents"] if d["id"] == ref.get("document_id") and d["status"] == "parsed"), None)
        block = next((b for b in doc["blocks"] if b["id"] == ref.get("block_id")), None) if doc else None
        quote = ref.get("quote", "")
        if not block or not quote.strip() or quote not in block["text"]:
            raise ValueError("Answer evidence must quote a readable workspace document exactly")
        result.append({"document_id": doc["id"], "block_id": block["id"], "filename": doc["filename"],
                       "quote": quote, "locator": block["locator"]})
    return result


def save_answer(ws, app, spec, qid, text, fact_paths, refs, save_to_profile=False):
    question = next((q for q in questions(spec) if q["id"] == qid), None)
    if question is None:
        raise ValueError("That question is no longer in this application's specification")
    if any(p not in ws["facts"] for p in fact_paths):
        raise ValueError("Choose existing company or project facts")
    proof = validate_evidence(ws, refs)
    old = app["answers"].get(qid)
    if old:
        app["history"].append({"kind": "answer", "id": qid, "previous": old, "at": now()})
    text = validate_answer(question, text)
    if save_to_profile:
        path = profile_field(question)
        if not path or not text:
            raise ValueError("Only a business or project detail can be saved to your reusable profile")
        correct_fact(ws, path, text, "Saved from a grant application by the founder")
        touch(ws, [path], "Saved a reusable detail from a grant application")
        if path == "project.description":
            ws.setdefault("discovery_intake", {})["description_authoritative"] = True
        fact_paths = list(dict.fromkeys([*fact_paths, path]))
    fields = ["specification"] + fact_paths
    if re.search(r"(?i)budget|cost|financ|begrot|kosten", question["heading"]):
        fields.append("budget")
    app["answers"][qid] = {"text": text, "evidence": proof, "at": now(),
        "dependencies": dependencies(ws, app, fields), "author": "founder"}


# "Kleine ondernemingen: maximaal 45%" / "Small enterprises: up to 45%": a funding rate per company size.
SIZE_TIER = re.compile(r"(?i)^(kleine en middelgrote|kleine|middelgrote|grote|small and medium(?:-sized)?|small|medium(?:-sized)?|large)\s+"
                       r"(?:ondernemingen|onderneming|bedrijven|enterprises|companies|firms)\s*:?\s*(?:krijgen\s+)?(?:maximaal|max\.?|tot|up to|at most)?\s*"
                       r"(\d+(?:[.,]\d+)?)\s*%")
SIZE_WORDS = {"kleine": {"small"}, "small": {"small"}, "middelgrote": {"medium"}, "medium": {"medium"}, "medium-sized": {"medium"},
              "grote": {"large"}, "large": {"large"}}


def size_tiers(spec):
    """Funding rates that depend on company size, and whether they apply with or without a collaboration (from their heading)."""
    tiers = []
    for obs in spec.get("financial_observations", []):
        match = SIZE_TIER.match(obs["text"].strip())
        if not match:
            continue
        words = match[1].casefold()
        sizes = {"small", "medium"} if " en " in words or " and " in words else SIZE_WORDS[words.split()[0]]
        heading = (obs.get("evidence") or {}).get("locator", "").casefold()
        together = True if re.search(r"\bmet samenwerking|\bwith (?:a )?collaboration|\bin (?:a )?collaboration", heading) else (
            False if re.search(r"\bzonder samenwerking|\bwithout (?:a )?collaboration", heading) else None)
        tiers.append({"sizes": sorted(sizes), "collaboration": together, "rate_percent": match[2].replace(",", "."), "evidence": obs["evidence"]})
    return tiers


def company_size(ws):
    """small / medium / large by number of employees (EU thresholds 50 and 250); None when the profile does not say."""
    fte = fact_value(ws, "company.fte")
    if fte is None:
        return None
    return "small" if float(fte) < 50 else "medium" if float(fte) < 250 else "large"


def financial_method(spec, ws):
    """Only use unqualified project grant rates/caps, or a rate per company size; complex methods stay unresolved."""
    tiers = size_tiers(spec)
    if len(tiers) >= 2:
        together = int(fact_value(ws, "project.organisation_count") or 1) >= 2
        usable = [t for t in tiers if t["collaboration"] in (None, together)]
        size = company_size(ws)
        setting = "in a collaboration" if together else "without a collaboration"
        if size is None:
            listed = "; ".join(f"{' and '.join(t['sizes'])} companies {t['rate_percent']}%" for t in usable)
            return {"kind": "by_size", "rate_percent": None, "cap_cents": None, "evidence": [t["evidence"] for t in usable], "tiers": usable,
                    "message": f"The rate depends on company size ({setting}): {listed}. Add your number of employees to your profile to calculate it."}
        match = next((t for t in usable if size in t["sizes"]), None)
        if match:
            return {"kind": "percentage", "rate_percent": match["rate_percent"], "cap_cents": None, "evidence": [match["evidence"]], "tiers": usable,
                    "message": f"{match['rate_percent']}% of the project costs for a {size} company {setting}, based on your number of employees. "
                               "Check the official definition of company size if you are close to a threshold."}
    rates, caps, fixed, proof, unresolved = set(), set(), set(), [], []
    for obs in spec.get("financial_observations", []):
        text = obs["text"]
        if obs.get("scope") == "programme":
            continue
        if re.search(r"(?i)\bUSD\b|\bGBP\b|[£$]|\bor\b|\bSMEs?\b|large (?:enterprises|companies)|research organisations|per (?:partner|participant)", text) or len(re.findall(r"\d+(?:[.,]\d+)?\s*%", text)) > 1:
            unresolved.append(text)
            continue
        simple_fixed = re.search(r"(?i)(?:fixed grant|fixed lump.sum|vaste subsidie).{0,30}(?:EUR|€)", text)
        if simple_fixed and obs.get("scope") == "project" and obs.get("amount_cents") is not None and not re.search(r"(?i)\bif\b|unless|except|indien|tenzij|depending", text):
            fixed.add(obs["amount_cents"])
            proof.append(obs["evidence"])
            continue
        if re.search(r"(?i)unless|except|depending|indien|tenzij|\bif\b|\bper partner\b|lump.sum|forfait|indirect|overhead|deprecia|afschrij|VAT|btw", text):
            unresolved.append(text)
            continue
        if obs.get("rate_percent") and re.search(r"(?i)grant|funding rate|subsidie|funds?\s+\d|covers?\s+\d", text):
            rate = Decimal(obs["rate_percent"])
            if 0 <= rate <= 100:
                rates.add(rate)
                proof.append(obs["evidence"])
        if obs.get("amount_cents") is not None and (re.search(r"(?i)(?:maximum|maximaal|max\.?|up to).{0,25}(?:grant|subsidie)|(?:grant|subsidie).{0,25}(?:maximum|maximaal|max\.?)", text) or
                                                    re.search(r"(?i)(?:geen|niet)\s+(?:subsidie|meer subsidie)\s+(?:meer )?dan\s*(?:EUR|€)|subsidie bedraagt (?:ten hoogste|maximaal)\s*(?:EUR|€)|grant of (?:at most|up to)\s*(?:EUR|€)", text)):
            caps.add(obs["amount_cents"])
            proof.append(obs["evidence"])
    if len(fixed) == 1 and not rates and not caps and not unresolved and not spec.get("conflicts"):
        return {"kind": "fixed", "amount_cents": next(iter(fixed)), "rate_percent": None, "cap_cents": None,
                "evidence": proof, "message": "Sourced fixed grant per project; applicability and completion conditions require review."}
    if len(rates) != 1 or len(caps) > 1 or fixed or unresolved or spec.get("conflicts"):
        return {"kind": "unresolved", "rate_percent": None, "cap_cents": None, "evidence": proof,
                "message": "Funding method needs review. Costs and financing are calculated; no grant entitlement is inferred."}
    return {"kind": "percentage", "rate_percent": str(next(iter(rates))), "cap_cents": next(iter(caps)) if caps else None,
            "evidence": proof, "message": "Simple sourced percentage method. Eligible costs and applicability still require review."}


def calculate(app, spec, ws):
    budget = Budget.model_validate(app["budget"])
    method = financial_method(spec, ws)
    lines, partners, categories = [], {}, {}
    for row in budget.lines:
        amount = int((Decimal(row.quantity) * row.unit_cost_cents).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        if amount > 100_000_000_000:
            raise ValueError("A cost row exceeds the supported budget limit")
        eligible_row = row.eligibility_review == "eligible" if row.eligibility_review is not None else row.eligible
        line = {**row.model_dump(), "total_cents": amount, "eligible_cents": amount if eligible_row else 0}
        lines.append(line)
        for table, key in ((partners, row.partner), (categories, row.category)):
            table.setdefault(key, {"total_cents": 0, "eligible_cents": 0})
            table[key]["total_cents"] += amount
            table[key]["eligible_cents"] += line["eligible_cents"]
    total = sum(r["total_cents"] for r in lines)
    eligible = sum(r["eligible_cents"] for r in lines)
    maximum = None
    if method["kind"] == "percentage":
        maximum = int((Decimal(eligible) * Decimal(method["rate_percent"]) / 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        if method["cap_cents"] is not None:
            maximum = min(maximum, method["cap_cents"])
    elif method["kind"] == "fixed":
        maximum = method["amount_cents"]
    requested = budget.requested_grant_cents
    own = None if requested is None else max(0, total - requested)
    return {"lines": lines, "total_cents": total, "eligible_cents": eligible, "maximum_grant_cents": maximum,
            "requested_grant_cents": requested, "cofinancing_cents": own,
            "confirmed_financing_cents": budget.confirmed_financing_cents,
            "funding_gap_cents": None if own is None else max(0, own - budget.confirmed_financing_cents),
            "method": method, "partners": partners, "categories": categories, "currency": "EUR"}


def generate(ws, app, spec, section_ids=None):
    """Grounded basic writing reuses answers verbatim. Never replace a human edit."""
    valid = {q["id"]: q for q in questions(spec)}
    chosen = section_ids if section_ids is not None else list(valid)
    for qid in chosen:
        if qid not in valid:
            raise ValueError("Unknown application section")
        old = app["drafts"].get(qid)
        if old and old.get("user_edited"):
            continue
        answer = app["answers"].get(qid)
        paths = ["specification", "answer:" + qid]
        text = answer["text"] if answer and answer["text"] else "[Answer required: " + valid[qid]["heading"] + "]"
        if not answer and qid == "project-summary" and fact_value(ws, "project.description"):
            text = str(fact_value(ws, "project.description"))
            paths.append("project.description")
        if answer:
            paths += list(answer["dependencies"])
        if re.search(r"(?i)budget|cost|financ|begrot|kosten", valid[qid]["heading"]):
            paths.append("budget")
        app["drafts"][qid] = {"text": text, "user_edited": False, "at": now(),
                              "dependencies": dependencies(ws, app, paths)}


def findings(ws, app, spec, latest=None):
    issues, calc = [], calculate(app, spec, ws)

    def add(code, label, severity="warning", section_id=None, extra=None):
        issues.append({"id": code, "message": label, "severity": severity, "section_id": section_id, **(extra or {})})

    if latest and latest["version"] != app["spec_version"]:
        add("source-changed", "Official requirements changed. Review the new version before export.", "error")
    question_ids = {q["id"] for q in questions(spec)}
    if not structured(spec) and not any(q["origin"] == "official_template" for q in questions(spec)):
        add("official-question-list", "Check the complete official application form", "warning")
    # A grant's budget checks must use its own saved costs, not another
    # project's intake total or the worked-example budget in the profile.
    check_context = {**ws, "budget_lines": [], "discovery_intake": {
        **ws.get("discovery_intake", {}), "budget_cents": calc["total_cents"] if calc["lines"] else None}}
    from .focus_grants import focus_for_spec
    through_fund = (focus_for_spec(spec) or {}).get("route") == "via_fund"
    for check in evaluate_specification(spec, check_context):
        if check["id"] in question_ids or check["category"] not in {"eligibility", "financial", "reference"} or reference_fragment(check.get("text", check["label"])):
            continue
        if through_fund:
            continue  # The scheme's conditions are for the investment funds; the startup approaches a fund instead (see the route).
        if structured(spec) and (check.get("scope", "call") != "call" or check["category"] == "reference"):
            continue  # General programme rules are reference reading on the grant page, not checks.
        if structured(spec) and check["category"] == "financial" and not check.get("rule"):
            continue  # Funding notes inform the budget step; they are not yes/no conditions.
        if check["outcome"] not in {"PASS", "NOT_APPLICABLE"}:
            from .matching_depth import rule_leaves
            fields = [leaf["field"] for leaf in rule_leaves(check.get("rule"), check_context, check["evidence"])
                      if leaf["outcome"] not in {"PASS", "NOT_APPLICABLE"}]
            add("requirement-" + check["id"], check["label"], "error" if check["outcome"] in {"FAIL", "SOURCE_CONFLICT"} else "warning",
                extra={"outcome": check["outcome"], "evidence": check["evidence"], "text": check.get("text", check["label"]),
                       "section": check.get("section", ""), "explanation": check.get("explanation"),
                       "condition_question": check["outcome"] == "MANUAL_REVIEW" and check["category"] == "eligibility",
                       "profile_fields": [field for field in fields if field in ws["facts"]],
                       "target_area": "Budget" if "project_budget_cents" in fields else "Review",
                       "category": check["category"], "reference_members": check.get("members", []),
                       "reference_hash": check.get("content_hash")})
    for q in questions(spec):
        entry = document_answer(app, q["id"])
        if not entry or not entry["text"].strip() or "[Answer required:" in entry["text"]:
            if q.get("required") is not False:  # Optional parts of a form ("only if you also develop software") may stay empty.
                add("missing-" + q["id"], "Answer needed: " + q["heading"], "error", q["id"])
            continue
        changed = stale_reasons(ws, app, entry)
        # Source facts attached to an answer remain relevant even after a draft edit.
        answer = app["answers"].get(q["id"], {})
        changed += stale_reasons(ws, app, answer)
        if changed:
            add("stale-" + q["id"], "Review changed information: " + ", ".join(dict.fromkeys(changed)), "warning", q["id"])
        text = entry["text"]
        try:
            validate_answer(q, text)
        except ValueError as exc:
            add("invalid-answer-" + q["id"], str(exc), "error", q["id"])
        from .funding_conditions import AMOUNT_PATTERN, money_cents
        for phrase, key in [(r"total project (?:budget|costs)", "total_cents"), (r"requested grant", "requested_grant_cents")]:
            match = re.search(r"(?i)" + phrase + r"\s*(?:is|of|:|=)?\s*(?:EUR|€)\s*" + AMOUNT_PATTERN, text)
            if match and calc[key] is not None and money_cents(match[1]) != calc[key]:
                add("figure-" + key + "-" + q["id"], "A stated " + key.replace("_cents", "").replace("_", " ") + " differs from the saved budget", "error", q["id"])
        if q.get("max_words") and len(text.split()) > q["max_words"]:
            add("length-" + q["id"], f"{q['heading']} exceeds {q['max_words']} words", "error", q["id"])
        if q.get("max_characters") and len(text) > q["max_characters"]:
            add("characters-" + q["id"], f"{q['heading']} exceeds {q['max_characters']} characters", "error", q["id"])
        for ref in answer.get("evidence", []):
            try:
                validate_evidence(ws, [ref])
            except ValueError:
                add("evidence-" + q["id"], "An answer cites a removed or unreadable document", "error", q["id"])
    for item in evidence_tasks(spec):
        link = app["attachments"].get(item["id"])
        if item["kind"] == "step":
            continue  # Steps on the funder's website are a checklist for submission day, not a preparation error.
        if link and link.get("not_applicable") and evidence_complete(ws, item, link):
            continue
        if item["kind"] == "instruction":
            if item.get("required") is not False and not evidence_complete(ws, item, link):
                add("instruction-" + item["id"], item["title"], "warning")
            continue
        if link and link.get("document_id") and not linked_document(ws, item, link):
            add("attachment-" + item["id"], "A linked attachment was removed", "error")
        elif item.get("required") is not False and not evidence_complete(ws, item, link):
            add("attachment-" + item["id"], ("Document needed: " if structured(spec) else "Evidence needed: ") + item["title"], "warning" if item.get("required") is None else "error")
    needs_budget = budget_required(spec) or bool(calc["lines"])
    if needs_budget and not calc["lines"]:
        add("budget-empty", "Add the project budget", "error")
    if needs_budget and calc["method"]["kind"] == "unresolved":
        add("financial-method", "Check in the official rules how the funding amount is calculated" if structured(spec) else calc["method"]["message"])
    if needs_budget and calc["method"]["kind"] == "by_size":
        add("financial-size", calc["method"]["message"], "warning", extra={"profile_fields": ["company.fte"], "target_area": "Review"})
    if needs_budget and calc["requested_grant_cents"] is None:
        add("requested-grant", "Enter the requested grant amount", "error")
    elif calc["requested_grant_cents"] is not None and calc["requested_grant_cents"] > calc["total_cents"]:
        add("grant-over-total", "Requested grant exceeds total project costs", "error")
    elif calc["requested_grant_cents"] is not None and calc["maximum_grant_cents"] is not None and calc["requested_grant_cents"] > calc["maximum_grant_cents"]:
        add("grant-over-maximum", "Requested grant exceeds the sourced percentage or cap", "error")
    if calc["funding_gap_cents"]:
        add("funding-gap", "Confirmed financing does not yet cover the co-financing requirement", "error")
    if any(row.get("eligibility_review") == "needs_review" or row.get("eligibility_review") is None and not row["eligible"] for row in calc["lines"]):
        add("cost-review", "Review which costs are eligible for this grant")
    start_date, end_date = fact_value(ws, "project.start_date"), fact_value(ws, "project.end_date")
    if start_date and end_date and end_date < start_date:
        add("project-dates", "Project end date precedes its start date", "error")
    for path, fact in ws["facts"].items():
        if fact["state"] == "conflict":
            add("conflict-" + path, "Resolve conflicting information: " + path)
    for issue in issues:
        section = issue.get("section_id")
        fingerprint = digest({"issue": {k: issue.get(k) for k in ("message", "outcome", "evidence")},
            "section": app["drafts"].get(section) or app["answers"].get(section),
            "finances": calc if any(word in issue["id"] for word in ("budget", "grant", "funding", "cost", "figure", "financial")) else None,
            "source_version": latest["version"] if latest else spec["version"], "reference_hash": issue.get("reference_hash")})
        review = app["reviews"].get(issue["id"])
        issue["fingerprint"] = fingerprint
        issue["review"] = review if review and review["fingerprint"] == fingerprint else None
        if issue.get("condition_question") and issue["review"] and issue["review"].get("answer") == "no":
            issue["severity"] = "error"  # The applicant says this condition is not met.
    return issues


def budget_required(spec):
    from .focus_grants import focus_for_spec
    if (focus_for_spec(spec) or {}).get("cost_table") is False:
        return False  # The funder asks for no cost table (WBSO is estimated from hours and wages instead).
    return bool(spec.get("financial_observations")) or any(
        re.search(r"(?i)budget|cost|financ|begrot|kosten", q["heading"]) for q in questions(spec)) or any(
        r.get("rule") and "project_budget_cents" in json.dumps(r["rule"]) for r in spec.get("requirements", []))


def default_variant(ws, spec):
    """The checked form a new application starts with: the software form when the profile says the project is software only."""
    variants = spec.get("form_variants") or {}
    if not variants:
        return None
    if fact_value(ws, "project.is_software_only") is True and "wbso-software" in variants:
        return "wbso-software"
    return next(iter(variants))


def with_variant(spec, app):
    """The specification as this application sees it, with the checked form the founder chose (WBSO: product or software).

    The grant has one specification; the choice only swaps which form's questions and fillable PDF the application uses.
    Answers are stored per question, so switching back restores what was written for the other form.
    """
    variants = spec.get("form_variants") or {}
    choice = app.get("form_variant")
    if choice is None or not variants:
        return spec
    if choice not in variants:
        raise ValueError(f"This application uses a form ({choice}) that the current requirements no longer offer")
    variant = variants[choice]
    variant_ids = {section["id"] for v in variants.values() for section in v["sections"]}
    variant_urls = {v["url"] for v in variants.values()}
    return {**spec, "application_sections": [s for s in spec["application_sections"] if s["id"] not in variant_ids] + variant["sections"],
            "templates": [t for t in spec.get("templates", []) if t["url"] not in variant_urls] + [
                {"url": variant["url"], "title": variant["title"], "format": "pdf", "sha256": variant["sha256"], "tables": [], "mapped": True}]}


def view(ws, app, spec, latest=None):
    result = deepcopy(app)
    for kind in ("answers", "drafts"):
        for entry in result[kind].values():
            entry["stale_reasons"] = stale_reasons(ws, app, entry)
    result.pop("history", None)
    issues = findings(ws, app, spec, latest)
    tasks = [{**task, "complete": evidence_complete(ws, task, app["attachments"].get(task["id"]))} for task in evidence_tasks(spec)]
    for task in tasks:
        tracked = app.get("checklist", {}).get(task["id"], {})
        task["checked"] = tracked["checked"] if tracked.get("fingerprint") == task["fingerprint"] else task["complete"]
    def area(issue):
        if issue.get("target_area"):
            return issue["target_area"]
        if issue["id"].startswith(("attachment-", "instruction-")):
            return "Evidence"
        if issue.get("section_id"):
            return "Answers"
        if issue["id"] in {"budget-empty", "financial-method", "requested-grant", "grant-over-total", "grant-over-maximum", "funding-gap", "cost-review"}:
            return "Budget"
        return "Review"
    for issue in issues:
        issue["area"] = area(issue)
        review = issue["review"] or {}
        resolved = review.get("answer") in {"yes", "na"} if issue.get("condition_question") else bool(review.get("acknowledged"))
        issue["needs_action"] = issue["severity"] == "error" or issue.get("outcome") in {"UNKNOWN", "CONFLICT", "FAIL", "SOURCE_CONFLICT"} or not resolved
        issue["profile_fields"] = issue.get("profile_fields", []) or ([issue["id"][9:]] if issue["id"].startswith("conflict-") else
            ["project.start_date", "project.end_date"] if issue["id"] == "project-dates" else [])
    form_questions = questions(spec)
    for question in form_questions:
        saved_text = app["answers"].get(question["id"], {}).get("text", "")
        try:
            validate_answer(question, saved_text)
        except ValueError:
            # Old free-text answers stay visible even if the source now selects
            # a typed control that cannot display their previous wording.
            kind = question["control"]["type"]
            question["control"] = {"type": "textarea", "hint": "Review this saved text and enter " +
                ("a date as YYYY-MM-DD." if kind == "date" else "a valid number." if kind == "number" else "one of the requested options.")}
    def clear(section):
        return not any(issue["needs_action"] and issue["area"] == section for issue in issues)
    statuses = {
        "Answers": all(bool(app["answers"].get(q["id"], {}).get("text", "").strip()) for q in questions(spec) if q.get("required") is not False) and clear("Answers"),
        "Budget": (bool(app["budget"]["lines"]) or not budget_required(spec)) and clear("Budget"),
        "Evidence": all(task["checked"] or task.get("required") is False for task in tasks if task["kind"] != "step"),
        "Review": not any(issue["needs_action"] for issue in issues),
    }
    from .application_suggestions import suggestions, budget_suggestion, document_suggestions
    from .model_adapter import configured
    return {**result, "questions": [{**q, "suggestions": suggestions(ws, q)} for q in form_questions],
            "ai_available": configured(),
            "budget_required": budget_required(spec),
            "budget_suggestion": budget_suggestion(ws), "document_suggestions": document_suggestions(ws, tasks),
            "reference_documents": spec.get("reference_documents") if structured(spec) else [item for item in spec.get("attachments", []) if source_scope(spec, item) in {"annex", "guidance"} or later_stage((item.get("evidence") or {}).get("quote", ""))],
            "assessment_criteria": [c for c in spec.get("assessment_criteria", []) if not re.search(r"(?i)\b(?:described|set out) in\b", c["criterion"])][:12],
            "funding_notes": [o for o in spec.get("financial_observations", []) if o.get("scope") != "programme"][:10],
            "uses_official_form": any(q["origin"] == "official_template" for q in form_questions),
            # A hand-checked PDF form (official_forms.py) that official_template fills field by field.
            "fills_checked_form": any(q.get("checked_form") for q in form_questions),
            "form_variants": [{"key": key, "label": v["label"], "explanation": v["explanation"], "title": v["title"]}
                              for key, v in (spec.get("form_variants") or {}).items()],
            "form_variant": app.get("form_variant"),
            **application_route(ws, app, spec, form_questions),
            "attachments_required": spec.get("attachments", []),
            "evidence_tasks": tasks, "section_status": {name: "complete" if complete else "needs_attention" for name, complete in statuses.items()},
            "calculation": calculate(app, spec, ws), "findings": issues,
            "specification_changed": bool(latest and latest["version"] != app["spec_version"]),
            "latest_spec_version": latest["version"] if latest else app["spec_version"],
            "sources": spec.get("sources", []), "templates": spec.get("templates", []),
            "progress": {"answered": sum(bool(app["answers"].get(q["id"], {}).get("text")) for q in questions(spec)),
                         "total": len(questions(spec)), "errors": sum(i["severity"] == "error" for i in issues)}}


def application_route(ws, app, spec, form_questions):
    """How this application is submitted, and a copy sheet for the funder's online form."""
    from .focus_grants import focus_for_spec, route_for, portal_sheet, verified_on
    entry = focus_for_spec(spec)
    provider = spec.get("provider") or str(spec.get("opportunity_id", "")).split("-")[0]
    focus = {k: entry.get(k) for k in ("key", "title", "summary", "amount", "window", "audience", "documents", "verify", "sources", "partners_required", "cost_table")} if entry else None
    if focus:
        focus["verified_on"] = verified_on(entry)
    return {"route": route_for(entry, provider), "focus": focus,
            "portal_sheet": portal_sheet(ws, app, spec, form_questions, calculate(app, spec, ws))}


def money(cents):
    return "Unknown" if cents is None else f"EUR {Decimal(cents) / 100:,.2f}"


def docx_bytes(ws, app, spec, latest=None):
    doc = Document()
    doc.add_heading(app["title"], 0)
    doc.add_paragraph("Application preparation draft · " + now())
    doc.add_paragraph(app["url"])
    doc.add_paragraph("Requirement version: " + app["spec_version"])
    doc.add_paragraph("Check the official form before submission. This document retains unresolved review items.")
    for q in questions(spec):
        doc.add_heading(q["heading"], 1)
        entry = document_answer(app, q["id"])
        doc.add_paragraph(entry["text"] if entry else "[Answer required]")
        if q.get("evidence"):
            doc.add_paragraph("Instruction source: " + q["evidence"].get("url", ""))
    calc = calculate(app, spec, ws)
    doc.add_heading("Project budget", 1)
    table = doc.add_table(rows=1, cols=4)
    for cell, text in zip(table.rows[0].cells, ["Cost", "Partner", "Total", "Eligible"]):
        cell.text = text
    for row in calc["lines"]:
        for cell, text in zip(table.add_row().cells, [row["description"], row["partner"], money(row["total_cents"]), money(row["eligible_cents"])]):
            cell.text = text
    for label, key in [("Total project costs", "total_cents"), ("Eligible costs", "eligible_cents"),
                       ("Calculated grant ceiling", "maximum_grant_cents"), ("Requested grant", "requested_grant_cents"),
                       ("Co-financing", "cofinancing_cents"), ("Funding gap", "funding_gap_cents")]:
        doc.add_paragraph(label + ": " + money(calc[key]))
    doc.add_heading("Review findings", 1)
    for issue in findings(ws, app, spec, latest):
        doc.add_paragraph(issue["severity"].upper() + ": " + issue["message"] +
                          (" · Reviewer note: " + issue["review"]["note"] if issue["review"] else ""))
    out = BytesIO()
    doc.save(out)
    # Reopen returned bytes before exposing them as a valid DOCX.
    Document(BytesIO(out.getvalue()))
    return out.getvalue()


def official_template(app, spec, documents, ws):
    """Fill the official form: a hand-checked PDF by its fields, or verified DOCX paragraph/empty table anchors."""
    checked = [q for q in questions(spec) if q.get("checked_form")]
    if checked:
        from .official_forms import FORMS, fill, section_id
        url = checked[0]["template_url"]
        form = next(f for f in FORMS.values() if f["url"] == url)
        template = next((t for t in spec.get("templates", []) if t["url"] == url), None)
        if template is None:
            raise ValueError("The official form was not retrieved with this grant's documents. Use the preparation package.")
        answers = {question["key"]: (document_answer(app, section_id(form, question)) or {}).get("text", "") for question in form["questions"]}
        return fill(form, documents.bytes_for(template["url"], template["sha256"]), answers, ws)
    candidates = [t for t in spec.get("templates", []) if t["format"] == "docx"]
    if len(candidates) != 1:
        raise ValueError("A single mapped DOCX template is required. Use the preparation package and official form links.")
    template = candidates[0]
    doc = Document(BytesIO(documents.bytes_for(template["url"], template["sha256"])))
    paragraphs = list(doc.paragraphs)
    mapped = []
    normal = lambda value: " ".join(value.split())
    for q in questions(spec):
        proof = q.get("evidence") or {}
        if q["origin"] != "official_template" or proof.get("url") != template["url"]:
            raise ValueError("Some questions do not map to this official form. Use the preparation package.")
        entry = document_answer(app, q["id"])
        if not entry or not entry["text"].strip() or "[Answer required:" in entry["text"]:
            raise ValueError("Complete every mapped answer before exporting the official form.")
        locator = proof.get("locator", "")
        paragraph = re.fullmatch(r"DOCX paragraph (\d+)", locator)
        cell = re.fullmatch(r"DOCX table (\d+), row (\d+), cell 1", locator)
        if paragraph:
            index = int(paragraph[1]) - 1
            if index >= len(paragraphs) or normal(paragraphs[index].text) != normal(q["heading"]):
                raise ValueError("The template paragraph no longer matches its retained instruction")
            from docx.oxml import OxmlElement
            from docx.text.paragraph import Paragraph
            element = OxmlElement("w:p")
            paragraphs[index]._p.addnext(element)
            Paragraph(element, paragraphs[index]._parent).add_run(entry["text"])
        elif cell:
            table_index, row_index = int(cell[1]) - 1, int(cell[2]) - 1
            try:
                cells = doc.tables[table_index].rows[row_index].cells
                if len(cells) != 2 or cells[0]._tc is cells[1]._tc or normal(cells[0].text) != normal(q["heading"]):
                    raise ValueError("Unsupported template table layout")
                if cells[1].text.strip() and not re.fullmatch(r"[\s.\[\]_…-]*|(?i:answer|antwoord|enter text|click here.*)", cells[1].text.strip()):
                    raise ValueError("The template answer cell contains instructions that require manual mapping")
                cells[1].text = entry["text"]
            except IndexError:
                raise ValueError("The template table no longer matches its retained instruction") from None
        else:
            raise ValueError("This template uses a layout that needs manual mapping. Use the preparation package.")
        mapped.append(entry["text"])
    out = BytesIO()
    doc.save(out)
    verified = Document(BytesIO(out.getvalue()))
    all_text = "\n".join([p.text for p in verified.paragraphs] + [c.text for t in verified.tables for r in t.rows for c in r.cells])
    if any(value not in all_text for value in mapped):
        raise ValueError("Official form validation failed: an answer is missing")
    return out.getvalue()


def package(ws, app, spec, latest, store, documents=None):
    output, text = BytesIO(), StringIO(newline="")
    writer = csv.writer(text)
    writer.writerow(["Cost", "Category", "Partner", "Quantity", "Unit cost cents", "Total cents", "Eligible cents", "Currency"])
    calc = calculate(app, spec, ws)
    for row in calc["lines"]:
        # Escape spreadsheet formula injection in founder-supplied labels.
        safe = lambda value: "'" + value if isinstance(value, str) and (value.lstrip().startswith(("=", "+", "-", "@")) or value.startswith(("\t", "\r"))) else value
        writer.writerow([safe(row["description"]), safe(row["category"]), safe(row["partner"]), row["quantity"], row["unit_cost_cents"], row["total_cents"], row["eligible_cents"], "EUR"])
    writer.writerow(["TOTAL", "", "", "", "", calc["total_cents"], calc["eligible_cents"], "EUR"])
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        archive.writestr("application.docx", docx_bytes(ws, app, spec, latest))
        archive.writestr("budget.csv", text.getvalue())
        archive.writestr("review.json", json.dumps(view(ws, app, spec, latest), ensure_ascii=False, indent=2))
        archive.writestr("requirements.json", json.dumps(spec, ensure_ascii=False, indent=2))
        archive.writestr("README.txt", "Preparation package. Review all unresolved findings and transfer answers into the official form.\n" + app["url"])
        if documents is not None:
            try:
                filled = official_template(app, spec, documents, ws)
                archive.writestr("official-form-filled.pdf" if filled.startswith(b"%PDF") else "official-form-draft.docx", filled)
            except (ValueError, KeyError) as exc:
                archive.writestr("template-mapping.txt", str(exc))
        for task in evidence_tasks(spec):
            if task["kind"] != "document":
                continue
            key = task["id"]
            doc = linked_document(ws, task, app["attachments"].get(key))
            if doc and (store.root / "uploads" / doc["storage_name"]).is_file():
                # Original filenames are display metadata; never archive paths.
                from pathlib import Path
                archive.write(store.root / "uploads" / doc["storage_name"], "attachments/" + key + Path(doc["filename"]).suffix)
    return output.getvalue()
