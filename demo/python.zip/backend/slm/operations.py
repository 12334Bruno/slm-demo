"""Private recovery credentials, deletion and consistent SQLite/upload backups."""
import hashlib
from contextlib import closing
import json
from pathlib import Path
import secrets
from typing import Literal
import sqlite3
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZIP_DEFLATED

from fastapi import HTTPException
from fastapi.responses import JSONResponse
from pydantic import Field
from .config import now
from .domain import Strict
from .hosted_access import current_owner, hosted


class Recovery(Strict):
    code: str = Field(min_length=40, max_length=100)


class PurgeRequest(Strict):
    confirm: Literal["DELETE ALL COMPANY DATA"]


def delete_workspace_data(store, analysis, discovery, wid):
    """Remove one company completely: its saved state, analysis tasks, matches, saved grants and uploaded files."""
    ws = store.load(wid)
    # Cancel outstanding results before deleting state; late workers cannot recreate it.
    analysis.reset(wid)
    discovery.db.reset_workspace(wid)
    with store.connect() as conn:
        from .hosted_access import require_owner
        conn.execute("BEGIN IMMEDIATE")
        require_owner(conn, wid)
        conn.execute("DELETE FROM workspaces WHERE id=?", (wid,))
        conn.execute("DELETE FROM workspace_owners WHERE workspace_id=?", (wid,))
        conn.execute("DELETE FROM grant_specification_seen WHERE workspace_id=?", (wid,))
        from .test_sessions import delete_for_workspace
        delete_for_workspace(conn, wid)
    for doc in ws["documents"]:
        (store.root / "uploads" / doc["storage_name"]).unlink(missing_ok=True)


def cookie(response, secret):
    import os
    response.set_cookie("slm_visitor", secret, httponly=True, samesite="lax",
                        secure=os.getenv("SLM_COOKIE_SECURE", "1") == "1", max_age=60 * 60 * 24 * 30)


def register(app, store, analysis, discovery):
    with store.connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS recovery_codes (owner TEXT PRIMARY KEY, code_hash TEXT UNIQUE NOT NULL)")

    @app.post("/api/session/recovery-code")
    def create_recovery():
        if not hosted() or not current_owner.get():
            raise ValueError("Recovery codes are used on the hosted application")
        code = secrets.token_urlsafe(32)
        with store.connect() as conn:
            conn.execute("INSERT INTO recovery_codes VALUES (?, ?) ON CONFLICT(owner) DO UPDATE SET code_hash=excluded.code_hash",
                         (current_owner.get(), hashlib.sha256(code.encode()).hexdigest()))
        return {"code": code, "message": "Keep this private. It restores access to your saved projects; replacing it invalidates the old code."}

    @app.post("/api/session/restore")
    def restore(body: Recovery):
        if not hosted():
            raise ValueError("Recovery is used on the hosted application")
        token = secrets.token_urlsafe(32)
        new_owner = hashlib.sha256(token.encode()).hexdigest()
        with store.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            previous = conn.execute("SELECT owner FROM recovery_codes WHERE code_hash=?", (hashlib.sha256(body.code.encode()).hexdigest(),)).fetchone()
            if previous is None:
                raise HTTPException(403, "Recovery code was not recognised")
            # Retain projects created in this browser before recovery as well.
            if current_owner.get() != previous[0]:
                conn.execute("UPDATE workspace_owners SET owner=? WHERE owner=?", (new_owner, current_owner.get()))
                conn.execute("DELETE FROM recovery_codes WHERE owner=?", (current_owner.get(),))
            conn.execute("UPDATE workspace_owners SET owner=? WHERE owner=?", (new_owner, previous[0]))
            conn.execute("UPDATE recovery_codes SET owner=? WHERE owner=?", (new_owner, previous[0]))
        response = JSONResponse({"restored": True})
        cookie(response, token)
        return response

    @app.delete("/api/workspaces/{wid}")
    def delete_workspace(wid: str):
        delete_workspace_data(store, analysis, discovery, wid)
        return {"deleted": True}

    @app.post("/api/workspaces/purge")
    def purge_all(body: PurgeRequest):
        """Delete every company on this laptop, including uploaded files. The grant catalogue is kept."""
        if hosted():
            raise HTTPException(403, "Deleting all company data is only possible in the local app.")
        ids = [item["id"] for item in store.list()]
        for wid in ids:
            delete_workspace_data(store, analysis, discovery, wid)
        # Files left behind by interrupted uploads belong to no company but may still hold company text.
        for path in (store.root / "uploads").iterdir():
            if path.is_file():
                path.unlink()
        return {"deleted": len(ids)}

    @app.delete("/api/workspaces/{wid}/documents/{did}")
    def delete_document(wid: str, did: str):
        from .storage import touch
        with store.edit(wid) as ws:
            doc = next((d for d in ws["documents"] if d["id"] == did), None)
            if doc is None:
                raise KeyError("Document not found")
            ws["documents"].remove(doc)
            # Preserve founder corrections, but withdraw unconfirmed proposals whose evidence disappeared.
            for fact in ws["facts"].values():
                if fact["state"] == "confirmed":
                    continue
                fact["evidence"] = [r for r in fact["evidence"] if r.get("document_id") != did]
                fact["candidates"] = [c for c in fact["candidates"] if not any(r.get("document_id") == did for r in c.get("evidence", []))]
                if not fact["evidence"]:
                    fact.update(value=None, state="missing", candidates=[])
            touch(ws, ["*"], "Removed a source document; dependent outputs require review")
        (store.root / "uploads" / doc["storage_name"]).unlink(missing_ok=True)
        return {"deleted": True}


def backup(store, destination):
    """Snapshot SQLite and uploads while writers are blocked; no .env or keys."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix="slm-backup-") as directory:
        state = Path(directory) / "slm.sqlite3"
        with store.connect() as guard:
            guard.execute("BEGIN IMMEDIATE")
            # Backup through a second read connection; backing up a write transaction deadlocks.
            # SQLite's transaction context manager does not close its file handle.
            # Close explicitly before the temporary directory is removed on Windows.
            with closing(store.connect()) as source, closing(sqlite3.connect(state)) as target:
                source.backup(target)
            with ZipFile(destination, "w", ZIP_DEFLATED) as archive:
                archive.write(state, "slm.sqlite3")
                for path in sorted((store.root / "uploads").iterdir()):
                    if path.is_file() and not path.is_symlink():
                        archive.write(path, "uploads/" + path.name)
                archive.writestr("manifest.json", json.dumps({"format": "slm-backup-v1", "at": now()}))
    destination.chmod(0o600)
    return destination


def restore_backup(archive_path, destination):
    """Restore only into an empty directory; never overwrite a running database."""
    destination = Path(destination)
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("Restore destination must be empty. Stop the server and preserve its data first.")
    with ZipFile(archive_path) as archive:
        if json.loads(archive.read("manifest.json"))["format"] != "slm-backup-v1":
            raise ValueError("Unsupported backup format")
        allowed = [i for i in archive.infolist() if i.filename == "slm.sqlite3" or
                   i.filename.startswith("uploads/") and len(Path(i.filename).parts) == 2 and ".." not in Path(i.filename).parts]
        if len(allowed) != len(archive.infolist()) - 1 or sum(i.file_size for i in allowed) > 5_000_000_000:
            raise ValueError("Backup contains unexpected files or exceeds the restore limit")
        destination.mkdir(parents=True, exist_ok=True)
        archive.extractall(destination, members=[i.filename for i in allowed])
    with closing(sqlite3.connect(destination / "slm.sqlite3")) as conn:
        if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("Restored database integrity check failed")
    return destination
