"""Laptop-wide choice whether company text may be sent to a cloud AI provider.

Stored in ``<data dir>/settings.json`` so it survives restarts. Until the operator
chooses, the server configuration decides (``SLM_AI_ENABLED`` and an API key).
Every model entry point checks ``cloud_ai_allowed()`` before sending anything.
"""
import json
import os
from pydantic import BaseModel, ConfigDict
from .config import data_dir


class Settings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    cloud_ai: bool


def settings_path():
    return data_dir() / "settings.json"


def cloud_ai_allowed() -> bool:
    path = settings_path()
    if not path.exists():
        return True
    return Settings.model_validate_json(path.read_text(encoding="utf-8")).cloud_ai


def set_cloud_ai(allowed: bool) -> None:
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(Settings(cloud_ai=allowed).model_dump()), encoding="utf-8")
    os.replace(temporary, path)
