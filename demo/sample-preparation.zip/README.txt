Preparation package. Review all unresolved findings and transfer answers into the official form.
https://www.rvo.nl/subsidies-financiering/visual-paginated-application